#!/usr/bin/env perl

use File::Path qw (rmtree);

rmtree ("treedir") or die "Could not remove treedir: $!";

mkdir ("treedir");
    
system ("../list2pkg","--treedir=treedir","--verbose","filelist",
	"test-0.1-i386-2sev.tgz");

exit $?
