#!/bin/bash
### Change the version string in list2pkg . Argument: project_root , script_from
#, script_to

# Copyright (C) 2008 Sebastien Vasey

# This file is part of list2pkg

# list2pkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# list2pkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with list2pkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 project_root script_from script_to" 1>&2
}

PROJECT_ROOT="$1"
SCRIPT_FROM="$2"
SCRIPT_TO="$3"

if [ $# -ne 3 ]; then
    usage
    exit 1
fi


VERSION="$(${PROJECT_ROOT}/helpers/version.sh $PROJECT_ROOT)"

sed "s@my \$VERSION = .*@my \$VERSION = \"$VERSION\";@" \
    $SCRIPT_FROM > $SCRIPT_TO

exit 0
