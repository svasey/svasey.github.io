#!/bin/sh

### Install list2pkg and its documentation.

# Author: Sebastien Vasey (http://svasey.org/)

# Feel free to edit those variables

if [ ! $PREFIX ]; then
    PREFIX=/usr/local
fi
if [ ! $SYSCONFDIR ]; then
    SYSCONFDIR=${PREFIX}/etc
fi
if [ ! $DOCDIR ]; then
    DOCDIR=${PREFIX}/share/doc
fi
if [ ! $MANDIR ]; then
    MANDIR=${PREFIX}/share/man
fi

VERSION="$(./helpers/version.sh $PWD)"
DOCPATH="${DOCDIR}/list2pkg-${VERSION}"
echo "Installing programs"

install -v -m0755 list2pkg ${PREFIX}/bin/list2pkg.cpy || exit 1
install -v -m0644 list2pkg.conf ${SYSCONFDIR}/list2pkg.conf || exit 1

# Change version string and various paths
./helpers/change-scriptver.sh $PWD ./list2pkg ${PREFIX}/bin/list2pkg.cpy \
    || exit 1
sed s@./././list2pkg.conf@${SYSCONFDIR}/list2pkg.conf@ \
    ${PREFIX}/bin/list2pkg.cpy > ${PREFIX}/bin/list2pkg || exit 1

chmod 755 ${PREFIX}/bin/list2pkg
rm ${PREFIX}/bin/list2pkg.cpy

install -d -m 0755 $DOCPATH || exit 1

txt_files=$(ls ./{README,TODO,INSTALL,FAQ,BUGS,COPYING,NEWS} \
    2>/dev/null || true)
man_files=$(ls doc/man/* 2>/dev/null || true)
html_files=$(ls doc/html/* 2>/dev/null || true)

echo "Installing html documentation files..."
install -v -m0644 $txt_files $html_files $DOCPATH || exit 1

echo "Installing manpages"

for f in $man_files ; do
    EXT="$(echo $f | sed -r 's/.+\.//')"
    DEST="${MANDIR}/man${EXT}"
    
    install -v -m0644 $f $DEST || exit 1
done

echo "Documentation installed"

exit 0