#!/bin/bash
### Change the version string in list2pkg . Argument: project_root , script_from
#, script_to

# Author: Sebastien Vasey (http://svasey.org/)

set -o errexit

usage ()
{
    echo "usage: $0 project_root script_from script_to" 1>&2
}

PROJECT_ROOT="$1"
SCRIPT_FROM="$2"
SCRIPT_TO="$3"

if [ $# -ne 3 ]; then
    usage
    exit 1
fi


VERSION="$(${PROJECT_ROOT}/helpers/version.sh $PROJECT_ROOT)"

sed "s@my \$VERSION = .*@my \$VERSION = \"$VERSION\";@" \
    $SCRIPT_FROM > $SCRIPT_TO

exit 0
