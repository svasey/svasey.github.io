#!/bin/bash

# Author: Sebastien Vasey (http://svasey.org/)

### Create a slackware package of list2pkg, assuming it has been installed on
### the system using urpkg. First argument argument: package name. If
### unspecified, will guess.

set -o errexit

usage ()
{
    echo "usage: $0 [pkgname]" 1>&2
}

if [ $# -eq 0 ]; then
    LONGNAME="$(urpkg --list --quiet | grep -E ^list2pkg)"
    VERSION=$(echo $LONGNAME | sed -r 's/list2pkg-(.+)/\1/' | tr '-' '_')
    BASENAME=$(echo $LONGNAME | sed -r 's/([^-]+)-.+/\1/')
    ARCH="$(uname --machine | tr - _)"
    BUILD="1"
    BUILDER="sev"
    PKGNAME="${BASENAME}-${VERSION}-${ARCH}-${BUILD}${BUILDER}.tgz"
elif [ $# -eq 1 ]; then
    PKGNAME="$1"
else
    usage
    exit 1
fi

VERSION=$(echo $PKGNAME | sed -r 's/[^-]+-([^-]+).+/\1/')

DESC="$(mktemp -t slack-desc.XXXXXX)"

(echo "       |-----handy-ruler------------------------------------------------------|"
echo "list2pkg: list2pkg $VERSION (create Slackware packages from a file list)"
echo "list2pkg: "
echo "list2pkg: List2pkg is a program to create Slackware packages in a simple way. " 
echo "list2pkg: more precisely, given a list of files, it will create a slackware " 
echo "list2pkg: package containing these files. A user trying to install that "
echo "list2pkg: package will see the same files installed at the same locations "
echo "list2pkg: they were on your system. "
echo "list2pkg: "
echo "list2pkg: Package created by Sebastien Vasey, using list2pkg"
echo "list2pkg: Contact: sebastien dot vasey at gmail dot com"
echo "list2pkg: For more information on list2pkg: http://www.svasey.org/list2pkg"
) > $DESC

urpkg --list --quiet list2pkg | list2pkg --slack-desc=$DESC $PKGNAME

rm -v $DESC

exit 0
