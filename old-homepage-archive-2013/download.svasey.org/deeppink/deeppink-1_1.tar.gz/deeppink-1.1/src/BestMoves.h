// Class containing a certain number (defined via a constructor argument.
// of best moves of the current position, and their respective heuristic.

/*
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#ifndef INCLUDE_BESTMOVES_H
#define INCLUDE_BESTMOVES_H

#include <iostream> 		// Testing only

#include <vector>
using std::vector;

#include "Coor.h"

class Square;

class BestMoves {
 private:
    vector<Coor> best_move; // Give the best moves, best_move[0] is the
				  // stronger move.


    vector<int> best_heuristic;	// Give the matching heuristic for each best move.

    int size() const 		// Get the number of candidate moves that are kept.
	{
	    return best_move.size();
	}
    
    void insert(const Coor& MOVE,int heuristic,int pos); // Insert a move
							 // and its heuristic
							 // in a position pos,
							 // and reorganize everything.
     
    
    void updateOpponentFreeSides(Square** board,const Coor& MOVE,
			       int axisid,void (Coor::*moveOnAxis)(int));
    // Update the opponent's free sides of the MOVE's player on
    // axisid. moveOnAxis is a pointer to the function used to change the
    // position of Coor on axisid.
    // Implemented in updateOpponentFreeSides.cpp
    

    void updatePlayerFreeSides(Square** board,const Coor& CAND,int player,
			     int axisid,void (Coor::*moveOnAxis)(int)) const;

    // Update the free sides of CAND for player, if some conditions are
    // satisfied on axisid. moveOnAxis is the function used to change the
    // position of Coor on axisid. The free sides can actually only be
    // incremented from 1 to 2.
    // best_moves is not updated, the calling function will take care of that.
    // Implemented in updatePlayerFreeSides.cpp

 public:
    BestMoves(int size); 	// Create a BestMoves object. size is the
				// number of candidates that it will keep.
    
    Coor getBest() const 	// Returns the best move.
	{
	    return best_move[0];
	}
    
	    
    void submit(const Coor& MOVE,int heuristic); // Submit a candidate move to
						 // be integrated in the best moves.
						 // The function
						 // differs from insert in the
						 // fact that the move might
						 // or might not be
						 // integrated depending on
						 // its heuristic.

    void findAndDelete(const Coor& MOVE); // Delete MOVE from the object and
					  // reorganize everything. Used when
					  // a move is physically played on
					  // the board and therefore cannot be
					  // candidate anymore.

    void updateAfterMovePlayed(const Coor& MOVE,Square** board); 
    // Update the candidate evaluations and the best candidate moves after a
    // move was played. Also delete MOVE from the candidate moves. Central
    // piece of the program.
    // Implemented in updateAfterMovePlayed.cpp

    friend std::ostream& operator << (std::ostream& os,const BestMoves& bm)// For testing only.
	{
	    for (int i=0;i<static_cast<int>(bm.best_move.size());i++){
		os << bm.best_move[i] << " : " << bm.best_heuristic[i];
		os << std::endl;
	    }return os;
	}
};

#endif
