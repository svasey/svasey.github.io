// deeppink - A fast connect 5 (Gomoku) program, that uses no backtracking or
// bruteforce algorithm whatsoever. 
// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger

/*
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#include <iostream>
using std::cout;
using std::cerr;
using std::endl;
using std::cin;

#include <config.h>
#include <string>
using std::string;
#include <cstring>

#include "global.h"
#include "Square.h"
#include "Coor.h"

#include "BestMoves.h"

// Initialize the free sides of all candidate moves on an empty board, as there
// are already some even tough there are no opponent stones. For example, if you
// put a pawn in a corner, the opponent can prevent you from doing a line with
// only one stone...
void initializeFreeSides(Square** board) // Might be optimized
{
    for (int x=0;x<20;x++){
	for (int y=0;y<20;y++){
	    // If < 4 squares away from the board's limit 
	    if (x<4 || x>15 || y<4 || y>15){

		// decrement diagonal free sides
		board[x][y].decrFreeSides(0,1);
		board[x][y].decrFreeSides(1,1);
		board[x][y].decrFreeSides(0,3);
		board[x][y].decrFreeSides(1,3);
		
		
		if (y<4 || y>15){ // column
		    board[x][y].decrFreeSides(0,0);
		    board[x][y].decrFreeSides(1,0);
		}
		
		
		if (x+y < 4 || x+y > 34){ // right diagonal
		    board[x][y].decrFreeSides(0,1);
		    board[x][y].decrFreeSides(1,1);
		}
		
		
		if (x<4 || x>15){ // line
		    board[x][y].decrFreeSides(0,2); 
		    board[x][y].decrFreeSides(1,2);
		}
		
		if (y-x > 15 || x-y > 15){ // left diagonal
		    board[x][y].decrFreeSides(0,3);
		    board[x][y].decrFreeSides(1,3);
		}
	    }
	}
    }
}

void displayBoard(Square** board)	// For testing only
{
    string spaces="    ";
    string undercores="___";
    message << spaces;
    for (int i=0;i<20;i++)
	message << undercores;
    message << endl;
    for (int y=19;y>=0;y--){
	if ((y+1) < 10)
	    message << 0;
	message << y+1 << " ";
	message << "|";
	for (int x=0;x<20;x++){
	    message << " " << board[x][y] << " ";
	}
	message << "|" << endl;
    }
    message << spaces;
    for (int i=0;i<20;i++)
	message << undercores;
    message << endl;
    message << spaces;
    for (int i=0;i<20;i++){
	if (i+1 < 10)
	    message << 0;
	message << i+1 << " ";
    }
    message << endl;
}

// Count the number of aligned stones of each type for each owner
void getWinner(Square** board,int aligned_stones[][2])
{
    for (int y=0;y<20;y++){
	for (int x=0;x<20;x++){
	    const int OWNER=board[x][y].owner;
	    const int OWNER_ID=OWNER-1;
	    	    
	    const Coor STONE=Coor(x,y);
	    
	    Coor c=STONE;
	    void (Coor::*moveOnAxis)(int)=&Coor::moveColumn;
	    
	    for (int i=0;i<4;i++,c=STONE){ // For each axis
		(c.*moveOnAxis)(1);

		// The number of stones with the same owner on each side of the
		// axis.
		int a1=0;
		int a2=0;
		for (int d=1;;(c.*moveOnAxis)(d)){
		    if (c.isOutOfRange() || 
			board[c.x][c.y].owner != OWNER){

			if (d == -1){
			    break;
			}
			c=STONE;
			d=-1;
		    }
		    else {
			d == 1 ? a1++:a2++;
		    }
		    
		}

		// Compute the total number of aligned stones.
		int a =a1+a2+1;

		if (a > 1)
		    aligned_stones[a-2][OWNER_ID]++;

		switch (i){
		    case 0: moveOnAxis=&Coor::moveRightDiag;
			break;
		    case 1: moveOnAxis=&Coor::moveLine;
			break;
		    case 2: moveOnAxis=&Coor::moveLeftDiag;
			break;
		}
	    }
	}
    }
}

int main(int argc,char* argv[]){
    
    bool engine=false;
    if (argc > 2){
	cerr << PACKAGE_TARNAME << " takes at most one argument." << endl;
	cerr << "See --help for usage" << endl;
	return 1;
    }
    if (argc > 1){
	if (strcmp(argv[1],"--version") == 0){
	    cout << PACKAGE_STRING << endl;
	    cout << "Copyright (c) 2007 Sebastien Vasey" << endl;
	    cout << "Copyright (c) 2007 Yann Schoenenberger" << endl;
	    cout << "This is free/opensource software, published under the GPL."
		 << endl << "<http://www.gnu.org/licenses/gpl.html>" << endl;
	    return 0;
	}
	else if (strcmp(argv[1],"--help") == 0){
	    cout << "Usage: " << PACKAGE_TARNAME << " [--engine]" << endl;
	    cout << "--engine: outputs only errors and necessary information."
		 << endl;
	    cout << "The standard --version and --help options are accepted."
		 << endl << endl;
	    cout << "Report bugs to <" << PACKAGE_BUGREPORT << ">." << endl;
	    return 0;
	}
	else if (strcmp(argv[1],"--engine") == 0)
	    engine=true;
	else {
	    cerr << "Unrecognized option: " << argv[1] << endl;
	    cerr << "See --help for usage" << endl;
	    return 1;
	}
    }

    // Output to stdout only if engine is false. Otherwise output nothing.
    if (engine)
	message.seekp(std::ios_base::end);
	    
    // Dynamically allocate the board array
    Square** board=new Square*[20];
    for (int i=0;i<20;i++){
	board[i]=new Square[20];
    }
    
    initializeFreeSides(board); // Get the free sides value for each of the
				// 400 candidate moves (they can be different
				// if near the edges of the board)
    // Code for the beginning of the game

    const std::string WHITE="white";
    const std::string BLACK="black";
    
    std::string color;
    message << "Enter the color you want " << PACKAGE_TARNAME
	    << " to play with. Possible options are " << BLACK << " or "
	    << WHITE << endl;
    cin >> color;		// Get the program's color

    if (color != WHITE && color != BLACK){
	cerr << "Bad color name !" << endl;
	return 1;
    }

    BestMoves best_moves(N_BM);	   // list the best candidate moves.

    if (color == WHITE){ // If we are white: play our first candidate-move
	displayBoard(board);
	board[FIRST_MOVE.x][FIRST_MOVE.y].owner=US;

	// Update the list of best moves
	best_moves.updateAfterMovePlayed(FIRST_MOVE,board); 

	// Display our move, transcribed in the `official' system
	message << "The computer move is: ";
	cout << FIRST_MOVE << endl;
    }
    displayBoard(board);
    // Code for the rest of the game

    // Maximum number of moves left to be played
    const int MAX_N_MOVES= color==WHITE ? 199:200;

    // Game result (1 if we won, -1 if we lost)
    int result=0;				
    for(int i=0;i<MAX_N_MOVES;i++){
	Coor their_move;
	message << "Enter your move. The format is `x y' where 1 1 is the" \
	    " lower left corner of the board" << endl;
	cin >> their_move;

	if (their_move.isOutOfRange()){
	    cerr << "Your move is out of range" << endl;
	    return 1;
	}

	else if (board[their_move.x][their_move.y].owner != EMPTY){
	    cerr << "Your move oversteps another" << endl;
	    return 1;
	}

	// The opponent won, stop the game and update the result.
	else if (board[their_move.x][their_move.y].winsTheGame(THEM)){
	    result=-1;
	    break;
	}

	board[their_move.x][their_move.y].owner=THEM;
	displayBoard(board);

	// Update the best candidate moves
	best_moves.updateAfterMovePlayed(their_move,board);
	Coor our_move=best_moves.getBest();
	
	// It can happen that the bestMoves size is too small, and some moves
	// have been 'forgotten' (near the end of the game). In that case, We
	// must set BestMoves to the max theoretical size, and recalculate all
	// moves's heuristics.
	if (our_move.x == -1){
	    // Set the size to the number of remaining moves
	    best_moves=BestMoves(MAX_N_MOVES-i); 
	    for (int x=0;x<20;x++){
		for (int y=0;y<20;y++){
		    if (board[x][y].owner==EMPTY){
			best_moves.submit(Coor(x,y),board[x][y]
					  .calculateHeuristic());
		    }
		}
	    }
	    our_move=best_moves.getBest();
	}
	
	message << "The computer move is: ";
	cout << our_move << endl;
	
	board[our_move.x][our_move.y].owner=US;
	displayBoard(board);
	if (board[our_move.x][our_move.y].winsTheGame(US)){
	    result=1;
	    break;
	}
	best_moves.updateAfterMovePlayed(our_move,board);
    }

 

    // Undefined result
    if (result == 0) {
	message << "There is no immediate winner." << endl;
	message << "I have to check the number of lines of 4,3 and 2" << endl;
	int aligned_stones[3][2];
	getWinner(board,aligned_stones);
	message << "Lines of 4 for me/you: " << aligned_stones[2][0] << " / "
		<< aligned_stones[2][1] << endl;
	if (aligned_stones[2][0] != aligned_stones[2][1] ){
	    result = (aligned_stones[2][0] > aligned_stones[2][1]) ? 1 : -1;
	}
	else {
	    message << "Lines of 3 for me/you: " << aligned_stones[1][0]
		    << " / " << aligned_stones[1][1] << endl;
	    if (aligned_stones[1][0] != aligned_stones [1][1]){
		result = (aligned_stones[1][0] > aligned_stones[1][1]) ? 1 : -1;
	    }
	    else {
		message << "Lines of 2 for me/you: " << aligned_stones[0][0]
			<< " /" << aligned_stones[0][1] << endl;
		if (aligned_stones[0][0] != aligned_stones[0][1]){
		    result = (aligned_stones[0][0] > aligned_stones[0][1])
			? 1: -1;
		}
	    }   
	}
    }
    if (result == 0){
	message << "There is a perfect equality, but I will grant the win " \
		<< "to the second player." << endl;
	if (color == WHITE)
	    result=-1;
	else
	    result=1;
    }

    if (result == 1)
	message << "The computer won. " << endl;
    else if (result == -1) 
	message << "You won. " << endl;
    message << "Result: ";
    cout << result << endl;
 
    for (int i=0;i<20;i++)
	delete[] board[i];
    delete[] board;

    return 0;
}
