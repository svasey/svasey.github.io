// Class containing various informations about a square: 
// 1) its 'owner', ie if it is empty or has a stone on it.
// 2) the informations about the candidate move on that square (meaningful
//    only if the square is empty), ie the number of free sides and aligned lines
//    for each axis and for each player.

/*
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#ifndef INCLUDE_SQUARE_H
#define INCLUDE_SQUARE_H

#include <iostream> 		// For testing only

class Square
{
 private:
    int line[2][4]; 		// Number of aligned stones in case the move
				// is played. First index is the player ([0]
				// is us). Second index is the axis ([0] is
				// the column, [1] is the upper right
				// diagonal, [2] is the line and [3] is the
				// upper left diagonal. (goes clockwise).

    int free_sides[2][4]; 	// Number of free sides on each side
				// of the pawn chain in case the move is
				// played. Follow the same index convention as line.
                                // In that program, the number of free sides
                                // is the minimum number of stones the opponent would
                                // need to put near the pawn chain in case they want to prevent us
                                // from aligning 5 stones.

 public:
    int owner; 			// Owner of the stone on the square. See
				// global.h for the int for each state.

    Square();

    int calculateHeuristic() const;  // Calculate an int heuristic value with
				     // all the line and free sides data, in
				     // order to make comparison of the move
				     // with others possible candidates.

    void incrLine(int playerid,int axisid,int value=1) // Increment line
	{
	    line[playerid][axisid]+=value;
	}
    
	
    
    int getLine (int playerid,int axisid) const
	{
	    return line[playerid][axisid];
	}
    

    void decrFreeSides (int playerid,int axisid,int value=1) // Decrement free_sides
	{
	    free_sides[playerid][axisid]-=value;
	}
	
    
    void setFreeSides(int playerid,int axisid,int value) // Set the
							 // free_sides' value
	{
	    free_sides[playerid][axisid]=value;
	}

    int getFreeSides (int playerid,int axisid) const 
	{
	    return free_sides[playerid][axisid];
	}

    bool winsTheGame(int player) const; // Return true if a move wins the game
				        // immediately, ie aligns 5 stones for
				        // player


    friend std::ostream& operator << (std::ostream& os,const Square& SQR) // testing
    {
	// if (SQR.owner==0){
// 	    // os << SQR.line[0][0] << "|" <<SQR.line[1][0];
// 	    os << SQR.free_sides[0][0] << "|" << SQR.free_sides[1][0];	
// 	}
	switch (SQR.owner){
	case 0:
	    os << " ";
	    break;
	case 1:
	    os << "X";
	    break;
	case 2:
	    os << "O";
	    break;
	    
	}
	return os;
    }
};

#endif
