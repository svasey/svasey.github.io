// Implementation of some functions declared in Square.h

/*
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#include "Square.h"
extern int EMPTY;
extern int US;
namespace Heuristic{
    extern int MAX;
    extern int SECOND_MAX;
    extern int OUR_COEF;
    extern int THEIR_COEF;
    extern int match(int n);
};

Square::Square()
{
    for (int i=0;i<2;i++){
	for (int j=0;j<4;j++){
	    line[i][j]=1;
	    free_sides[i][j]=2;
	}
    }
    owner=EMPTY;
}

int Square::calculateHeuristic() const // For detailed explanation about
				       // the used heuristic, see
				       // the documentation.

{
    int h[2]={0,0};	       // heuristic value of the move for US and THEM.
    
    int best_h=0;		// Used to register if the move is winning in
				// a two moves depth (4 aligned, 2 free sides)
	    

    for (int i=0;i<2;i++){	// For each player
	for (int j=0;j<4;j++){	// For each axis

	    if (line[i][j]> 4) // line of 5: winning move
		return Heuristic::MAX-i;	// -i is used so that the heuristic is
					// slightly less in case the move is
					// played by THE (as THEM is always > US)
	    

	    // Line of 4 with 2 free sides. Wins unless the opponent has a
	    // direct five-stone move. If one winning move has already been
	    // found for US, do not register it for THEM.

	    else if (line[i][j]==4 && free_sides[i][j]==2)
		best_h=Heuristic::SECOND_MAX-i;
	    
	    else if (free_sides[i][j])
		h[i]+=Heuristic::match(line[i][j]+free_sides[i][j]-1);
	       // One is added to the aligned stones if 2 free sides (as one
	       // more free sides can theoretically be aligned.)  
	    
	}
    }
    if (best_h)
	return best_h;
    return Heuristic::OUR_COEF*h[0]+Heuristic::THEIR_COEF*h[1];	    
}

bool Square::winsTheGame(int player) const
{
    const int PLAYER_ID= player==US ? 0:1;
    //The index value is [0] for US, [1] for THEM.

    for (int i=0;i<4;i++){
	if (line[PLAYER_ID][i] > 4)
	    return true;
    }
    return false;
}
