// Implementation of the function updateOpponentFreeSides, declared in BestMoves.h

/*
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#include "BestMoves.h"
#include "Square.h"
#include "Coor.h"

extern int EMPTY;
extern int US;
extern int THEM;

void BestMoves::updateOpponentFreeSides(Square** board,const Coor& MOVE,
					int axisid,void (Coor::*moveOnAxis)(int))
{
    const int PLAYER=board[MOVE.x][MOVE.y].owner;
    const int OPPONENT= PLAYER==US ? THEM:US;
    const int OPPONENT_ID= OPPONENT==US ? 0:1;

    Coor c=MOVE;		// Place a cursor on the MOVE square.
    
    for (int d=1;;d=-1,c=MOVE){	// d is the direction on the axis (1 or -1)
	
	(c.*moveOnAxis)(d*5);	// Move 5 squares away, in order to check if a
				// friendly stone stands. If that is the case,
				// update all the candidate between MOVE and
				// that square 's free sides to 0.

	if (c.isOutOfRange() || board[c.x][c.y].owner==PLAYER){
	    (c.*moveOnAxis)(-d);
	    
	    for (int i=0;i<4;i++,(c.*moveOnAxis)(-d)){
		if (!c.isOutOfRange() && board[c.x][c.y].owner==EMPTY){
		    board[c.x][c.y].setFreeSides(OPPONENT_ID,axisid,0);
		    submit(c,board[c.x][c.y].calculateHeuristic());
		}
	    }
	} else {
	    (c.*moveOnAxis)(-4*d); // Go back 4 squares (ie one square from
				   // MOVE).

	    for (int i=1,n_op=0;i<5;i++,(c.*moveOnAxis)(d)){ // For each
							     // square in a 4
							     // squares
							     // radius.
	
		// n_op is the number of opponents stones encountered so far.

		if (c.isOutOfRange() || board[c.x][c.y].owner==PLAYER){	
		    // Update all candidate free sides in between to 0 and stop everything.

		    for ((c.*moveOnAxis)(-d);i>1;i--,(c.*moveOnAxis)(-d)){
			if (!c.isOutOfRange() && board[c.x][c.y].owner==EMPTY){
			    board[c.x][c.y].setFreeSides(OPPONENT_ID,axisid,0);
			    submit(c,board[c.x][c.y].calculateHeuristic());
			}
		    }
		    break;
		}
		if (board[c.x][c.y].owner==OPPONENT)
		    n_op++;
		
		else if (board[c.x][c.y].owner==EMPTY && 
		    board[c.x][c.y].getFreeSides(OPPONENT_ID,axisid)==2
			 // We can increment only if there are 2 free sides.
		    ){
		    if (board[c.x][c.y].getLine(OPPONENT_ID,axisid) < 3){
			board[c.x][c.y].setFreeSides(OPPONENT_ID,axisid,1);
			submit(c,board[c.x][c.y].calculateHeuristic());
		    } else {	// Exception if high number of aligned stones,
				// in that case, a special formula is used
				// (see doc. for more details)
			if (5-board[c.x][c.y].getLine(OPPONENT_ID,axisid) >= i-n_op){
			    board[c.x][c.y].setFreeSides(OPPONENT_ID,axisid,1);
			    submit(c,board[c.x][c.y].calculateHeuristic());
			}
			n_op=0;	// Reinitialize n_op.
		    }
		}
	    }
	}
	if (d == -1)
	    return;
    }
}
