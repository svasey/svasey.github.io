// Contains a 2-d position, ie a move or the coordinates of a square.

/*
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#ifndef INCLUDE_COOR_H
#define INCLUDE_COOR_H

#include <algorithm>		// Only for std::min
using std::min;

// For testing only
#include "Square.h"

struct Coor {
    int x,y;

    Coor(int xx=0,int yy=0)
	{
	    x=xx;y=yy;
	}

    // Test if the coordinates are in the board's range (in our system of
    // coordinates). Returns true if out of range.
    bool isOutOfRange() const 
	{
	    return x<0 || x>=20 || y<0 || y>=20;
	}
    
    // Move the square's position on a specified axis
    void moveColumn(int n)
	{
	    y-=n;		// if n>0: move up (rapport to the official sys)
	}
    void moveRightDiag(int n)
	{
	    // if n>0: move in a upper-right direction.
	    y-=n;
	    x+=n;
	}
    void moveLine(int n)
	{
	    // if n>0: move right
	    x+=n;
	}
    void moveLeftDiag(int n)
	{
	    // if n>0: move in a lower right direction.
	    y+=n;
	    x+=n;
	}

    
    // Calculate a coefficient giving how near from the center a square
    // is. The higher the coefficient, the nearer from the center. The coeff is
    // used in case two candidate moves have an equal heuristic.
    int calculateCenterCoef() const 
	{
	    return min(19-x,x)+min(19-y,y);
	}


    bool operator == (const Coor& c) const 
	{
	    return x==c.x && y==c.y;
	}

    friend std::ostream& operator << (std::ostream& os,const Coor& coor)
	{
	    return os << coor.x+1 << " " << coor.y+1;
	}
    friend std::istream& operator >> (std::istream& is,Coor& coor)
	{
	    is >> coor.x >> coor.y;
	    coor.x--;
	    coor.y--;
	    return is;
	}
};

#endif
