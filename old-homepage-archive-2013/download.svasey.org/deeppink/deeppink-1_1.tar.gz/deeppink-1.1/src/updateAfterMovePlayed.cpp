// Implementation of updateAfterMovePlayed (prototype in BestMoves.h)

/*
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
 
#include "BestMoves.h"
#include "Square.h"
#include "Coor.h"

extern int EMPTY;
extern int US;


void BestMoves::updateAfterMovePlayed(const Coor& MOVE,Square** board)
{
    findAndDelete(MOVE); // Remove the played move from the candidate moves
    
    const int PLAYER=board[MOVE.x][MOVE.y].owner; // Player of the submitted move.
    const int PLAYER_ID= PLAYER==US ? 0:1;

    Coor c=MOVE; // Initialize a cursor on the played move square

    void (Coor::*moveOnAxis)(int)=&Coor::moveColumn; // Begin the search on
						     // the column axis.

    for (int i=0;i<4;i++,c=MOVE) // For each of the 4 axis
    {
	updateOpponentFreeSides(board,c,i,moveOnAxis); // Update the opponent's
						       // free sides for each
						       // square on the axis.	

	(c.*moveOnAxis)(1);
	for (int d=1,n_stones=0;;(c.*moveOnAxis)(d)){
	    // d is the direction, n_stones is the number of stones encountered.

	    if (!c.isOutOfRange() && board[c.x][c.y].owner==PLAYER) 
		// Increment the number of stones that will be added

		n_stones++;
	    
	    else {
		if (!c.isOutOfRange() && board[c.x][c.y].owner==EMPTY){	
		    // End of the chain: increment the number of aligned stones

		    board[c.x][c.y].incrLine
			(PLAYER_ID,i,board[MOVE.x][MOVE.y].getLine(PLAYER_ID,i)-n_stones);
		    
		    if (board[c.x][c.y].getFreeSides(PLAYER_ID,i)==1){	
			// Possibility to increment the nbr of free sides if ==1

			updatePlayerFreeSides(board,c,PLAYER,i,moveOnAxis);
			
		    }
		    
		    // Submit the move to the list of best candidates.
		    submit(c,board[c.x][c.y].calculateHeuristic()); 
		}

		// Change direction
		if (d == -1)
		    break;
		d=-1;
		c=MOVE;
		n_stones=0;
	    }
	}
	
	switch (i){		// Change the function used to move on the axis.
	    case 0: 
		moveOnAxis=&Coor::moveRightDiag;break;
	    case 1:
		moveOnAxis=&Coor::moveLine;break;
	    case 2:
		moveOnAxis=&Coor::moveLeftDiag;break;
	}
    }
}
