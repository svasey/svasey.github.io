/* Contains implementation of the functions declared in urpkg.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include "urpkg.h"
#include "fs.h"
#include "dt.h"
#include "str.h"
#include "pkg.h"
#include "proc.h"
#include "mem.h"

void
signal_handler (int sig)
{
	static int already_invoked = 0;

	xstderr ("Interrupt signal received\n");
	/* Another instance of the handler is running */
	if (already_invoked){
		xstderr ("Another instance is running, please wait\n");
		return;
	}
	
	already_invoked = 1;
	error_set (CUSTOM_ERROR,"Process terminated by user\n");

	error_exit (1,1);
}

int
check_pkgname (const char *username)
{
	int r;

	xdebug ("%s (%s)\n",__FUNCTION__,username);
	if (ugrp_check_format (username) < 0){
		return -1;
	}

	r = ugrp_user_exists_p (username,NULL);
	if (r < 0){
		return -1;
	}
	else if (r){
		error_set (UGEXIST_ERROR,username);
		return -1;
	}
	
	return 0;
}

int
sanity_checks (const struct user_action *action)
{
	/* True if respectively the shared group and the install group exist  */
	int shared_exists;
	int install_exists;
	int r;

	xlog ("Doing some sanity checks\n");
	
	if (action->action == UNKNOWN){
		error_set (CUSTOM_ERROR,"No action given");
		return -1;
	}
	/* Check whether we are the superuser */
	if ((action->action != LIST_INST) && (action->action != LIST_DIR)
	    && (action->action != LIST_SHARED) && (action->action != FIND)
	    && (!action->pretend)){
		if (! ugrp_have_privilleges_p ()){
			xwarn ("It is recommended that I run with root "
			       "privilleges\n");
		}
	}

	shared_exists = ugrp_group_exists_p (SHARED_GROUP,NULL);
	if (shared_exists < 0){
		return -1;
	}
	install_exists = ugrp_group_exists_p (INSTALL_GROUP,NULL);
	if (install_exists < 0){
		return -1;
	}

	xlog ("Checking whether the shared group exists...\n");
	if (!shared_exists){
		xwarn ("The shared group %s does not exist. Please create "
		       "it\n",SHARED_GROUP);
	}
	xlog ("Checking whether the install group exists...\n");
	if (!install_exists){
		xwarn ("The install group %s does not exist. Please create "
		       "it\n",INSTALL_GROUP);
	}

	xlog ("Checking whether the package directory %s is a directory\n",
	      action->pkg_dir);
	r = fs_is_directory_p (action->pkg_dir);
	if (r < 0){
		return -1;
	}
	if (!r){
		error_set (CUSTOM_ERROR,"The package directory %s must be "
			   "a directory !\n",action->pkg_dir);
		return -1;
	}
	if (action->action == INSTALL){
		xlog ("Checking whether %s is a valid package user...\n",
		      string_list_first (&action->pkg_list));
		if (check_pkgname (string_list_first (&action->pkg_list)) < 0){
			error_set (CUSTOM_ERROR,"Cannot create package: %s",
				   error_describe ());
			return -1;
		}
	}

	if (action->action == ADD_FILES){
		struct string_list_el *it;
		struct string_list_el *pos;
		struct string_list owners;
		const char *pkg = string_list_first (&action->pkg_list);

		xlog ("Checking whether files to add are not already part of "
		      "the package...\n");
		for (it = string_list_it (&action->file_list);it != NULL
			     ;it = it->next){
			string_list_init (&owners);
			if (find_file_owner (it->string,&owners) < 0){
				return -1;
			}
			string_list_find (&owners,pkg,&pos,&string_equal_p);
			if (pos != NULL){
				error_set (CUSTOM_ERROR,"File %s is already "
					   "part of package %s",it->string,
					   pkg);
				return -1;
			}
		}
	}

	return 0;
}

int
find_file_owner (const char *filename,struct string_list *pkg_list)
{
	/* Group and owner of the file  */
	char groupname[UGRP_MAX_LENGTH];
	char ownername[UGRP_MAX_LENGTH];
	/* Array of string list of all extra files */
	struct string_list *all_extra;
	int r;
	int i;

	xdebug ("%s (%s,%p)\n",__FUNCTION__,filename,pkg_list);

	/* If we cannot match the numeric id with a textual user, don't
	   abort  */
	if (fs_file_owner (filename,ownername) < 0){
		if (urpkg_errno == UID_ERROR){
			error_init ();
			strcpy (ownername,"noname");
		}
		else {
			return -1;
		}
	}
	if (fs_file_group (filename,groupname) < 0){
		if (urpkg_errno == GID_ERROR){
			error_init ();
			strcpy (groupname,"noname");
		}
		else {
			return -1;
		}
	}

	/* We will take care of duplicates afterward */
	r = pkguser_p (ownername);
	if (r < 0){
		return -1;
	}
	else if (r){
		string_list_add (pkg_list,ownername);
	}
	r = pkguser_p (groupname);
	if (r < 0){
		return -1;
	}
	else if (r){
		string_list_add (pkg_list,groupname);
	}

	if ( ( all_extra = find_all_extra_files () ) == NULL){
		return -1;
	}

	for (i = 0;string_list_size (&all_extra[i]) != 0;i++){
		/* Second element of all_extra[i] */
		struct string_list_el *first;
		struct string_list_el *pos;

		first = string_list_it (&all_extra[i]);
		
		if (string_list_find_at (first->next, filename, &pos,
					 &fs_samefile_p) < 0){
			return -1;
		}
		/* Package contains the file */
		else if (pos != NULL){
			string_list_add (pkg_list,first->string);
		}
	}
	string_list_remove_dup (pkg_list,&string_equal_p);

	xdebug ("Owners of %s follow\n",filename);
	string_list_print (xdebug,pkg_list);

	return 0;
}

int 
find_pkg (const char* filename)
{
	struct string_list pkg_list;
	struct string_list_el *it;

	string_list_init (&pkg_list);

	if (find_file_owner (filename,&pkg_list) < 0){
		error_set (CUSTOM_ERROR,"An error occured when looking up "
			   "package owners of file: %s",error_describe ());
		return -1;
	}

	xmsg ("File %s is part of the following packages:\n",filename);
	for (it = string_list_it (&pkg_list);it != NULL;it = it->next){
		char pkgname[PKG_MAX_LENGTH];
		int r = pkg_user_to_name (it->string,pkgname);

		xassert (r == 0);

		xstdout ("%s\n",pkgname);
	}

	return 0;
}

int
run_install (const char *cmd,char *const argv[])
{
	FILE *install_out;
	FILE *install_err;
	FILE *install_log;
	int pid;
	int err_pid;
	int c;
	int r;

	xmsg ("Running install command: %s %s\n",
	      cmd,proc_args_to_str (&argv[1]));
	install_out = proc_open (cmd,argv,&pid,&install_err);

	if (install_out == NULL){
		return -1;
	}

	/* Open an installation log file */
	install_log = io_fopen (INSTALL_LOG,"w+");
	if (install_log == NULL){
		error_set (FWRITE_ERROR,INSTALL_LOG,strerror (errno));
		return -1;
	}

	/* Fork: the child will print stderr, we will print stdout */
	err_pid = fork ();
	if (err_pid < 0){
		error_set (FORK_ERROR,strerror (errno));
		return -1;
	}
	/* Child process */
	else if (err_pid == 0){
		io_print_stream (xstderr,install_err,install_log);
		exit (0);
	}
	/* Parent process */
	io_print_stream (xstdout,install_out,NULL);

	if (waitpid (err_pid,&r,0) < 0){
		return -1;
	}

	rewind (install_log);
	if ( (c = fgetc (install_log)) != EOF){
		xwarn ("The install command printed something to "
		       "stderr (see %s): \n",INSTALL_LOG);
		ungetc (c,install_log);
		io_print_stream (xstderr,install_log,NULL);
	}
	
	io_fclose (install_log);

	if (( r = proc_close (pid)) < 0){
		return -1;
	}
	if (r != 0){
		error_set (CMD_ERROR,cmd,argv,r);
		return -1;
	}

	xmsg ("Install command returned successfully\n");
	return 0;
}

int
create_pkgdir (const char *path,const char *username)
{
	const mode_t DIR_MODE = 0755;
	const mode_t FILE_MODE = 0644;

	/* .urpkg directory inside path */
	char priv[PATH_MAX];
	char added[PATH_MAX];
	uid_t uid;
	gid_t gid;
	struct passwd *ud = getpwnam (username);

	xlog ("Creating package directory in %s for username %s\n",path,
	      username);
	uid = ud->pw_uid;
	gid = ud->pw_gid;

	if (fs_dir_create (path,DIR_MODE,uid,gid) < 0){
		return -1;
	}

	if ((strlen (path) + strlen ("/") + strlen (PRIVDIR)) >= PATH_MAX){
		error_set (LONGPATH_ERROR,"Concatenation of %s and %s is too "
			   "long",path,PRIVDIR);
		return -1;
	}

	strcpy (priv,path);
	strcat (priv,"/");
	strcat (priv,PRIVDIR);

	if (fs_dir_create (priv,DIR_MODE,uid,gid) < 0){
		return -1;
	}

	if ((strlen (path) + strlen ("/") + strlen (added)) >= PATH_MAX){
		error_set (LONGPATH_ERROR,"Concatenation of %s and %s is too "
			   "long",path,added);
		return -1;
	}

	strcpy (added,path);
	strcat (added,"/");
	strcat (added,ADDED_FILE);

	if (fs_file_create (added,FILE_MODE,uid,gid) < 0){
		return -1;
	}

	return 0;
}

int
create_pkg (const char *username,const char *pkgdir)
{
	/* Arguments to give to useradd (groups will be handled by
	   usermod). The empty strings will be filled later */
	char *uadd_argv[] = {USERADD_PATH,"--comment","","--home",
			     "",(char *)(username),NULL};
	char *umod_argv[] = {USERMOD_PATH,"--gid",(char *)(username),"--groups",
			     "","--lock",(char *)(username),NULL};
	char pkgname[PKG_MAX_LENGTH];
	char pkgdir_full[PATH_MAX];
	char grouplist[UGRP_MAX_LENGTH * 2 + 2];
	int r;

	xlog ("Creating package user %s\n",username);
	r = pkg_user_to_name (username,pkgname);
	xassert (r == 0);
	uadd_argv[2] = pkgname;

	if ((strlen (pkgdir) + strlen ("/") + strlen (pkgname)) >= PATH_MAX){
		error_set (LONGPATH_ERROR,"Concatenation of package dir: %s "
			   "and package name: %s is too long",pkgdir,pkgname);
		return -1;
	}

	strcpy (pkgdir_full,pkgdir);
	strcat (pkgdir_full,"/");
	strcat (pkgdir_full,pkgname);
	uadd_argv[4] = pkgdir_full;

	/* Run useradd */
	PROC_RUN_CHECK (USERADD_PATH,uadd_argv);

	/* Add the group if needed */
	r = ugrp_group_exists_p (username,NULL);
	if (r < 0){
		return -1;
	}
	else if (!r){
		if (create_group (username) < 0){
			return -1;
		}
	}

	/* Run usermod */
	xassert ((ugrp_check_format (INSTALL_GROUP) == 0)
		 && (ugrp_check_format (SHARED_GROUP) == 0));
	strcpy (grouplist,INSTALL_GROUP);
	strcat (grouplist,",");
	strcat (grouplist,SHARED_GROUP);
	umod_argv[4] = grouplist;

	PROC_RUN_CHECK (USERMOD_PATH,umod_argv);

	if (create_pkgdir (pkgdir_full,username) < 0){
		error_set (CUSTOM_ERROR,"Could not create package directory "
			   ": %s",error_describe ());
		return -1;
	}

	return 0;
}

int 
install_pkg (const char *username,const char *pkgdir,
	     const char *install_cmd,char *const install_argv[],
	     const struct dictionary *postscript_args,
	     const struct scripts_exclude *exclude)
{
	char pkgname[PKG_MAX_LENGTH];
	int r;

	r = pkg_user_to_name (username,pkgname);

	xassert (r == 0);
	
	xmsg ("Installing package %s...\n",pkgname);

	if (gen_env (username,pkgdir) < 0){
		return -1;
	}

	if (!exclude->preinst){
		char *const EMPTY_ARGV[] = {DEFAULT_PREINST,NULL};

		xlog ("Running preinstall script...\n");
		r = proc_run (DEFAULT_PREINST,EMPTY_ARGV);
		if (r < 0){
			error_set (CUSTOM_ERROR,"Could not run preinstall "
				   "script: %s",error_describe ());
			return -1;
		}
		else if (r != 0){
			error_set (CMD_ERROR,DEFAULT_PREINST,EMPTY_ARGV,r);
			return -1;
		}
	}
	xlog ("Creating package user...\n");
	if (create_pkg (username,pkgdir) < 0){
		error_set (CUSTOM_ERROR,"Couldn't create package user: %s",
			   error_describe ());
		return -1;
	}

	xlog ("Removing install log file...\n");
	if (fs_file_delete (INSTALL_LOG) < 0){
		return -1;
	}
	
	xlog ("Dropping privilleges...\n");
	if (ugrp_drop_privilleges (username) < 0){
		return -1;
	}
	xlog ("Running installation command...\n");
	if (run_install (install_cmd,install_argv) < 0){
		return -1;
	}
	xlog ("Getting privilled again..\n");
	if (ugrp_restore_privilleges () < 0){
		return -1;
	}
	/* Change the owner of the installation log file */
	if (install_log_sanitize () < 0){
		return -1;
	}
	if (!exclude->postinst){
		xlog ("Running postinstall scripts...\n");
		if (run_postinst_scripts (postscript_args,
					  &exclude->postinst_list) < 0){
			error_set (CUSTOM_ERROR,"Running postinstall scripts "
				   "failed: %s",error_describe ());
			return -1;
		}
	}
	
	return 0;
}

int
remove_regfiles (const struct string_list *files)
{
	struct string_list_el *it;
	
	for (it = string_list_it (files);it != NULL;it = it->next){
		xassert (fs_abspath_p (it->string));
		xassert (strcmp ("/",it->string) != 0);
		xmsg ("Removing %s\n",it->string);
		if (fs_file_delete (it->string) < 0){
			error_set (CUSTOM_ERROR,"Error while deleting file %s "
				   ": %s",error_describe ());
			return -1;
		}
	}

	return 0;
}

int
remove_emptydir (const struct string_list *dir)
{
	struct string_list_el *it;

	for (it = string_list_it (dir);it != NULL;it = it->next){
		xassert (fs_abspath_p (it->string));
		xassert (strcmp ("/",it->string) != 0);
		if (! fs_file_exists_p (it->string)){
			continue;
		}
		if (fs_is_nonempty_dir_p (it->string)){
			xwarn ("I will not remove %s : not empty. Please "
			       "remove it manually.\n",it->string);
			continue;
		}
		xmsg ("Removing %s\n",it->string);
		if (fs_file_delete (it->string) < 0){
			error_set (CUSTOM_ERROR,"Error while deleting file %s "
				   ": %s",error_describe ());
			return -1;
		}
	}

	return 0;
}

FILE *
open_extra (const char *username,const char *mode)
{
	char file[PATH_MAX];
	struct passwd *ud = getpwnam (username);
	int r;

	xdebug ("%s (%s,%s)\n",__FUNCTION__,username,mode);
	if (ud == NULL){
		error_set (UGFIND_ERROR,username,strerror (errno));
		return NULL;
	}

	xassert ((strlen (ud->pw_dir) + strlen ("/") + strlen (ADDED_FILE))
		 < PATH_MAX);

	strcpy (file,ud->pw_dir);
	strcat (file,"/");
	strcat (file,ADDED_FILE);

	r = fs_file_exists_p (file);
	if (r < 0){
		return NULL;
	}
	else if (!r){
		error_set (FNEXIST_ERROR,file);
		return NULL;
	}

	return (io_fopen (file,mode));
}

struct string_list *
find_all_extra_files (void)
{
	static struct string_list *ret = NULL;
	struct string_list installed;
	struct string_list_el *it;
	int i;

	xdebug ("%s ()\n",__FUNCTION__);
	if (ret != NULL){
		return ret;
	}
	
	string_list_init (&installed);
	
	if (find_installed (&installed) < 0){
		return NULL;
	}

	/* This is the maximum size it can be */
	ret = xmalloc (sizeof(struct string_list)
		       * (string_list_size (&installed) + 1));

	i = 0;
	for (it = string_list_it (&installed);it != NULL;it = it->next){
		struct string_list extra;
		struct string_list tmp;

		string_list_init (&extra), string_list_init (&tmp),
			string_list_init (&ret[i]);
		if (find_extra_files (it->string,&extra) < 0){
			return NULL;
		}

		if (string_list_size (&extra) == 0){
			continue;
		}

		/* First element: the package username */
		string_list_add (&tmp, it->string);
		string_list_cat (&tmp, &extra, &ret[i]);

		string_list_free (&tmp), string_list_free (&extra);
		i++;
	}
	string_list_free (&installed);
	string_list_init (&ret[i]);

	return ret;
}

int
find_extra_files (const char *username,struct string_list *dest)
{
	/* Open the list of extra files for username */
	FILE *extra = open_extra (username,"r");
	char file[PATH_MAX + 1];

	if (extra == NULL){
		if (urpkg_errno == FNEXIST_ERROR){
			xdebug ("%s: added file list does not exist\n",
				__FUNCTION__);
			return 0;
		}
		else {
			return -1;
		}
	}
			
	/* The extra file has only one field, containing the absolute path of
	   each file that has been added */
	errno = 0;
	while (fgets (file,PATH_MAX,extra) != NULL){
		if (lastchar (file) != '\n'){
			error_set (LONGPATH_ERROR,"Line beginning by "
				   "%s in %s",file,io_stream_to_name (extra));
			io_fclose (extra);
			return -1;
		}
		/* Remove trailing new line */
		chomp (file);
		string_list_add (dest,file);
		errno = 0;
	}

	if (errno != 0){
		error_set (FREAD_ERROR,io_stream_to_name (extra),
			   strerror (errno));

		return -1;
	}

	io_fclose (extra);

	return 0;
}

int
find_owned_files (const char *username,const char *findcmd,
		  struct string_list *dest)
{
	char *const FIND_ARGV[] = {(char *)(findcmd),(char *)(username),NULL};
	FILE *owned;
	int pid;
	int r;
	char line[PATH_MAX + 1];

	owned = proc_open (findcmd,FIND_ARGV,&pid,NULL);

	if (owned == NULL){
		return -1;
	}

	errno = 0;
	while (fgets (line,PATH_MAX,owned) != NULL){
		if (lastchar (line) != '\n'){
			error_set (LONGPATH_ERROR,"Line beginning by %s in "
				   "output of find command",line);
			proc_close (pid);
			return -1;
		}
		chomp (line);
		string_list_add (dest,line);
		errno = 0;
	}

	if ( (r = proc_close (pid)) < 0){
		return -1;
	}
	else if (r != 0){
		error_set (CMD_ERROR,findcmd,FIND_ARGV,r);
		return -1;
	}
	if (errno != 0){
		error_set (CUSTOM_ERROR,"Something happened while reading "
			   "output of %s : %s",findcmd,strerror (errno));
		return -1;
	}

	return 0;
}

int
find_group_files (const char *groupname,const char *findcmd,
		  struct string_list *dest)
{
	return find_owned_files (groupname,findcmd,dest);
}

int
find_unique_files (const char *username,const struct string_list *file_list,
		   struct string_list *unique,struct string_list *shared)
{
	struct string_list_el *it;

	xdebug ("%s (%s,%p,%p,%p)\n",__FUNCTION__,username,file_list,
		unique,shared);
	for (it = string_list_it (file_list);it != NULL;it = it->next){
		struct string_list pkg_list;

		string_list_init (&pkg_list);
		xassert (fs_file_exists_p (it->string));
		if (find_file_owner (it->string,&pkg_list) < 0){
			return -1;
		}
		xassert (! string_list_empty_p (&pkg_list));
		if (string_list_size (&pkg_list) == 1){
			string_list_add (unique,it->string);
		}
		else {
			string_list_add (shared,it->string);
		}
				
		string_list_free (&pkg_list);
		
	}

	return 0;
}

int
find_inpath (const struct string_list *file_list,const char *path,
	     struct string_list *dest)
{
	struct string_list_el *it;
	int r;

	xdebug ("%s (%p,%s,%p)\n",__FUNCTION__,file_list,path,dest);
	for (it = string_list_it (file_list);it != NULL;it = it->next){
		r = fs_is_inpath_p (path,it->string);
		if (r < 0){
			return -1;
		}
		else if (r){
			xdebug ("%s : %s\n",__FUNCTION__,it->string);
			string_list_add (dest,it->string);
		}
	}

	return 0;
}

int
find_destroy (const char *username,const char *findcmd,int pretend)
{
	/* Lists of owned (package user is the owner or group) and extra files
	   part of the package */
	struct string_list owned_files;
	struct string_list extra_files;
	/* List of all files */
	struct string_list file_list;
	/* List of files belonging only to the package */
	struct string_list unique_list;
	/* List of files belonging to the package but to other packages as
	   well */
	struct string_list shared_list;
	/* List of directories */
	struct string_list dir_list;
	/* List of regular files */
	struct string_list reg_list;

	string_list_init (&owned_files), string_list_init (&extra_files),
		string_list_init (&file_list), string_list_init (&unique_list),
		string_list_init (&shared_list), string_list_init (&reg_list),
		string_list_init (&dir_list);

	/* Find files */
	xlog ("Finding extra files...\n");
	if (find_extra_files (username,&extra_files) < 0){
		error_set (CUSTOM_ERROR,"Could not find extra files: %s",
			   error_describe ());
		return -1;
	}
	xlog ("Finding owned files...\n");
	if (find_owned_files (username,findcmd,&owned_files) < 0){
		error_set (CUSTOM_ERROR,"Could not find owned files: %s",
			   error_describe ());
		return -1;
	}

	/* Separate unique and shared */
	string_list_cat (&owned_files,&extra_files,&file_list);
	string_list_free (&owned_files), string_list_free (&extra_files);
	if (find_unique_files (username,&file_list,&unique_list,
			       &shared_list) < 0){
		return -1;
	}
	if (! string_list_empty_p (&shared_list)){
		xwarn ("The following files are shared with other packages "
		       "and will not be removed:\n");
		string_list_print (xstderr,&shared_list);
	}
	string_list_free (&shared_list), string_list_free (&file_list);
	if (pretend){
		xmsg ("The following files would be removed:\n");
		string_list_print (xstdout,&unique_list);
		return 0;
	}
	/* Remove file first, then directories */
	if (fs_find_directories (&unique_list,&reg_list,&dir_list) < 0){
		return -1;
	}
	xlog ("Removing regular files...\n");
	if (remove_regfiles (&reg_list) < 0){
		return -1;
	}
	xlog ("Removing empty directories...\n");
	if (remove_emptydir (&dir_list) < 0){
		return -1;
	}
	string_list_free (&unique_list), string_list_free (&reg_list),
		string_list_free (&dir_list);

	return 0;
}

int
remove_user (const char *username)
{
	char *const udel_argv[] = {USERDEL_PATH,(char *)(username),
				   NULL};
	const char *homedir;

	if ( ( homedir = ugrp_user_homedir (username) ) == NULL){
		error_set (CUSTOM_ERROR,"Could not find home directory of user "
			   "%s : %s",username,error_describe ());
		return -1;
	}

	xlog ("Removing package user %s\n",username);
	PROC_RUN_CHECK (USERDEL_PATH,udel_argv);

	xlog ("Removing home directory of %s\n",username);
	if (fs_file_delete (homedir) < 0){
		error_set (CUSTOM_ERROR,"Could not remove home directory of "
			   "user %s : %s",username,error_describe ());
		return -1;
	}

	return 0;
}

int
uninstall_pkg (const char *username,const char *findcmd,int pretend)
{
	char pkgname[PKG_MAX_LENGTH];
	int r;

	r = pkg_user_to_name (username,pkgname);

	xassert (r == 0);

	xmsg ("Uninstalling package %s...\n",pkgname);

	if (gen_env (username,NULL) < 0){
		return -1;
	}
	xmsg ("Listing and removing files...\n");
	if (find_destroy (username,findcmd,pretend) < 0){
		return -1;
	}
	xmsg ("Removing package user...\n");
	if (pretend){
		xmsg ("Package user %s would be removed\n",username);
	}
	else if (remove_user (username) < 0){
		return -1;
	}

	return 0;
}

int 
gen_env (const char *username,const char *pkgdir)
{
	/* We will set several variables: the user name (user), the package name
	   (pkgname), and the package home directory (homedir) */

	const char VAR_USER[] = VAR_PREFIX "USER";
	const char VAR_PKGNAME[] = VAR_PREFIX "PKGNAME";
	const char VAR_HOMEDIR[] = VAR_PREFIX "HOMEDIR";
		
	char homedir[PATH_MAX];
	char pkgname[PKG_MAX_LENGTH];

	xlog ("Generating environment...\n");
	xdebug ("%s (%s,%s)\n",__FUNCTION__,username,pkgdir);
	if (pkgrp_p (username)){
		strcpy (pkgname,"");
	}
	else if (pkg_user_to_name (username,pkgname) < 0){
		return -1;
	}

	if (pkgdir == NULL){
		if ( ( pkgdir = ugrp_user_homedir (username) ) == NULL){
			return -1;
		}
		xassert (strlen (pkgdir) < PATH_MAX);
		strcpy (homedir,pkgdir);
	}
	/* Homedir should also be a string of length 0 */
	else if (strlen (pkgdir) == 0){
		strcpy (homedir,"");
	}
	else {
		xassert ((strlen (pkgdir) + strlen ("/") + strlen (pkgname))
			 < PATH_MAX);
		strcpy (homedir,pkgdir);
		strcat (homedir,"/");
		strcat (homedir,pkgname);
	}

	if ((setenv (VAR_USER,username,1) < 0)
	    || (setenv (VAR_PKGNAME,pkgname,1) < 0)
	    || (setenv (VAR_HOMEDIR,homedir,1) < 0)){
		error_set (CUSTOM_ERROR,"Could not set environment correctly: "
			   "%s",strerror (errno));
		return -1;
	}

	return 0;
}

int
run_postinst_scripts (const struct dictionary *args,
		      const struct string_list *exclude_list)
{
	DIR *dp;
	struct dirent *ep;

	xlog ("Running postinstall scripts\n");
	if (! (dp = opendir (DEFAULT_POSTINST_DIR))){
		error_set (DIR_ERROR,DEFAULT_POSTINST_DIR,strerror (errno));
		return -1;
	}

	errno = 0;
	while ( (ep = readdir (dp)) ){
		const char *argument;
		struct string_list_el *pos;
		int r;
		char cmd[PATH_MAX];
		char *script_argv[] = {"command","argument",NULL};

		/* Ignore hidden files */
		if (ep->d_name[0] == '.'){
			continue;
		}
		if (string_list_find (exclude_list,ep->d_name,&pos,
				      &string_beginwith_p) < 0){
			return -1;
		}
		/* d_name begins with some elements in exclude_list */
		else if (pos != NULL){
			continue;
		}

		/* If there is no argument, then argument will be NULL and
		   everything will be fine in script_argv */
		argument = dictionary_get_val (args,ep->d_name);
		xassert ((strlen (DEFAULT_POSTINST_DIR) + strlen ("/") 
			  + strlen (ep->d_name)) < PATH_MAX);
		strcpy (cmd,DEFAULT_POSTINST_DIR);
		strcat (cmd,"/");
		strcat (cmd,ep->d_name);
		script_argv[0] = cmd;
		script_argv[1] = (char *)(argument);

		r = proc_run (cmd,script_argv);
		if (r < 0){
			return -1;
		}
		else if (r != 0){
			error_set (CMD_ERROR,cmd,script_argv,r);
			return -1;
		}
		errno = 0;
	}

	if (errno != 0){
		error_set (DIR_ERROR,DEFAULT_POSTINST_DIR,strerror (errno));
		return -1;
	}
	closedir (dp);

	return 0;
}

int 
list_files (const char *username,const char *findcmd)
{
	/* List of owned (package user is the owner or group) and extra files
	   part of the package */
	struct string_list owned_files;
	struct string_list extra_files;
	struct string_list shared_list;
	struct string_list unique_list;
	struct string_list file_list;
	char pkgname[PKG_MAX_LENGTH];

	if (pkg_user_to_name (username,pkgname) < 0){
		return -1;
	}

	if (gen_env (username,NULL) < 0){
		return -1;
	}
	string_list_init (&owned_files), string_list_init (&extra_files),
		string_list_init (&shared_list), string_list_init(&unique_list),
		string_list_init (&file_list);

	if (find_extra_files (username,&extra_files) < 0){
		error_set (CUSTOM_ERROR,"Could not find extra files: %s",
			   error_describe ());
		return -1;
	}
	if (find_owned_files (username,findcmd,&owned_files) < 0){
		error_set (CUSTOM_ERROR,"Could not find owned files: %s",
			   error_describe ());
		return -1;
	}

	string_list_cat (&owned_files,&extra_files,&file_list);
	string_list_free (&owned_files), string_list_free (&extra_files);
	if (find_unique_files (username,&file_list,&unique_list,
			       &shared_list) < 0){
		return -1;
	}
	if (! string_list_empty_p (&shared_list)){
		xmsg ("The following files are shared with other packages:\n");
		string_list_print (xstdout,&shared_list);
		xmsg ("\n");
	}
	xmsg ("The following files are unique to package %s\n",pkgname);
	string_list_print (xstdout,&unique_list);
	string_list_free (&shared_list) , string_list_free (&unique_list) ,
		string_list_free (&file_list);

	return 0;
}

int
list_instdir (const char *path,const char *findcmd)
{
	/* Used to speedup things: once we have found all installation
	   directories, we don't have to rerun the command even if the function
	   is called several times with different path arguments. */
	static int know_instdir = 0;
	static struct string_list instdir;

	struct string_list dir_list;
	struct string_list_el *it;
	int r;

	xlog ("Listing installation directories in %s\n",path);
	if (!know_instdir){
		if (gen_env (INSTALL_GROUP,"") < 0){
			return -1;
		}
		string_list_init (&instdir);
		xlog ("Running find command...\n");
		if (find_group_files (INSTALL_GROUP,findcmd,&instdir) < 0){
			error_set (CUSTOM_ERROR,"Error while running the find "
				   "command: %s",error_describe ());
			return -1;
		}
		/* Check that all files listed are directories */
		for (it = string_list_it (&instdir);it != NULL;it = it->next){
			r = fs_is_directory_p (it->string);
			if (r < 0){
				error_set (CUSTOM_ERROR,"Error while checking "
					   "the install directories list: %s",
					   error_describe ());
				return -1;
			}
			else if (!r){
				xwarn ("File %s should be a directory\n",
				       it->string);
			}
		}
		know_instdir = 1;
	}

	string_list_init (&dir_list);
	if (find_inpath (&instdir,path,&dir_list) < 0){
		return -1;
	}

	string_list_print (xstdout,&dir_list);
	string_list_free (&dir_list);
	
	return 0;
}

int
list_shared (const char *path,const char *findcmd)
{
	/* Used to speed things up (see list_instdir) */
	static int know_shared = 0;
	static struct string_list shared_list;

	struct string_list subfile_list;
	struct string_list_el *it;
	int r;

	xlog ("Listing shared directories in %s\n",path);
	if (!know_shared){
		if (gen_env (SHARED_GROUP,"") < 0){
			return -1;
		}
		string_list_init (&shared_list);
		xlog ("Running find command...\n");
		if (find_group_files (SHARED_GROUP,findcmd,&shared_list) < 0){
			error_set (CUSTOM_ERROR,"Error while running the find "
				   "command: %s",error_describe ());
			return -1;
		}
		/* Check that all files listed are regular files */
		for (it = string_list_it (&shared_list);it != NULL
			     ;it = it->next){
			r = fs_is_directory_p (it->string);
			if (r < 0){
				error_set (CUSTOM_ERROR,"Error while checking "
					   "the shared files list: %s",
					   error_describe ());
				return -1;
			}
			else if (r){
				xwarn ("File %s should be a regular file\n",
				       it->string);
			}
		}
		know_shared = 1;
	}

	string_list_init (&subfile_list);
	if (find_inpath (&shared_list,path,&subfile_list) < 0){
		return -1;
	}

	string_list_print (xstdout,&subfile_list);
	string_list_free (&subfile_list);

	return 0;	
}

int 
find_installed (struct string_list *installed)
{
	struct passwd *ud;

	setpwent ();
	errno = 0;
	while ( (ud = getpwent ()) != NULL){
		if (pkguser_p (ud->pw_name)){
			string_list_add (installed,ud->pw_name);
		}
		errno = 0;
	}
	endpwent ();
	if (errno != 0){
		error_set (UGFIND_ERROR,NULL,strerror (errno));
		return -1;
	}

	return 0;
}

int
install_log_sanitize (void)
{
	xdebug ("%s ()\n",__FUNCTION__);
	if (chown (INSTALL_LOG,getuid (),getgid ()) < 0){
		error_set (FPERM_ERROR,INSTALL_LOG,strerror (errno));
		return -1;
	}

	return 0;
}

int
list_installed_pkg (void)
{
	int r;
	char pkgname[PKG_MAX_LENGTH];
	struct string_list installed;
	struct string_list_el *it;

	string_list_init (&installed);

	if (find_installed (&installed) < 0){
		return -1;
	}
		
	for (it = string_list_it (&installed);it != NULL;it = it->next){
		r = pkg_user_to_name (it->string,pkgname);
		xassert (r == 0);
			
		xstdout ("%s\n",pkgname);
	}

	return 0;
}

int
add_file (const char *file,const char *username,int change_owner,
	  int change_group)
{
	/* We assume the file is not already listed in the extra file
	   list. This should be done in the sanity checking part */

	if (change_owner || change_group){
		xlog ("Changing owner/group of file %s\n",file);
		if (change_owner){
			if (fs_file_chown (file,username) < 0){
				return -1;
			}
		}
		if (change_group){
			if (fs_file_chgrp (file,username) < 0){
				return -1;
			}
		}
	}
	else {
		char resolved[PATH_MAX];
		FILE *extra = open_extra (username,"a");

		if (extra == NULL){
			return -1;
		}

		if (realpath (file,resolved) == NULL){
			error_set (RPATH_ERROR,file,strerror (errno));
			return -1;
		}
		
		xlog ("Adding file %s to the list of extra files\n",resolved);

		fprintf (extra,"%s\n",resolved);
		io_fclose (extra);
	}
	
	return 0;
}

int
free_file (const char *file,const char *username,const char *new_owner,
	   const char *new_group)
{
	/* First, remove the file from the list of extra files if it is in
	   it. */

	FILE *extra = open_extra (username,"w");
	FILE *bckp;
	char line[PATH_MAX + 1];
	char file_owner[UGRP_MAX_LENGTH];
	char file_group[UGRP_MAX_LENGTH];
	char next_owner[UGRP_MAX_LENGTH] = "root";
	char next_group[UGRP_MAX_LENGTH] = "root";

	int r;

	xlog ("Removing file %s from list of extra file\n",file);
	if (extra == NULL){
		return -1;
	}
	bckp = io_fopen_backup (extra);
	if (bckp == NULL){
		return -1;
	}
	errno = 0;
	while (fgets (line,PATH_MAX,bckp) != NULL){
		if (lastchar (line) != '\n'){
			error_set (LONGPATH_ERROR,"Line beggining by %s in "
				   "list of added files",line);
			return -1;
		}
		chomp (line);
		r = fs_samefile_p (file,line);
		if (r < 0){
			return -1;
		}
		/* If this is not the file we are looking for, just write it
		   back to the original file */
		else if (!r){
			fprintf (extra,line);
			fprintf (extra,"\n");
		}
		errno = 0;
	}
	if (errno != 0){
		error_set (CUSTOM_ERROR,"Something happend while reading "
			   "content of added file: %s",strerror (errno));
		return -1;
	}
	io_fclose (extra);
	io_fclose (bckp);
	if (fs_file_owner (file,file_owner) < 0){
		return -1;
	}
	if (fs_file_group (file,file_group) < 0){
		return -1;
	}
	xlog ("Changing file owner if necessary\n");
	if (strcmp (file_owner,username) == 0){
		if ((new_owner != NULL) && (strlen (new_owner) > 0)){
			xassert (strlen (new_owner) < UGRP_MAX_LENGTH);
			strcpy (next_owner,new_owner);
		}
		if (fs_file_chown (file,next_owner) < 0){
			return -1;
		}
	}
	if (strcmp (file_group,username) == 0){
		if ((new_group != NULL) && (strlen (new_group) > 0)){
			xassert (strlen (new_group) < UGRP_MAX_LENGTH);
			strcpy (next_group,new_group);
		}
		if (fs_file_chgrp (file,next_group) < 0){
			return -1;
		}
	}

	return 0;
}

int 
create_group (const char *groupname)
{
	char *const GRPADD_ARGV[]={GROUPADD_PATH,(char *)(groupname),NULL};
	int r = proc_run (GROUPADD_PATH,GRPADD_ARGV);

	xlog ("Creating group %s\n",groupname);
	if (r < 0){
		error_set (CUSTOM_ERROR,"Could not run groupadd command: %s ",
			   error_describe ());
		return -1;
	}
	else if (r != 0){
		error_set (CMD_ERROR,GROUPADD_PATH,GRPADD_ARGV,r);
		return -1;
	}
	
	return 0;
}

int
add_instdir (const char *filename)
{
	int r;

	xlog ("Let %s be an install directory\n",filename);

	/* Sanity check */
	r = fs_is_directory_p (filename);
	if (r < 0){
		return -1;
	}
	else if (!r){
		error_set (CUSTOM_ERROR,"File %s is not a directory",filename);
		return -1;
	}
	
	/* Create the install group if it does not exist */
	r = ugrp_group_exists_p (INSTALL_GROUP,NULL);
	if (r < 0){
		return -1;
	}
	else if (!r){
		if (create_group (INSTALL_GROUP) < 0){
			error_set (CUSTOM_ERROR,"Could not create install "
				   "group: %s",error_describe ());
			return -1;
		}
	}

	if (fs_file_chgrp (filename,INSTALL_GROUP) < 0){
		return -1;
	}

	if (fs_file_set_sticky (filename,1) < 0){
		return -1;
	}
	if (fs_file_set_gw (filename,1) < 0){
		return -1;
	}

	return 0;
}

int
remove_instdir (const char *filename,const char *new_group,int new_perm)
{
	const mode_t MODE = 0755;

	mode_t new_mode = ((new_perm >= 0) ? new_perm : MODE);
	char file_owner[UGRP_MAX_LENGTH];
	const char *next_group;

	xlog ("%s will not be an installation directory anymore\n",filename);

	if (fs_file_owner (filename,file_owner) < 0){
		return -1;
	}

	if ((new_group != NULL) && (strlen (new_group) != 0)){
		next_group = new_group;
	}
	else {
		next_group = file_owner;
	}

	if (fs_file_chgrp (filename,next_group) < 0){
		return -1;
	}
	if (chmod (filename,new_mode) < 0){
		return -1;
	}

	return 0;
}

int
add_shared (const char *filename)
{
	int r;

	xlog ("Let %s be a shared file\n",filename);
	r = ugrp_group_exists_p (SHARED_GROUP,NULL);
	if (r < 0){
		return -1;
	}
	else if (!r){
		if (create_group (SHARED_GROUP) < 0){
			error_set (CUSTOM_ERROR,"Could not create shared "
				   "group: %s",error_describe ());
			return -1;
		}
	}

	if (fs_file_chgrp (filename,SHARED_GROUP) < 0){
		return -1;
	}
	if (fs_file_set_gw (filename,1) < 0){
		return -1;
	}

	return 0;
}

int
remove_shared (const char *filename,const char *new_group,int new_perm)
{
	const mode_t MODE = 0644;

	mode_t new_mode = ((new_perm >= 0) ? new_perm : MODE);
	char file_owner[UGRP_MAX_LENGTH];
	const char *next_group;

	xlog ("%s will not be a shared file anymore\n",filename);

	if (fs_file_owner (filename,file_owner) < 0){
		return -1;
	}

	if ((new_group != NULL) && (strlen (new_group) != 0)){
		next_group = new_group;
	}
	else {
		next_group = file_owner;
	}

	if (fs_file_chgrp (filename,next_group) < 0){
		return -1;
	}
	if (chmod (filename,new_mode) < 0){
		return -1;
	}

	return 0;
}
