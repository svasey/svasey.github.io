/* Contains all the functions related to command line options parsing */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_CLOPT_H
#define INCLUDE_CLOPT_H

#include <getopt.h>

#include "action.h"


/* Given a long option string, generate and allocate a short option string for
   getopt. Return it. */
char *
gen_shortopt_string (struct option longopt[],char **shortopt);

/* Print the program's help text (--help) , using xstdout */
void
help_text (void);

/* Print a short message giving information about where to report bugs,
   followed by a new line, using xstdout */
void
bug_text (void);

/* Print a short text giving the program's usage, followed by a new line using
   xstdout */
void
usage_text (void);

/* Print version information, using xstdout */
void
version_text (void);

/* Print some information about the settings urpkg was compiled with */
void
info_text (void);

/* Return true if the given (long) option string is a special option (i.e an
   option specifying arguments to some user postinst script) */
int
is_specialopt_p (const char *optstr);

/* Process the special option optstr (i.e extract the name and arguments of the
   script) and put the results into the action object. */
void
process_specialopt (const char *optstr,struct user_action *action);

/* Parse the command line options and arguments; Put what the user asked to do
   in user_action. Otherwise, exit with an error message. Also handle the
   standard --help and --version options. This does not check for the
   meaningfulness of individual arguments. Return -1 on failure, 0 on success */
int
parse_options(int argc,char *argv[],struct user_action *user_action);

/* Parse the command line arguments (what comes after the options :-). start
   describes the starting point of our investigation. Again, does not check for
   the meaningfulness of individual arguments. The results are put in
   action. Assume that action->action is not UNKNOWN. Return -1 on failure, 0 on
   sucess */
int
parse_args(int argc,char *argv[],int start,struct user_action *action);

#endif	/* INCLUDE_CLOPT_H */
