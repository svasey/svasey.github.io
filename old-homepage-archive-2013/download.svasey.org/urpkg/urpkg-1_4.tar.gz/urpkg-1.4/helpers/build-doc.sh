#!/bin/bash

# Build all the documentation (manpages, html, pdf...). Argument: project root
# directory , project doc build directory

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 project_root_directory documentation_build_directory" 1>&2
}

PROJECT_ROOT="$1"
SRC="${PROJECT_ROOT}/doc/main.xml"
DOCBUILD_ROOT="$2"

if [ $# -ne 2 ]; then
    usage
    exit 1
fi

cd "$DOCBUILD_ROOT"

${PROJECT_ROOT}/helpers/gen-varentitiesxml.sh $PROJECT_ROOT

STYLESHEETS_DIR="/usr/share/xml/docbook/xsl-stylesheets-1.73.2/xhtml"

XSLT_CMD="xsltproc --path $PWD"

# Convert everything to xhtml (transitionnal unfortunately)
$XSLT_CMD ${STYLESHEETS_DIR}/chunk.xsl $SRC
$XSLT_CMD ${STYLESHEETS_DIR}/docbook.xsl $SRC > index-nochunk.html


# Build the text documentation (e.g INSTALL, BUGS...) only the README file is
# handwritten.

for f in $PWD/*.html ; do
    if echo $f | grep 'nochunk.html$' > /dev/null; then
	continue
    elif grep 'id="compile-install">' $f >/dev/null ; then
	INSTALL_FILE=$f
    elif grep 'id="todo">' $f >/dev/null ; then
	TODO_FILE=$f
    elif grep 'id="bugs">' $f >/dev/null ; then
	BUGS_FILE=$f
    elif grep 'id="faq">' $f >/dev/null ; then
	FAQ_FILE=$f
    fi
done

if [ ! "$INSTALL_FILE" -o ! "$TODO_FILE" -o ! "$BUGS_FILE" -o ! "$FAQ_FILE" ];
then
    echo "Some documentation files were not found" 1>&2
    exit 1
fi

LYNX_DUMP="lynx -dump -nolist"
IMPORTANT_TEXT="INSTALL TODO BUGS FAQ"

$LYNX_DUMP $INSTALL_FILE > INSTALL
$LYNX_DUMP $TODO_FILE > TODO
$LYNX_DUMP $BUGS_FILE > BUGS
$LYNX_DUMP $FAQ_FILE > FAQ

# Build the manual pages

for f in urpkg.1.man.xml urpkgize.1.man.xml ; do
    xmlto --searchpath $PWD --skip-validation man ${PROJECT_ROOT}/doc/$f
done

# cp -v $IMPORTANT_TEXT $PROJECT_ROOT

exit 0
