#!/bin/bash

# Bootstrap the installation of urpkg: use urpkg to install itself. Takes
# several argument: the project root directory and the project build directory

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 project_root_dir build_dir" 1>&2
}

if [ $# -ne 2 ]; then
    usage
    exit 1
fi

PROJECT_ROOT="$1"
BUILD_DIR="$2"
URPKG="${BUILD_DIR}/src/urpkg"
PKGDIR="$(mktemp -d -t urpkg.XXXXXXXX)"
VERSION="$(${PROJECT_ROOT}/helpers/version.sh $PROJECT_ROOT)"
FINDCMD="${PROJECT_ROOT}/scripts/find"
TRUE_PKGDIR="$($URPKG --info | grep 'package directory' | sed -r 's/.+: //')"

chmod -Rv o+xrw ${BUILD_DIR}
$URPKG --install --pkg-name="urpkg-${VERSION}" --findcmd="$FINDCMD" \
    --pkg-dir="$PKGDIR" --no-preinst --no-postinst make -C $BUILD_DIR install

cp -rav ${PKGDIR}/urpkg-${VERSION} ${TRUE_PKGDIR}/

USERNAME="$(stat --format=%U ${TRUE_PKGDIR}/urpkg-${VERSION})"

usermod --home ${TRUE_PKGDIR}/urpkg-${VERSION} $USERNAME

rm -rv $PKGDIR

exit 0


