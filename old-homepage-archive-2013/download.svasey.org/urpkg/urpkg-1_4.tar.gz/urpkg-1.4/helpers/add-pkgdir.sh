#!/bin/bash

### Run by the slackware-creating script. Add the package directory to the
### slackware package. The first argument is the path to the package tree
### directory

set -o errexit

if [ $# -ne 1 ]; then
    echo "ERROR: expected excatly one argument" 1>&2
    exit 1
fi

PKGTREE="$1"
if [ ! -d ${PKGTREE/usr/urpkg ]; then
    mkdir -m 0755 ${PKGTREE}/usr/urpkg
fi

exit 0
