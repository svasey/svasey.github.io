#!/bin/bash

# Update the text files in our source directory (TODO, FAQ etc...) by copying
# the files in the documentation build directories, given as first argument. The
# project root is the second argument

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 documentation_build_directory project_root_directory" 1>&2
}

BUILD_DOCDIR="$1"
PROJECT_ROOT="$2"

if [ $# -ne 2 ]; then
    usage
    exit 1
fi

for f in ${BUILD_DOCDIR}/{TODO,FAQ,INSTALL,BUGS} ; do
    cp -v $f $PROJECT_ROOT/.
done

exit 0
