#!/bin/bash

### Run by the slackware-creating script. Add the package directory to the
### slackware package. The first argument is the path to the package tree
### directory.

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.

set -o errexit

if [ $# -ne 1 ]; then
    echo "ERROR: expected exactly one argument" 1>&2
    exit 1
fi

PKGTREE="$1"
PKGDIR=$(urpkg --info --quiet | grep "Default package directory:" | \
    sed -r 's@.+: (.+)@\1@')

if [ ! -d ${PKGTREE}/${PKGDIR} ]; then
    mkdir -m 0755 ${PKGTREE}/${PKGDIR}
fi

exit 0
