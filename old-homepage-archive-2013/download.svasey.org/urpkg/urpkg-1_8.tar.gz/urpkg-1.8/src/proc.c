/* Contains implementations of functions defined in proc.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "proc.h"
#include "io.h"
#include "error.h"
#include "mem.h"

FILE *
proc_open (const char *cmd,char *const argv[],int *pid,FILE **err)
{
	const int READ = 0;
	const int WRITE = 1;
	FILE *out = NULL;
	int p_out[2];		/* pipe */
	int p_err[2];

	xdebug ("%s (%s , %s , %p , %p)\n",__FUNCTION__,cmd,
		proc_args_to_str (argv),pid,err);

	xassert (strcmp (argv[0],cmd) == 0);
	if ((pipe (p_out) < 0) || (pipe (p_err) < 0)){
		error_set (PIPE_C_ERROR,strerror (errno));
		return NULL;
	}
	*pid = fork ();
	if (*pid < 0){
		error_set (FORK_ERROR,strerror (errno));
		return NULL;
	}
	else if (*pid == 0){	/* We are in child process */
		/* Close reading end of the pipe */
		close (p_out[READ]);
		close (p_err[READ]);
		/* Redirect stdout to writing end of the pipe */
		if ((dup2 (p_out[WRITE],fileno (stdout)) < 0)
		    || ((err != NULL)
			&& (dup2 (p_err[WRITE],fileno (stderr)) < 0))){
			
			error_set (DUP_ERROR,strerror (errno));
			error_exit (-1,0);
		}
		else if (err == NULL){
			close (p_err[WRITE]);
		}

		/* Set the process real uid and gid to the effective ones, just
		   in case the caller wants us to drop our privilleges. */
		if (setreuid (geteuid (),-1) < 0
		    || setregid (getgid (),-1) < 0){
			error_set (PRIV_ERROR,strerror (errno));
			error_exit (-1,0);
		}
		if (execvp (cmd,argv) < 0){
			error_set (EXEC_ERROR,cmd,argv,strerror (errno));
			error_exit (-1,0);
		}
	}
	else {	/* Parent process */
		/* Close write end of the pipe */
		close (p_out[WRITE]);
		close (p_err[WRITE]);
		if ((! (out = fdopen (p_out[READ],"r")))
		    || ((err != NULL) &&
			( ( *err = fdopen (p_err[READ],"r") ) == NULL))){
			error_set (PIPE_R_ERROR,strerror (errno));
			return NULL;
		}
		/* Add to process table */
		proc_table_add (*pid,out,((err == NULL) ? NULL : *err));
	}

	xdebug ("%s: %p\n",__FUNCTION__,out);
	return out;
}

int
proc_close (int pid)
{
	/* Exit status of the program */
	int status;
	
	xdebug ("%s (%d)\n",__FUNCTION__,pid);

	if (waitpid (pid,&status,0) < 0){
		error_set (PWAIT_ERROR,pid,strerror (errno));
		return -1;
	}
	/* Once found, remove from process_table */
	proc_table_remove (pid,NULL,NULL);

	xdebug ("proc_close: %d\n",status);
	return status;
}

int
proc_close_all (void)
{
	int i;
	int r;
	int ret = 0;

	xdebug ("%s ()\n",__FUNCTION__);
	
	for (i = 0;i < MAX_PROCESS;i++){
		if (process_table[i].pid == 0){
			continue;
		}
		else {
			r = proc_close (process_table[i].pid);
			if (r < 0){
				ret = r;
			}
		}
	}

	return ret;
}

int
proc_kill (int pid)
{
	/* True if we have already sent the process the TERM signal */
	int sent_term = 0;
	
	xmsg ("Terminating process %d\n",pid);

	while (1){
		/* First, check whether the process hasn't already terminated */
		int r = waitpid (pid,NULL,WNOHANG);
		
		if (r < 0){
			error_set (PWAIT_ERROR,pid,strerror (errno));
			return -1;
		}
		if (r == pid){
			break;
		}

		/* Send the TERM signal */
		xmsg ("Sending the TERM signal\n");
		if (!sent_term && (kill (pid,SIGTERM) < 0)){
			error_set (SIG_ERROR,pid,SIGTERM,strerror (errno));
			return -1;
		}
		else if (!sent_term){
			sleep (2); /* Leave the process time to terminate */
			sent_term = 1;
			continue;
		}
		xmsg ("Sending the KILL signal\n");
		/* Send the KILL signal */
		if (kill (pid,SIGKILL) < 0){
			error_set (SIG_ERROR,pid,SIGKILL,strerror (errno));
			return -1;
		}

		break;
	}

	return 0;
}

int
proc_run (const char *cmd,char *const argv[])
{
	int pid;
	FILE *out;
	int r;

	xlog ("Running command %s %s\n",cmd,proc_args_to_str (argv));

	if ( (out = proc_open (cmd,argv,&pid,NULL)) == NULL){
		error_set (CUSTOM_ERROR,"Could not run command %s %s : %s"
			   ,cmd,proc_args_to_str (argv),error_describe ());
		return -1;
	}

	io_print_stream (xstdout,out,NULL);

	if ( (r = proc_close (pid)) < 0){
		error_set (CUSTOM_ERROR,"Could not end process launched by "
			   "command %s %s : %s",cmd,proc_args_to_str (argv)
			   ,error_describe ());
		return -1;
	}
	
	xlog ("Command %s returned with exit status %d\n",cmd,r);
	return r;
}

const char *
proc_args_to_str (char *const args[])
{
	static char *str = NULL;
	int length;		/* Total length of all strings */
	int i;

	if (str != NULL){
		free (str);
	}
	
	length = 0;
	for (i = 0;args[i] != NULL;i++){
		length += strlen (args[i]) + 1;
	}
	str = xmalloc ((length + 2) * sizeof(char));
	str[0] = '\0';
	for (i = 0;args[i] != NULL;i++){
		strcat (str,args[i]);
		if (args[i + 1] != NULL){
			strcat (str," ");
		}
	}

	return str;
}

void
proc_table_add (int pid,FILE *out,FILE *err)
{
	int i;
	
	xdebug ("%s (%p,%p,%d)",__FUNCTION__,out,err,pid);

	for (i = 0;(i < MAX_PROCESS) && (process_table[i].pid != 0);i++);
	xassert (i < MAX_PROCESS);
	process_table[i].pid = pid;
	process_table[i].out_stream = out;
	process_table[i].err_stream = err;
}

void
proc_table_remove (int pid,const FILE *out,const FILE *err)
{
	int i;
	
	xdebug ("%s (%d,%p,%p)",__FUNCTION__,pid,out,err);

	for (i = 0;i < MAX_PROCESS;i++){
		if (((pid != 0) && (process_table[i].pid == pid))
		    || ((out != NULL) && (process_table[i].out_stream == out))
		    || ((err != NULL) && (process_table[i].err_stream == err))){
			/* No need to refill the hole we created, just zero the
			   pid and the next element will be added here. */
			
			process_table[i].pid = 0;
			if (process_table[i].out_stream != NULL){
				fclose (process_table[i].out_stream);
			}
			process_table[i].out_stream = NULL;
			if (process_table[i].err_stream != NULL){
				fclose (process_table[i].err_stream);
			}
			process_table[i].err_stream = NULL;
			break;
		}
	}
	/* Check that the object we were looking for existed */
	xassert (i < MAX_PROCESS);
}

void
proc_table_init (void)
{
	int i;

	for (i = 0;i < MAX_PROCESS;i++){
		process_table[i].pid = 0;
		process_table[i].err_stream = NULL; 
		process_table[i].out_stream = NULL;
	}
}
