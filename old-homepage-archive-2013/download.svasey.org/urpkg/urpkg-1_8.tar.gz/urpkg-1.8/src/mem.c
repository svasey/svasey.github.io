/* Contains implementation of the functions in mem.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <stdlib.h>

#include "mem.h"
#include "io.h"
#include "error.h"

void *
xmalloc (size_t size)
{
	static int had_error = 0;
	void *ret = malloc (size);

	if (ret == NULL){
		xerror ("Not enough memory to continue");

		if (!had_error){
			had_error = 1;
			error_cleanup ();
		}
		exit (1);
	}

	return ret;
}

void *
xrealloc (void *ptr,size_t size)
{
	static int had_error = 0;
	void *ret = realloc (ptr,size);

	if (ret == NULL){
		xerror ("Not enough memory to continue");

		if (!had_error){
			had_error = 1;
			error_cleanup ();
		}
		exit (1);
	}

	return ret;
	
}
