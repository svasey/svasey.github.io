#!/bin/bash
# Print the program's version number. Argument: project root directory

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

PROJECT_ROOT="$1"

if [ -f ${PRJECT_ROOT}/VERSION ]; then
    VERSION="$(cat VERSION)"
elif (which git && which sed) &>/dev/null ; then
    VERSION="$(git-describe --tags)"
    VERSION="$(echo $VERSION | sed 's/^v//')"
    DIFF="$(git --no-pager diff)"
    if [ "$DIFF" ]; then
	VERSION="${VERSION}-custom"
    fi
else
    VERSION="unknown"
fi

echo "$VERSION"

exit 0