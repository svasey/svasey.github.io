/* Contains implementation of the functions declared in pkg.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "pkg.h"
#include "urpkg.h"
#include "io.h"
#include "error.h"
#include "str.h"

int
pkg_user_name_table_build (void)
{
	struct passwd *ud;
	int r;

	xdebug ("%s ()\n",__FUNCTION__);
	dictionary_init (&pkg_user_name_table);
	
	setpwent ();
	errno = 0;
	while ( (ud = getpwent ()) != NULL){
		r = pkguser_p (ud->pw_name);
		if (r < 0){
			return -1;
		}
		else if (r){
			const char *username = ud->pw_name;
			const char *pkgname = ugrp_read_comment (username);

			if (pkgname == NULL){
				return -1;
			}
			pkg_user_name_add_match (username,pkgname);

		}
		errno = 0;
	}
	endpwent ();
	if (errno != 0){
		error_set (UGFIND_ERROR,NULL,strerror (errno));
		return -1;
	}

	pkg_built_table = 1;

	return 0;
}

void
pkg_user_name_add_match (const char *username,const char *pkgname)
{
	dictionary_add (&pkg_user_name_table,username,pkgname);
}

int
pkg_guess (char *name)
{
	char cwd[PATH_MAX];
	char *base;

	xlog ("Guessing package name\n");

	if (getcwd (cwd,PATH_MAX) == NULL){
		error_set (DIR_ERROR,"Current directory",strerror (errno));
		return -1;
	}

	if (strlen (cwd) == 0){
		error_set (CUSTOM_ERROR,"Could not guess package name: no "
			   "current directory");
		return -1;
	}

	base = strrchr (cwd,'/') + 1;
	if (base == NULL){
		error_set (CUSTOM_ERROR,"No / in current directory %s",cwd);
		return -1;
	}
	if (strchr (base,'-') == NULL){
		time_t timer = time (NULL);
		struct tm *date;
		/* Version string: -yyymmdd + null byte: 10 characters */
		char datestr[10];

		date = localtime (&timer);
		sprintf (datestr,"-%.4d%.2d%.2d",date->tm_year + 1900,
			 date->tm_mon + 1,date->tm_mday);
		xassert ((strlen (cwd) + strlen (datestr)) < PATH_MAX);
		strcat (cwd,datestr);
	}

	if (strlen (base) >= PKG_MAX_LENGTH){
		error_set (CUSTOM_ERROR,"Cannot guess package name from "
			   "current directory: too long (%s has more than "
			   "%d characters",base,PKG_MAX_LENGTH - 1);
		return -1;
	}

	strcpy (name,base);
	
	xlog ("Guess: package name: '%s'\n",name);
	
	return 0;
}

int
pkg_build_user (const char *name,char *user)
{
	xlog ("Building user from package name %s\n",name);

	xassert (name != NULL);
	if ((strlen (name) + strlen (USER_PREFIX)) >= UGRP_MAX_LENGTH){
		error_set (CUSTOM_ERROR,"Cannot build username: too long "
			   "(%s%s has more than %d characters",USER_PREFIX,
			   name,UGRP_MAX_LENGTH - 1);
		return -1;
	}
	sprintf (user,"%s%s",USER_PREFIX,name);
	ugrp_replace_weirdchar (user);

	xlog ("Built user %s from package name %s\n",user,name);
	return 0;
}

int
pkg_name_to_user (const char *name,char *user,int in_db)
{
	struct string_list resolve_list;
	struct string_list_el *it;
	int n_match = 0; /* Number of match found */
	/* Resolved package name */
	const char *res_pkgname = NULL;

	xdebug ("%s (%s,%p)\n",__FUNCTION__,name,user);
	if (!pkg_built_table){
		if (pkg_user_name_table_build () < 0){
			return -1;
		}
	}
	
	if (!in_db){
		if (name == NULL){
			char pkgname[PKG_MAX_LENGTH];
			if (pkg_guess (pkgname) < 0){
				return -1;
			}
			name = pkgname;
		}
		if (pkg_build_user (name,user) < 0){
			return -1;
		}
		if (check_pkgname (user) < 0){
			return -1;
		}

		pkg_user_name_add_match (user,name);
	}
	else {
		xlog ("Resolving package name %s\n",name);
		string_list_init (&resolve_list);
		dictionary_to_list (&pkg_user_name_table,&resolve_list);
		for (it = string_list_it (&resolve_list);it != NULL
			     ;it = it->next->next){
			const char *username = it->string;
			const char *pkgname = it->next->string;
			
			if (string_beginwith_p (pkgname,name)){
				n_match++;
				if (n_match > 1){
					error_set (CUSTOM_ERROR,"Ambiguous "
						   "package name %s: "
						   "%s or %s ?",
						   name,res_pkgname,pkgname);
					return -1;
				}
				xassert (strlen (username) < UGRP_MAX_LENGTH);
				strcpy (user,username);
				res_pkgname = pkgname;
			}
		}
		/* No match found */
		if (n_match == 0){
			error_set (CUSTOM_ERROR,"No match found for package "
				   "name %s",name);
			return -1;
		}
		xlog ("Resolved to user %s\n",user);
		string_list_free (&resolve_list);
	} /* End: else (if name != NULL) */

	return 0;
}

int
pkg_user_to_name (const char *username,char *pkgname)
{
	/* Resolved package name */
	const char *res_pkgname;

	xdebug ("%s (%s)\n",__FUNCTION__,username);
	if (!pkg_built_table){
		if (pkg_user_name_table_build () < 0){
			return -1;
		}
	}

	res_pkgname = dictionary_get_val (&pkg_user_name_table,username);

	if (res_pkgname == NULL){
		error_set (CUSTOM_ERROR,"No matching package name found for "
			   "user %s",username);
		return -1;
	}

	xassert (strlen (res_pkgname) < PKG_MAX_LENGTH);
	strcpy (pkgname,res_pkgname);

	xdebug ("%s : %s\n",__FUNCTION__,pkgname);

	return 0;
}

int
pkguser_p (const char *username)
{
	/* If username is a package user, it must begin with UGRP_PREFIX, and
	   the comment in its comment field must be its package name */
	const char *comment;
	int i;
	int r;
	const char *c;

	xdebug ("%s (%s)\n",__FUNCTION__,username);

	if (pkg_built_table){
		int ret;
		if (dictionary_get_val (&pkg_user_name_table,username) != NULL){
			ret = 1;
		}
		else {
			ret = 0;
		}
		xdebug ("%s : %d\n",__FUNCTION__,ret);
		return ret;
	}

	if (! string_beginwith_p (username,USER_PREFIX)){
		xdebug ("%s : 0\n",__FUNCTION__);
		return 0;
	}

	r = ugrp_user_exists_p (username,NULL);
	if (r < 0){
		return -1;
	}
	else if (!r){
		xdebug ("%s : %d\n",__FUNCTION__,0);
		return 0;
	}

	comment = ugrp_read_comment (username);
	if (comment == NULL){
		return -1;
	}

	c = username + strlen (USER_PREFIX);
	for (i = 0;i < strlen (comment);i++){
		/* The real name must match the username, except for special
		   character, replaced by _ in the username */
		if ((*c != comment[i]) && (*c != '_')){
			xdebug ("%s : 0\n",__FUNCTION__);
			return 0;
		}
		c++;
	}

	/* The two strings must end at the same time */
	if (comment[i] == *c){
		xdebug ("%s : 1\n",__FUNCTION__);
		return 1;
	}
	else {
		xdebug ("%s : 0\n",__FUNCTION__);
		return 0;
	}
}

int
pkgrp_p (const char *name)
{
	if ((strcmp (name,INSTALL_GROUP) == 0)
	    || (strcmp (name,SHARED_GROUP) == 0)){
		return 1;
	}
	else {
		return 0;
	}
}
	
