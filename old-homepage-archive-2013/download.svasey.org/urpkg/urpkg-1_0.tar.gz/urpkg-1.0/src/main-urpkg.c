/* Contains only the main function for the urpkg program */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <signal.h>
#include <string.h>
#include <errno.h>

#include "action.h"
#include "proc.h"
#include "io.h"
#include "clopt.h"
#include "error.h"
#include "urpkg.h"
#include "pkg.h"

int 
main (int argc,char* argv[])
{
	struct user_action action;
	struct string_list_el *pkg_it;
	struct string_list_el *file_it;
	/* Contains the return value of the main command */
	int status = 0;

	ugrp_dropped_privilleges = 0;
	pkg_built_table = 0;
	error_init ();
	proc_table_init ();
	io_stream_table_init ();

	if (parse_options (argc,argv,&action) < 0){
		usage_text ();
		error_exit (1,1);
	}

	verbosity = action.verbosity;

	if (action.action == HELP){
		help_text ();
		return 0;
	}
	else if (action.action == XVERSION){
		version_text ();
		return 0;
	}
	else if (action.action == INFO){
		info_text ();
		return 0;
	}

	if (action_complete (&action) < 0){
		error_exit (1,1);
	}

	if (sanity_checks (&action) < 0){
		error_exit (1,1);
	}

	global_action = action;
	
	/* Print a summary of what is being asked (using xmsg) */
	if ((action.verbosity == VERBOSE) || (action.verbosity == XDEBUG)
	    || (action.pretend)){
		action_print (&xmsg,&action);
	}

	/* Set signal handlers */
	if ((signal (SIGTERM,signal_handler) < 0)
	    || (signal (SIGINT,signal_handler) < 0)
	    || (signal (SIGHUP,signal_handler) < 0)){
		error_set (HANDLERSET_ERROR,"Error when setting signal "
			   "handlers: %s",strerror (errno));
		error_exit (1,1);
	}

	switch (action.action){
	case INSTALL:
		if (action.pretend){
			break;
		}
		status = install_pkg (string_list_first (&action.pkg_list),
				      action.pkg_dir,action.install_cmd,
				      action.install_argv,
				      &action.postscript_args,
				      &action.exclude);
		break;
	case UNINSTALL:
		for (pkg_it = string_list_it (&action.pkg_list);pkg_it != NULL
			     ;pkg_it = pkg_it->next){
			
			status = uninstall_pkg (pkg_it->string,action.find_cmd
						,action.pretend);

			if (status < 0){
				break;
			}
		}
		break;
	case LIST_INST:
		if (action.list_all){
			status = list_installed_pkg ();
		}
		else {
			for (pkg_it = string_list_it (&action.pkg_list)
				     ;pkg_it != NULL;pkg_it = pkg_it->next){
				status = list_files (pkg_it->string
						     ,action.find_cmd);
				if (status < 0){
					break;
				}
			}
		}
		break;
	case LIST_DIR:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			status = list_instdir (file_it->string,action.find_cmd);
			if (status < 0){
				break;
			}
		}
		break;
	case LIST_SHARED:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			status = list_shared (file_it->string,action.find_cmd);
			if (status < 0){
				break;
			}
		}
		break;
	case ADD_FILES:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			const char *pkg = string_list_first (&action.pkg_list);
			
			status = add_file (file_it->string,pkg,
					   action.change_owner,
					   action.change_group);
			if (status < 0){
				break;
			}
		}
		break;
	case FREE_FILES:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			const char *pkg = string_list_first (&action.pkg_list);

			status = free_file (file_it->string,pkg,
					    action.new_owner,action.new_group);
			if (status < 0){
				break;
			}
		}
		break;
	case GEN:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			status = add_instdir (file_it->string);
			if (status < 0){
				break;
			}
		}
		break;
	case UNGEN:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			status = remove_instdir (file_it->string,
						 action.new_group
						 ,action.new_perm);
			if (status < 0){
				break;
			}
		}
		break;
	case SHARE:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			status = add_shared (file_it->string);
			if (status < 0){
				break;
			}
		}
		break;
	case UNSHARE:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			status = remove_shared (file_it->string,
						action.new_group
						,action.new_perm);
			if (status < 0){
				break;
			}
		}
		break;
	case FIND:
		for (file_it = string_list_it (&action.file_list)
			     ;file_it != NULL;file_it = file_it->next){
			status = find_pkg (file_it->string);
			if (status < 0){
				break;
			}
		}
		break;		
	default:
		/* Should not happen */
		xassert (0);
		break;
	}

	if (status < 0){
		error_exit (1,1);
	}

	xlog ("Program terminated successfully\n");
			
	return 0;
}



