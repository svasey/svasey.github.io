/* Contains functions that do the "real" stuff, i.e. (un)installing, cleaning up
   etc.. */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_URPKG_H
#define INCLUDE_URPKG_H

#include <stdio.h>

#include "action.h"
#include "dt.h"
#include "io.h"
#include "error.h"

/* Contains all we need to know about what we have to do */
struct user_action global_action;

/* Signal handler */
void
signal_handler (int sig);

/* Check whether the package user is apt for being created (i.e correctly
   formated and does not exist). Return 0 in case it is ok, -1 otherwise,
   setting urpkg_errno appropriately. */
int
check_pkgname (const char *username);

/* Check if everything is alright with the given parameter (never trust user
   input :-) ), so that we can proceed normaly afterward. Return 0 if things are
   fine, -1 if an error has been detected */
int
sanity_checks (const struct user_action *action);

/* Create a group (usually the install or the shared group) */
int
create_group (const char *groupname);

/* Create a new package user from username, put in the install group. Create a
   package home directory in pkgdir and put in all the necessary files. */
int
create_pkg (const char *username,const char *pkgdir);

/* Remove user username from the user database, home directory included. */
int
remove_user (const char *username);

/* Create the package directory path, copying all the necessary
   files. We assume the path does not exist and that it is to be owned by
   username. Still, it will remain world-readable. */
int
create_pkgdir (const char *path,const char *username);

/* Remove the regular files contained in list. Print their name using xmsg when
   removing them. */
int
remove_regfiles (const struct string_list *files);

/* Remove the empty directories in dir. If some of them are not empty, print a
   warning. Print their name using xmsg when removing them. */
int
remove_emptydir (const struct string_list *dir);

/* This will allocate an array of string list containing as first element the
   package username and as the rest the extra files for that package. Return
   NULL if some error happened. The last element of the returned array is a
   string list of size 0. Since the function only creates an element if the
   package has extra files, this is unambigous */
struct string_list *
find_all_extra_files (void);

/* Find all files that are part of the program but do not have the package user
   as owner or group. Put them into dest */
int
find_extra_files (const char *username,struct string_list *dest);

/* Find files that are owned by the given package user, and put them in
   list. Use findcmd to get the file list. */
int
find_owned_files (const char *username,const char *findcmd,
		  struct string_list *dest);

/* Find files owned by groupname, and put them in dest. */
int
find_group_files (const char *groupname,const char *findcmd,
		  struct string_list *dest);

/* From a list of file part of the package username, determine which are shared
   (also part of other packages) and which are not */
int
find_unique_files (const char *username,const struct string_list *file_list,
		   struct string_list *unique,struct string_list *shared);

/* Find all package that are installed, and put their username in installed */
int
find_installed (struct string_list *installed);

/* Change the owner and permission of the installation log so that it does not
   stay with unmatched numeric ids. */
int
install_log_sanitize (void);

/* Open the list of extra files for package username. */
FILE *
open_extra (const char *username,const char *mode);

/* Put the files in dir present in file_list in dest. */
int
find_inpath (const struct string_list *file_list,const char *path,
	     struct string_list *dest);

/* Remove the files part of the username package if pretend is off, only print
   them if pretend is on. Print a warning if the package shares files with
   other packages, but don't remove those files. If some directories part of the
   package are not empty after the file removal has been done, print a warning
   but do not remove them */
int
find_destroy (const char *username,const char *findcmd,int pretend);

/* Find the package(s) that contain a given file and put their username in
   pkg_list */
int
find_file_owner (const char *filename,struct string_list *pkg_list);

/* Find the package(s) that contain a given file and print them to stdout using
   xstdout. */
int
find_pkg (const char *filename);

/* Run the install command. Let stdout and stderr flow, but if something ends up
   being printed to stderr, Print it again after the command exited, with a
   warning. If the command exits with nonzero status, set urpkg_errno
   appropriately and return -1. */
int
run_install (const char *cmd,char *const argv[]);

/* Install the package whose package user is username, putting metafiles in
   pkgdir. scripts_args and exclude are related to the scripts that get run
   before and after the installation. user_preinst is the path to the user
   preinstall script. */
int 
install_pkg (const char *username,const char *pkgdir,const char *install_cmd,
	     char *const install_argv[],
	     const struct dictionary *postscript_args,
	     const struct scripts_exclude *exclude);

/* Set all the environment variables before running the scripts. A null value
   for the pkgdir means we have to guess it; */
int
gen_env (const char *username,const char *pkgdir);

/* Uninstall the package username. If pretend is true, only list the files that
   would have been removed but don't actually remove them. If remove_groups is
   true, remove the groups the package user was in (the group which has its
   name will be removed anyway), if no other users use it */
int 
uninstall_pkg (const char *username,const char *findcmd,int pretend);


/* Run the postinstall scripts; Arguments are described in args. Scripts to be
   excluded are in exclude_list. Assume that the environment variables have
   already been set, and that we are root */
int 
run_postinst_scripts (const struct dictionary *args,
		      const struct string_list *exclude_list);

/* List files that are part of username, using xstdout */
int 
list_files (const char *username,const char *findcmd);

/* List all packages installed on the system, using xstdout */
int
list_installed_pkg (void);

/* Add file to package, changing their owner and group only if respectively
   change_group and change_owner are true */
int
add_file (const char *file,const char *username,int change_owner,
	  int change_group);

/* Free file from being part of package restore their owner and group using the
   information when we added the file to the package, or using new_owner and/or
   new_group if they are non-null */
int
free_file (const char *file,const char *username,const char *new_owner,
	   const char *new_group);

/* Set directory to be an install directory. Create the install group if
   necessary */
int 
add_instdir (const char *filename);

/* Remove a directory from being an install directory. Restore its group and
   permissions if new_group is non-null and new_perm non-negative */
int
remove_instdir (const char *filename,const char *new_group,int new_perm);

/* Set filename to be a shared file. Create the shared group if necessary */
int
add_shared (const char *filename);

/* Remove a filename from being a shared file. Restore its group and
   permissions if new_group is non-null or new_perm not negative */
int
remove_shared (const char *filename,const char *new_group,int new_perm);

/* List the install directories in path (that are in the install directories
   file), using xstdout */
int
list_instdir (const char *path,const char *findcmd);

/* List the shared files in path, using xstdout */
int
list_shared (const char *path,const char *findcmd);

#endif	/* INCLUDE_URPKG_H */
