/* Contains some small helper functions dealing with strings */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_STR_H
#define INCLUDE_STR_H

#include <stdlib.h>

/* Strip all trailing new lines from str */
void
chomp (char *str);

/* Return the last character from str (before the null byte) */
char
lastchar (const char *str);

/* Return 1 if s1 is exactly the same as s2, 0 otherwise */
int
string_equal_p (const char *s1,const char *s2);

/* Return 1 if str begins with sub, 0 otherwise */
int
string_beginwith_p (const char *str,const char *sub);

/* Like the standard functions, but do the memory allocation for you. Also,
   strncpy adds a null byte at the end of the string */
char *
xstrcpy (char **s1,const char *s2);

char *
xstrncpy (char **s1,const char *s2,size_t n);

#endif	/* INCLUDE_STR_H */
