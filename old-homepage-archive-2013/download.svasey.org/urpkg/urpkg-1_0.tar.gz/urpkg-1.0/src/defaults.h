/* Contains macros containing default paths and name. Some of them can be
   changed with the configure script */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_DEFAULT_H
#define INCLUDE_DEFAULT_H

#include "config.h"

/* Print debug message when --xdebug is specified on the command line */
#define DEBUG_MSG 1

#define BACKUP_SUFFIX ".bckp"

/* What is added before the username when installing a package */
#define USER_PREFIX "urpkg-"

/* What is added before the name of environment variables defined by the
   program */
#define VAR_PREFIX "URPKG_"

/* The path where the package keeps its meta files like added; relative to the
   home directory */
#define PRIVDIR ".urpkg/"

/* Text file where the path of all added files are stored, relative to the
   package's home directory */
#define ADDED_FILE PRIVDIR "/added"

/* The install group */
#define INSTALL_GROUP "urpkgrp-install"

/* The shared group */
#define SHARED_GROUP "urpkgrp-shared"

#endif	/* INCLUDE_DEFAULT_H */
