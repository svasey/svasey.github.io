/* Implementations of the functions in error.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <stdlib.h>
#include <stdarg.h>

#include "error.h"
#include "io.h"
#include "str.h"
#include "mem.h"
#include "proc.h"
#include "dt.h"
#include "ugrp.h"
#include "action.h"
#include "urpkg.h"

void
error_init (void)
{
	int i;
	static int first = 1;
	
	urpkg_errno = NO_ERROR;

	for (i = 0;i < MAX_ARGS;i++){
		if (error_args[i] != NULL){
			if (!first){
				free (error_args[i]);
			}
			error_args[i] = NULL;
		}
	}
	if (first){
		error_assert_first = 1;
	}

	first = 0;
}

void
error_set (enum error_code val,...)
{
	va_list ap;
	struct alloc_string astr;
	const char *str;
	char **argv;
	int n;

	xdebug ("%s (%d)\n",__FUNCTION__,val);

	va_start (ap,val);

	/* Reinitialize everything as it was before */
	error_init ();
	xassert (val > NO_ERROR);
	urpkg_errno = val;

	switch (val){
		/* Errors taking only one string argument */
	case FWRITE_ERROR:
	case FCREATE_ERROR:
	case FREAD_ERROR:
	case FPERM_ERROR:
	case FSTAT_ERROR:
	case FOPEN_ERROR:
	case DIR_ERROR:
	case FREMOVE_ERROR:
	case FNEXIST_ERROR:
	case UGNAME_ERROR:
	case UGFIND_ERROR:
	case UGNEXIST_ERROR:
	case UGEXIST_ERROR:
	case RPATH_ERROR:
		str = va_arg (ap,const char *);
		if (str != NULL){
			xstrcpy (&error_args[0],str);
		}
		else {
			xstrcpy (&error_args[0],"???");
		}
		break;
		
		/* Errors taking only one integer argument */
	case UID_ERROR:
	case GID_ERROR:
	case PWAIT_ERROR:
		n = va_arg (ap,int);
		error_args[0] = xmalloc (20 * sizeof(char));
		snprintf (error_args[0],20,"%d",n);
		break;
		
		/* Errors taking two integers as arguments */
	case SIG_ERROR:
		n = va_arg (ap,int);
		error_args[0] = xmalloc (20 * sizeof(char));
		snprintf (error_args[0],20,"%d",n);
		n = va_arg (ap,int);
		error_args[1] = xmalloc (20 * sizeof(char));
		snprintf (error_args[1],20,"%d",n);
		break;
		
		/* Errors taking a command (string) and its arguments (null
		   terminated array of string) */
	case EXEC_ERROR:
	case CMD_ERROR:
		str = va_arg (ap,const char *);
		if (str != NULL){
			xstrcpy (&error_args[0],str);
		}
		else {
			xstrcpy (&error_args[0],"???");
		}

		/* Make a string of space-separated arguments */
		argv = va_arg (ap,char **);
		str = proc_args_to_str (&argv[1]);

		if (str != NULL){
			xstrcpy (&error_args[1],str);
		}
		else {
			xstrcpy (&error_args[1],"???");
		}

		if (val == CMD_ERROR){
			n = va_arg (ap,int);
			/* Return status hasn't been converted */
			if (n >= 256){
				n /= 256;
			}
			error_args[2] = xmalloc (sizeof(char) * 20);
			snprintf (error_args[2],20,"%d",n);
		}
		break;
	default:
		break;
	}	

	/* A lot of errors take a description of the error as last
	   argument. The last error_args element will be used for it. */
	if ((val != UID_ERROR) && (val != GID_ERROR)
	    && (val != UGNEXIST_ERROR) && (val != UGEXIST_ERROR)
	    && (val != CMD_ERROR) && (val != FNEXIST_ERROR)){
		
		str = va_arg (ap,const char *);
		if (str == NULL){
			xstrcpy (&error_args[MAX_ARGS - 1],"???");
		}
		else {
			alloc_string_init (&astr,100);
			alloc_string_push_valist (&astr,str,ap);
			error_args[MAX_ARGS - 1] = astr.str;
		}
	}

	va_end (ap);
}



const char *
error_describe (void)
{
	static struct alloc_string astr;
	static int first = 1;

	/* Guess on the length of the string */
	const int LENGTH = 4096;

	if (!first){
		alloc_string_free (&astr);
	}
	alloc_string_init (&astr,LENGTH);
	
	switch (urpkg_errno){
	case NO_ERROR:
		alloc_string_push (&astr,"No error set");
		break;
	case FWRITE_ERROR:
		alloc_string_push (&astr,"Could not write to file %s : %s",
				   error_args[0],error_args[MAX_ARGS - 1]);
		break;
		
	case FCREATE_ERROR:
		alloc_string_push (&astr,"Could not create file %s : %s",
				   error_args[0],error_args[MAX_ARGS - 1]);
		break;
		
	case FREAD_ERROR:
		alloc_string_push (&astr,"Could not read file %s : %s",
				   error_args[0],error_args[MAX_ARGS - 1]);
		break;
	case FPERM_ERROR:
		alloc_string_push (&astr,"Could not change metadata of file %s "
				   ": %s",error_args[0],
				   error_args[MAX_ARGS - 1]);
		break;
	case FSTAT_ERROR:
		alloc_string_push (&astr,"Could not stat file %s : %s",
				   error_args[0],error_args[MAX_ARGS - 1]);
		break;
	case DIR_ERROR:
		alloc_string_push (&astr,"Could not open/close directory %s "
				   "for listing : %s",error_args[0],
				   error_args[MAX_ARGS - 1]);
		break;
	case FREMOVE_ERROR:
		alloc_string_push (&astr,"Could not remove file %s : %s",
				   error_args[0],error_args[MAX_ARGS - 1]);
		break;
	case FNEXIST_ERROR:
		alloc_string_push (&astr,"File %s does not exist",
				   error_args[0]);
		break;
	case UID_ERROR:
		alloc_string_push (&astr,"Could not find any user name for "
				   "uid %s",error_args[0]);
		break;
	case GID_ERROR:
		alloc_string_push (&astr,"Could not find any group name for "
				   "gid %s",error_args[0]);
		break;
	case PIPE_C_ERROR:
		alloc_string_push (&astr,"Could not create pipe: %s",
				   error_args[MAX_ARGS - 1]);
		break;
	case PIPE_R_ERROR:
		alloc_string_push (&astr,"Could not read pipe: %s",
				   error_args[MAX_ARGS - 1]);
		break;
	case FORK_ERROR:
		alloc_string_push (&astr,"Could not fork process: %s",
				   error_args[MAX_ARGS - 1]);
		break;
	case DUP_ERROR:
		alloc_string_push (&astr,"Could not redirect file descriptor"
				   ": %s",error_args[MAX_ARGS - 1]);
		break;
	case PRIV_ERROR:
		alloc_string_push (&astr,"Could not change privilleges of "
				   "the process: %s",error_args[MAX_ARGS - 1]);
		break;
	case EXEC_ERROR:
		alloc_string_push (&astr,"Could not run external program %s "
				   "with arguments %s : %s",error_args[0],
				   error_args[1],error_args[MAX_ARGS - 1]);
		break;
	case PWAIT_ERROR:
		alloc_string_push (&astr,"Could not wait for process %s to "
				   "terminate: %s",error_args[0],
				   error_args[MAX_ARGS - 1]);
		break;
	case SIG_ERROR:
		alloc_string_push (&astr,"Could not send signal %s to process "
				   "%s : %s",error_args[1],error_args[0],
				   error_args[MAX_ARGS - 1]);
		break;
	case UGNAME_ERROR:
		alloc_string_push (&astr,"Bad format for user/group name %s : "
				   "%s",error_args[0],error_args[MAX_ARGS - 1]);
		break;
	case UGFIND_ERROR:
		alloc_string_push (&astr,"Error while looking up the "
				   "user/group database with name %s : %s",
				   error_args[0],error_args[MAX_ARGS - 1]);
		break;
	case UGNEXIST_ERROR:
		alloc_string_push (&astr,"User/group %s does not exist",
				   error_args[0]);
		break;
	case UGEXIST_ERROR:
		alloc_string_push (&astr,"User/group %s already exists",
				   error_args[0]);
		break;
	case RPATH_ERROR:
		alloc_string_push (&astr,"Error while resolving path %s : %s",
				   error_args[0],error_args[MAX_ARGS - 1]);
	case LONGPATH_ERROR:
		alloc_string_push (&astr,"%s is too long",
				   error_args[MAX_ARGS - 1]);
		break;
	case INVOKE_ERROR:
		alloc_string_push (&astr,"Invocation error: %s",
				   error_args[MAX_ARGS - 1]);
		break;
	case HANDLERSET_ERROR:
		alloc_string_push (&astr,"Could not set signal handlers: %s",
				   error_args[MAX_ARGS - 1]);
		break;
	case CMD_ERROR:
		alloc_string_push (&astr,"Command %s with arguments '%s' "
				   "returned non-zero status %s",
				   error_args[0],error_args[1],error_args[2]);
		break;
	case CUSTOM_ERROR:
		alloc_string_push (&astr,"%s",error_args[MAX_ARGS - 1]);
		break;
	default:
		/* Should not happen */
		xassert (0);
		break;
	} /* End switch */
	
	return alloc_string_read (&astr)	;
}

void
error_cleanup (void)
{
	static int in_error_cleanup = 0;
	extern struct user_action global_action;

	if (in_error_cleanup){
		return;
	}
	
	in_error_cleanup = 1;

	xstderr ("Cleaning up...\n");
	/* Get maximum privillege */
	if (ugrp_dropped_privilleges && (ugrp_restore_privilleges () < 0)){
		xerror ("%s",error_describe ());
		error_init ();
	}

	xstderr ("Terminating all processes...\n");
	if (proc_close_all () < 0){
		xerror ("%s",error_describe ());
		error_init ();
	}

	xstderr ("Closing all files...\n");
	io_fclose_all (1);

	/* Uninstall the uncompletely installed package */
	if ((global_action.action == INSTALL)
	    && (ugrp_user_exists_p (string_list_first (&global_action.pkg_list),
				    NULL) == 1)){
		global_action.action = UNINSTALL;
		xstderr ("Uninstalling uncompletely installed package. "
			 "PLEASE DO NOT KILL\n");
		if (uninstall_pkg (string_list_first (&global_action.pkg_list),
				   global_action.find_cmd,0) < 0){
			xerror ("Failed to uninstall package: %s",
				error_describe ());
		}
	}
}

void
error_exit (int status,int cleanup)
{
	static int first_time = 1;
		
	xerror ("%s",error_describe ());
	if (first_time && cleanup){
		first_time = 0;
		error_cleanup ();
	}
	exit (status);
}
