/* Contains implementation of the functions declared in str.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <string.h>

#include "str.h"
#include "mem.h"

void
chomp (char *str)
{
	int i;

	for (i = (strlen (str) - 1);i >= 0;i--){
		if (str[i] == '\n'){
			str[i] = '\0';
		}
		else {
			break;
		}
	}
}

char
lastchar (const char *str)
{
	if (str[0] == '\0'){
		return '\0';
	}
	else {
		return str[strlen (str) - 1];
	}
}

int
string_equal_p (const char *s1,const char *s2)
{
	if (strcmp (s1,s2) == 0){
		return 1;
	}
	else {
		return 0;
	}
}

int
string_beginwith_p (const char *str,const char *sub)
{
	if (strstr (str,sub) == str){
		return 1;
	}
	else {
		return 0;
	}
}

char *
xstrcpy (char **s1,const char *s2)
{
	xstrncpy (s1,s2,strlen (s2));
	return *s1;
}

char *
xstrncpy (char **s1,const char *s2,size_t n)
{
	int len = strlen (s2);
	int size;

	size = ((len < n) ? len : n);

	*s1 = xmalloc (sizeof(char) * (size + 1));
	strncpy (*s1,s2,n);
	(*s1)[size] = '\0';

	return *s1;
}

