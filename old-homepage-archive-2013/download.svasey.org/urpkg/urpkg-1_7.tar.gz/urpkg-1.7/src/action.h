/* Contains functions used to specify an action that the program should do */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_ACTION_H
#define INCLUDE_ACTION_H

#include <limits.h>

#include "dt.h"
#include "ugrp.h"

enum verbosity {QUIET,NORMAL,VERBOSE,XDEBUG};

/* Scripts that are excluded from being run */
struct scripts_exclude
{
	/* Exclude the preinstall script from being
	   run */
	int preinst;

	/* Exclude all postinstall scripts from being run */
	int postinst;
	
	/* Specific user postinstall scripts not to be run */
	struct string_list postinst_list;
};

/* What the user asked the program to do */
struct user_action
{
	/* The different actions the program can take. */
	enum action {HELP,XVERSION,INFO,INSTALL,UNINSTALL,LIST_INST,LIST_DIR,
		     LIST_SHARED,ADD_FILES,FREE_FILES,GEN,UNGEN,SHARE,
		     UNSHARE,FIND,UNKNOWN} action;
	/* The level of verbosity for the program's output. */
	enum verbosity verbosity;
	
	/* True if the --pretend flag is given */
	int pretend;
	/* True if we have to list all installed packages */
	int list_all;

	/* True if we have to change the file's owner and/or groups (add
	   action) */
	int change_owner;
	int change_group;
	
	/* Directory of the packages home dir (e.g /usr/pkg) */
	char pkg_dir[PATH_MAX];
	/* The command that should be run when installing the files, without the
	   arguments */
	char install_cmd[PATH_MAX];
	/* A shell script used to list files belonging to a package whose user
	   name is given as first argument. */
	char find_cmd[PATH_MAX];
	/* The new group and/or owner of the file (e.g free actions) */
	char new_owner[UGRP_RE_MAX_LENGTH];
	char new_group[UGRP_RE_MAX_LENGTH];
	/* New permission mask for the file */
	int new_perm;
	/* Arguments to the install script, with the last element being a NULL
	   value. */
	char **install_argv;
	
	/* The arguments to the different postinstall scripts */
	struct dictionary postscript_args;
	/* List of all packages specified on the command line (for some actions,
	   like uninstall) */
	struct string_list pkg_list;
	/* List of all files specified on the command line (for some actions,
	   like add-files) */
	struct string_list file_list;
	/* Give information about which scripts must be excluded from being
	   run */
	struct scripts_exclude exclude;
};

/* Get a string describing each action */
#define ACT_TOSTR(A)					\
	((A == HELP) ? "get help" :			\
	 (A == XVERSION) ? "get version" :		\
	 (A == INFO) ? "get settings info" :		\
	 (A == INSTALL) ? "install" :			\
	 (A == UNINSTALL) ? "uninstall" :		\
	 (A == LIST_INST) ? "list package file" :	\
	 (A == LIST_DIR) ? "list install directory" :	\
	 (A == LIST_SHARED) ? "list shared files" :	\
	 (A == ADD_FILES) ? "add files" :		\
	 (A == FREE_FILES) ? "free files" :		\
	 (A == GEN) ? "gen" :				\
	 (A == UNGEN) ? "ungen" :			\
	 (A == SHARE) ? "share" :			\
	 (A == UNSHARE) ? "unshare" :			\
	 (A == FIND) ? "find" :	"unknown")		

/* Get a string describing each possible verbosity */
#define VER_TOSTR(V)				\
	((V == QUIET) ? "quiet" :		\
	 (V == NORMAL) ? "normal" :		\
	 (V == VERBOSE) ? "verbose" :		\
	 (V == XDEBUG) ? "debug" : "unknown")

/* Print the value of a flag (on or off) */
#define FLAG_TOSTR(F) ((F) ? "on" : "off")

/* Initialize actions with the default values */
void
action_init (struct user_action *action);

/* Print a verbose description of the action that is being asked using
   formatf */
void
action_print (void (*formatf)(const char *fmt,...),
	      const struct user_action *action);

/* Complete the different fields of the action after user input. */
int
action_complete (struct user_action *action);


#endif	/* INCLUDE_ACTION_H */
