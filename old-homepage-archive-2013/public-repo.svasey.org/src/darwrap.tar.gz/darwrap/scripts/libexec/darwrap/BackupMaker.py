"""Classes making the actual backup"""

### Author: Sebastien Vasey (http://svasey.org/)

import os
from os.path import join, exists, isdir, basename
from copy import copy
from time import localtime, mktime, sleep
from glob import glob
from fnmatch import fnmatch
from os import remove
from shutil import rmtree, copyfile
from math import floor
from tempfile import mkdtemp

from darwrap.BackupStatus import BackupStatus, Status
from darwrap.DarwrapConfig import GlobalConfig, Profile
from darwrap.DarwrapError import BackupNotDoneError, StatusFileError, \
    BackupFailedError, IndexError
from darwrap.DarRunner import DarRunner, DarIndexRunner
from darwrap.Encryption import Paritor, ParitorGenerator, Encryptor, \
    EncryptorGenerator, Signer, SignerGenerator
from darwrap.BackupObject import Archive, Index, StatusFileArchive

from svlib.fs.func import removeThing
from svlib.atomicfile.AtomicFile import AtomicFile, atomicFileCopy
from svlib.picklefile.PickleFile import AtomicPickleFile

class BackupMaker:
    """Main backup class"""

    def __init__ (self, configPath, backupProfile, progConfig, action,
                  pidFile):
        """
        configPath is the path to the configuration file, backupProfile is the
        profile as a Profile object, and progConfig is the content of the
        configuration file as a GlobalConfig object. Action is the action
        specified by the user, as a string
        """

        self.configPath = configPath
        self.action = action
        self.backupProfile = backupProfile
        self.progConfig = progConfig
        self.pidFile = pidFile
        progConfig.applySettings ()
        self.profilePath = join (self.progConfig.spoolpath,
                                 self.backupProfile.name)
        self.statusFilePath = join (self.profilePath,
                                    "status.xml")
        try:
            os.makedirs (self.profilePath)
        except OSError as err:
            if not (exists (self.profilePath)):
                raise

        self.statusFile = BackupStatus (self.statusFilePath)
        if not exists (self.statusFilePath) and (action != 'reset'):
            print 'WARNING: status file does not exist. ' + \
                'I will try to download it. Use reset if you want to ' + \
                'initialize something new'
            

    def processStatusFile (self, paritor, encryptor, signer):
        """
        Do some safety check on the status file, downloading it if necessary. If
        it needs to be downloaded, the paritor, signer and encryptor will be
        used to decrypt and verify it
        """
        
        if self.action == 'reset':
            self.statusFile.reset (self.backupProfile)
        elif not exists (self.statusFilePath):
            self.downloadStatusFile (paritor, encryptor, signer)

        if (not (self.statusFile.profileEquals (self.backupProfile))) and \
                ((self.action == 'new') or  (self.action == 'continue')):
            raise StatusFileError ("Your profile does not match the one in " +
                                   "the backup status file. Change back " +
                                   "your profile or remove the status file " +
                                   self.statusFilePath + " to reset the backup")

    def downloadStatusFile (self, paritor, encryptor, signer):
        """
        Download the status file from the remote destination, decrypt it, and
        copy it to the local status file. Only do this if the file does not
        exist. Also download all the existing archive catalog on the remote
        destination.
        """

        if exists (self.statusFilePath):
            return
        destination = self.backupProfile.destination
        tempDir = mkdtemp (dir = self.profilePath, prefix = 'statFile')
        (indexName, statusName) = self.findBestIndexStatusPair ()
        filePath = destination.downloadFile (statusName, tempDir, paritor,
                                             encryptor, signer)
        self.statusFile.reset (self.backupProfile)
        atomicFileCopy (filePath, self.statusFilePath)
        
        for el in glob (join (self.profilePath, 'statFile*')):
            removeThing (el)

        print 'Downloading missing archive catalogs'
        # Download archive catalogs
        toDownload = destination.listFiles (self.backupProfile.name +
                                            '.*.catalog.*.dar.gpg')
        for el in toDownload:
            destination.downloadFile (el, self.profilePath, paritor, encryptor,
                                      signer)

    def getSortedArchiveList (self):
        """
        Return the archive list, sorted from oldest to newest, without the
        'empty' archives
        """

        archiveList = self.statusFile.archiveList
        archiveList = filter (lambda x: not x.isUnused (), archiveList)
        def archiveCmp (a, b):
            return int (floor (a.timestamp - b.timestamp))
            
        return sorted (archiveList, archiveCmp)

    def getStatus (self):
        """
        Return the current backup status as a Status object
        """

        self.statusFile.read ()
        
        return self.statusFile.status
    
    def make (self):
        """Make the actual backup"""
        self.statusFile.writeStatus (Status ("LOCAL"))
        self.doContinue ()
    
    def isDone (self):
        """Return true if the previous backup was done correctly, false
        otherwise"""

        self.statusFile.read ()
        if self.statusFile.status.status == self.statusFile.status.DONE:
            return True
        else:
            return False

    def isBlocked (self):
        """
        Return true if the current profile has been blocked from running by the
        user, false otherwise
        """

        self.statusFile.read ()
        
        return self.statusFile.blocked

    def block (self):
        """
        Block the profile from running until unblocked.
        """

        self.statusFile.read ()
        self.statusFile.writeBlocked ()

    def unblock (self):
        """
        Unblock the profile: it can now run at will
        """

        self.statusFile.read ()
        self.statusFile.writeUnblocked ()

    def writePid (self):
        """
        Write the current PID to the pid file
        """

        stream = AtomicPickleFile (self.pidFile)
        stream.writeContent (os.getpid ())
        
    def doContinue (self):
        """Continue an interrupted backup"""
        self.writePid ()
        self.statusFile.read ()
        
        if self.statusFile.status.status == self.statusFile.status.LOCAL:
            self.cleanupProfileDir ()
            self.localBackup ()
            self.statusFile.writeStatus (Status ("CRYPTING"))
            self.statusFile.read ()
        if self.statusFile.status.status == self.statusFile.status.CRYPTING:
            self.cryptBackup ()
            self.statusFile.writeStatus (Status ("SENDING"))
            self.statusFile.read ()
        if self.statusFile.status.status == self.statusFile.status.SENDING:
            self.sendBackup ()
            self.statusFile.writeArchive (self.statusFile.currentArchive)
            self.statusFile.writeStatus (Status ("CLEANING"))
            self.statusFile.read ()
        if self.statusFile.status.status == self.statusFile.status.CLEANING:
            self.backupProfile.destination.updateListCache ()
            self.cleanupBackup ()
            self.statusFile.writeStatus (Status ("DONE"))
            # Reset the current archive field
            self.statusFile.writeCurrentArchive (Archive (''))
            self.statusFile.read ()
        if self.statusFile.status.status != self.statusFile.status.DONE:
            raise BackupNotDoneError ("Could not finish doing backup")

    def cleanupProfileDir (self):
        """Remove all files relevant to the backup from the profile directory"""
        toRemoveCandidates = glob (join (self.profilePath,
                               self.backupProfile.name + ".?*"))
        toRemove = (glob (join (self.profilePath,
                                "index." + \
                                    self.backupProfile.name + ".*")))
        toRemove.extend (glob (join (self.profilePath,
                                     'config.' + \
                                         self.backupProfile.name + '.*')))
        toRemove.extend (glob (join (self.profilePath,
                                     'status.' + \
                                         self.backupProfile.name + '.*')))

        for el in toRemoveCandidates:
            toRemove.append (el)
            if not fnmatch (basename (el), "*.catalog.*.dar"):
                continue
            for archive in self.statusFile.archiveList:
                if archive.hasDerivativeName (el):
                    toRemove.pop ()
                    break
        for el in toRemove:
            if exists (el):
                if isdir (el):
                    rmtree (el)
                else:
                    remove (el)
        

    def runLocal (self):
        """Run a local backup once everything has been initialised. Write the
        currentArchive part of the status file"""

        self.statusFile.writeCurrentArchive (self.backupTape)
        self.darRunner = DarRunner (self.backupProfile.darOptions,
                                    self.backupProfile.source,
                                    self.referenceTape,
                                    self.backupTape,
                                    self.catalogTape,
                                    self.profilePath)

        indexObj = Index ('')
        indexName = indexObj.genFromArchive (self.backupTape)
        self.darIndexRunner = DarIndexRunner (indexName, self.catalogTape,
                                              self.profilePath)
        ret = self.darRunner.run ()
        if ret != 0:
            raise BackupFailedError ("Backup failed: dar exited with " +
                                     "status " +
                                     str (ret))
        # The only thing we have left to do is to index the backup
        if self.darIndexRunner.run () != 0:
            raise BackupFailedError ("Failed to index backup")

    
    def localBackup (self):
        """Do a local backup. Write the archives section of the status file"""

        backupTapeId = self.backupProfile.rotationScheme.tapeToUse \
            (self.statusFile.archiveList)
        self.backupTape = copy (self.statusFile.archiveList[backupTapeId])
        self.backupTape.profileName = self.backupProfile.name
        self.backupTape.partition = self.statusFile.source
        self.backupTape.level = backupTapeId + 1
        self.backupTape.cycleDay = self.backupProfile.rotationScheme.today \
            (self.statusFile.archiveList)
        self.backupTape.timestamp = mktime (localtime ())
        self.backupTape.onlyCatalog = False
        if self.backupProfile.rotationScheme.doFullBackup \
                (self.backupTape,self.statusFile.archiveList):
            self.backupTape.isFull = True
            self.referenceTape = None
        else:
            self.backupTape.isFull = False
            referenceTapeId = self.backupProfile.rotationScheme.getReference \
                (self.backupTape, self.statusFile.archiveList)
            self.referenceTape = \
                copy (self.statusFile.archiveList[referenceTapeId])
            self.referenceTape.onlyCatalog = True
        self.backupTape.genName ()
        self.catalogTape = copy (self.backupTape)
        self.catalogTape.onlyCatalog = True
        self.catalogTape.genName ()
        try:
            self.runLocal ()
        except Exception as err:
            # Kill dar before going further (not possible anymore)
            # self.darRunner.stop ()
            raise

    def createTempStatusFile (self,path):
        """
        Create a slightly forward into the future status path at path,
        indicating the backup as done, and with the current archive in the
        archive list
        """
        
        # We first have to create another temporary status file to write the
        # data in and then copy it, otherwise the temporary file will be an
        # atomic file which is not really necessary and which creates a fs mess

        tempDir = mkdtemp (dir = self.profilePath, prefix = 'tempStatus')
        tempPath = join (tempDir, 'tempStatus.xml')
        atomicFileCopy (self.statusFilePath, tempPath)
        
        tempStatus = BackupStatus (tempPath)
        tempStatus.read ()
        tempStatus.writeStatus (Status ('DONE'))
        tempStatus.writeArchive (tempStatus.currentArchive)
        tempStatus.writeCurrentArchive (Archive (''))
        copyfile (tempPath, path)
        for el in glob (join (self.profilePath, 'tempStatus*')):
            removeThing (el)
        
    def cryptBackup (self):
        """
        Encrypt the backup, sign it, and create parity files
        """

        # Find the backup tape
        self.backupTape = self.statusFile.currentArchive
        
        self.encryptor = (EncryptorGenerator \
                              (self.backupProfile.cryptoOptions)).encryptor
        self.signer = (SignerGenerator \
                           (self.backupProfile.cryptoOptions)).signer
        self.paritor = (ParitorGenerator \
                            (self.backupProfile.parityOptions)).paritor

        toEncrypt = glob (join (self.profilePath, self.backupTape.genName ())
                          + '*.dar')

        # Find index
        index = Index ('')
        index.genFromArchive (self.backupTape)
        indexPath = join (self.profilePath, index.name)
        toEncrypt.append (indexPath)

        # Encrypt status file. We use a slightly forward into the future backup
        # file, indicating the backup as done, and with the current archive in
        # the archive list
        statusFile = StatusFileArchive ('')
        statusFile.genFromArchive (self.backupTape, 'xml')
        tempStatusFile = join (self.profilePath, statusFile.name)
        self.createTempStatusFile (tempStatusFile)
        toEncrypt.append (tempStatusFile)
        
        # Encrypt configuration file
        outFile = self.encryptor.encryptFile (self.configPath,
                                              join (self.profilePath,
                                                    'config.' +
                                                    self.backupProfile.name +
                                                    '.xml.gpg'))
        self.signer.signFile (outFile)
        self.paritor.genParityFiles (outFile)

        # Encrypt catalog tape
        catalogTape = copy (self.backupTape)
        catalogTape.onlyCatalog = True
        catalogName = catalogTape.genName () + '.1.dar'
        catalogPath = join (self.profilePath, catalogName)
        outFile = self.encryptor.encryptFile (catalogPath)
        self.signer.signFile (outFile)
        self.paritor.genParityFiles (outFile)

        # Encrypt the rest
        for el in toEncrypt:
            outFile = self.encryptor.encryptFile (el)
            self.signer.signFile (outFile)
            self.paritor.genParityFiles (outFile)
            # We remove AFTER having generated the parity files: this way we
            # will not have problems if for some reason there is a crash in the
            # middle of the par2 creation...
            removeThing (el)
        
    def sendBackup (self):
        """Send the remaining backup files and remove once sent"""
        print 'Sending backup to its destination'

        destination = self.backupProfile.destination
        toSend = glob (join (self.profilePath, self.backupProfile.name + \
                                 ".?*.gpg"))
        toSend.extend (glob (join (self.profilePath, self.backupProfile.name + \
                                       ".?*.par2")))
        toSend.extend (glob (join (self.profilePath, self.backupProfile.name + \
                                       '.?*.sig')))
        toSend.extend (glob (join (self.profilePath, 'config.' +
                                   self.backupProfile.name + '.xml.gpg*')))
        destination.sendFiles (toSend)

        # Sending the index and the status file causes some atomicity problems:
        # * We cannot send the index before the status file: then the old status
        #   file will say an archive exists while the new index file will deny
        #   it.
        # * We cannot send the index after the status file: then the old index
        #   file will say an archive does not exist while the new status file
        #   will say it does.
        # 
        # We solve that problem by putting the same date to the index and the
        # status file: this way we will only remove the old index and status
        # files on the destination if both the newest index and the newest
        # status file have the same date.
        indexList = glob (join (self.profilePath, "index." + \
                                   self.backupProfile.name + ".*.dmd.gpg*"))
        indexToSend = []
        # Get any element of the index list
        indexToSend.extend (indexList)
        # Append the status file to the list
        statusList = glob (join (self.profilePath, 'status.' + 
                                 self.backupProfile.name + '.*.xml.gpg*'))
        # If this doesn't exist, this means there has been some problem
        # after the files were sent (when removing them). This means we
        # don't need to send the files over.
        indexToSend.extend (statusList)
        destination.sendFiles (indexToSend, doRemove = False)
        
        for el in statusList + indexList:
            removeThing (el)

    def findBestIndexStatusPair (self):
        """
        On the destination, find the most recent index/status couple having the
        same date and return the name of their encrypted version as a (index,
        status) tuple. If no such pair exist, raise an IndexError
        """

        destination = self.backupProfile.destination
        
        # List of all the status files
        statusList = destination.listFiles ('status.' +
                                            self.backupProfile.name +
                                            '.*.*.*.*.*.xml.gpg')
        # List of all the index files
        indexList = destination.listFiles ('index.' +
                                           self.backupProfile.name +
                                           '.*.*.*.*.*.dmd.gpg')


        mostRecentIndex = None
        mostRecentStatus = None
        bestTimestamp = -1
        for statusEl in statusList:
            for indexEl in indexList:
                status = StatusFileArchive (statusEl)
                index = Index (indexEl)
                
                if status.timestamp == index.timestamp:
                    if status.timestamp > bestTimestamp:
                        mostRecentIndex = indexEl
                        mostRecentStatus = statusEl
                        bestTimestamp = status.timestamp

        if bestTimestamp == -1:
            raise IndexError ('Could not find any valid index/status couple ' +
                              'with the same date. Index and status lists ' +
                              'are ' + str (indexList) + ' ' + str (statusList))
        else:
            return (mostRecentIndex, mostRecentStatus)
            
    def indexAndStatusToRemove (self):
        """
        Return all the index and status files that have to be removed from the
        remote destination (as a list)
        """

        destination = self.backupProfile.destination

        # List of all the status files
        statusList = destination.listFiles ('status.' +
                                            self.backupProfile.name +
                                            '.*')
        # List of all the index files
        indexList = destination.listFiles ('index.' +
                                           self.backupProfile.name +
                                           '.*')

        toRemoveCandidates = statusList + indexList
        toRemove = []

        try:
            (index, status) = self.findBestIndexStatusPair ()
            for el in toRemoveCandidates:
                toRemove.append (el)
                if el.startswith (index) or el.startswith (status):
                    toRemove.pop ()
            
        except IndexError as err:
            print 'WARNING: no valid index and status file on destination'

        return toRemove
        
    def cleanupDestDir (self):
        """Cleanup the destination of all useless files"""
        destination = self.backupProfile.destination
        archiveList = self.statusFile.archiveList
        name = self.backupProfile.name

        # A previous version of darwrap created .bckp files
        toRemove = destination.listFiles ("*.bckp")
        removeCandidates = destination.listFiles (name + ".?*")

        toRemove.extend (self.indexAndStatusToRemove ())

        for el in removeCandidates:
            toRemove.append (el)
            for archive in archiveList:
                if archive.hasDerivativeName (el):
                    toRemove.pop ()
                    break
        destination.removeFiles (toRemove)
    def cleanupBackup (self):
        """Remove all the files left, "re-use" tapes."""
        print 'Cleaning up local and remote files'
        self.cleanupProfileDir ()
        self.cleanupDestDir ()

    
    
