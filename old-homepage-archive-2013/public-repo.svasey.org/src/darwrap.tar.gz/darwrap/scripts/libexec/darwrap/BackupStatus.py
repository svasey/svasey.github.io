"""Classes representing the backup status file"""

### Author: Sebastien Vasey (http://svasey.org/)

from xml.dom import minidom
from time import strptime, mktime, localtime, strftime

from darwrap.DarwrapConfig import Config, RotationScheme, Destination, Profile
from darwrap.DarwrapError import ParsingError
from svlib.atomicfile.AtomicFile import AtomicFile
from darwrap.BackupObject import Archive



class Status:
    """Describes the status of a backup"""

    LOCAL, CRYPTING, SENDING, CLEANING, DONE = range (5)
    status_values = ["LOCAL", "CRYPTING", "SENDING", "CLEANING", "DONE"]
    status = None
    

    def __init__ (self, name):
        for index, val in enumerate (self.status_values):
            if name == val:
                self.status = index
        if self.status is None:
            raise ParsingError ("Status in status file is none of the " +
                                "possible values")

    def write (self, stream):
        val = ""
        if not (self.status is None):
            val = self.status_values[self.status]
            
        stream.write ("<status>" + val + "</status>\n")
        
    

class BackupStatus (Config):
    """Main backup status file"""

    filepath = None
    
    profileName = None
    rotationScheme = None
    source = None
    destination = None
    archiveList = []
    # Archive which is currently being created
    currentArchive = None
    status = None
    # True if the backup has been blocked by the user
    blocked = False
    
    def __init__ (self, filepath):
        self.filepath = filepath
        self.profileName = None
        self.rotationScheme = None
        self.source = None
        self.destination = None
        self.archiveList = []
        self.currentArchive = Archive ('')
        self.status = None
        self.blocked = False

    def writeProfileStream (self, profileName,
                            rotationScheme, source, destination, stream):
        stream.write ("<profileName>" +
                      profileName + "</profileName>\n")
        rotationScheme.write (stream)
        stream.write ("<source>" + source + "</source>\n")
        destination.write (stream)

    def writeArchiveListStream (self, archiveList, stream):
        stream.write ("<archives>\n")
        for el in archiveList:
            stream.write ("<name>" + el.name + "</name>\n")
        stream.write ("</archives>\n")

    def writeCurrentArchiveStream (self, currentArchive, stream):
        stream.write ('<currentArchive>')
        toWrite = ''
        if not currentArchive is None:
            toWrite = currentArchive.name
        stream.write (toWrite)
        stream.write ('</currentArchive>\n')

    def writeStatusStream (self, status, stream):
        status.write (stream)

    def writeBlockedStream (self, blocked, stream):
        stream.write ('<blocked>')
        toWrite = 'False'
        if blocked:
            toWrite = 'True'
        stream.write (toWrite)
        stream.write ('</blocked>\n')
        
    def reset (self, profile):
        """(Re)initialise the status file"""
        
        with AtomicFile (self.filepath, "w") as stream:
            stream.write ("<statusFile>\n")
            self.writeProfileStream (profile.name, profile.rotationScheme,
                                     profile.source,
                                     profile.destination, stream)
            archiveList = []
            for i in range (profile.rotationScheme.narchives):
                archiveList.append (Archive (""))

            self.writeArchiveListStream (archiveList, stream)
            self.writeCurrentArchiveStream (Archive (''), stream)
            self.writeStatusStream (Status ("DONE"), stream)
            self.writeBlockedStream (False, stream)
            stream.write ("</statusFile>\n")

    def write (self):
        with AtomicFile (self.filepath, "w") as stream:
            stream.write ("<statusFile>\n")
            
            self.writeProfileStream (self.profileName,
                                     self.rotationScheme,
                                     self.source,
                                     self.destination, stream)
            self.writeArchiveListStream (self.archiveList, stream)
            self.writeCurrentArchiveStream (self.currentArchive, stream)
            self.writeStatusStream (self.status, stream)
            self.writeBlockedStream (self.blocked, stream)
            stream.write ("</statusFile>\n")
            
    def read (self):
        document = minidom.parse (self.filepath)
        self.archiveList = []
        for child in document.childNodes[0].childNodes:
            if child.nodeType != child.TEXT_NODE:
                if child.tagName == "profileName":
                    self.profileName = child.firstChild.data
                elif child.tagName == "rotationScheme":
                    self.rotationScheme = RotationScheme.parse (child)
                elif child.tagName == "source":
                    self.source = child.firstChild.data
                elif child.tagName == "destination":
                    self.destination = Destination.parse (child)
                elif child.tagName == "archives":
                    for grandchild in child.childNodes:
                        if grandchild.nodeType != child.TEXT_NODE:
                            if grandchild.tagName == "name":
                                if grandchild.firstChild is None:
                                    self.archiveList.append (Archive (""))
                                else:
                                    self.archiveList.append \
                                        (Archive (grandchild.firstChild.data))
                elif child.tagName == 'currentArchive':
                    if child.firstChild is None:
                        self.currentArchive = Archive ('')
                    else:
                        self.currentArchive = Archive (child.firstChild.data)
                elif child.tagName == "status":
                    self.status = Status (child.firstChild.data)
                elif child.tagName == "blocked":
                    if child.firstChild.data == 'True':
                        self.blocked = True
                    else:
                        self.blocked = False
                    
    def profileEquals (self, profile):
        """Returns true if the part of the profile member of that structure are
        the same as the one passed as argument"""
        self.read ()
        return (self.rotationScheme == profile.rotationScheme) and \
            (self.profileName == profile.name) and \
            (self.source == profile.source) and \
            (self.destination == profile.destination)
    
                    
    def writeStatus(self, status):
        self.status = status
        self.write ()

    def writeBlocked (self):
        self.blocked = True
        self.write ()

    def writeUnblocked (self):
        self.blocked = False
        self.write ()
    
    def writeArchive (self, archive):
        """Write the archive to the status file, overwritting archives of the
        same level"""

        self.archiveList[archive.level - 1] = archive
        self.write ()

    def writeCurrentArchive (self, currentArchive):
        """
        Write a new current archive to the status file, replacing the old one
        """

        self.currentArchive = currentArchive
        self.write ()
        
