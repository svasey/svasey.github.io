"""Contain all classes to encrypt, sign and check data parity"""

### Author: Sebastien Vasey (http://svasey.org/)

from os.path import dirname, join, basename, exists
from os import remove
from subprocess import Popen, PIPE
from glob import glob
from tempfile import mkdtemp, NamedTemporaryFile
from shutil import rmtree
from getpass import getpass
from re import findall
from math import log
from signal import SIGTERM, signal
import sys
import errno

from svlib.servicerunner.Runner import callCmd, callCmdGetOutput, \
    UnexpectedStatusError
from svlib.fs.func import removeThing
from svlib.math.main import isPowerOfTwo

from darwrap.DarwrapConfig import CryptoConfig, ParityConfig
from darwrap.DarwrapError import EncryptionError, ParityError

class Encryptor:
    """Encrypt files"""

    def __init__ (self):
        raise NotImplementedError ()

    
    def outputFromInput (self, input):
        """Return the path of the output file from the path of the input file"""
        return join (dirname (input), basename (input) + ".gpg")

    def initDecryption (self, privKeyPath = None):
        """
        To call before any decryption, just in case we are using public-key
        encryption.
        """
        pass
    
    def encryptFile (self, input, output = None):
        """Encrypt a file, return the name of the output file."""
        raise NotImplementedError ()
    def decryptFile (self, input, output = None):
        """
        Decrypt a file, return the name of the output file
        """
        raise NotImplementedError ()

class GpgEncryptor (Encryptor):
    def __init__ (self, gpgOpts):
        self.gpgOpts = gpgOpts
        self.process = None
        def cleanup(signum, frame):
            # print "DEBUG: cleaning up"
            if self.process:
                self.process.terminate ()
        # If SIGTERM is received, forward it to the child process
        signal (SIGTERM, cleanup)
    def genBaseCmd (self):
        return ["gpg", "--batch", '--quiet', "--no-default-keyring",
                "--compress-level", "0", "--trust-model", "always",
                "--homedir", self.gpghome] + self.gpgOpts

    def preEncrypt (self, input, output):
        # This might be dangerous in case an error happens: an existing file
        # would have been removed for no apparent reason. However, the
        # alternative, the --yes option to gpg is worse...
        if exists (output):
            remove (output)
        # Create a gnupg home directory, so that we do not use any user's
        # directory
        self.gpghome = mkdtemp (suffix = 'gnupg-home')

    def postEncrypt (self):
        """
        Called internally when we are done encrypting the file
        """
        # Remove gnupg home
        removeThing (self.gpghome, ignoreNotExists = True)
        

class GpgPubKeyEncryptor (GpgEncryptor):
    keyring = None
    keyId = None

    def __init__ (self, keyring, keyId, gpgOpts):
        GpgEncryptor.__init__ (self, gpgOpts)
        self.keyring = keyring
        self.keyId = keyId

    def genEncryptCmd (self, input, output):
        cmd = self.genBaseCmd ()
        cmd.extend (["--encrypt", "--keyring", self.keyring,
                     "--recipient", self.keyId,"--output", output, input])
        return cmd
    def genDecryptCmd (self, input, output):
        cmd = self.genBaseCmd ()
        cmd.extend (['--decrypt', '--keyring', self.keyring,
                     '--secret-keyring', self.privKeyPath,
                     '--passphrase-fd', '0', '--output', output, input])
        return cmd
        
    def encryptFile (self, input, output = None):
        """
        Make sure you call initDecryption before calling that function
        """
        if output is None:
            output = self.outputFromInput (input)
        self.preEncrypt (input, output)
        self.cmd = self.genEncryptCmd (input, output)
        try:
            callCmd (self.cmd)
        except UnexpectedStatusError as err:
            raise EncryptionError ("The command " + repr (self.cmd) +
                                   " exited with non-zero status " +
                                   str(err.returnStatus))
        self.postEncrypt ()

        return output

    def initDecryption (self, privKeyPath):
        """
        Initialize the decryption process: reads the passphrase from the user
        and register the private key path. This is to be called once before all
        the calls you want to encryptFile. This way the passphrase will be
        cached into memory.
        I tought of using gpg-agent to do that but I wasn't sure how to proceed.
        """

        if privKeyPath is None:
            raise EncryptionError ('Need path to private key to decrypt ' +
                                   'backup')
        self.privKeyPath = privKeyPath
        print 'Please enter your GPG passphrase: '
        self.privKeyPassphrase = getpass ()
        goodPassPhrase = False
        while not goodPassPhrase:
            # Check that this is the good passphrase
            tempFile = NamedTemporaryFile (mode = 'w', delete = False)
            tempFile.write ('hello world')
            tempFile.flush ()
            tempPath = tempFile.name
            outFile = self.encryptFile (tempPath)
            try:
                tempOut = NamedTemporaryFile (mode = 'w', delete = False)
                self.decryptFile (outFile, tempOut.name)
                goodPassPhrase = True
            except EncryptionError as err:
                print 'Incorrect passphrase'
                print 'Please enter your GPG passphrase: '
                self.privKeyPassphrase = getpass ()
            tempFile.close ()
            tempOut.close ()
            removeThing (tempPath)
            removeThing (tempOut.name, ignoreNotExists = True)
                
        
        

    def decryptFile (self, input, output = None):
        if output is None:
            if basename (input).endswith ('.gpg'):
                output = input[:-4]
            else:
                output = input + '.decrypted'
        self.preEncrypt (input, output)
        self.cmd = self.genDecryptCmd (input, output)
        

        self.process = Popen (self.cmd, stdin = PIPE)
        try:
            self.process.communicate (input = self.privKeyPassphrase)
        except OSError as err:
            # If it isn't an interrupted call, raise
            if err.errno != errno.EINTR:
                raise
        self.ret = self.process.wait ()
        
        self.postEncrypt ()

        if self.ret != 0:
            raise EncryptionError ('The command ' + repr (self.cmd) +
                                   'exited with non-zero status ' +
                                   str (self.ret))
        return output
    
    

class GpgSymmetricEncryptor (GpgEncryptor):
    passphrase = None

    def __init__ (self, passphrase, gpgOpts):
        GpgEncryptor.__init__ (self, gpgOpts)
        self.passphrase = passphrase

    def genEncryptCmd (self, input, output):
        cmd = self.genBaseCmd ()
        cmd.extend (["--symmetric","--passphrase-fd", "0",
                    "--output", output, input])

        return cmd

    def genDecryptCmd (self, input, output):
        cmd = self.genBaseCmd ()
        cmd.extend (['--decrypt', '--passphrase-fd', '0',
                     '--output', output, input])
        return cmd
        
        
    def encryptFile (self, input, output = None):
        if output is None:
            output = self.outputFromInput (input)
        self.preEncrypt (input, output)
        self.cmd = self.genEncryptCmd (input, output)
        self.process = Popen (self.cmd, stdin = PIPE)
        try:
            self.process.communicate (input = self.passphrase)
        except OSError as err:
            # If it isn't an interrupted call, raise
            if err.errno != errno.EINTR:
                raise
        self.ret = self.process.wait ()

        self.postEncrypt ()
        
        if self.ret != 0:
            raise EncryptionError ("The command " + repr (self.cmd) +
                                   "exited wit non-zero status " +
                                   str(self.ret))

        return output

    def decryptFile (self, input, output = None):
        if output is None:
            if basename (input).endswith ('.gpg'):
                output = input[:-4]
            else:
                output = input + '.decrypted'

        self.preEncrypt (input, output)
        self.cmd = self.genDecryptCmd (input, output)
        self.process = Popen (self.cmd, stdin = PIPE)
        try:
            self.process.communicate (input = self.passphprase)
        except OSError as err:
            # If it isn't an interrupted call, raise
            if err.errno != errno.EINTR:
                raise
        self.ret = self.process.wait ()
        
        self.postEncrypt ()

        if self.ret != 0:
            raise EncryptionError ('The command ' + repr (self.cmd) +
                                   'exited with non-zero status ' +
                                   str (self.ret))
        return output
    

class EncryptorGenerator:
    """Generate an encryptor of the correct type"""

    cryptoConfig = None
    encryptor = None
     
    def __init__ (self, cryptoConfig):
        self.cryptoConfig = cryptoConfig
        if cryptoConfig.key.type == cryptoConfig.key.SYMMETRIC:
            self.encryptor = GpgSymmetricEncryptor (cryptoConfig.key.passphrase,
                                                    cryptoConfig.gpgOpts)
        elif cryptoConfig.key.type == cryptoConfig.key.PUBLIC:
            self.encryptor = GpgPubKeyEncryptor (cryptoConfig.key.keyring,
                                                 cryptoConfig.key.keyId,
                                                 cryptoConfig.gpgOpts)

class Signer:
    """
    Sign and verify file signatures. The signature is a detached .sig file.
    """

    def __init__ (self):
        raise NotImplementedError ()

    def sigFilePath (self, input):
        """
        Return the path of the signature file from the path of the input
        """
        return input + '.sig'

    def signFile (self, input, output = None):
        """
        Clearsign a file, return the name of the output file
        """
        raise NotImplementedError ()
    def verifySig (self, sig):
        """
        Verify a signature file, `sig`. Assumes the original file is
        present. Raise an EncryptionError if the signature is incorrect
        """
        raise NotImplementedError ()

class GpgSigner (Signer):
    def __init__ (self, signring, secring, signKey, gpgOpts):
        self.signring = signring
        self.secring = secring
        self.signKey = signKey
        self.gpgOpts = gpgOpts

    def createHome (self):
        """
        Create GPG home before actually calling gpg
        """

        self.gpghome = mkdtemp (suffix = 'gnupg-home')

    def removeHome (self):
        """
        Remove GPG home
        """
        removeThing (self.gpghome, ignoreNotExists = True)
        
    def genBaseCmd (self):
        return ['gpg', '--batch', '--quiet', '--no-default-keyring',
                '--trust-model', 'always', '--homedir', self.gpghome,
                '--keyring', self.signring, '--secret-keyring',
                self.secring] + self.gpgOpts
    

    def signFile (self, input, output = None):
        if output is None:
            output = self.sigFilePath (input)

        removeThing (output, ignoreNotExists = True)
        self.createHome ()
        self.cmd = self.genBaseCmd () + ['--detach-sign', '-u',
                                         self.signKey, '-o', output, input]
        try:
            callCmd (self.cmd)
        except UnexpectedStatusError as err:
            raise EncryptionError ('The commad ' + repr (self.cmd) +
                                   ' exited with non-zero status ' +
                                   str (err.returnStatus))
        self.removeHome ()

        return output

    def verifySig (self, sig):
        self.createHome ()

        self.cmd = self.genBaseCmd ()
        try:
            callCmd (self.cmd + ['--verify', sig])
        except UnexpectedStatusError as err:
            raise EncryptionError ('The commad ' + repr (self.cmd) +
                                   ' exited with non-zero status ' +
                                   str (err.returnStatus))
            
        self.removeHome ()

class SignerGenerator:
    """
    Generate a Signer of the correct ttype
    """

    cryptoConfig = None
    signer = None
    
    def __init__ (self, cryptoConfig):
        self.cryptoConfig = cryptoConfig
        # Only the GPG Signer is supported
        self.signer = GpgSigner (cryptoConfig.signring,
                                 cryptoConfig.secring,
                                 cryptoConfig.signKey, cryptoConfig.gpgOpts)

class Paritor:
    """Create parity files"""
    def __init__ (self):
        raise NotImplementedError ()

    def outputFromInput (self, input):
        return join (dirname (input), basename (input) + ".par2")
    
    def genParityFiles (self, input, output = None):
        """Generate a parity files, return a list with the name of all
        files. output must be the base parity file"""
        raise NotImplementedError ()

class Par2Paritor (Paritor):
    redundancy = None
    
    def __init__ (self, redundancy):
        self.redundancy = redundancy

    def genCmd (self, input, output):
        cmd = ["par2", "create", '-q', "-r" + str(self.redundancy),
               output, input]
        
        return cmd
        
    def genParityFiles (self, input, output = None):
        if output is None:
            output = self.outputFromInput (input)

        self.cmd = self.genCmd (input, output)
        try:
            callCmd (self.cmd)
        except UnexpectedStatusError as err:
            raise ParityError ("Could not generate par2 file for input " +
                               input + " : par2 command " + self.cmd +
                               " generated non-zero status " +
                               str (err.returnStatus))
        if output[-5:] == ".par2":
            return glob (output[:-5] + "*.par2")
        else:
            return glob (output + "*.par2")

    def verify (self, par2file):
        """
        Use the par2 file to verify the integrity of the data. Return the number
        of blocks that would be needed for recovery (-1 means the data's
        integrality has been preserved). 0 means that the file is damaged, but
        that no recovery volume is needed, the information in the par2 file will
        be enough. Note that this assumes the integrity of the par2file. If this
        is not the case, the number of bad blocks given might be wrong.
        """

        cmd = ['par2','verify', par2file]
        (returnCode, stdoutString, stderrString) = callCmdGetOutput \
            (cmd, expectedReturnStatus = None)

        if returnCode != 0 and returnCode != 1 and returnCode != 2:
            raise ParityError ('Error while verifying parity file ' + par2file +
                               ' exit status was ' + str (returnCode))

        # If exit status is 0, everything ok, repair not required 
        if returnCode == 0:
            return -1

        badlyBroken = False
        outLines = stdoutString.split ('\n')
        for el in outLines:
            groupList = findall \
                (r'^You have (\d+) out of (\d+) data blocks available.$', el)
            if len (groupList) > 0:
                found = int (groupList[0][0])
                total = int (groupList[0][1])

                return total - found
            
            
        assert (False) 

    def filesForRepair (self, nBlocks, fileList):
        """
        Given the complete list of par2 volume (basenames only), and the number
        of blocks to recover, return the files that are needed for repair
        (list). Note that this assumes the integrity of all the files in
        fileList, which in general cannot be assumed. Hence you shouldn't bother
        and just download all the files if there is an error.
        If not enough volumes are available, raise a ParityError
        """

        if nBlocks <= 0:
            return []

        assert (len (fileList) > 0)
        
        name = ''
        if len (fileList) > 0:
            name = '.'.join (fileList[0].split ('.')[:-2])
        numberList = []
        for el in fileList:
            volStr = el.split ('.')[-2]
            groups = findall (r'vol\d+\+(\d+)', el)
            numberList.append (int (groups[0]))

        # Dictionary mapping the number of volume to its filename
        numberNameDict = dict (zip (numberList, fileList))
            
        # The numberList should contain only powers of 2, except for the largest
        # element. Check this
        numberList.sort ()
        for index, value in enumerate (numberList):
            if not isPowerOfTwo (value):
                assert ((index + 1) == len (numberList))




        toRet = []
        for el in reversed (numberList):
            if nBlocks >= el:
                toRet.append (numberNameDict[el])
                nBlocks -= el

        if nBlocks > 0:
            raise ParityError ('Not enough recovery blocks to repair file. ' +
                               'Recovery blocks were ' + repr (fileList))

        assert (nBlocks == 0)
        
                
        return toRet
            

    def repair (self, par2file):
        """
        Assuming all the needed files are available, check and repair the data
        described in the given par2 file. Remove the old file once it has been
        repaired. 
        """

        cmd = ['par2', 'repair', '-q', par2file]
        callCmd (cmd)
        # Par2 renames the old file by adding a .1 to its name.
        removeThing (par2file[:-4] + '1', ignoreNotExists = True)
        

class ParitorGenerator:
    """Generate a paritor of the correct type"""
    parityConfig = None
    paritor = None

    def __init__ (self, parityConfig):
        self.parityConfig = parityConfig
        
        # For the moment, the only supported paritor type is part2
        self.paritor = Par2Paritor (parityConfig.redundancy)
