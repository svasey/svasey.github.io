"""Classes representing various files of the backup"""

### Author: Sebastien Vasey (http://svasey.org/)

from time import mktime, localtime, strptime, strftime
from os.path import basename

class BackupObject :
    name = None

    def __init__ (self, name):
        self.name = name

    def name2partition (self, partitionName):
        if partitionName == "root":
            return "/"
        else:
            return partitionName.replace ("-", "/")
            
    def partition2name (self, partition):
        if partition == "/":
            return "root"
        else:
            return (partition.replace ("/","-")).strip ("-")

class Archive (BackupObject):
    """Describes a backup archive"""

    def __init__ (self, name):
        BackupObject.__init__ (self, name)

        # Parse the name
        if name:
            (profileName, partition, year, month,
             day, hour, minutes, isFull, level, cycleDay, catalog) \
             = name.split ('.')
            self.profileName = profileName
            self.partition = self.name2partition (partition)
            if isFull == "full":
                self.isFull = True
            elif isFull == "diff":
                self.isFull = False
            self.level = int(level)
            self.cycleDay = int(cycleDay)

            timestruct = strptime (year  + month + day + hour + minutes,
                                   "%Y%m%d%H%M")
            self.timestamp = mktime (timestruct)
            if catalog == "catalog":
                self.onlyCatalog = True
            else:
                self.onlyCatalog = False
        else:
            self.cycleDay = 0
            self.level = 0

    def genName (self):
        """Update the name member from the other ones"""

        timestruct = localtime (self.timestamp)
        partition = self.partition2name (self.partition)
        isFull = "diff"
        if self.isFull:
            isFull = "full"
        catalog = "catalog"
        if not self.onlyCatalog:
            catalog = "archive"
        
        self.name = ".".join ((self.profileName, partition,
                               strftime ("%Y.%m.%d.%H.%M", timestruct),
                               isFull, str(self.level),
                               str(self.cycleDay),
                               catalog))
        return self.name
            
    def isUnused (self):
        """Return true if the archive hasn't been used yet"""
        if not self.name:
            return True
        else:
            return False

    def hasDerivativeName (self, objectName):
        """Return true if the object named objectName has a content based on the
        content of our archive (i.e encrypted, par2 etc...). This is done by
        only comparing the name and hoping conventions are followed"""

        if self.isUnused ():
            return False
        
        name = self.genName ()
        nameNoCatalog = ".".join ((name.split ("."))[:-1])

        return (basename (objectName)).find (nameNoCatalog, 0) != -1

    def dateString (self):
        """
        Return a string giving the date of the archive (in a human-readable
        format) and other important information, like whether it is a full or
        differential backup. Do not write a final newline.
        """

        timeStr = strftime ('%Y/%m/%d, %Hh%M', localtime (self.timestamp))
        if self.isFull:
            return timeStr + ' [full]'
        else:
            return timeStr + ' [differential]'
        

class Index (BackupObject):
    """Class representing a backup index"""

    def __init__ (self, name):
        BackupObject.__init__ (self, name)
        # Default extension and prefix
        self.extension =  'dmd'
        self.prefix = 'index'
        
        # Parse the name:
        if name:
            (prefix, profileName, partition,
             year, month, day, hour, minutes, extension) = name.split (".", 8)
            self.prefix = prefix
            self.profileName = profileName
            self.partition = self.name2partition (partition)
            self.extension = extension

            timestruct = strptime (year + month + day + hour + minutes,
                                   "%Y%m%d%H%M")
            self.timestamp = mktime (timestruct)
            
    def genFirstPartName (self):
        partition = self.partition2name (self.partition)
        return ".".join ([self.prefix, self.profileName, partition])
            
    def genName (self):
        timestruct = localtime (self.timestamp)
        
        self.name = ".".join ([self.genFirstPartName (),
                              strftime ("%Y.%m.%d.%H.%M", timestruct),
                              self.extension])
        return self.name

    def genFromArchive (self, archive, extension = None):
        """
        From an Archive object, generate itself to have the same properties as
        that archive. Use the given extension, or the default one if
        None. Return the new index name
        """

        self.profileName = archive.profileName
        self.partition = archive.partition
        self.timestamp = archive.timestamp
        if not extension is None:
            self.extension = extension

        return self.genName ()

class StatusFileArchive (Index):
    """
    Represent a status file ready to be backed up
    """

    def __init__ (self, name):
        Index.__init__ (self, name)
        self.extension = 'xml'
        self.prefix = 'status'
    
