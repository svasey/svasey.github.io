"""Classes describing darwrap's configuration file and its parsing"""

### Author: Sebastien Vasey (http://svasey.org/)

import fnmatch
from xml.dom import minidom
from os import putenv, remove, makedirs, listdir, rename
from os.path import ismount, basename, join, exists
from glob import glob
from shutil import copyfile
from time import sleep, ctime
from tempfile import mkdtemp

from svlib.servicerunner.Runner import callCmd, UnexpectedStatusError, \
    callCmdGetOutput
from svlib.fs.func import removeThing, mkdirTry
from svlib.string.func import stripExtension
from svlib.random.Random import randomString


from darwrap.DarwrapError import ParsingError, ObjectUncompleteError, \
    SendFileError, DestinationListError, RotationSchemeError, EncryptionError

from darwrap.BackupObject import Archive

class Config:
    """General class describing a configuration"""

    xmlRoot = None
    
    # xmlroot is the root of the section we have to parse to get the
    # configuration
    def __init__ (self, xmlRoot = None):
        self.xmlRoot = xmlRoot
        if not (xmlRoot is None):
            self.read ()

    def read (self):
        raise NotImplementedError ()

    def checkComplete (self):
        raise NotImplementedError ()

    def write (self, stream):
        stream.write (self.xmlRoot.toxml ())

class DarConfig (Config):
    """Describes dar's options"""
    splitSize = "100M"
    excludedFileList = []
    optStr = None

    def read (self):
        self.excludedFileList = []
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "splitSize":
                    self.splitSize = child.firstChild.data.strip ()
                elif child.tagName == "excludedFileList":
                    self.excludedFileList = (FileList (child)).fileList
                elif child.tagName == "optStr":
                    self.optStr = child.firstChild.data.strip ()

    def checkComplete (self):
        pass
                
class CryptoConfig (Config):
    """Describe the backup's cryptographic options"""

    gpgOpts = []
    key = None
    secring = None
    signring = None
    signKey = None

    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "key":
                    self.key = GpgKey (child)
                elif child.tagName == 'secring':
                    self.secring = child.firstChild.data.strip ()
                elif child.tagName == 'signring':
                    self.signring = child.firstChild.data.strip ()
                elif child.tagName == 'signKey':
                    self.signKey = child.firstChild.data.strip ()
                elif child.tagName == 'gpgOpts':
                    self.gpgOpts = (child.firstChild.data.strip ()).split ()
                    
                    
    def checkComplete (self):
        if (not self.key is None):
            self.key.checkComplete ()
        if (not self.secring is None) or (not self.signKey is None) or \
                (not self.signring is None):
            if (self.secring is None) or (self.signKey is None) \
                or (self.signring is None):
                
                raise ObjectUncompleteError ('secring, signring and signKey ' +
                                             'must either be all specified ' +
                                             'or all be empty')
            
class ParityConfig (Config):
    """Describe the parity extra-information options"""

    redundancy = 5

    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "redundancy":
                    self.redundancy = int (child.firstChild.data)

    def checkComplete (self):
        pass
            
class GpgKey (Config):
    NONE, SYMMETRIC, PUBLIC = range (3)
    type = NONE
    passphrase = None
    keyring = None
    keyId = None

    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "keyring":
                    self.keyring = child.firstChild.data.strip ()
                    self.type = self.PUBLIC
                elif child.tagName == "keyId":
                    self.keyId = child.firstChild.data.strip ()
                    self.type = self.PUBLIC
                elif child.tagName == "passphrase":
                    self.passphrase = child.firstChild.data
                    self.type = self.SYMMETRIC
                elif child.tagName == "passphraseFile":
                    filename = child.firstChild.data.strip ()
                    with open (filename, 'r') as file:
                        self.passphrase = file.read (5000)
                        if file.read (1) != "":
                            raise ParsingError ("Passphrase file " +
                                                filename + " too long")
                        self.type = self.SYMMETRIC
                        
    def checkComplete (self):
        pass
    
class RotationScheme (Config, object):
    """Describes a rotation scheme"""
    narchives = 10

    def parse (xmlRoot):
        try:
            type = xmlRoot.getAttribute ("type")
            if type == "TowerOfHanoi":
                return TowerOfHanoi (xmlRoot)
            else:
                raise ParsingError ("Unknown rotation scheme " +
                                    "type: " + type)
        except Exception as err:
            raise ParsingError ("Problem with the rotation "
                                "scheme type attribute: " + repr (err))

    def tapeToUse (self, archiveList):
        """Virtual function which returns the tape to use given the
        archiveList"""
        raise NotImplementedError ("tapeToUse is virtual")

    def today (self, archiveList):
        """Return the current cycleDay"""
        raise NotImplementedError ()

    def doFullBackup (self, archive, archiveList):
        """Return true if we need to do a full backup. False otherwise"""
        raise NotImplementedError ("doFullBackup is virtual")

    def getReference (self, archive, archiveList):
        """Return the index of the reference in archiveList when doing a
        differential backup using archive"""
        raise NotImplementedError ("getReference is virtual")

    def archiveForDate (self, date, archiveList):
        """
        Return the archive whose timestamp is date or the closest before
        date. Return it as an Archive object. If no archive has a equal to or
        before date, raise a RotationSchemeError
        """

        raise NotImplementedError ('archiveForDate is virtual')

    def archiveDependencies (self, archive, archiveList):
        """
        Given a backup archive, return a list of all the archives that will need
        to be restored before it, in the order they will need to be
        restored. Return an empty list if no archives need to be restored
        before.
        """

        raise NotImplementedError ('archiveDependencies is virtual')

        
    
    parse = staticmethod (parse)

    def __eq__ (self, rs):
        if isinstance (rs, type (self)):
            return self.narchives == rs.narchives
        return False

class TowerOfHanoi (RotationScheme):
    # Level at which we do full backup
    fullLevel = -1

    def __eq__ (self, rs):
        if isinstance (rs, type (self)):
            return (super (TowerOfHanoi, self).__eq__ (rs)) and \
                (self.fullLevel == rs.fullLevel)
        return False

    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "narchives":
                    self.narchives = int (child.firstChild.data.strip ())
                elif child.tagName == "fullLevel":
                    self.fullLevel = int (child.firstChild.data.strip ())
    def checkComplete (self):
        if self.fullLevel == -1:
            raise ObjectUncompleteError ("Missing fullLevel tag in rotation " +
                                         "scheme description")
        elif self.fullLevel >= self.narchives:
            # We must accept the case of narchives == 1 and fullLevel == 1
            if (self.narchives != 1) or (self.fullLevel > self.narchives):
                raise ObjectUncompleteError ("Full level is too high in " +
                                             "rotation scheme description: " +
                                             "must be strictly smaller than " +
                                             "number of archives (or 1)")

    def today (self, archiveList):
        # Cycle day of the most recent archive
        lastDay = 0
        # Most recent archive timestamp: the day we will return is the cycle day
        # of the archive with the most recent timestamp incremented by one
        latestTimestamp = 0
        maxDays = 2 ** (len (archiveList) - 1)
        for member in archiveList:
            if not member.isUnused ():
                if member.timestamp > latestTimestamp:
                    latestTimestamp = member.timestamp
                    lastDay = member.cycleDay

        today = lastDay + 1 
        if today > maxDays:
            today = 1

        return today

    def tapeToUse (self, archiveList):
        """Given the list of current tapes, return the id of the one we will use
        for the next backup. Assume the archive list is sorted by cycle day (i.e
        the first archive has cycle day 1, the second cycle day 2 etc..."""

        today = self.today (archiveList)

        # Credit for that code goes to
        # http://www.alvechurchdata.co.uk/softhanoi.htm
        mod = 1
        archive = 0
        while mod <= (2 ** (len (archiveList) - 1)):
            if today & mod:
                return archive
            mod = mod * 2
            archive = archive + 1

        # Should not happen
        assert (False)

    def doFullBackup (self, archive, archiveList):
        if archive.level >= self.fullLevel:
            return True
        maxLevel = 0
        for el in archiveList:
            if not (el.isUnused ()):
                if el.level > maxLevel:
                    maxLevel = el.level
        if maxLevel <= archive.level:
            return True
        else:
            return False

    def getReference (self, archive, archiveList):
        latest = -1
        latestTimestamp = 0
        for id, el in enumerate (archiveList):
            if not (el.isUnused ()):
                if el.level > archive.level:
                    if (el.timestamp > latestTimestamp) and \
                            (el.timestamp < archive.timestamp):
                        latestTimestamp = el.timestamp
                        latest = id
        return latest

    def archiveForDate (self, date, archiveList):
        bestChoice = None
        for el in archiveList:
            if not el.isUnused () and (el.timestamp <= date):
                bestChoice = el

        if not bestChoice:
            raise RotationSchemeError ('No archive before the given ' +
                                       'date: ' + ctime (date))
        

        return bestChoice

    def archiveDependencies (self, archive, archiveList):
        # If the archive is a full backup, there is no dependency
        if archive.isFull:
            return []

        # Otherwise, find the dependencies recursively
        else:
            firstDependency = archiveList[self.getReference (archive,
                                                             archiveList)]
            return self.archiveDependencies (firstDependency, archiveList) + \
                [firstDependency]

        

class Destination (Config, object):
    """Describes a backup destination"""

    def __eq__ (self, dest):
        if isinstance (dest, type (self)):
            return True
        return False
    
    def parse (xmlRoot):
        try:
            type = xmlRoot.getAttribute ("type")
            if type == "mountpoint":
                return MountpointDestination (xmlRoot)
            elif type == "s3":
                return S3Destination (xmlRoot)
            elif type == "rsync":
                return SSHRsyncDestination (xmlRoot)
            else:
                raise ParsingError ("Unknown destination type: " +
                                    type)
        except Exception as err:
            raise ParsingError ("Problem with the destination type " +
                                "attribute: " + repr (err))
    
    parse = staticmethod (parse)

    def sendFiles (self, fileList, doRemove = True, remoteNames = None):
        """Send filenames to the destination. If remoteNames is specified, it
        must be a list with a name (not a path, just a base name) for each file
        in fileList. If you want a default name to be used, the list element
        must be "". If doRemove is true, then remove the local files after
        having sent them. Overwrite the remote file if it exists already. Each
        file transaction must be atomic (i.e either the old remote file is still
        in place, or it has been completely replaced by the new one)"""
        raise NotImplementedError ()
    def removeFiles (self, fileNameList):
        """Remove the files  in fileNameList in destination. Once again,
        each name is only a base name, not a full path"""
        raise NotImplementedError ()

    def updateListCache (self):
        """
        Call this function if you want to update the list of files that are on
        the destination. This might have no effect for some destination
        """

        raise NotImplementedError ()
    
    def listFiles (self, pattern = None):
        """
        Glob for a specific pattern in path. If patern is None, simply return
        a list of all files and directories. The file list might be
        locally-cached. Use updateListCache if you want to update the cache
        """

        raise NotImplementedError ()

    def fetchFiles (self, fileList, writeTo, localNames = None,
                    overwrite = False):
        """
        Fetch the files from the destination to the writeTo
        directory. localNames has the same function as remoteNames in
        sendFiles. Once the files appear in the directory, they are required to
        be complete (i.e one can assume if the files appear in a directory
        listing that they have been entirely fetched). If overwrite is False, no
        existing file will be overwritten, instead it will be assumed that the
        corresponding remote file has already been successfully downloaded.
        """
        raise NotImplementedError ()
    
    def downloadFile (self, fileName, writeTo, paritor, encryptor, signer):
        """
        Download fileName from the remote destination, check its integrity
        (using paritor and signer) and decrypt it (using encryptor). If it has
        already been downloaded or decrypted, do not redo the whole thing. Put
        the file in the writeTo directory. Return the complete path to the
        decrypted file
        """

        filePath = join (writeTo, fileName)
        plainName = stripExtension (fileName)
        plainPath = join (writeTo, plainName)
        if exists (plainPath):
            # Everything has already been done: the code below guarantees that
            # the file is complete. Remove every useless encrypted file or par2
            # information that might be lying around
            for el in glob (filePath + '*'):
                removeThing (el)
            return plainPath

        print 'Downloading, checking and decrypting', fileName
        hasSig = self.listFiles (fileName + '.sig')
        if hasSig:
            self.fetchFiles ([fileName + '.sig'], writeTo)
        self.fetchFiles ([fileName, fileName + '.par2'], writeTo)
        par2file = filePath + '.par2'
        sigFile = filePath + '.sig'

        checkedSig = False

        
        badBlocks = paritor.verify (par2file)

        if badBlocks >= 0:
            print 'WARNING: file', fileName, 'is damaged (' + \
                str (badBlocks) + ') bad blocks. Trying to repair.'
        if badBlocks > 0:
            # Fetch the list of volume file
            volumeList = self.listFiles (fileName + '.vol*.par2')
            
            # List of additionnal par2 volume to download to repair the file. We
            # do not use the paritor.filesForRepair because we cannot assume the
            # integrity of the par2 volume, so we just download everything and
            # hope it is enough.
            toDownload = volumeList
            self.fetchFiles (toDownload, writeTo)
        if badBlocks >= 0:
            paritor.repair (par2file)

        if hasSig:
            # If the signature doesn't match, an exception will be thrown
            signer.verifySig (sigFile)
        else:
            print
            print 'WARNING: BAD SIGNATURE: file', fileName, \
                ' has no signature file !!!'
            print

        # Decrypt the file
        tempDir = mkdtemp (dir = writeTo, prefix = fileName +
                           '.decrypt')
        tempPath = join (tempDir, plainName)
        encryptor.decryptFile (filePath, tempPath)
        rename (tempPath, plainPath)
        for el in glob (filePath + '*'):
            removeThing (el, ignoreNotExists = True)

        return plainPath

class MountpointDestination (Destination):
    """Describes a destination to a mountpoint"""

    mountpoint = None
    # Path relative to the fs root, must be in the mountpoint
    path = None
    # If true, umount the drive after the backup has been done
    doUmount = True

    def __eq__ (self, dest):
        if isinstance (dest, type (self)):
            return (super (MountpointDestination, self).__eq__ (dest)) and \
                (self.path == dest.path) and \
                (self.mountpoint == dest.mountpoint) and \
                (self.doUmount == dest.doUmount)
        return False
    
    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "path":
                    self.path = child.firstChild.data.strip ()
                elif child.tagName == "mountpoint":
                    self.mountpoint = child.firstChild.data.strip ()
                elif child.tagName == 'doumount':
                    umountText = child.firstChild.data.strip ()
                    if (umountText == 'no') or (umountText == 'false') or \
                            (umountText == '0'):
                        self.doUmount = False
                    else:
                        self.doUmount = True

    def checkComplete (self):
        if self.path is None:
            raise ObjectUncompleteError ("Mountpoint destinatino missing path")
        elif self.mountpoint is None:
            raise ObjectUncompleteError ("Mountpoint destination missing " +
                                         "mountpoint")

    def syncDrive (self):
        """Run the unix sync command"""
        try:
            callCmd (["sync"])
        except UnexpectedStatusError as err:
            raise SendFileError ("Could not sync drive: sync exited with " +
                                 "status " + str (err.returnStatus))
        
        # Sleep a while, waiting for everything to settle down
        sleep (2)
        

    def mountDrive (self):
        """Mount our drive at mountpoint. Do not do anything if the mountpoint
        is already mounted"""

        self.syncDrive ()

        if not ismount (self.mountpoint):
            try:
                callCmd (["mount", self.mountpoint])
            except UnexpectedStatusError as err:
                raise SendFileError ("Could not mount " + self.mountpoint +
                                     " : mount exited with status " + 
                                     str (err.returnStatus))
        
    def umountDrive (self):
        """Umount the drive at mountpoint. Do not do anything if the drive was
        already umounted, or if self.doUmount is False"""

        self.syncDrive ()

        if self.doUmount and ismount (self.mountpoint):
            try:
                callCmd (["umount", self.mountpoint])
            except UnexpectedStatusError as err:
                raise SendFileError ("Could not umount " + self.mountpoint +
                                     ": mount exited with status " +
                                     str (err.returnStatus))

    def send (self, source, remoteName):
        """Send a single file source to the destination, naming it remoteName,
        assuming every pre-operation (mounting etc...) has been completed. This
        is guaranteed to be atomic"""
        tempDir = mkdtemp (dir = self.path, prefix = 'darwrapSend')
        tempPath = join (tempDir, remoteName)
        destPath = join (self.path, remoteName)
        copyfile (source, tempPath)
        rename (tempPath, destPath)
        for el in glob (join (self.path, 'darwrapSend*')):
            removeThing (el)

    def fetch (self, remote, source, localName):
        """
        Fetch a single file from the destination to the source, naming it
        localName, assuming every pre-operation (mounting, etc...) has been
        completed
        """
        copyfile (join (self.path, remote), join (source, localName))
        
    def sendFiles (self, fileList, doRemove = True, remoteNames = None):
        if remoteNames is None:
            remoteNames = []
            for f in fileList:
                remoteNames.append ("")
        self.mountDrive ()
        try:
            try:
                makedirs (self.path)
            except OSError as err:
                if not (exists (self.path)):
                    raise
            for local, remote in zip (fileList, remoteNames):
                if remote == "":
                    remote = basename (local)
                
                self.send (local, remote)
                if doRemove:
                    remove (local)
        finally:
            self.umountDrive ()
                

    def removeFiles (self, fileNameList):
        self.mountDrive ()
        try:
            for name in fileNameList:
                remove (join (self.path, name))
        finally:
            self.umountDrive ()

    def updateListCache (self):
        # There is just no use for a cache for a local drive
        pass
            
    def listFiles (self, pattern = None):
        """
        This version does not implement updateCache
        """
        
        self.mountDrive ()
        toReturn = []

        try:
            if pattern is None:
                toReturn = listdir (self.path)
            else:
                toReturn = glob (join (self.path, pattern))
        finally:
            self.umountDrive ()

        return map (basename, toReturn)

    def fetchFiles (self, fileList, writeTo, localNames = None,
                    overwrite = False):
        if localNames is None:
            localNames = []
            for f in fileList:
                localNames.append ('')
        self.mountDrive ()
        for el in glob (join (writeTo, 'Mountpoint.fetchFiles*')):
            removeThing (el, ignoreNotExists = True)
        tempDir = mkdtemp (dir = writeTo, prefix = 'Mountpoint.fetchFiles')
        for local, remote in zip (localNames, fileList):
            if local == '':
                local = basename (remote)
            if overwrite or (not exists (join (writeTo, local))):
                self.fetch (remote, tempDir, local)
                rename (join (tempDir, local), join (writeTo, local))
                
        removeThing (tempDir, ignoreNotExists = True)
        self.umountDrive ()
            
            
        

        
class S3Destination (Destination):
    """Describes a destination to a s3 location"""

    bucket = None
    location = None
    keyfile = None
    optStr = None
    # Keeps a copy of the S3 file list
    listCache = None

    def __eq__ (self, dest):
        if isinstance (dest, type (self)):
            return (super (S3Destination, self).__eq__ (dest)) and \
                (self.bucket == dest.bucket) and \
                (self.location == dest.location) and \
                (self.keyfile == dest.keyfile) and \
                (self.optStr == dest.optStr)
        return False
    
    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "bucket":
                    self.bucket = child.firstChild.data.strip ()
                elif child.tagName == "location":
                    self.location = child.firstChild.data.strip ()
                elif child.tagName == "keyfile":
                    self.keyfile = child.firstChild.data.strip ()
                elif child.tagName == "optStr":
                    self.optStr = child.firstChild.data.strip ()
                    
    def checkComplete (self):
        if self.bucket is None:
            raise ObjectUncompleteError ("S3 Bucket missing")
        elif self.location is None:
            raise ObjectUncompleteError ("S3 Location missing")
        elif self.keyfile is None:
            raise ObjectUncompleteError ("S3 keyfile missing")

    def genBaseCmd (self):
        cmd = ["aws", "--fail", "--secrets-file=" + self.keyfile]
        if not self.optStr is None:
            cmd.extend (self.optStr.split ())

        return cmd

    def send (self, source, remoteName):
        """Send a single file source to the destination, naming it remoteName
        assuming every pre-operation has been completed"""
        cmd = self.genBaseCmd ()
        cmd.append ("put")
        path = join (self.bucket, self.location, remoteName)
        cmd.extend ([path, source])
        callCmd (cmd)

    def fetch (self, remote, writeTo, localName):
        """
        Fetch a single file 'remote', writing it to the writeTo directory,
        naming it localName
        """

        cmd = self.genBaseCmd ()
        cmd.append ('get')

        localPath = join (writeTo, localName)
        remotePath = join (self.bucket, self.location, remote)
        cmd.extend ([remotePath, localPath])
        callCmd (cmd)
    
    def sendFiles (self, fileList, doRemove = True, remoteNames = None):
        if remoteNames is None:
            remoteNames = []
            for f in fileList:
                remoteNames.append ("")
    
        # Create the bucket if it does not exist yet
        cmd = self.genBaseCmd ()
        cmd.extend (["mkdir", self.bucket])
        # It does not matter if this returns with non-zero exit status: this
        # probably means the bucket already exists. If this is another error, it
        # will be caught when we try to send a file
        callCmd (cmd, expectedReturnStatus = None)

        for local, remote in zip (fileList, remoteNames):
            if remote == "":
                remote = basename (local)

            self.send (local, remote)
            if doRemove:
                remove (local)

    def fetchFiles (self, fileList, writeTo, localNames = None,
                    overwrite = False):
        if localNames is None:
            localNames = []
            for f  in fileList:
                localNames.append ('')

        for el in glob (join (writeTo, 'S3.fetchFiles*')):
            removeThing (el, ignoreNotExists = True)
        tempDir = mkdtemp (dir = writeTo, prefix = 'S3.fetchFiles')
        for local, remote in zip (localNames, fileList):
            if local == '':
                local = basename (remote)
            if overwrite or not exists (join (writeTo, local)):
                self.fetch (remote, tempDir, local)
                rename (join (tempDir, local), join (writeTo, local))
                    
        removeThing (tempDir, ignoreNotExists = True)

        
    def remove (self, fileName):
        cmd = self.genBaseCmd ()
        cmd.append ("delete")
        path = join (self.bucket, self.location, fileName)
        cmd.append (path)
        callCmd (cmd)

    def removeFiles (self, fileNameList):
        for el in fileNameList:
            self.remove (el)

    def updateListCache (self):
        cmd = self.genBaseCmd ()
        path = join (self.bucket, self.location)
        cmd.extend (["ls", "-1", path])

        try:
            (retcode, stdoutContent, stderrContent) = callCmdGetOutput (cmd)
        except UnexpectedStatusError as err:
            raise DestinationListError ("Could not list S3 path " + path +
                                        " : aws exited with status " +
                                        str (err.returnStatus))
        # Since this ends with a new line, we have to remove the last
        # element
        self.listCache = map (basename, (stdoutContent.split ("\n"))[:-1])
            
    def listFiles (self, pattern = None):
        if self.listCache is None:
            self.updateListCache ()

        if pattern is None:
            return self.listCache
        else:
            return fnmatch.filter (self.listCache, pattern)

class SSHRsyncDestination (Destination):
    """Send to a remote destination using rsync over SSH"""

    # Additionnal rsync/ssh options
    rsyncOpts = ''
    sshOpts = ''
    host = None
    hostPath = None
    sshUser = None
    sshConfigFile = None
    # Keep a copy of the file list on the destination
    listcache = None

    def __eq__ (self, dest):
        if (isinstance (dest, type (self))):
            return (super (SSHRsyncDestination, self).__eq__ (dest)) and \
                (self.rsyncOpts == dest.rsyncOpts) and \
                (self.sshOpts == dest.sshOpts) and \
                (self.host == dest.host) and \
                (self.hostPath == dest.hostPath) and \
                (self.sshUser == dest.sshUser) and \
                (self.sshConfigFile == dest.sshConfigFile)
        else:
            return False

    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType != child.COMMENT_NODE):
                if child.tagName == "rsyncOpts":
                    self.rsyncOpts = child.firstChild.data.strip ()
                elif child.tagName == "sshOpts":
                    self.sshOpts = child.firstChild.data.strip ()
                elif child.tagName == "host":
                    self.host = child.firstChild.data.strip ()
                elif child.tagName == "hostPath":
                    self.hostPath = child.firstChild.data.strip ()
                elif child.tagName == "sshUser":
                    self.sshUser = child.firstChild.data.strip ()
                elif child.tagName == "sshConfigFile":
                    self.sshConfigFile = child.firstChild.data.strip ()

    def serverstring (self):
        """Return the full string representing the server to send to"""
        return self.sshUser + '@' + self.host
                    
    def sshbase (self):
        """Return the SSH base command"""
        return ['ssh', '-t', '-F', self.sshConfigFile] + self.sshOpts.split (' ') #+ [self.serverstring ()]
    
    def rsyncbase (self):
        """Return the rsync base command"""
        return ['rsync', '--append', '--rsh=' + ' '.join (self.sshbase ()[:-1])] + self.rsyncOpts.split (' ')

    def mkRemoteDir (self, path, canExist = True):
        mkdirCmd = ['mkdir']
        if canExist:
            mkdirCmd.append ('-p')
            
        cmd = self.sshbase () + mkdirCmd + [path]
        callCmd (cmd)        

    def tempSendPrefix (self):
        return '__darwrap_send__'
        
    def send (self, source, remoteName):
        """Send a single file source to the destination, naming it
        remoteName. This is guaranteed to be atomic"""

        tempDirPath = join (self.hostPath, self.tempSendPrefix ())
        tempDestPath = join (tempDirPath, remoteName)

        destPath = join (self.hostPath, remoteName)
        cmd = self.rsyncbase () + [source, self.serverstring () + ':' +
                                   tempDestPath]
        callCmd (cmd)
        callCmd (self.sshbase () + ['mv', tempDestPath, destPath])

        
    def sendFiles (self, fileList, doRemove = True, remoteNames = None):
        if remoteNames is None:
            remoteNames = []
            for f in fileList:
                remoteNames.append ("")

        self.mkRemoteDir (self.hostPath)
        tempDirPath = join (self.hostPath, self.tempSendPrefix ())
        self.mkRemoteDir (tempDirPath)

        for local, remote in zip (fileList, remoteNames):
            if remote == '':
                remote = basename (local)

            self.send (local, remote)
            if doRemove:
                remove (local)

        callCmd (self.sshbase () + ['rm', '-rf', tempDirPath])
                                    

    def removeFiles (self, fileNameList):
        sizeLimit = 1000
        if len (fileNameList) > sizeLimit:
            self.removeFiles (fileNameList[:sizeLimit])
            self.removeFiles (fileNameList[sizeLimit:])
        else:
            fullnames = map (lambda el: join (self.hostPath, el), fileNameList)
            if fullnames:
                callCmd (self.sshbase () + ['rm'] + fullnames)           

    
    def updateListCache (self):
        cmd = self.sshbase () + ['ls', self.hostPath]
        (retcode, stdoutContent, stderrContent) = callCmdGetOutput (cmd)
        self.listCache = map (basename, (stdoutContent.split ()))
    
    def listFiles (self, pattern = None):
        if self.listCache is None:
            self.updateListCache ()

        if pattern is None:
            return self.listCache
        else:
            return fnmatch.filter (self.listCache, pattern)
        

    def fetch (self, remote, writeTo, localName):
        """
        Fetch a single file 'remote', writing it to the writeTo directory,
        naming it localName
        """

        cmd = self.rsyncbase () + [self.serverstring() + ':' + join (self.hostPath, remote),
                                   join (writeTo, localName)]
        callCmd (cmd)
        
    def fetchFiles (self, fileList, writeTo, localNames = None,
                    overwrite = False):
        if localNames is None:
            localNames = []
            for f in fileList:
                localNames.append ('')
        tempPrefix = '__SSHRsync.fetchFiles__'
        tempDir = join (writeTo, tempPrefix)
        mkdirTry (tempDir)
        for local, remote in zip (localNames, fileList):
            if local == '':
                local = basename (remote)
            if overwrite or (not exists (join (writeTo, local))):
                self.fetch (remote, tempDir, local)
                rename (join (tempDir, local), join (writeTo, local))
            
        removeThing (tempDir)

    def checkComplete (self):
        if self.host is None:
            raise ObjectUncompleteError ('Host is missing')
        elif self.hostPath is None:
            raise ObjectUncompleteError ('Host path is missing')
        elif self.sshUser is None:
            raise ObjectUncompleteError ('SSH User is missing')
        elif self.sshConfigFile is None:
            raise ObjectUncompleteError ('SSH config file is missing')

class DarwrapConfig (Config):
    """Darwrap configuration class"""

    filepath = None
    progConfig = None
    profileList = []
    
    def __init__ (self, filepath):
        self.filepath = filepath
    def read (self):
        """Parse the configuration file stored at self.filepath"""
        document = minidom.parse (self.filepath)
        self.profileList = []
        for child in document.childNodes[0].childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "global":
                    self.progConfig = GlobalConfig (child)
                elif child.tagName == "profile":
                    self.profileList.append (Profile (child))
        if self.progConfig is None:
            raise ParsingError ("Could not find global or default section " +
                                "in " + self.filepath)
        if not self.profileList:
            raise ParsingError ("Not profiles found in " + self.filepath)
        self.checkComplete ()
            
    def findProfile (self, profileName):
        """Return the backup profile object having name profileName, or None if
        not found"""
        for el in self.profileList:
            if el.name == profileName:
                return el
        return None
    def checkComplete (self):
        if self.progConfig is None:
            raise ObjectUncompleteError ("Missing global program configuration")
        self.progConfig.checkComplete ()
        for profile in self.profileList:
            profile.checkComplete ()
        
    

            

class GlobalConfig (Config):
    """Describes darwrap's configuration, not specific to any profile"""

    spoolpath = None
    syspath = "/bin:/usr/bin:/usr/local/bin:/sbin:/usr/sbin:/usr/local/sbin"
    
    def read (self):
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType != child.COMMENT_NODE):
                if child.tagName == "spoolpath":
                    self.spoolpath = child.firstChild.data.strip ()
                elif child.tagName == "syspath":
                    self.syspath = child.firstChild.data.strip ()
        pass
    
    def checkComplete (self):
        if self.spoolpath is None:
            raise ObjectUncompleteError ("Missing spool path")

    def applySettings (self):
        """Apply settings like syspath"""
        putenv ("PATH", self.syspath)
    

class Profile (Config):
    """Describe a backup profile configuration"""

    name = None
    destination = None
    source = None
    darOptions = DarConfig ()
    cryptoOptions = CryptoConfig ()
    parityOptions = ParityConfig ()
    rotationScheme = None
    
    def read (self):
        try:
            self.name = self.xmlRoot.getAttribute ("name")
        except Exception as err:
            raise ParsingError ("No name attribute to profile section: " +
                                repr (err))
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "destination":
                    self.destination = Destination.parse (child)
                elif child.tagName == "source":
                    self.source = child.firstChild.data.strip ()
                elif child.tagName == "darOptions":
                    self.darOptions = DarConfig (child)
                elif child.tagName == "cryptoOptions":
                    self.cryptoOptions = CryptoConfig (child)
                elif child.tagName == "parityOptions":
                    self.parityOptions = ParityConfig (child)
                elif child.tagName == "rotationScheme":
                    self.rotationScheme = RotationScheme.parse (child)
                
    def checkComplete (self):
        """Raise an exception if the object is not complete"""
        if (self.name is None):
            raise ObjectUncompleteError ("No name given to profile")
        if (self.destination is None):
            raise ObjectUncompleteError ("No destination in profile " +
                                         self.name)
        if (self.source is None):
            raise ObjectUncompleteError ("No source provided in profile " +
                                         self.name)
        if (self.rotationScheme is None):
            raise ObjectUncompleteError ("No rotation scheme in profile " +
                                         self.name)

        self.destination.checkComplete ()
        self.darOptions.checkComplete ()
        self.cryptoOptions.checkComplete ()
        self.parityOptions.checkComplete ()
        self.rotationScheme.checkComplete ()


class FileList (Config):
    """Helper class to help parse filelists"""
    
    fileList = []

    def readSourceFile (self, filename):
        with open (filename, 'r') as file:
            for line in file:
                fileexpr = line.strip ("\n")
                files = glob (fileexpr)
                # Dar will take care of non-existing files
                if not files:
                    self.fileList.append (fileexpr)
                else:
                    self.fileList.extend (files)
    
    def read (self):
        self.fileList = []
        for child in self.xmlRoot.childNodes:
            if (child.nodeType != child.TEXT_NODE) and \
                    (child.nodeType  != child.COMMENT_NODE):
                if child.tagName == "file":
                    self.fileList.append (child.firstChild.data.strip ())
                elif child.tagName == "source":
                    self.readSourceFile (child.firstChild.data.strip ())
        
    

                



    
