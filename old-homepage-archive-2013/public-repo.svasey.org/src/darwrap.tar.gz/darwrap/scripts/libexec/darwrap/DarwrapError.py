"""Darwrap exception classes""" 

### Author: Sebastien Vasey (http://svasey.org/)

class DarwrapError (Exception):
    """Base class for exceptions in darwrap"""
    def __init__ (self, value = "No error description provided",
                  returnStatus = 1):
        self.value = value
        self.returnStatus = returnStatus
    def __str__ (self):
        return "Darwrap error: " + self.value
    def isDarwarpError ():
        return True

class KillError (DarwrapError):
    pass
    
class ParsingError (DarwrapError):
    pass

class ObjectUncompleteError (ParsingError):
    pass

class InvocationError (DarwrapError):
    pass

class BackupNotDoneError (DarwrapError):
    pass

class BackupBlockedError (DarwrapError):
    pass

class StatusFileError (DarwrapError):
    pass

class BackupFailedError (DarwrapError):
    pass

class RestoreError (DarwrapError):
    """
    Raised when an error happens at restoration time
    """
    pass

class IndexError (DarwrapError):
    """
    Thrown when impossible to find an index/status couple with the same date on
    the remote destination
    """
    pass

class RotationSchemeError (DarwrapError):
    """
    Raised when an error happens while calling rotation scheme methods
    """
    pass

class EncryptionError (DarwrapError):
    pass

class ParityError (DarwrapError):
    pass

class SendFileError (DarwrapError):
    pass

class IndexError (DarwrapError):
    pass

class DestinationListError (DarwrapError):
    pass

class AlreadyRunningError (DarwrapError):
    def __init__ (self):
        DarwrapError.__init__ (self, "Another instance is already running: " +
                               "try `kill` if you want to stop it", 2)
