"""
Main backup-restoring program
"""

### Author: Sebastien Vasey (http://svasey.org/)

from optparse import OptionParser
import sys

def parsecl ():
    """
    Parse the command line arguments and return a tuple; (profileName,
    configPath, action, restoreDate, restoreDest, restoreSrc, restoreFile,
    darManagerOpts, darOpts, privKey) containing all the options that were given
    by the user.
    """

    raise NotImplementedError ()

def main ():
    (profileName, configPath, action, restoreDate, restoreDest, restoreSrc,
     restoreFile, darManagerOpts, darOpts, privKey) =  parsecl ()

if __name__ == '__main__':
    sys.exit (main ())
