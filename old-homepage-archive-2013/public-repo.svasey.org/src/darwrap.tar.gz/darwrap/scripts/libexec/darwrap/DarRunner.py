"""Classes for running dar"""

### Author: Sebastien Vasey (http://svasey.org/)

from tempfile import NamedTemporaryFile, mkdtemp
from os.path import join, exists, basename
from subprocess import Popen, check_call, PIPE
import subprocess
from glob import glob
from time import sleep
from copy import copy

from svlib.servicerunner.Runner import callCmd, callCmdGetOutput, \
    UnexpectedStatusError
from svlib.fs.func import ls, removeThing

from BackupObject import Archive
from DarwrapError import IndexError

class DarRunner:
    """Create the actual backup archive"""
    
    darConfig = None
    # Source directory to backup
    source = None
    
    # Backup archive to take as reference. if None, do full backup
    reference = None
    # Backup archive to output to
    dest = None
    # Catalog to output after having made the backup
    catalog = None

    # Directory where we are doing this
    profileDir = None
    
    # True if we started the backup
    started = False
    
    def __init__ (self, darConfig, source, reference, dest, catalog,
                  profileDir):
        self.darConfig = darConfig
        self.source = source
        self.reference = reference
        self.dest = dest
        self.catalog = catalog
        self.profileDir = profileDir
        self.cmd = self.genDarCmd ()

    def genDarCmd (self):
        """Return a list with the dar command to run"""
        cmd = ["dar", "--create", join (self.profileDir,
                                        self.dest.genName ())]
        cmd.extend (["-Q", "--noconf", "--alter=atime",
                    "--empty-dir"])
        if not (self.darConfig.optStr is None):
            cmd.extend (self.darConfig.optStr.split ())

        # Generate a temporary file wth all files to exclude
        stream = NamedTemporaryFile (prefix = self.dest.profileName + ".",
                                     dir = self.profileDir, delete = False)
        for f in self.darConfig.excludedFileList:
            stream.write (f + "\n")

        cmd. extend (["--slice", self.darConfig.splitSize,
                      "--exclude-from-file", stream.name,
                      "--fs-root", self.source])
        stream.close ()
        if not (self.reference is None):
            cmd.extend (["--ref", join (self.profileDir,
                                       self.reference.genName ())])

        if not (self.catalog is None):
            cmd.extend (["--on-fly-isolate", join (self.profileDir,
                                                  self.catalog.genName ())])

        return cmd

    def run (self):
        return callCmd (self.cmd, expectedReturnStatus = None)
        
    def currentSlice (self):
        """Return the number of the slice dar is currently writing to, or the
        last written slice number if dar is not writing to any slice, or 0 if no
        slice has yet been written to"""
        commonName = self.dest.genName ()
        archives = glob (join (self.profileDir,commonName + ".?*"))
        maxSlice = 0
        for el in archives:
            name = basename (el)
            (sliceNumber, sep, rest) = \
                name[len (commonName) + 1:].partition (".")
            if int(sliceNumber) > maxSlice:
                maxSlice = int(sliceNumber)

        return maxSlice
            
class DarIndexRunner:
    """Update the backup index"""
    backupIndexName = None
    toAdd = None
    profileDir = None

    def __init__ (self, backupIndexName, toAdd, profileDir):
        self.backupIndexName = backupIndexName
        self.toAdd = toAdd
        self.profileDir = profileDir

    def genCmd (self):
        cmd = ["dar_manager", "--verbose", "-Q", "--base",
               join (self.profileDir,self.backupIndexName)]
        cmd.extend (["--add", join (self.profileDir, self.toAdd.genName ())])
        toAddArchive = copy (self.toAdd)
        toAddArchive.onlyCatalog = False
        cmd.append (join (".", toAddArchive.genName ()))
        
        return cmd


    def removeArchivesWithLevel (self, level):
        """Remove all archives of a given level from the index file"""

        (retcode, out, errOut) = callCmdGetOutput \
            (["dar_manager", "-Q", "--base",
                  join (self.profileDir, self.backupIndexName),
                  "--list"])
        if retcode != 0:
            raise IndexError ("Listing the index file returned non-zero " +
                              "status: " + str (retcoe))

        # The last element is the empty string ("")
        lines = (out.split ("\n"))[:-1]
        toParse = []
        
        for id, lin in enumerate (lines):
            if lin.find ("-" * 5) != -1:
                toParse = lines[(id + 1):]
                break

        # This is a little trick: this way, we will be able to remove the
        # archiveId without having the other archiveId we are interested in
        # changed.
        toParse.reverse ()
        for lin in toParse:
            (archiveId, path, basename) = lin.split ()
            archive = Archive (basename)
            if archive.level == level:
                callCmd (["dar_manager", "-Q", "--base",
                          join (self.profileDir, self.backupIndexName),
                          "--delete", archiveId])
                            

    def run (self):
        """Run the dar indexer, blocking and returning the return status"""

        if not (exists (join (self.profileDir, self.backupIndexName))):
            cmd = ["dar_manager", "-Q", "--create",
                   join (self.profileDir, self.backupIndexName)]
            self.ret = callCmd (cmd, expectedReturnStatus = None)
            if self.ret != 0:
                return self.ret

        self.removeArchivesWithLevel (self.toAdd.level)
            
        self.cmd = self.genCmd ()

        return callCmd (self.cmd, expectedReturnStatus = None)

class DarRestore:
    """
    To use to restore a hierarchy using dar
    """

    def __init__ (self, restoreDir, archive, src, dest, darOpts):
        """
        restoreDir is the directory where all the archives are. archive is the
        archive to use, as an Archive object. src is the source directory we
        should restore, dest is where we should restore it, darOpts is a list of
        additionnal options to pass to dar
        """

        self.restoreDir = restoreDir
        self.archive = archive
        self.src = src
        self.dest = dest
        self.darOpts = darOpts

    
    def genDarCmd (self):
        """
        Update the cmd member with the dar command that we should run for
        restoration. Assume all the archives are ready to be used in the 
        directory. Return the full command (as a list)
        """

        self.cmd = ['dar'] +  self.darOpts + \
            ['--extract', join (self.restoreDir, self.archive.genName ()),
             '-Q', '--noconf', '--fs-root', self.dest, '--no-warn',
             '--go-into', self.src]
        return self.cmd

    def run (self):
        """
        Run the restoration command, assuming everything is ready. Raise an
        UnexpectedStatusError if dar's return status is not 0. Return the return
        status (always 0)
        """

        return subprocess.check_call (self.cmd, stdout = open ('/dev/null', 'w'))

    def downloadNeededFiles (self, downloadFunc):
        """
        Download all files that are needed for restoration using
        downloadFunc. For this to work, the last slice must already be in the
        restore directory. If you want to avoid one unecessary iteration, please
        also put the first slice in :-) .
        """

        needed = self.getNeededFiles ()
        while needed:
            for el in needed:
                downloadFunc (el + '.gpg')
            needed = self.getNeededFiles ()
        
    
    def getNeededFiles (self):
        """
        Get a partial list of all the archive files that are needed for the
        restoration but are not yet in the restore directory. Return an empty
        list if no more slices are needed. You should download the archives in
        the list that is returned, and call that function again to see if more
        slices are needed. This doesn't work in case the last slice is missing:
        the last slice should therefore already be in the restore directory
        """

        tempDir = mkdtemp (dir = self.restoreDir, prefix = 'neededFiles')
        cmd = self.genDarCmd ()
        # Perform a real run with an action everytime a slice is needed. The
        # action will be to touch an empty file in the temporary directory named
        # the same as the needed slice. Once this is run, we just need to list
        # the files. Unfortunately --empty does not work. FIXME: this is a hack
        # that makes things very slow: find a better way.
        cmd = cmd + ['--execute', 'touch ' + join (tempDir, '%b.%n.%e')]

        # This can make things slightly faster if the restore process is
        # interrupted and then resumed.
        cmd.remove ('--no-warn')
        subprocess.call (cmd, stdout = open ('/dev/null', 'w'))

        needed = ls (tempDir)
        for el in glob (join (self.restoreDir,'neededFiles*')):
            removeThing (el)

        # Remove the files already in the restore directory from the needed list
        return filter (lambda el: not exists (join (self.restoreDir, el)),
                       needed)
