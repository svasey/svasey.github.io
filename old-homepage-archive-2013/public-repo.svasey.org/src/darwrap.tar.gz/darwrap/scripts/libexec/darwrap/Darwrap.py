"""Do a backup using dar. You must pass the backup profile and the configuration
file as argument."""

### Author: Sebastien Vasey (http://svasey.org/)

import sys

from optparse import OptionParser
from glob import glob
from os import rename, stat, kill
from signal import SIGTERM, SIGKILL
from os.path import join, exists, realpath
from time import time, ctime, strptime, mktime, sleep
from datetime import datetime
from calendar import monthrange
from inspect import getmembers
from tempfile import mkdtemp

from darwrap.DarwrapError import DarwrapError, BackupNotDoneError, \
    InvocationError, AlreadyRunningError, RestoreError, RotationSchemeError, \
    BackupBlockedError, KillError
from darwrap.DarwrapConfig import DarwrapConfig
from darwrap.BackupMaker import BackupMaker
from darwrap.BackupStatus import Status
from darwrap.Encryption import ParitorGenerator, EncryptorGenerator, \
    SignerGenerator
from darwrap.DarRunner import DarRestore

from svlib.globallock.GlobalLock import GlobalLock, LockingFailedError
from svlib.fs.func import diskUsage, mkdirTry, removeThing
from svlib.string.func import stripExtension
from svlib.picklefile.PickleFile import AtomicPickleFile

class Darwrap:
    """Darwrap program class"""
    # This will be overwritten by the install.sh script. Make sure not to rename
    # that variable.
    version = "0.1.1-32-gc47e80b-+"

    # List of all possible actions
    ACTION_LIST = ['continue', 'new', 'status', 'list', 'restore',
                   'restore-clean', 'reset', 'block', 'unblock', 'kill']
    # Actions that cannot be run concurrently on the same profile
    SENSIBLE_ACTIONS = ['continue', 'new', 'restore', 'restore-clean',
                        'reset', 'block', 'unblock']

    def configurationInodeNumber (self):
        """Return a readable hash of the configurationFile inode number"""

        canonicalPath = realpath (self.configurationFile)
        confStat = stat (canonicalPath)
        return confStat.st_ino

    def getServiceName (self):
        """Return a service name for this runner"""
        
        # It would be too long to use profileName + configurationFile as name,
        # but we still need a unique name, so we use the inode number of the
        # configurationFile and append it to darwrap-profileName.
        inodeNumber = self.configurationInodeNumber ()
        
        return "darwrap-" + self.profileName + "-" + str(inodeNumber)

    def __init__ (self, profileName = None , configurationFile = None,
                  action = None, options = None):
        """
        If the profileName is None, this is interpreted as the construction of
        a 'dummy' object, useful only to e.g get the version number
        """
        
        self.profileName = profileName
        self.configurationFile = configurationFile
        self.action = action
        self.options = options
        if options is None:
            self.secPath = None
        else:
            self.secPath = options.secpath

        if self.profileName is not None:
            if action not in self.ACTION_LIST:
                raise InvocationError ('Invalid action specified')
            serviceName = self.getServiceName ()
            self.runLock = GlobalLock (serviceName)
            self.pidFile = join ('/tmp', serviceName + '.pid')

    def start (self):
        """Try to run darwrap. If the action is in SENSIBLE_ACTIONS, and another
        instance using the same configuration is already running, raise
        AlreadyRunningError"""


        if self.action in self.SENSIBLE_ACTIONS:
            try:
                self.runLock.lock (block = False)
            except LockingFailedError:
                raise AlreadyRunningError ()
        try:
            self.run ()
        except:
            raise
        finally:
            if self.runLock.hasLock:
                self.runLock.unlock ()

    def checkStatus (self):
        """
        Print a message to stdout giving darwrap's status to the user
        """

        running = self.runLock.isLocked ()

        if running:
            print 'Darwrap is currently running'
        else:
            print 'Darwrap is currently NOT running'
        if self.backup.isBlocked ():
            print 'This backup has been BLOCKED from running by a user'
        # Find out whether we are doing a full or differential backup
        currentArchive = self.backup.statusFile.currentArchive            
        if not currentArchive.isUnused ():
            print 'Current archive used is', currentArchive.dateString ()
        print 'Current status follows'
        print

        profilePath = self.backup.profilePath
        status = self.backup.getStatus ()
        if status.status == status.DONE:
            print 'Backup done'
        elif status.status == status.LOCAL:
            print 'Doing local dar backup'
            print 'About', diskUsage \
                (glob (join (profilePath, '*.archive.*.dar'))) / 1000, \
                'KB of dar archives have already been created'
        elif status.status == status.CRYPTING:
            print 'Encrypting and computing backup parity information'
            plainList = glob (join (profilePath, '*.archive.*.dar')) + \
                glob (join (profilePath, '*.dmd')) + glob (join (profilePath,
                                                                '*.xml'))

            gpgList = glob (join (profilePath, '*.gpg'))

            
            print 'About', diskUsage (plainList) / 1000, \
                'KB left to be processsed.'
        elif status.status == status.SENDING:
            print 'Sending backup'
            
            fileList = glob (join (profilePath, '*.gpg')) + \
                glob (join (profilePath, '*.par2'))
            print 'About', diskUsage (fileList) / 1000, 'KB (' + \
                str (len (fileList)), 'files) remain to be sent'
        elif status.status == status.CLEANING:
            print 'Cleaning up after backup'
        else:
            # There is norrmally no other possible status value
            assert (False)

    def listArchives (self):
        """
        List all the complete backup archives that are available for
        restoration to the user (via stdout)
        """

        archiveList = self.backup.getSortedArchiveList ()

        if len (archiveList) == 0:
            print '(No backup archive available yet)'
        for el in archiveList:
            print el.dateString ()

    def processRestoreOptions (self, options):
        """
        Given the command line options as given by OptionParser, return a tuple
        (date, restoreDest, restoreSrc, darOpts, secPath) containing the date
        given by the user (as a unix timestamp), path where to restore the data,
        the path to restore (file or directory), the options passed to dar (as a
        list), and the path to the secret keyring
        """

        date = time ()
        if options.date:
            date = options.date
            
        restoreDest = self.backup.statusFile.source
        if options.restoredest:
            restoreDest = options.restoredest
        restoreSrc = '.'
        if options.restoresrc:
            restoreSrc = options.restoresrc
        darOpts = []
        if options.daropts:
            darOpts = options.daropts.split ()
        secPath = None
        secPath = options.secpath

        return (date, restoreDest, restoreSrc, darOpts, secPath)

    def archiveForDate (self, date):
        """
        Return the archive whose timestamp is date or the closest before
        date. Return it as an Archive object. If no archive has a equal to or
        before date, raise a RestoreError
        """

        archiveList = self.backup.getSortedArchiveList ()
        rotationScheme = self.backup.backupProfile.rotationScheme
        try:
            return rotationScheme.archiveForDate (date, archiveList)
        except RotationSchemeError:
            raise RestoreError ('No archive available before ' + ctime (date))

    def archiveDependencies (self, archive):
        """
        Return a list of all the archives that need to be restored before
        archive, in the order they have to be restored. Return an empty list if
        there are no such archives
        """

        archiveList = self.backup.getSortedArchiveList ()
        rotationScheme = self.backup.backupProfile.rotationScheme

        return rotationScheme.archiveDependencies (archive, archiveList)

    def findLastSliceFile (self, archive):
        """
        Find the remote file name corresponding to the last slice of the
        archive. Return the file basename
        """

        archiveName = archive.genName ()
        destination = self.backup.backupProfile.destination
        sliceList = destination.listFiles (archiveName + '.*.dar.gpg')
        maxNumber = -1
        for el in sliceList:
            sliceNumber = int (el[len (archiveName) + 1:].split ('.')[0])
            if sliceNumber > maxNumber:
                maxNumber = sliceNumber
        assert (maxNumber != -1)
        
        return archiveName + '.' + str (maxNumber) + '.dar.gpg'
    
    def downloadFile (self, fileName):
        """
        Download fileName from the remote destination, check its integrity and
        decrypt it. If it has already been downloaded or decrypted, do not redo
        the whole thing. Put the file in the restore directory. Return the
        complete path to the decrypted file
        """

        destination = self.backup.backupProfile.destination
        
        return destination.downloadFile (fileName, self.restoreDir,
                                         self.paritor, self.encryptor,
                                         self.signer)

    def restoreArchive (self, archive, src, dest):
        """
        Restore a given source directory (src) from a given archive (archive) to
        a given destination directory (dest)
        """

        archiveName = archive.genName ()
        firstSlice = archiveName + '.1.dar.gpg'
        lastSlice = self.findLastSliceFile (archive)
        print 'Downloading needed dar files'
        self.downloadFile (firstSlice)
        self.downloadFile (lastSlice)
        restorer = DarRestore (self.restoreDir, archive, src, dest,
                               self.darOpts)
        restorer.downloadNeededFiles (self.downloadFile)
        print 'Extracting data from dar archive'
        restorer.run ()
        
    
    def restoreBackup (self, options):
        """
        Restore the backup archive described in options
        """

        (date, restoreDest,  restoreSrc, self.darOpts, self.secPath) = \
            self.processRestoreOptions (options)

        # Directory where files will be downloaded
        self.restoreDir = join (self.backup.profilePath, 'restore')
        mkdirTry (self.restoreDir)
        
        archive = self.archiveForDate (date)
        
        # List of the archives to restore, in the order they have to be restored
        restoreList = self.archiveDependencies (archive) + [archive]

        print 'Archives that will be restored are, in order'
        for el in restoreList:
            print el.dateString ()
        
        for el in restoreList:
            print 'Restoring archive', el.dateString ()
            self.restoreArchive (el, restoreSrc, restoreDest)

    def restoreClean (self):
        """
        Cleanup after a successful restoration
        """

        self.restoreDir = join (self.backup.profilePath, 'restore')
        removeThing (self.restoreDir)

    def doKill (self):
        """
        Do a few sanity checks, then send SIGTERM and maybe SIGKILL to a darwrap
        instance with the current profile. Raise an InvocationError if the
        sanity checks fail
        """

        running = self.runLock.isLocked ()

        if not running:
            raise InvocationError ('No darwrap backup is running for that ' +
                                   'profile')

        status = self.backup.getStatus ()
        if status.status == status.DONE:
            raise InvocationError ('Backup has already been done: nothing ' +
                                   'to kill')
        if not exists (self.pidFile):
            raise InvocationError ('Pid file ' + self.pidFile + ' does not ' +
                                   'exist')

        pid = (AtomicPickleFile (self.pidFile)).readContent ()
        kill (pid, SIGTERM)
        sleep (2)
        if exists (join ('/proc', str (pid))):
            print 'Backup did not respond to SIGTERM, trying SIGKILL'
            kill (pid, SIGKILL)
        if exists (join ('/proc', str (pid))):
            raise KillError ('Failed to kill process ' + pid)
            
        print 'Currently running backup has been killed.'
        
    def run (self):
        """Run darwrap"""
        config = DarwrapConfig (self.configurationFile)
        config.read ()
        profile = config.findProfile (self.profileName)
        if profile is None:
            raise InvocationError ("Could not find profile named " + \
                                       self.profileName)
        self.backup = BackupMaker (self.configurationFile,
                                   profile, config.progConfig, self.action,
                                   self.pidFile)
        self.paritor = (ParitorGenerator \
                            (self.backup.backupProfile.parityOptions)).paritor
        self.encryptor = (EncryptorGenerator \
                              (self.backup.backupProfile.cryptoOptions)).encryptor
        self.signer = (SignerGenerator \
                           (self.backup.backupProfile.cryptoOptions)).signer
        if ((self.action != 'reset') and \
                (not exists (self.backup.statusFilePath))) or \
                (self.action == 'restore'):
            self.encryptor.initDecryption (self.secPath)

        self.backup.processStatusFile (self.paritor, self.encryptor, self.signer)
        if self.action == 'reset':
            # Nothing to be done, everything was done in processStatusFile
            # constructor.
            pass
        elif self.action == 'block':
            self.backup.block ()
            print 'Backup successfully blocked from running.'
        elif self.action == 'unblock':
            self.backup.unblock ()
            print 'Backup successfully unblocked.'
        elif self.action == 'kill':
            self.doKill ()
        elif self.action == 'new':
            if (not self.backup.isDone ()):
                raise BackupNotDoneError ("Previous backup has not been " +
                                          "done correctly. Please use " +
                                          "continue to finish that backup " +
                                          "first")
            elif self.backup.isBlocked ():
                raise BackupBlockedError ('Backup has been blocked by the ' +
                                          'user. Use unblock to change this.')
            else:
                self.backup.make ()
        elif self.action == 'continue':
            if self.backup.isBlocked ():
                raise BackupBlockedError ('Backup has been blocked by the ' +
                                          'user. Use unblock to change this.')
            else:
                self.backup.doContinue ()
        elif self.action == 'restore-clean':
            self.restoreClean ()
        elif self.action == 'status':
            self.checkStatus ()
        elif self.action == 'restore':
            self.backup.downloadStatusFile (self.paritor, self.encryptor,
                                            self.signer)
            self.restoreBackup (self.options)
        elif self.action == 'list':
            self.backup.downloadStatusFile (self.paritor, self.encryptor,
                                            self.signer)
            self.listArchives ()

def parseDate (parser, dateStr):
    """
    From a yyyy[MMddhhmm] date string, return the equivalent timestamp or raise
    an error via the command line parser if the date string could not be parsed
    """

    year = 1900
    month = 12
    day = 31
    hour = 23
    minute = 59
    
    if len (dateStr) >= 4:
        year = int (dateStr[:4])
    else:
        parser.error ('Date member must contain at least the year')
        
    if len (dateStr) >= 6:
        month = int (dateStr[4:6])
    if len (dateStr) >= 8:
        day = int (dateStr[6:8])
    else:
        # Get the last day of the month
        day = monthrange (year, month)[1]
        
    if len (dateStr) >= 10:
        hour = int (dateStr[8:10])
    if len (dateStr) >= 12:
        minute = int (dateStr[10:12])

    date = datetime (year, month, day, hour, minute)

    return mktime (date.timetuple ())
    

def parsecl ():
    """
    Parse the command line arguments and return a (options, profileName,
    configurationFile, action) tuple, where options is a dictionary containing
    all the options given and their value
    """
    
    # Create dummy Darwrap object to get the version
    dummy = Darwrap ()
    parser = OptionParser (usage = 'darwrap profileName configurationFile ' +
                           'action',  version = '%prog ' + dummy.version)
    parser.add_option ('-d', '--date', dest = 'date',
                       help = 'Date of the backup to restore. Can only be ' +
                       'used with restore, a backup matching that date will ' +
                       'be selected, or the closest one before that date. ' +
                       'If not given, the latest backup will be selected. ')
    parser.add_option ('-r', '--dest-root', dest = 'restoredest',
                       help = 'Can only be used with restore. Where ' +
                       'everything will be restored. If not given, default ' +
                       'to the source path given in the configuration file')
    parser.add_option ('-R', '--to-restore', dest = 'restoresrc',
                       help = 'Can only be used with restore. Hierarchy to ' +
                       'restore. If not given, default to .')
    parser.add_option ('-O', '--dar-opts', dest = 'daropts',
                       help = 'Can only be used with restore. Additionnal ' +
                       'options to pass to dar (space-separated)')
    parser.add_option ('-S', '--secring-path', dest = 'secpath',
                       help = 'Path to gpg ' +
                       'private keyring in case one needs to decrypt ' +
                       'public-key encrypted backups or status file. ' +
                       'Darwrap will ask for the passphrase')
    (options, args) = parser.parse_args ()

    if len (args) != 3:
        parser.error ('I expect exactly three arguments')

    action = args[2]

    # Parse the date option
    if options.date:
        options.date = parseDate (parser, options.date)

    return (options,) + tuple (args)

        
    
def main ():
    # Parse command line options

    (options, profileName, configurationFile, action) = parsecl ()
    try:
        prog = Darwrap (profileName, configurationFile, action, options)
        prog.start ()
    except DarwrapError as err:
        sys.stderr.write (str (err) + "\n")
        return 1
    
    return 0
    
if __name__ == "__main__":
    sys.exit (main ())

    

