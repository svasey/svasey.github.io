"""Daemon which tries to continue unfinished backups"""

### Author: Sebastien Vasey (http://svasey.org/)

import sys
from time import sleep
from traceback import print_exc
from optparse import OptionParser
from subprocess import Popen
from signal import SIGTERM, signal

from svlib.servicerunner.Runner import callCmd

def parsecl ():
    """
    Parse the command line. Return a tuple (profileList, checkInterval, ' +
    'multipleResume) where `profileList` is the path to the file containing the
    backup profiles to resume, `checkInterval` is the interval to wait between
    two checks, and `multipleResume` is true if resuming multiple profiles at
    the time is allowed.
    """
    
    parser = OptionParser (usage = 'darwrap-continued profileList ' +
                           'checkInterval')
    parser.add_option ('-m', '--multiple-resume', dest = 'nowait',
                       help = 'Resume multiple profile at the time',
                       action = 'store_true', default = False)

    (option, args) = parser.parse_args ()

    if len (args) != 2:
        parser.error ('I expect exactly two arguments')

    return (args[0], float (args[1]), option.nowait)

def main ():
    (profileList, checkInterval, multipleResume) = parsecl ()

    # List of commands to run. Each command is a list of arguments
    cmdList = []
    # The format is very simple: each line describes the two first arguments to
    # pass to darwrap when running the backup
    with open (profileList, "r") as profileStream:
        for line in profileStream:
            (profileName, configFile) = line.split (" ")
            configFile = configFile.strip ()
            cmd = ["darwrap", profileName, configFile, "continue"]
            cmdList.append (cmd)

    # Currently used Popen objects
    popenDict = dict ()
    def cleanup(signum, frame):
        # print "DEBUG: cleaning up"
        for (key, value) in popenDict.items ():
            if value is not None:
                value.terminate ()
    # If SIGTERM is received, forward it to the child process
    signal (SIGTERM, cleanup)
    while True:
        for cmd in cmdList:
            # Return status is None if the process hasn't terminated yet.
            ret = None
            if multipleResume:
                if cmd not in popenDict:
                    popenDict[cmd] = Popen (cmd)
                else:
                    ret = popenDict[cmd].poll ()
                    if ret is not None:
                        del popenDict[cmd]
            else:
                ret = callCmd (cmd, expectedReturnStatus = None)

            print 'DEBUG: command', cmd, 'exited with return status', ret
            
        print "DEBUG: sleeping for", checkInterval, "seconds"
        sleep (checkInterval)

if __name__ == "__main__":
    sys.exit (main ())
