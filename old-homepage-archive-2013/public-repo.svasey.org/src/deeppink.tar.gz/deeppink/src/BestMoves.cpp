// Implementation of some functions defined in BestMoves.h

/*
  Copyright (c) 2007 Sebastien Vasey
  Copyright (c) 2007 Yann Schoenenberger
  This program is free software: you can redistribute it and/or modify
  it under the terms of the MIT License. See COPYING for more information.
*/
 
#include <vector>
using std::vector;

#include "BestMoves.h"

#include "Coor.h"

BestMoves::BestMoves(int size)
{
    best_move.assign(size,Coor(-1,-1));	// All moves initialized to (-1,-1)
    best_heuristic.assign(size,0); // All heuristics initialized to 0
}

void BestMoves::insert(const Coor& MOVE,int heuristic,int pos)
{
    for (int i=size()-1;i>pos;i--){	// Move all moves below pos down.
	best_move[i]=best_move[i-1];
	best_heuristic[i]=best_heuristic[i-1];
    }
    best_move[pos]=MOVE;
    best_heuristic[pos]=heuristic;
}

void BestMoves::submit(const Coor& MOVE,int heuristic)
{
    int p_del=-1;		// Position of an eventual move to be deleted
				// (if it is the same as the submitted one.

    int p_ins=0;		// Position of the eventual insertion
        
    for (int i=size()-1;i>=0;i--){	// Find p_del
	if (MOVE == best_move[i]){
	    p_del=i;
	    break;
	}
    }
    for (int i=size()-1;i>=0;i--){	// Find p_ins
	if (heuristic < best_heuristic[i] || ( // If the move has less value,
					       // its position is below.
		heuristic==best_heuristic[i]
		&& MOVE.calculateCenterCoef()<best_move[i].calculateCenterCoef())){
	    p_ins=i+1;
	    break;
	}
    }
    
    if (p_del==-1){		// No move needs to be deleted
	if (p_ins != size())		// The move can be inserted
	    insert(MOVE,heuristic,p_ins);
	return;
    }
    if (p_del < p_ins){		// If the rank of p_del is higher than the one
				// of p_ins, p_ins moves one rank and is inserted
	p_ins--;
	for (int i=p_del;i<p_ins;i++){
	    best_move[i]=best_move[i+1];
	    best_heuristic[i]=best_heuristic[i+1];
	}
    } else {
	for (int i=p_del;i>p_ins;i--){
	    best_move[i]=best_move[i-1];
	    best_heuristic[i]=best_heuristic[i-1];
	}
    }
    best_move[p_ins]=MOVE;
    best_heuristic[p_ins]=heuristic;
}
    
void BestMoves::findAndDelete(const Coor& MOVE)
{
    for (int i=size()-1;i>=0;i--){
	if (MOVE == best_move[i]){ // MOVE is found: reorganize everything.
	    for (int j=i;j<size()-1;j++){ // Every moves below MOVE are moved up.
		best_move[j]=best_move[j+1];
		best_heuristic[j]=best_heuristic[j+1];
	    }		    
	    best_move[size()-1]=Coor(-1,-1);
	    best_heuristic[size()-1]=0; // The last move is reinitialized.
	    return;
	}
    }
}
