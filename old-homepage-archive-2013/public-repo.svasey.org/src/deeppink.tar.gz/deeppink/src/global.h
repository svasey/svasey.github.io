// Contains all variables or functions needed in more than one file of the
// program, or that are important for its behavior, so that they can be
// changed easily.

/*
  Copyright (c) 2007 Sebastien Vasey
  Copyright (c) 2007 Yann Schoenenberger
  This program is free software: you can redistribute it and/or modify
  it under the terms of the MIT License. See COPYING for more information.
*/
 
#ifndef INCLUDE_GLOBAL_H
#define INCLUDE_GLOBAL_H


#include <iostream>
#include "Coor.h"


// Used to output something to stdout only if not in engine mode.
std::ostream message(std::cout.rdbuf());

int EMPTY=0;		// int used in the Square class for owner if
				// the square is empty.
int US=1;			// int used if the square has a stone of OUR
				// color on it.
int THEM=2;		// used if the stone has a stone of THEIR
				// color on it.

int N_BM=400;		// Number of candidate best moves that will be
                        // kept by the BestMoves object.

Coor FIRST_MOVE=Coor(10,10); // move that will be played if we are first
                             // to move (in our system of coordinates)


// Value and functions used when calculating an heuristic
namespace Heuristic 	
{
    int MAX=12648430;	// Heuristic for a move aligning 5 stones

    int SECOND_MAX=57005; // Heuristic for a move aligning 4 stones,
				 // with 2 free sides.

    int OUR_COEF=3;	// Multiple of the move's heuristic value
				// concerning OUR data (aligned stones and
				// free sides). After being multiplied, the
				// value will be added to
				// THEIR_COEF*their_value.

    int THEIR_COEF=2;	// Same as above, concerning THEM

    // Match a number of aligned stones to a heuristic value.
    int match(int n){
	int kv[4]={1,3,12,60};
	return kv[n-1];
    }
};
#endif
