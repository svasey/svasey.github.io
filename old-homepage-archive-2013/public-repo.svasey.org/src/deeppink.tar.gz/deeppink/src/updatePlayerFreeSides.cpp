// Implementation of the updatePlayerFreeSides function, declared in BestMoves.h

/*
  Copyright (c) 2007 Sebastien Vasey
  Copyright (c) 2007 Yann Schoenenberger
  This program is free software: you can redistribute it and/or modify
  it under the terms of the MIT License. See COPYING for more information.
*/
 
#include "BestMoves.h"
#include "Square.h"
#include "Coor.h"

extern int EMPTY;
extern int US;
extern int THEM;

void BestMoves::updatePlayerFreeSides(Square** board,const Coor& CAND
				      ,int player,int axisid,
				      void (Coor::*moveOnAxis)(int)) const
{
    const int PLAYER_ID= player==US ? 0:1;
    const int OPPONENT= player==US ? THEM:US;
    
    const int RANGE=5-board[CAND.x][CAND.y].getLine(PLAYER_ID,axisid); 
    // If no opponent or edge of the board are encountered in that range, the
    // targeted free sides value will be decremented (set to 2)
							       


    Coor c=CAND;		// Initialize a cursor at the position of
				// CAND, the square where the free sides might be
				// decremented.

    for (int d=1;;d=-1,c=CAND){	// For each direction
	(c.*moveOnAxis)(d);
	bool incr_i=false;	// Say if i can be incremented. i can be
				// incremented only if there is no PLAYER
				// immediately after CAND.
	for (int i=0;i<RANGE;(c.*moveOnAxis)(d)){
	    if (c.isOutOfRange() || board[c.x][c.y].owner==OPPONENT)
		return;		// Opponent or edge of the board in the range:
				// no decrement.

	    if (incr_i)
		i++;
	    else if (board[c.x][c.y].owner==EMPTY){
		// Square empty: we can now increment i.
		incr_i=true;
		i++;
	    }
	    
	    // If the square owner is PLAYER, we continue until we find an
	    // empty square. The range will be checked rapport to that square.
	}
	if (d == -1){		
	    // If everything has been checked and the function hasn't exited,
	    // set the free sides to 2.
	    
	    board[CAND.x][CAND.y].setFreeSides(PLAYER_ID,axisid,2);
	    return;
	}
    }
}
