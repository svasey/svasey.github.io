### Author: Sebastien Vasey (http://svasey.org/)

"""Small script to set bluetooth to discoverable or hidden. Must be run as root
to work. Without argument, show the current discoverability status"""

from svbluetooth.security import setDiscoverable, setHidden, NotRootException, \
    isDiscoverable

from svlib.string.func import unsensitiveEquals

import sys
from optparse import OptionParser


def main ():
    # Parse cl options
    parser = OptionParser (usage="bt-discoverable " +
                           "[on|off|discoverable|hidden]")
    (option, args) = parser.parse_args ()

    if len (args) > 1:
        parser.error ("Incorrect number of arguments")

    elif len (args) == 1:
        try:
            if unsensitiveEquals (args[0], "discoverable") or \
                    unsensitiveEquals (args[0], "on"):
                setDiscoverable ()
                print "Bluetooth adapter in discoverable mode" 
            elif unsensitiveEquals (args[0], "hidden") or \
                    unsensitiveEquals (args[0], "off"):
                setHidden ()
                print "Bluetooth adapter in hidden mode"
            else:
                parser.error ("Invalid argument: check usage")
        except NotRootException as err:
            sys.stderr.write ("FAILED: You need to have root privillege\n")
            return 1
    else:
        # Show status
        if isDiscoverable ():
            print "Bluetooth adapter is currently in discoverable mode"
        else:
            print "Bluetooth adapter is currently in hidden mode"

    return 0

if __name__ == "__main__":
    sys.exit (main ())
    
