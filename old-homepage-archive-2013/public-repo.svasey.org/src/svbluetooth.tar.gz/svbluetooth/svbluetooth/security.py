### Author: Sebastien Vasey (http://svasey.org/)

"""Code dealing with security"""

from svlib.servicerunner.Runner import callCmd, callCmdGetOutput
from svlib.security.privillege import hasRootPrivillege

class NotRootException (Exception):
    """Thrown when we are not root"""
    pass

def setDiscoverable ():
    """Set the hardware to discoverable. Must have root privillege"""
    changeDiscoverability (True)
    
def setHidden ():
    """Set the hardware to hidden. Must have root privillege"""
    changeDiscoverability (False)

def isDiscoverable ():
    """Return true if we are currently in discoverable mode, false
    otherwise. Does _not_ need root privillege"""
    (retcode, stdoutString, stderrString) = callCmdGetOutput (['hciconfig',
                                                               'hci0'])
    return (stdoutString.find ('ISCAN') != -1) and \
        (stdoutString.find ('PSCAN') != -1) 

def changeDiscoverability (discoverable):
    """If discoverable is true, set to discoverable, otherwise set to
    hidden. Must have root privillege"""

    if not hasRootPrivillege ():
        raise NotRootException ()
    
    cmd = ['hciconfig', 'hci0']
    if (discoverable):
        cmd.append ('piscan')
    else:
        cmd.append ('pscan')

    callCmd (cmd)
