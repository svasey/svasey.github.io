### Author: Sebastien Vasey (http://svasey.org/)

"""Small script to send file to my nokia6600. Assumes bluetooth is already
enabled. Reads the mac address from a $HOME/.nokia6600-addr file"""

from svbluetooth.nokia6600 import sendFile
from svbluetooth.btaddr import BtAddrFile

import sys
from os import environ
from os.path import join
from optparse import OptionParser

BTADDR_FILE = join (environ['HOME'], ".nokia6600-addr")

def main ():
    # Parse cl options
    parser = OptionParser (usage = "nokia6600-send file1 [file2 ...]")

    (option, args) = parser.parse_args ()

    if len (args) == 0:
        parser.error ("Incorrect number of arguments")

    # Read bluetooth mac addres from file
    btAddrFile = BtAddrFile (BTADDR_FILE)
    btAddr = btAddrFile.readContent ()

    for file in args:
        sendFile (file, btAddr)


if __name__ == "__main__":
    sys.exit (main ())
