### Author: Sebastien Vasey (http://svasey.org/)

"""Code for communicating with the nokia 6600 using bluetooth. This code is
currently quite hackish (calls external shell commands most of the time...)"""

from svbluetooth.security import setDiscoverable
from svbluetooth.btaddr import BtAddr

from time import sleep, time
from subprocess import Popen, PIPE
from os.path import exists, join
from os import stat
from glob import glob
from signal import SIGTERM, signal

from svlib.servicerunner.Runner import callCmd, UnexpectedStatusError
from svlib.picklefile.PickleFile import AtomicPickleFile
from svlib.atomicfile.AtomicFile import AtomicFile
from svlib.fs.func import removeThing

RECEIVE_HELPER_PID_PATH="/tmp/nokia6600-receive-helper-pid"

class FileNotReceivedError (Exception):
    """Raised when we did not receive an obex file correctly"""
    def __init__ (self, retcode, stdoutString, stderrString):
        self.retcode = retcode
        self.stdoutString = stdoutString
        self.stderrString = stderrString

    def __str__ (self):
        return "Obexpushd could not receive file: return status is " + \
            str(self.retcode) + \
            "\nstdout is " + self.stdoutString +  "\nStderr is " + \
            self.stderrString

def sendFile (filePath, btAddr):
    """Send a file to the phone using bluetooth (OBEX). Assumes bluetooth is
    already initialized on the client. btAddr is an object of type BtAddr"""

    cmd = ['obexftp','--uuid','none','--channel','9','--bluetooth',
           btAddr.addrString (),'--put', filePath]
    ret = None
    try:
        ret = callCmd (cmd)
    # I haven't yet figured out why this 255 error status is sometimes
    # returned. No serious problem happened, so there is no use throwing an
    # exception.
    except UnexpectedStatusError as err:
        if (err.returnStatus != 255):
            raise

def receiveFile (nFiles = 1):
    """Wait until some number of file are received from the phone and then
    return. nFiles is the number of files to wait for. Raise a
    FileNotReceivedError when an error happened"""

    # Cleanup a bit
    for el in glob (RECEIVE_HELPER_PID_PATH + '-*'):
        removeThing (el)

    nReceived = 0
    proc = None
    def cleanup(signum, frame):
        # print "DEBUG: cleaning up"
        if proc:
            proc.terminate ()
    # If SIGTERM is received, forward it to the child process
    signal (SIGTERM, cleanup)
    proc = Popen (['obexpushd','-n','-B','-s', 'nokia6600-receive-helper'])

    # Wait until we have received everything, then kill obexpushd
    currentId = 1
    while nReceived < nFiles:
        # Any PID file created after `startTime`, where the pid is not running,
        # is equivalent to a file that has been received.
        currentPath = RECEIVE_HELPER_PID_PATH + '-' + str (currentId)
        if exists (currentPath):
            pid = (AtomicPickleFile (currentPath)).readContent ()
            # If the next file exists, this must mean the previous process
            # has already exited
            if exists (RECEIVE_HELPER_PID_PATH + '-' + \
                           str (currentId + 1)) or \
                           not exists (join ('/proc', str (pid))):
                nReceived += 1
                currentId += 1
                print 'DEBUG: received file', nReceived, 'out of', nFiles
                    
        sleep (1)

    # Cleanup a bit
    for el in glob (RECEIVE_HELPER_PID_PATH + '-*'):
        removeThing (el)
        
    proc.terminate ()
    sleep (1)
    if proc.poll () is None:
        proc.kill ()
