### Author: Sebastien Vasey (http://svasey.org/)

"""Small script to receive files sent from the nokia6600"""

from svbluetooth.nokia6600 import receiveFile, FileNotReceivedError

import sys
from optparse import OptionParser
from os import chdir, getcwd

def main ():
    # Parse cl options
    parser = OptionParser (usage = "nokia6600-receive [nfiles] [directory]")

    (option, args) = parser.parse_args ()

    nFiles = 1
    directory = getcwd ()
    if len (args) > 2:
        parser.error ("Incorrect number of arguments")
    if len (args) > 0:
        nFiles = int(args[0])
        if nFiles < 1:
            parser.error ("Number of files to receive must be positive")
    if len (args) > 1:
        directory = args[1]
    

    chdir (directory)
    try:
        receiveFile (nFiles)
    except FileNotReceivedError as err:
        sys.stderr.write ("Error: " + str(err))
        return 1

if __name__ == "__main__":
    sys.exit (main ())
