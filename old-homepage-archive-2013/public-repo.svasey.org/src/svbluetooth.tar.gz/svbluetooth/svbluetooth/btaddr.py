### Author: Sebastien Vasey (http://svasey.org/)

"""Classes and methods to deal with bluethooth (MAC) addresses"""

from svlib.nopicklefile.NoPickleFile import SimpleStringFile

class BtAddr:
    addrBytes = [0,0,0,0,0,0]

    def __init__ (self, addrString = None, addrBytes = None):
        """Initialize either from a sequence of 6 bytes or from a string. If
        none of these are given 00:00:00:00:00:00 is assumed. The string should
        contains 6 values with one or two hexadecimal digits separated by :"""

        self.addrBytes = [0,0,0,0,0,0]
        if not (addrBytes is None):
            self.addrBytes = addrBytes

        elif not (addrString is None):
            splittedStr = addrString.split(':')
            for (index, field) in enumerate (splittedStr):
                self.addrBytes[index] = int(field, 16)

    def addrString (self):
        """Return a string representing the object, each field is represented in
        hexadecimal using capital letters for the 10 to 15 digits. The 6 fields
        are separated by :"""

        addrString = ['','','','','','']

        for (index, field) in enumerate (self.addrBytes):
            addrString[index] = format (field, 'X')
        
        return ':'.join (addrString)

    def __str__ (self):
        return self.addrString ()

class BtAddrFile (SimpleStringFile):
    """File containing a bluetooth mac address as a simple string"""
    
    def __init__ (self, filePath):
        SimpleStringFile.__init__ (self, filePath)

    def readContent (self):
        return BtAddr (addrString = SimpleStringFile.readContent (self))

    def writeContent (self, btaddr):
        return SimpleStringFile.writeContent (self, btaddr.addrString ())

        
