### Author: Sebastien Vasey (http://svasey.org/)

"""
Utility functions to parse the command line of a rst2xxxx command
"""

from sys import argv

def getSrcAndDest (arguments = argv):
    """
    Return a (source,destination) tuple from the command line arguments
    args, in the same format as argv. If there is no source, None will be
    returned. If there is no destination,  '.' will be returned
    """

    source = None
    destination = '.'

    args = arguments[1:]
    if len (args) >= 1:
        if (len (args) == 1) or args[-2].startswith ('-') :
            if not args[-1].startswith ('-'):
                source = args[-1]
        elif len (args) >= 2:
            source = args[-2]
            destination = args[-1]

    return (source, destination)
