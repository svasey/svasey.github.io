### Author: Sebastien Vasey (http://svasey.org/)

"""
Functions to improve an existing latex file written with the rst writer
"""

from svlib.file.func import readContent, writeContent
from os.path import normpath

def doLatexImprovements (inFile, outFile, pageDirUrl = '.'):
    """
    Do the necessary improvements in inFile and write them to
    outFile. pageDirUrl is the url of the containing directory of the original
    html/rst file, it is used to convert relative links to absolute links
    """

    inContent = readContent (inFile)
    outContent = improveAllFootnotes (inContent)
    outContent = improveAllHref (outContent, pageDirUrl)
    outContent = improvePackages (outContent)

    writeContent (outContent, outFile)

def improvePackages (contentString):
    """
    Add additionnal latex packages to use so that the document compiles
    correctly.
    """


    # List of statements to add (in no particular order)
    toAdd = [r'\usepackage{amsfonts}',r'\usepackage{amsmath}',
             r'\usepackage{amssymb}']
    
    # Find a line beginning with \usepackage, write our package to the next
    # line.
    startIndex = contentString.find (r'\usepackage')
    endIndex = contentString[startIndex:].find ('\n') + startIndex
    for el in toAdd:
        contentString = contentString[:endIndex] + '\n' + el + \
            contentString[endIndex:]

    return contentString
    
def getHrefEnd (str):
    """
    Given that the string begins with a \href, find the end of that href command
    and return its index (i.e the index of the last character (}) of the href
    command)
    """

    assert (str.startswith (r'\href'))

    # Count of closed and open curly braces (} and {) found. Once the number of
    # closing matches the number of opening, and at least two of each have been
    # found we have the end of the href command (we have to account for more
    # than two because there might be arbitrary commands inside the href
    closedCount = 0
    openedCount = 0

    for i in range (len (str) - 1):
        twoChar = str[i] + str[i + 1]
        if twoChar[0] != '\\':
            if twoChar[1] == '{':
                openedCount = openedCount + 1
            elif twoChar[1] == '}':
                closedCount = closedCount + 1
        if (closedCount == openedCount) and (closedCount >= 2):
            return i + 1


    # Should not happen: the href command should be closed
    assert (False)
    
    return len (str) - 1

def latexCommandGetArg (commandString, argId):
    """
    Get the content of the argId th argument of commandString, where argId is
    1-based
    """

    # Closed and open curly braces
    closedCount = 0
    openedCount = 0
    # Indices of the last closed and opened curly braces
    lastOpened = -1
    lastClosed = -1

    # Current argument id we are reading
    currentId = 1
    for i in range (len (commandString) - 1):
        twoChar = commandString[i] + commandString[i + 1]
        if twoChar[0] != '\\':
            if (twoChar[1] == '}') or (twoChar[1] == '{'):
                if twoChar[1] == '}':
                    closedCount = closedCount + 1
                elif twoChar[1] == '{':
                    if closedCount == openedCount:
                        lastOpened = i + 1                        
                    openedCount = openedCount + 1

                if (closedCount == openedCount):
                    lastClosed = i + 1
                    if currentId == argId:
                        return commandString[(lastOpened + 1):lastClosed]
                    currentId = currentId + 1
        
            
    assert (False)
    
    return ''
    

def getHrefUrl (hrefString):
    """
    From a href command string, return the url (first argument) that was passed
    to it
    """
    return latexCommandGetArg (hrefString, 1)

def getHrefName (hrefString):
    """
    From a href command string, return the name (second argument) that was
    passed to it
    """
    return latexCommandGetArg (hrefString, 2)

def isInternalLink (url):
    """
    Return true if the url is a (relative) internal link
    false otherwise
    """

    return url.startswith (r'\#')

def isAbsoluteUrl (url):
    """
    Return true if the given string is a url and it is absolute
    """

    # TODO: this is hackish and might not cover all cases: find a better
    # function from a better library
    splitUrl = url.split ('://')

    return len (splitUrl) == 2    

def isRelativeUrl (url):
    """
    Return true if the given string is a relative url, false otheriwse
    """

    splitUrl = url.split ('://')

    return len (splitUrl) == 1

def getInternalLinkDest (url):
    """
    Return where the internal link points to (i.e to which label
    """
    # We strip the url of the two first characters, which are \#
    return url[2:]

def improveHref (hrefString, pageDirUrl = '.'):
    """
    Given a string containing a \href command, improve it (i.e change its
    content, posssibly by adding other commands), so that it is more printable
    once converted to pdf. Return the improved href string. pageDirUrl is the
    url of the original html page's containing directory, and is used when
    converting relative link to absolute
    """

    print "DEBUG improving href string '" + hrefString + "'"
    # Of course, this assertion is not exhaustive, but it might catch a few
    # errors
    assert (hrefString.startswith (r'\href') and hrefString.endswith ('}'))

    url = getHrefUrl (hrefString)
    name = getHrefName (hrefString)
    print "DEBUG: url is", url
    print "DEBUG: name is", name

    # If the visible part is the url already, we display the url and try to
    # break it correctly using the url package
    if isAbsoluteUrl (name):
        # I do not use the name variable, as some of the characters are weirdly
        # escaped in href
        return r'\url{' + url + '}'

    # If we have an internal link, add the label reference in brackets after the
    # name element, and create the link there
    if isInternalLink (url):
        dest = getInternalLinkDest (url)
        return name + r' (\autoref{' + dest + '})'

    # If we have a relative url, we transform it into an absolute url
    if isRelativeUrl (url):
        if isAbsoluteUrl (pageDirUrl):
            splitUrl = pageDirUrl.split ('://')
            protoPart = splitUrl[0]
            pathPart = splitUrl[1]
            url = protoPart + '://' + normpath (pathPart + '/' + url)
        else:
            url = normpath (pageDirUrl + '/' + url)

    # We just put the link in a footnote so that the user knows what this points
    # to.
    return r'\href{' + url + '}{' + name + '}' + r'\footnote{\url{' + url + '}}'
    
def replaceCommands (contentString, commandString, getEndFunc, replaceFunc):
    """
    Parse a latex content string looking for commandString. Use getEndFunc to
    locate the end of the command in the text given its start index. Use
    replaceFunc to know what to replace the string with. getEndFunc takes the
    string starting with the command as argument,  replaceFunc takes the whole
    command string as argument.
    """
    
    outputString = ''
    contentToParse = contentString
    while contentToParse != '':
        startIndex = contentToParse.find (commandString)

        # No more command string to change
        if startIndex == -1:
            outputString = outputString + contentToParse
            contentToParse = ''
        # The backslash has been escaped: not a command
        elif (startIndex != 0) and (contentToParse[startIndex - 1] == '\\'):
            outputString = outputString + contentToParse[:(startIndex + 1)]
            contentToParse = contentToParse[(startIndex + 1):]
        # Command has been found
        else:
            outputString = outputString + contentToParse[:startIndex]
            # Get last character of the command
            endIndex = getEndFunc (contentToParse[startIndex:]) + startIndex
            cmdString = contentToParse[startIndex:(endIndex + 1)]
            contentToParse = contentToParse[(endIndex + 1):]
            replacedCmd = replaceFunc (cmdString)
            outputString = outputString + replacedCmd
            

    return outputString
    
    
def improveAllHref (contentString, pageDirUrl = '.'):
    """
    Improve all the \href commands in the contentString and return the content
    as a string. pageDirUrl is used to convert relative links to absolute links:
    see improveHref
    """

    return replaceCommands (contentString, r'\href{', getHrefEnd,
                           (lambda hrefString: improveHref (hrefString,
                                                            pageDirUrl)))

def getFootnoteEnd (contentString):
    """
    Given that the string begins with some footnote, footnotetext, or
    footnotemark command, find the end of that command and return its index (i.e
    the index of the last character of the command
    """

    assert (contentString.startswith (r'\footnote'))

    if contentString.startswith (r'\footnotemark'):
        # No argument at all
        return contentString.find (']')
    else:
        assert (contentString.startswith (r'\footnote[') or
                contentString.startswith (r'\footnotetext['))
        # Number of closed and opened curly braces ({ and }) that were seen
        closedCount = 0
        openedCount = 0

        for i in range (len (contentString) - 1):
            twoChar = contentString[i] + contentString[i + 1]
            if twoChar[0] != '\\':
                if twoChar[1] == '{':
                    openedCount = openedCount + 1
                elif twoChar[1] == '}':
                    closedCount = closedCount + 1
            if (closedCount == openedCount) and (closedCount >= 1):
                return i + 1

        # Should not happen: there should be the same number of closing braces
        # as opening braces
        assert (False)

        return len (str) - 1

def improveFootnote (footnote):
    """
    Given a footnote command, improve it so that it does not use fixed-numbered
    ids but autonumbered ids. It is guaranteed that the command passed as
    argument uses fixed ids i.e it has a [] argument. Return the improved
    version.
    """

    # In short, we have to remove the [...] part
    startIndex = footnote.find ('[')
    endIndex = footnote.find (']')

    endString = footnote[(endIndex + 1):]
    if endIndex == len (footnote) - 1:
        endString = ''

    return footnote[:startIndex] + endString

def improveFootnotemark (footnoteString, contentString):
    """
    Given a footnotemark command, convert it to a footnote command by looking
    into contentString for the reference footnotetext
    """

    matchingFootnoteText = footnoteString.replace (r'\footnotemark',
                                                   r'\footnotetext')
    matchPos = contentString.find (matchingFootnoteText)
    while (matchPos != 0) and (matchPos != -1) and \
            (contentString[matchPos - 1] == '\\'):
        matchPos = contentString.find (matchingFootnoteText)

    assert (matchPos != -1)

    matchEnd = getFootnoteEnd (contentString[matchPos:]) + matchPos
    footnoteTextCommand = contentString[matchPos:(matchEnd + 1)]
    print "DEBUG: footnoteTextCommand:", footnoteTextCommand
    text = latexCommandGetArg (footnoteTextCommand, 1)

    return r'\footnote{' + text + '}'

def improveFootnotetext (footnoteString):
    """
    Simply remove all footnotetext command: they have been replaced by footnotes
    if everything went well
    """

    return ''

def improveAllFootnotes (contentString):
    """
    Change all footnotes command in the contentString to use auto-numbering
    """

    outString = replaceCommands (contentString, r'\footnote[', getFootnoteEnd,
                           improveFootnote)
    outString = replaceCommands (outString, r'\footnotemark[',
                                 getFootnoteEnd,
                                 (lambda footnoteString:
                                      improveFootnotemark (footnoteString,
                                                           outString)))
    return replaceCommands (outString, r'\footnotetext[',
                                getFootnoteEnd, improveFootnotetext)


