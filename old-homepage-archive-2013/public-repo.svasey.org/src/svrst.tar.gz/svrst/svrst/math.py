### Author: Sebastien Vasey (http://svasey.org/)

"""
Define a math role and directive for RST. This was originally inspired from
http://www.hvergi.net/2008/06/restructuredtext-extensions/comment-page-1/
"""

from hashlib import sha224
from os.path import join, exists, abspath, basename
from tempfile import mkdtemp
from os import getcwd, chdir, environ
from shutil import copyfile, rmtree

from docutils import nodes, utils
from docutils.parsers.rst import directives, roles, Directive

from svlib.servicerunner.Runner import callCmd
from svlib.string.func import contains
from svlib.file.func import getLineContent
from svlib.fs.func import relPath

ROLE_NAME='math'
DIRECTIVE_NAME='math'

INLINE_IMG_CLASS='inlineformulaimg'
IMG_CLASS='formulaimg'

INLINE_NOIMG_CLASS='inlinemath'

def wrapFormula(formula, font_size, latex_class):
    """
    Return a complete latex document (as a string) containing the given
    formula (given using latex syntax
    """
    
    return r"""\documentclass[%(font_size)spt]{%(latex_class)s}
               \usepackage[latin1]{inputenc}
               \usepackage{amsmath}
               \usepackage{amsfonts}
               \usepackage{amssymb}
               \pagestyle{empty}
               \newsavebox{\formulabox}
               \newlength{\formulawidth}
               \newlength{\formulaheight}
               \newlength{\formuladepth}
               \setlength{\topskip}{0pt}
               \setlength{\parindent}{0pt}
               \setlength{\abovedisplayskip}{0pt}
               \setlength{\belowdisplayskip}{0pt}
               \begin{lrbox}{\formulabox}
               $%(formula)s$
               \end{lrbox}
               \settowidth {\formulawidth}  {\usebox{\formulabox}}
               \settoheight{\formulaheight} {\usebox{\formulabox}}
               \settodepth {\formuladepth}  {\usebox{\formulabox}}
               \newwrite\foo
               \immediate\openout\foo=\jobname.depth
                   \addtolength{\formuladepth} {1pt}
                   \immediate\write\foo{\the\formuladepth}
               \closeout\foo
               \begin{document}
               \usebox{\formulabox}
               \end{document}""" % locals()

def renderFormula (formula, outFolder, fontSize = 11, latexClass = 'article'):
    """
    Create a png image in outFolder containing the given formula, with the
    given font_size and using the given latex class (the defaults should be good
    enough). Arrange for the png image to have a unique name. Return the
    complete path of the file as a string
    """

    formulaHash = sha224 (formula).hexdigest ()
    imageName = formulaHash + "-" + str (fontSize) + "-" + latexClass + ".png"
    outPath = join (outFolder, imageName)

    # If the exact same formula has already been rendered, there is no need to
    # render it again
    if exists (outPath):
        return outPath
 
    tempDir = mkdtemp ()
    formulaTex = join (tempDir, 'formula.tex')
 
    with open (formulaTex, 'w') as formulaStream:
        formulaStream.write(wrapFormula (formula, fontSize, latexClass))

    callCmd (['latex','--interaction=nonstopmode', \
                  '--output-directory=' + tempDir, formulaTex])
 
    callCmd (['dvips','-E', join (tempDir,'formula.dvi'), '-o',
              join (tempDir, 'formula.ps')])
 
    callCmd (['convert','-density','120','-trim',
              '-transparent','#FFFFFF',
              join (tempDir, 'formula.ps'), join (tempDir, 'formula.png')])
 
    copyfile (join (tempDir, "formula.png"), outPath)
    rmtree (tempDir)
 
    return outPath

def formulaHtmlImg (formula, formulaDir, htmlOut, itemClass):
    """
    Return a string with the <img /> element containing the given formula, and
    the given itemClass. htmlOut is the output html file and is used to
    calculate the relative path of the formula
    """

    source = renderFormula (formula, formulaDir)
    itemSrc = join (relPath (formulaDir, htmlOut), basename (source))
    itemAlt = formula.replace ('\n',' ')
    
    return htmlImage (itemSrc, itemClass, itemAlt)

def formulaHtmlNonImg (formula):
    """
    Return a html element containing the formula, no image
    """

    import cgi
    
    return '<span class="' + INLINE_NOIMG_CLASS + '">' + cgi.escape (formula) + '</span>'

def formulaAloneOnLine (rawtext, inPath, lineno):
    """
    Return true if the formula is alone on its own line, false otherwise
    """

    if not inPath is None:
        lineContent = getLineContent (inPath, lineno)
        if unicode (lineContent.strip ().decode ('utf-8')) == rawtext:
            return True

    return False
    
def htmlImage (source, itemClass, alternative):
    """
    Return a string with an <img /> tag with the given source, class and
    alternative text
    """

    return '<img class="' + itemClass + '" alt="' + alternative + '" src="' + \
        source + '" />'

def formulaFitForHtml (formula):
    """
    Return true if the formula can be rendered in html without an img
    object. For the moment, I use an array of "forbidden" characters that
    contains things like ^ and \. Once these appear, I know I will have to use
    an image
    """

    FORBIDDEN=['\\','^']

    if contains (formula, FORBIDDEN):
        return False
    else:
        return True
        
def html_math_directive (pngDir, outPath, name, arguments, options, content,
                         lineno, content_offset, block_text, state,
                         state_machine):
    formula = '\n'.join (content)
    htmlImage = formulaHtmlImg (formula, pngDir, outPath, IMG_CLASS)

    return [nodes.raw('', htmlImage, format='html')]

def html_math_role(pngDir, outPath, inPath,
                   name, rawtext, text, lineno, inliner, options={},
                   content=[]):
    """
    pngDir is the directory where the png should be stored, outPath is the
    directory in which we will store the html file, . if it is stdout. inPath is
    the path to the input file, None if stdin
    """
    # Restore escaped backslashes
    formula = rawtext.split('`')[1].replace('\\\\','\\')
    
    # Check if the formula is on a line of its own
    aloneOnLine = formulaAloneOnLine (rawtext, inPath, lineno)

    item = formulaHtmlNonImg (formula)

    if not formulaFitForHtml (formula) or aloneOnLine:
        itemClass = INLINE_IMG_CLASS
        if aloneOnLine:
            itemClass = IMG_CLASS
        item = formulaHtmlImg (formula, pngDir, outPath, itemClass)
    
    return [nodes.raw(rawtext, item, format='html')], []
 
def htmlRegister (pngDir, outPath, inPath):
    """
    Register the html math directive and role.
    """

    funcObj = (lambda name, arguments, options,  \
                   content, lineno, content_offset, \
                   block_text, state, state_machine: \
                   html_math_directive \
                   (pngDir, outPath, name, arguments, \
                        options, content, lineno, \
                        content_offset, block_text, state, \
                        state_machine))
    funcObj.content = 1
    directives.register_directive('math', funcObj)


    roles.register_canonical_role('math',
                                  (lambda name,rawtext, text, lineno, \
                                       inliner, options={}, content=[]: \
                                       
                                       html_math_role (pngDir, outPath, inPath,
                                                       name, rawtext, text,
                                                       lineno, inliner, options,
                                                       content)))

def latexFormula (formula):
    """Return a latex text displaying formula in a displaymath environment"""

    return '\\begin{displaymath} ' + formula + ' \\end{displaymath}'

def latexInlineFormula (formula):
    """Return a latex text displaying formula inline"""

    return '$ ' + formula + ' $'
    
def latex_math_directive (name, arguments, options, content, lineno,
                          content_offset, block_text, state, state_machine):
    formula = '\n'.join (content)
    
    return [nodes.raw ('', latexFormula (formula), format = 'latex')]

def latex_math_role (inPath, name, rawtext, text, lineno, inliner, options = {},
                     content = []):
    formula = rawtext.split ('`')[1].replace ('\\\\','\\')

    item = latexInlineFormula (formula)
    if formulaAloneOnLine (rawtext, inPath, lineno):
        item = latexFormula (formula)
    
    return [nodes.raw (rawtext, item, format = 'latex')], []

def latexRegister (inPath):
    """
    Register the latex math directive and role
    """
    latex_math_directive.content = 1
    directives.register_directive('math', latex_math_directive)
    roles.register_canonical_role \
        ('math', (lambda name, rawtext, text, lineno, inliner, options = {},
                  content = []: latex_math_role (inPath, name, rawtext, text,
                                                 lineno, inliner, options,
                                                 content)))
 

