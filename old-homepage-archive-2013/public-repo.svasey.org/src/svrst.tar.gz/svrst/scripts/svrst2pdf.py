#!/usr/bin/env python

### Author: Sebastien Vasey (http://svasey.org/)

### Generate a pdf from a rst document, using svrst2latex and compiling the
### latex file. The environment variable FULL_DIR_URL should be used to indicate
### the full url of the containing directory of the rst (or html) file. It will
### be used to convert relative link to absolute so that the printing still
### makes sense.

from sys import argv, stderr, exit
from os import getcwd, chdir, environ
from os.path import abspath, join
from tempfile import mkdtemp
from shutil import rmtree, move

from svlib.servicerunner.Runner import callCmd


    

args = argv[1:]
if len (args) < 2:
    stderr.write ('I need the source and destination files\n')
    exit (2)

destination = abspath (args[-1])
source = abspath (args[-2])

if (destination[0] == '-') or (source[0] == '-'):
    stderr.write ('I need the source and destination files\n')
    exit (2)

# Do all the build in a temporary directory, then move the pdf file and remove
# everything else

tempDir = mkdtemp (prefix = 'svrst2pdf.py')
tempTexOut = join (tempDir, 'out.temp.tex')
texOut = join (tempDir, 'out.tex')
pdfOut = join (tempDir, 'out.pdf')

callCmd (['svrst2latex.py'] + args[:-2] + [source, tempTexOut])

betterOpts = []
if 'FULL_DIR_URL' in environ:
    betterOpts = ['--dir-url=' + environ['FULL_DIR_URL']]
# Improve the outputed texfile
callCmd (['betterrstlatex.py'] + betterOpts + [tempTexOut, texOut])

# Call pdflatex three times
for i in range (3):
    callCmd (['pdflatex', '-halt-on-error', '-output-directory',
              tempDir, texOut])

move (pdfOut, destination)
rmtree (tempDir)

exit (0)
