#!/usr/bin/env python

### Author: Sebastien Vasey (http://svasey.org/)

### Generate latex from rst. Use svrst addons.

from docutils import nodes, utils
from docutils.parsers.rst import directives, roles
from docutils.core import publish_cmdline, default_description

import svrst.math
from svrst.parsecl import getSrcAndDest
 
try:
    import locale
    locale.setlocale(locale.LC_ALL, '')
except:
    pass

(source, destination) = getSrcAndDest ()

svrst.math.latexRegister (source)

description = ('Generates Latex documents from standalone reStructuredText '
               'sources, uses svrst addons.  ' + default_description)

publish_cmdline(writer_name='latex', description=description)
