#!/usr/bin/env python

### Author: Sebastien Vasey (http://svasey.org/)

### Generate xhtml from rst. Use svrst addons. The environment variable
### SVRST_PNGDIR is used for the output directory of math images 

from os import environ, getcwd
from os.path import dirname

from docutils import nodes, utils
from docutils.parsers.rst import directives, roles
from docutils.core import publish_cmdline, default_description

import svrst.math
from svrst.parsecl import getSrcAndDest

from svlib.fs.func import mkdirTry

try:
    import locale
    locale.setlocale(locale.LC_ALL, '')
except:
    pass

(source, destination) = getSrcAndDest ()

try:
    pngDir = environ['SVRST_PNGDIR']
except KeyError as err:
    pngDir = getcwd ()

# Create the png directory if it does not already exists
mkdirTry (pngDir)

svrst.math.htmlRegister (pngDir, dirname (destination), source)

description = ('Generates (X)HTML documents from standalone reStructuredText '
               'sources, uses svrst addons.  ' + default_description)

publish_cmdline(writer_name='html', description=description)
