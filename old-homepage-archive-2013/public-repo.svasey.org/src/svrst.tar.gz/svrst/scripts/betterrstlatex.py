#!/usr/bin/env python

### Author: Sebastien Vasey (http://svasey.org/)

### Given a latex file outputed by a rst2latex program, improve it for a final
### compilation to pdf.

from optparse import OptionParser
from sys import exit

from svrst.improvelatex import doLatexImprovements

parser = OptionParser (usage = 'betterrstlatex source dest')
parser.add_option ('-d', '--dir-url', dest = 'url', help='Specify full url ' +
                   'of the original directory', metavar='URL')

dirUrl = '.'
(option, args) = parser.parse_args ()
if option.url:
    dirUrl = option.url

if len (args) != 2:
    parser.error ("Incorrect number of arguments: need exactly two arguments")

inFile = args[0]
outFile = args[1]

doLatexImprovements (inFile, outFile, dirUrl)

exit (0)
