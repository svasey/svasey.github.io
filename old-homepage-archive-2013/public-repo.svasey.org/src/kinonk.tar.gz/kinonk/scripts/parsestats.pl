#!/usr/bin/perl
# Process kinonk's stats file and create a lot of charts with a lot of
# information
# 
# The first argument is the statistics file. The second one is the path where
# you would like the information files to be created.

use strict;
use warnings;

use GD::Graph::bars;
use GD::Graph::points;
use JSON;

# The width and height of the graph.
my $WIDTH=600;
my $HEIGHT=600;

# The minimum quantity, in percentage of the maximum.
my $MIN_QUANTITY=1;

my $STATSFILE=$ARGV[0];
my $OUTDIR=$ARGV[1];

# The datas concerning the number of candidates. The first index is the depth,
# the second one is the quantity of ncand==0, ==1 etc...
my @data_ncand=();

# The datas concerning the cutoffs (same format as data_ncand)
my @data_cutoffs=();

# The number of analyzed ([0]) and maximum ([1] positions for each depth.
my @data_positions=();

# The number of times each pentomino shape generated a cutoff for each
# depth. The first index is the depth, the second is the pentomino's id
my @data_pento=();


# Remove uninteresting datas (used for points graphs only)
sub filterData {
    my @graph_data=@_[0 .. $#_];
    my @new_gd=([],[]);
    my $max=0;
    foreach (@{$graph_data[1]}){
	if ($_ > $max){
	    $max=$_;
	}
    }
    if ($max == 0){
	return @new_gd;
    }
    my $min=($MIN_QUANTITY/100)*$max;
    for (my $i=0;$i<@{$graph_data[0]};$i++){
	my $quantity=${$graph_data[1]}[$i];
	my $nmoves=${$graph_data[0]}[$i];

	if ($quantity >= $min){
	    push(@{$new_gd[0]},$nmoves);
	    push(@{$new_gd[1]},$quantity);
	}
    }
    return @new_gd;
}


sub createPointGraph {
    my $name=$_[0];
    my $title=$_[1];
    my @data=filterData(@_[2 .. $#_]);


    my $x_label;
    if ($name =~ /cutoff/){
	$x_label="Analyzed moves before a cutoff";
    }
    else {
	$x_label="Number of candidates";
    }

    my $graph=GD::Graph::points->new($WIDTH,$HEIGHT);
    $graph->set(
	x_label=>$x_label
	,y_label => 'Quantity'
	,text_space => 20
	,transparent => 0
	,bgclr => 'white'
	,y_tick_number => 'auto'
	,x_tick_number => 'auto'
	,markers=>[3]
	,marker_size=>1) or die $graph->error;
    
    my $out="${OUTDIR}/${name}";
    print "Creating chart ${out} ... \n";
    if (@{$data[1]} == 0){
	print "All the chart y values are null. The chart needn't be created\n";
	return 0;
    }
    my $gd=$graph->plot(\@data) or warn $graph->error and return;
    open (IMG,">$out") or die $!;
    binmode IMG;
    print IMG $gd->png;
    close IMG;
    return 1;
}

sub createBarGraph {
    my $name=$_[0];
    my $title=$_[1];
    my @data=@_[2 .. $#_];


    # There are three types of bars graph: those with depth as the x label,
    # those with the pentomino type as the x label, and those with a number of
    # moves as the x label. For the latter we need to do some repartition.
    
    my @range=(0,0,1,2,3,5,6,10,11,50,51,100,101,300,301,500,501,700,701
	       ,1000,1001,100000);
    my @data_bars=([],[]);
    if ($name !~ /depth/ && $name !~ /pento/){
	for (my $i=0;$i<@range;$i+=2){
	    my $lower=$range[$i];
	    my $upper=$range[$i+1];
	    
	    if ($i+1 == $#range){
		push(@{$data_bars[0]},">=$lower");
	    }
	    elsif ($lower == $upper){
		push(@{$data_bars[0]},"$lower");
	    }
	    else {
		push(@{$data_bars[0]},"${lower}-${upper}");
	    }
	    
	    push (@{$data_bars[1]},0);
	    for (my $j=0;$j<@{$data[0]};$j++){
		my $ncand=${$data[0]}[$j];
		my $quantity=${$data[1]}[$j];
		
		if (($ncand >= $lower && $ncand <= $upper)){
		    ${$data_bars[1]}[$i/2]+=$quantity;
		}
		elsif ($ncand > $upper){
		    next;
		}
	    }
	}
    }
    else {
	if (@{$data[2]} == 0){
	    @data_bars=@data[0,1];
	}
	else {
	    @data_bars=@data;
	}
    }


    my $x_label;
    if ($name =~ /cutoff/){
	$x_label="Analyzed moves before a cutoff";
    }
    if ($name =~ /ncand/){
	$x_label="Number of candidates";
    }
    if ($name =~ /positions/ || $name =~ /depths/){
	$x_label="Depth";
    }
    if ($name =~ /pento/) {
	$x_label="Pentomino shape";
    }
    
    my $graph=GD::Graph::bars->new($WIDTH,$HEIGHT);
    $graph->set(
	x_label => $x_label
	,y_label => 'Quantity'
	,r_margin => 50
	,transparent => 0
	,bgclr=>'white'
	,text_space=> 20
	,y_tick_number => 'auto'
	,zero_axis_only => 1
	,show_values => 0) or die $graph->error;
    my $out="${OUTDIR}/${name}";
    print "Creating chart $out ...\n";
    
    my $gd=$graph->plot(\@data_bars) or warn $graph->error and return;
    open(IMG,">$out") or die $!;
    binmode IMG;
    print IMG $gd->png;
    close IMG;
}

# Create the graphs about the distribution of the number of
# candidates/cutoffs. This will create a bar and a points graph for each depth
# for which this is worthwhile (cf filterData) and using the total of all depth
# combined.
sub createDistGraphs {

    my @graph_data=([],[]);

    for (my $i=0;$i<12;$i++){
	my $depth=$i;
	if ($i < 10){
	    $depth="0" + $depth;
	}
	# Fill graph_data with @data_cutoffs
	for (my $j=0;$j<@{$data_cutoffs[$i]};$j++){
	    push (@{$graph_data[0]},$j);
	    push (@{$graph_data[1]},$data_cutoffs[$i][$j]);
	}

	my $title="Distribution of the number of analyzed moves before a"
	    . " cutoff at depth ${i}";

	if (createPointGraph("cutoffs.${depth}.points.png",$title,@graph_data)){
	    createBarGraph("cutoffs.${depth}.bars.png",$title,@graph_data);
	}
	else {
	    print "The bar chart will not be created\n";
	}

	@graph_data=([],[]);
 	# Fill graph_data with @data_ncand
	for (my $j=0;$j<@{$data_ncand[$i]};$j++){
	    push (@{$graph_data[0]},$j);
	    push (@{$graph_data[1]},$data_ncand[$i][$j]);
	}

	$title="Distribution of the number of candidate moves at depth ${i}";
	
	if (createPointGraph("ncand.${depth}.points.png",$title,@graph_data)){
	    createBarGraph("ncand.${depth}.bars.png",$title,@graph_data);
	}
	else {
	    print "The bar chart will not be created\n";
	}

	@graph_data=([],[]);
    }
    # Fill in graph_data with a total of @data_cutoffs
    for (my $i=0;$i<12;$i++){
	for (my $j=0;$j<@{$data_cutoffs[$i]};$j++){
	    if ($i == 0){
		push (@{$graph_data[0]},$j);
		push (@{$graph_data[1]},0);
	    }
	    ${$graph_data[1]}[$j]+=${$data_cutoffs[$i]}[$j];
	}
    }

    my $title="Total number of analyzed moves before a cutoff";
    createBarGraph("cutoffs.all.bars.png",$title,@graph_data);
    createPointGraph("ncand.all.points.png",$title,@graph_data);
    

    @graph_data=([],[]);
    # Fill graph_data with a total of @data_ncand

    for (my $i=0;$i<12;$i++){
	for (my $j=0;$j<@{$data_ncand[$i]};$j++){
	    if ($i == 0){
		push (@{$graph_data[0]},$j);
		push (@{$graph_data[1]},0);
	    }
	    ${$graph_data[1]}[$j]+=${$data_ncand[$i]}[$j];
	}
    }
    
    $title="Total number of candidate moves";
    createBarGraph("ncand.all.bars.png",$title,@graph_data);
    createPointGraph("ncand.all.points.png",$title,@graph_data);
}    

# Create a bar graph containing an average of the number of candidates/cutoffs
# for each depth. Also do the same for the number of analyzed positions (and put
# it in perspective rapport to the maximum possible number). Also create a graph
# with the number of times each pentomino shape generated a cutoff, for each
# depth + a 'total' graph.
sub createDepthPentoGraphs {
    
    my @graph_data=([],[],[]);

    # Fill in graph_data with @data_cutoffs

    for (my $i=0;$i<12;$i++){
	push (@{$graph_data[0]},$i);
	my $average_sum=0;
	my $total_quantity=0;
	for (my $j=0;$j<@{$data_cutoffs[$i]};$j++){
	    my $quantity=${$data_cutoffs[$i]}[$j];
	    $total_quantity+=$quantity;
	    $average_sum+=$quantity*$j;
	}
	my $average;
	if ($total_quantity == 0){
	    $average=0;
	}
	else {
	    $average=int($average_sum/$total_quantity+0.5);
	}
	push (@{$graph_data[1]},$average);
    }

    # Fill in graph_data with @data_ncand

    for (my $i=0;$i<12;$i++){
	my $average_sum=0;
	my $total_quantity=0;
	for (my $j=0;$j<@{$data_ncand[$i]};$j++){
	    my $quantity=${$data_ncand[$i]}[$j];
	    $total_quantity+=$quantity;
	    $average_sum+=$quantity*$j;
	}
	my $average;
	if ($total_quantity == 0){
	    $average=0;
	}
	else {
	    $average=int($average_sum/$total_quantity+0.5);
	}
	push (@{$graph_data[2]},$average);
    }
    
    my $title="Average of the number of candidates and analyzed moves before" .
	" a cutoff at each depth";
    createBarGraph("ncand-cutoffs.depths.bars.png",$title,@graph_data);

    @graph_data=([],[],[]);

    # Fill in graph_data with @data_positions
    for (my $i=0;$i<12;$i++){
	push (@{$graph_data[0]},$i);
	push (@{$graph_data[1]},$data_positions[0][$i]);
	push (@{$graph_data[2]},$data_positions[1][$i]);
    }
    
    $title="Number of analyzed positions compared to the maximum number of"
	. " positions at each depth";
    createBarGraph("positions.depths.bars.png",$title,@graph_data);

    my @graph_data2=($graph_data[0],$graph_data[1],[]);
    $title="Number of analyzed positions at each depth";
    createBarGraph("analyzedpositions.depths.bars.png",$title,@graph_data2);

    @graph_data2=($graph_data[0],$graph_data[2],[]);
    $title="Maximum number of positions at each depth";
    createBarGraph("maxpositions.depths.bars.png",$title,@graph_data2);

    for (my $i=0;$i<12;$i++){
	@graph_data=([],[],[]);
	my $depth;
	if ($i < 10){
	    $depth= "0${i}";
	}
	else {
	    $depth=$i;
	}

	for (my $j=0;$j<12;$j++){
	    my $pento_letter;
	    $pento_letter="I" if $j == 0;
	    $pento_letter="L" if $j == 1;
	    $pento_letter="Y" if $j == 2;
	    $pento_letter="N" if $j == 3;
	    $pento_letter="V" if $j == 4;
	    $pento_letter="P" if $j == 5;
	    $pento_letter="U" if $j == 6;
	    $pento_letter="Z" if $j == 7;
	    $pento_letter="F" if $j == 8;
	    $pento_letter="T" if $j == 9;
	    $pento_letter="W" if $j == 10;
	    $pento_letter="X" if $j == 11;

	    push (@{$graph_data[0]},$pento_letter);
	    push (@{$graph_data[1]},$data_pento[$i][$j]);
	}
	
	$title="Number of times each pentomino shape generated a cutoff at"
	    . " depth ${i}";
	createBarGraph("cutoffs.pento.${depth}.bars.png",$title,@graph_data);
    }
    @{$graph_data[1]}=();
    for (my $i=0;$i<12;$i++){
	for (my $j=0;$j<12;$j++){
	    if ($i == 0){
		push (@{$graph_data[1]},0);
	    }
	    $graph_data[1][$j]+=$data_pento[$i][$j];
	}
    }
    $title="Number of times each pentomino shape generated a cutoff for all"
	." depths";
    createBarGraph("cutoffs.pento.all.bars.png",$title,@graph_data);
}


if (@ARGV < 2){
    die "Takes two arguments: the stats file and the output directory";
}
if ( ! -d $OUTDIR || ! -f $STATSFILE){
    die "$OUTDIR is not a regular directory or $STATSFILE is not a regular"
    . " file.";
}

if (-s "${STATSFILE}" > 1000000){
    die("$STATSFILE is too big, I refuse to open it");
}
    
open(FILE,"<$STATSFILE") or die $!;

my @json_obj=<FILE>;
unshift(@json_obj,"{");
push(@json_obj,"}");

my $stats=jsonToObj("@json_obj");

close(FILE);

for (my $i=0;$i<12;$i++){
    push (@data_ncand,$stats->{'number_candidates'}->{"depth_${i}"});
    push (@data_cutoffs,$stats->{'analyzed_before_cutoff'}->{"depth_${i}"});
    push (@data_pento,$stats->{'pento_cutoff'}->{"depth_${i}"});
}
push (@{$data_positions[0]},@{$stats->{'analyzed_pos'}});
push (@{$data_positions[1]},@{$stats->{'max_pos'}});

createDistGraphs();
createDepthPentoGraphs();

exit 0;
	  



