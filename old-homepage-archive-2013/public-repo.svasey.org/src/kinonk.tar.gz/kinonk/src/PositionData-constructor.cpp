// PositionData-constructor.cpp -- Implementation of PositionData constructor
// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   PositionData-constructor.cpp
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Wed Sep 19 22:10:20 2007
 * 
 * @brief  Contains PositionData::PositionData (its constructor)
 * 
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#include "PositionData.h"
#include "Move.h"
#include "Coor.h"

#include <vector>
using std::vector;

extern Coor SIZE;
extern bool EXCLUDE_PENTO[12];
extern bool KATAMINO_RULES;

namespace Stats {
    extern int size_matrix;
};

// NOTE: no checks are performed on the size or the PENTO_ID. Make sure to do
// that before calling that constructor
PositionData::PositionData():board(SIZE)
{
            
    vector<Move> table;		// Table of all theoretically possible moves
        
    Coor clist[8][5];		// Coordinates of the pentomino, for
				// each orientation (maximum of 8).

    // There shouldn't be any negative coordinates. The pentomino are
    // declared to fit in the lower left corner(0,0)

    // Process the PENTO_ID vector
    for (int i=0;i<12;i++){
	if (EXCLUDE_PENTO[i])
	    continue;

	switch (i){
	case 0:			// 'I' pentomino (2 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(0,1);
	    clist[0][2]=Coor(0,2);
	    clist[0][3]=Coor(0,3);
	    clist[0][4]=Coor(0,4);
	    
	    clist[1][0]=Coor(0,0);
	    clist[1][1]=Coor(1,0);
	    clist[1][2]=Coor(2,0);
	    clist[1][3]=Coor(3,0);
	    clist[1][4]=Coor(4,0);
	    
	    	    
	    table.push_back(Move(0,clist[0],SIZE));
	    table.push_back(Move(0,clist[1],SIZE));
	    break;
		
	case 1:			// 'L' pentomino (8 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(0,1);
	    clist[0][2]=Coor(0,2);
	    clist[0][3]=Coor(0,3);
	    clist[0][4]=Coor(1,3);
	    
	    clist[1][0]=Coor(0,0);
	    clist[1][1]=Coor(0,1);
	    clist[1][2]=Coor(1,0);
	    clist[1][3]=Coor(2,0);
	    clist[1][4]=Coor(3,0);
	    
	    clist[2][0]=Coor(0,0);
	    clist[2][1]=Coor(1,0);
	    clist[2][2]=Coor(1,1);
	    clist[2][3]=Coor(1,2);
	    clist[2][4]=Coor(1,3);
	    
	    clist[3][0]=Coor(0,1);
	    clist[3][1]=Coor(1,1);
	    clist[3][2]=Coor(2,1);
	    clist[3][3]=Coor(3,1);
	    clist[3][4]=Coor(3,0);
	    
	    // Symmetrical rotation
	    clist[4][0]=Coor(1,0);
	    clist[4][1]=Coor(1,1);
	    clist[4][2]=Coor(1,2);
	    clist[4][3]=Coor(1,3);
	    clist[4][4]=Coor(0,3);
	    
	    clist[5][0]=Coor(0,0);
	    clist[5][1]=Coor(0,1);
	    clist[5][2]=Coor(1,1);
	    clist[5][3]=Coor(2,1);
	    clist[5][4]=Coor(3,1);

	    clist[6][0]=Coor(0,0);
	    clist[6][1]=Coor(1,0);
	    clist[6][2]=Coor(0,1);
	    clist[6][3]=Coor(0,2);
	    clist[6][4]=Coor(0,3);
	    
	    clist[7][0]=Coor(0,0);
	    clist[7][1]=Coor(1,0);
	    clist[7][2]=Coor(2,0);
	    clist[7][3]=Coor(3,0);
	    clist[7][4]=Coor(3,1);

	    for (int j=0;j<8;j++){
		table.push_back(Move(1,clist[j],SIZE));
	    }
	    break;
	    
	    
	case 2:			// 'Y' pentomino (8 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(0,1);
	    clist[0][2]=Coor(1,1);
	    clist[0][3]=Coor(0,2);
	    clist[0][4]=Coor(0,3);
	    
	    clist[1][0]=Coor(0,0);
	    clist[1][1]=Coor(1,0);
	    clist[1][2]=Coor(2,0);
	    clist[1][3]=Coor(2,1);
	    clist[1][4]=Coor(3,0);
	    
	    clist[2][0]=Coor(1,0);
	    clist[2][1]=Coor(1,1);
	    clist[2][2]=Coor(1,2);
	    clist[2][3]=Coor(0,2);
	    clist[2][4]=Coor(1,3);
	    
	    clist[3][0]=Coor(0,1);
	    clist[3][1]=Coor(1,1);
	    clist[3][2]=Coor(1,0);
	    clist[3][3]=Coor(2,1);
	    clist[3][4]=Coor(3,1);
	    
	    // Symmetrical rotation
	    clist[4][0]=Coor(1,0);
	    clist[4][1]=Coor(0,1);
	    clist[4][2]=Coor(1,1);
	    clist[4][3]=Coor(1,2);
	    clist[4][4]=Coor(1,3);
	    
	    clist[5][0]=Coor(0,1);
	    clist[5][1]=Coor(1,1);
	    clist[5][2]=Coor(2,1);
	    clist[5][3]=Coor(2,0);
	    clist[5][4]=Coor(3,1);
	    
	    clist[6][0]=Coor(0,0);
	    clist[6][1]=Coor(0,1);
	    clist[6][2]=Coor(0,2);
	    clist[6][3]=Coor(1,2);
	    clist[6][4]=Coor(0,3);

	    clist[7][0]=Coor(0,0);
	    clist[7][1]=Coor(1,0);
	    clist[7][2]=Coor(1,1);
	    clist[7][3]=Coor(2,0);
	    clist[7][4]=Coor(3,0);
	    
	    for (int j=0;j<8;j++){
		table.push_back(Move(2,clist[j],SIZE));
	    }
	    break;
	    
	case 3:			// 'N' pentomino (8 orientations)
	    clist[0][0]=Coor(1,0);
	    clist[0][1]=Coor(1,1);
	    clist[0][2]=Coor(0,1);
	    clist[0][3]=Coor(0,2);
	    clist[0][4]=Coor(0,3);
	    
	    clist[1][0]=Coor(0,0);
	    clist[1][1]=Coor(1,0);
	    clist[1][2]=Coor(2,0);
	    clist[1][3]=Coor(2,1);
	    clist[1][4]=Coor(3,1);
	    
	    clist[2][0]=Coor(1,0);
	    clist[2][1]=Coor(1,1);
	    clist[2][2]=Coor(1,2);
	    clist[2][3]=Coor(0,2);
	    clist[2][4]=Coor(0,3);

	    clist[3][0]=Coor(0,0);
	    clist[3][1]=Coor(1,0);
	    clist[3][2]=Coor(1,1);
	    clist[3][3]=Coor(2,1);
	    clist[3][4]=Coor(3,1);

	    // Symmetrical rotation
	    clist[4][0]=Coor(0,0);
	    clist[4][1]=Coor(0,1);
	    clist[4][2]=Coor(1,1);
	    clist[4][3]=Coor(1,2);
	    clist[4][4]=Coor(1,3);

	    clist[5][0]=Coor(0,1);
	    clist[5][1]=Coor(1,1);
	    clist[5][2]=Coor(2,1);
	    clist[5][3]=Coor(2,0);
	    clist[5][4]=Coor(3,0);

	    clist[6][0]=Coor(0,0);
	    clist[6][1]=Coor(0,1);
	    clist[6][2]=Coor(0,2);
	    clist[6][3]=Coor(1,2);
	    clist[6][4]=Coor(1,3);

	    clist[7][0]=Coor(0,1);
	    clist[7][1]=Coor(1,1);
	    clist[7][2]=Coor(1,0);
	    clist[7][3]=Coor(2,0);
	    clist[7][4]=Coor(3,0);

	    for (int j=0;j<8;j++){
		table.push_back(Move(3,clist[j],SIZE));
	    }
	    
	    break;
	    
	case 4:			// 'V' pentomino (4 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(0,1);
	    clist[0][2]=Coor(0,2);
	    clist[0][3]=Coor(1,2);
	    clist[0][4]=Coor(2,2);

	    clist[1][0]=Coor(0,0);
	    clist[1][1]=Coor(1,0);
	    clist[1][2]=Coor(2,0);
	    clist[1][3]=Coor(0,1);
	    clist[1][4]=Coor(0,2);

	    clist[2][0]=Coor(0,0);
	    clist[2][1]=Coor(1,0);
	    clist[2][2]=Coor(2,0);
	    clist[2][3]=Coor(2,1);
	    clist[2][4]=Coor(2,2);

	    clist[3][0]=Coor(0,2);
	    clist[3][1]=Coor(1,2);
	    clist[3][2]=Coor(2,2);
	    clist[3][3]=Coor(2,1);
	    clist[3][4]=Coor(2,0);

	    for (int j=0;j<4;j++){
		table.push_back(Move(4,clist[j],SIZE));
	    }
	    	    
	    break;
	    
	case 5:			// 'P' pentomino (8 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(1,0);
	    clist[0][2]=Coor(0,1);
	    clist[0][3]=Coor(1,1);
	    clist[0][4]=Coor(0,2);

	    clist[1][0]=Coor(0,0);
	    clist[1][1]=Coor(1,0);
	    clist[1][2]=Coor(2,0);
	    clist[1][3]=Coor(1,1);
	    clist[1][4]=Coor(2,1);

	    clist[2][0]=Coor(1,0);
	    clist[2][1]=Coor(0,1);
	    clist[2][2]=Coor(1,1);
	    clist[2][3]=Coor(0,2);
	    clist[2][4]=Coor(1,2);

	    clist[3][0]=Coor(0,0);
	    clist[3][1]=Coor(1,0);
	    clist[3][2]=Coor(0,1);
	    clist[3][3]=Coor(1,1);
	    clist[3][4]=Coor(2,1);

	    // Symmetrical rotation
	    clist[4][0]=Coor(0,0);
	    clist[4][1]=Coor(1,0);
	    clist[4][2]=Coor(0,1);
	    clist[4][3]=Coor(1,1);
	    clist[4][4]=Coor(1,2);

	    clist[5][0]=Coor(1,0);
	    clist[5][1]=Coor(2,0);
	    clist[5][2]=Coor(0,1);
	    clist[5][3]=Coor(1,1);
	    clist[5][4]=Coor(2,1);

	    clist[6][0]=Coor(0,0);
	    clist[6][1]=Coor(0,1);
	    clist[6][2]=Coor(1,1);
	    clist[6][3]=Coor(0,2);
	    clist[6][4]=Coor(1,2);

	    clist[7][0]=Coor(0,0);
	    clist[7][1]=Coor(1,0);
	    clist[7][2]=Coor(2,0);
	    clist[7][3]=Coor(0,1);
	    clist[7][4]=Coor(1,1);

	    for (int j=0;j<8;j++){
		table.push_back(Move(5,clist[j],SIZE));
	    }
	    break;
	    
	case 6:			// 'U' pentomino (4 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(2,0);
	    clist[0][2]=Coor(0,1);
	    clist[0][3]=Coor(1,1);
	    clist[0][4]=Coor(2,1);

	    clist[1][0]=Coor(0,0);
	    clist[1][1]=Coor(1,0);
	    clist[1][2]=Coor(0,1);
	    clist[1][3]=Coor(0,2);
	    clist[1][4]=Coor(1,2);

	    clist[2][0]=Coor(0,0);
	    clist[2][1]=Coor(1,0);
	    clist[2][2]=Coor(2,0);
	    clist[2][3]=Coor(0,1);
	    clist[2][4]=Coor(2,1);

	    clist[3][0]=Coor(0,0);
	    clist[3][1]=Coor(1,0);
	    clist[3][2]=Coor(1,1);
	    clist[3][3]=Coor(0,2);
	    clist[3][4]=Coor(1,2);
	    
	    for (int j=0;j<4;j++){
		table.push_back(Move(6,clist[j],SIZE));
	    }
	    break;
	    
	case 7:			// 'Z' pentomino (4 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(1,0);
	    clist[0][2]=Coor(1,1);
	    clist[0][3]=Coor(1,2);
	    clist[0][4]=Coor(2,2);

	    clist[1][0]=Coor(2,0);
	    clist[1][1]=Coor(0,1);
	    clist[1][2]=Coor(1,1);
	    clist[1][3]=Coor(2,1);
	    clist[1][4]=Coor(0,2);

	    // Symmetrical rotation
	    clist[2][0]=Coor(1,0);
	    clist[2][1]=Coor(2,0);
	    clist[2][2]=Coor(1,1);
	    clist[2][3]=Coor(0,2);
	    clist[2][4]=Coor(1,2);

	    clist[3][0]=Coor(0,0);
	    clist[3][1]=Coor(0,1);
	    clist[3][2]=Coor(1,1);
	    clist[3][3]=Coor(2,1);
	    clist[3][4]=Coor(2,2);

	    for (int j=0;j<4;j++){
		table.push_back(Move(7,clist[j],SIZE));
	    }
	    break;
	    
	case 8:			// 'F' pentomino (8 orientations)
	    clist[0][0]=Coor(1,0);
	    clist[0][1]=Coor(2,0);
	    clist[0][2]=Coor(0,1);
	    clist[0][3]=Coor(1,1);
	    clist[0][4]=Coor(1,2);

	    clist[1][0]=Coor(0,1);
	    clist[1][1]=Coor(1,0);
	    clist[1][2]=Coor(1,1);
	    clist[1][3]=Coor(2,1);
	    clist[1][4]=Coor(2,2);

	    clist[2][0]=Coor(1,0);
	    clist[2][1]=Coor(1,1);
	    clist[2][2]=Coor(2,1);
	    clist[2][3]=Coor(0,2);
	    clist[2][4]=Coor(1,2);

	    clist[3][0]=Coor(0,0);
	    clist[3][1]=Coor(0,1);
	    clist[3][2]=Coor(1,1);
	    clist[3][3]=Coor(2,1);
	    clist[3][4]=Coor(1,2);

	    // Symmetrical rotation
	    clist[4][0]=Coor(0,0);
	    clist[4][1]=Coor(1,0);
	    clist[4][2]=Coor(1,1);
	    clist[4][3]=Coor(2,1);
	    clist[4][4]=Coor(1,2);

	    clist[5][0]=Coor(2,0);
	    clist[5][1]=Coor(0,1);
	    clist[5][2]=Coor(1,1);
	    clist[5][3]=Coor(2,1);
	    clist[5][4]=Coor(1,2);

	    clist[6][0]=Coor(1,0);
	    clist[6][1]=Coor(0,1);
	    clist[6][2]=Coor(1,1);
	    clist[6][3]=Coor(1,2);
	    clist[6][4]=Coor(2,2);

	    clist[7][0]=Coor(1,0);
	    clist[7][1]=Coor(0,1);
	    clist[7][2]=Coor(1,1);
	    clist[7][3]=Coor(2,1);
	    clist[7][4]=Coor(0,2);
	    
	    for (int j=0;j<8;j++){
		table.push_back(Move(8,clist[j],SIZE));
	    }
	    break;
	    
	case 9:			// 'T' pentomino (4 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(1,0);
	    clist[0][2]=Coor(2,0);
	    clist[0][3]=Coor(1,1);
	    clist[0][4]=Coor(1,2);

	    clist[1][0]=Coor(2,0);
	    clist[1][1]=Coor(0,1);
	    clist[1][2]=Coor(1,1);
	    clist[1][3]=Coor(2,1);
	    clist[1][4]=Coor(2,2);

	    clist[2][0]=Coor(1,0);
	    clist[2][1]=Coor(1,1);
	    clist[2][2]=Coor(0,2);
	    clist[2][3]=Coor(1,2);
	    clist[2][4]=Coor(2,2);

	    clist[3][0]=Coor(0,0);
	    clist[3][1]=Coor(0,1);
	    clist[3][2]=Coor(1,1);
	    clist[3][3]=Coor(2,1);
	    clist[3][4]=Coor(0,2);

	    for (int j=0;j<4;j++){
		table.push_back(Move(9,clist[j],SIZE));
	    }
	    break;
	    
	case 10:		// 'W' pentomino (4 orientations)
	    clist[0][0]=Coor(0,0);
	    clist[0][1]=Coor(0,1);
	    clist[0][2]=Coor(1,1);
	    clist[0][3]=Coor(1,2);
	    clist[0][4]=Coor(2,2);

	    clist[1][0]=Coor(1,0);
	    clist[1][1]=Coor(2,0);
	    clist[1][2]=Coor(0,1);
	    clist[1][3]=Coor(1,1);
	    clist[1][4]=Coor(0,2);

	    clist[2][0]=Coor(0,0);
	    clist[2][1]=Coor(1,0);
	    clist[2][2]=Coor(1,1);
	    clist[2][3]=Coor(2,1);
	    clist[2][4]=Coor(2,2);

	    clist[3][0]=Coor(2,0);
	    clist[3][1]=Coor(1,1);
	    clist[3][2]=Coor(2,1);
	    clist[3][3]=Coor(0,2);
	    clist[3][4]=Coor(1,2);

	    for (int j=0;j<4;j++){
		table.push_back(Move(10,clist[j],SIZE));
	    }
	    break;
	    
	case 11:		// 'X' pentomino (one orientation)
	    clist[0][0]=Coor(1,0);
	    clist[0][1]=Coor(0,1);
	    clist[0][2]=Coor(1,1);
	    clist[0][3]=Coor(2,1);
	    clist[0][4]=Coor(1,2);

	    table.push_back(Move(11,clist[0],SIZE));
	    break;
	}
	
    }
    
    

    // Temporary variable that will be entirely copied to all_moves
    vector<Move> all_positions;

    // Takes the base move and try to move it all over the board. Register all
    // the positions in all_positions.
    for (vector<Move>::iterator i=table.begin();i!=table.end();i++){
	
	// Check that all pentomino orientations
	// fit on the board
	if (i->isOutOfRange(SIZE)){
	    table.erase(i);
	    
	    // Since i was erased, the next one has
	    // now taken its place
	    i--;		
	    continue;
	}
	for (int y=0;y<SIZE.y;y++){
	    if (!i->isOutOfRange(SIZE))
		all_positions.push_back(*i);
	    
	    const Move LEFTIMAGE=*i;
	    for (int x=0;x<SIZE.x;x++){
		i->moveHor(1); // Move right
		if (!i->isOutOfRange(SIZE))
		    all_positions.push_back(*i);
	    }
	    *i=LEFTIMAGE;
	    i->moveVer(1); // Move up
	}
	
    }


    // Copy the moves to all_moves and valid them all. You are then free to
    // invalid some of them using PositionData::addReasonToInvalid 
    n_cand=all_positions.size();
    all_moves=new MetaMove[n_cand];
    for (int i=0;i<n_cand;i++){
	all_moves[i]=all_positions[i];
	if (i != 0)
	    all_moves[i].previous_valid=&all_moves[i-1];
	if (i != n_cand-1)
	    all_moves[i].next_valid=&all_moves[i+1];
	all_moves[i].all_moves_pos=&all_moves[i];
    }
    for (int i=0;i<n_cand;i++){
	vector<Move> eq;
	all_moves[i].getEquivalentPos(SIZE,eq);
	for (int j=i+1;j<n_cand;j++){
	    for (int k=0;k<static_cast<int>(eq.size());k++){
		if (all_moves[j] == eq[k])
		    all_moves[j].is_equivalent=true;
	    }
	}
    }
    
    // Construct the indexes

    
    // Allocate space for the square_index, since we know how many
    // squares there will be
    square_index=new vector<MetaMove*>[SIZE.getInt(SIZE)];
        
    // Reserve space for the playing_order, since we know the max number of
    // moves that could be played
    playing_order.reserve(12);

    
    for (int i=0;i<getNCand();i++){
	// Get the move pointers

	// Add the moves to the indexes
	pento_index[all_moves[i].pento_id].push_back(&all_moves[i]);
	for (int j=0;j<5;j++){
	    square_index[all_moves[i].pos[j].getInt(SIZE)].push_back
		(&all_moves[i]);
	}
    }

    // sets the size of the dynamically allocated matrixes.
    int max_n_cand=getNCand();
    Stats::size_matrix=max_n_cand+1; 
    // +1 is needed because there can also be 0 candidate...
        
    // If Katamino Rules are used, only the moves adjacent to the center are valid
    if (KATAMINO_RULES){
	// Find the central square(s)
	vector<Coor> center;

	if (SIZE.x%2==0 && SIZE.y%2==0){ // SIZE.x and SIZE.y are even
	    center.push_back(Coor(SIZE.x/2-1,SIZE.y/2-1));
	    center.push_back(Coor(SIZE.x/2,SIZE.y/2-1));
	    center.push_back(Coor(SIZE.x/2-1,SIZE.y/2));
	    center.push_back(Coor(SIZE.x/2,SIZE.y/2));
	}
	else if (SIZE.x==SIZE.y){ // It is a square so SIZE.x and SIZE.y are odd
	    center.push_back(Coor(SIZE.x/2,SIZE.y/2));
	}
	else{ // It is a rectangle
	    if (SIZE.x>SIZE.y){ // horizontal rectangle
		center.push_back(Coor(SIZE.x/2,SIZE.y/2));
		if (SIZE.y%2==0) center.push_back(Coor(SIZE.x/2,SIZE.y/2-1));
		else if (SIZE.x%2==0) 
		    center.push_back(Coor(SIZE.x/2-1,SIZE.y/2));
	    }
	    else{ // vertical rectangle
		center.push_back(Coor(SIZE.x/2,SIZE.y/2));
		if (SIZE.x%2==0) center.push_back(Coor(SIZE.x/2-1,SIZE.y/2));
		else if(SIZE.y%2==0) 
		    center.push_back(Coor(SIZE.x/2,SIZE.y/2-1));
	    }
	};
	
	// invalidate all moves not overlaping the center 
	int max_increment = getNCand();
	for (int i=0;i<max_increment;i++) addReasonToInvalid(&all_moves[i]);

	// revalidate all moves overlaping the center		
	for (unsigned int i=0;i<center.size();i++){
	    for (vector<MetaMove*>::iterator 
		     it=square_index[center[i].getInt(SIZE)].begin();
		 it<square_index[center[i].getInt(SIZE)].end();it++){
		if (!(*it)->isValid()) addAdjacent(*it);
	    }
	}
    }
    
    for (int i=0;i<max_n_cand;i++)
	all_moves[i].checkAdjValidity();
}
