// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   Move.h
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Tue Sep 18 17:47:24 2007
 * 
 * @brief  Contains the declaration of the Move and MetaMove class.
 * 
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
  
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#ifndef INCLUDE_MOVE
#define INCLUDE_MOVE

// Contain the description of a move, basically the id of the used pentomino
// and its position if  the move is played. It also contains a pointer to its
// MetaMove equivalent in all_moves.
// A MetaMove is a child of the Move class. It contains members like the number
// of times the move has generated a cutoff or whether the move is valid or
// not. It is used inside the PositionData class to do various operations
// related to the bruteforce search. Move objects are used by public functions
// of that class to communicate with the outside world.

#include "Coor.h"

#include <iostream>
#include <vector>
#include <set>

using std::set;
using std::vector;

extern Coor SIZE;

class MetaMove;
/**
 * Contains the description of a pentomino, and the squares where it must be put
 * on the board. For some reasons, it also contains the adjacent squares of the
 * move. This is used by, for example PositionData::playMove, when the katamino
 * rules are used. Last but not least, it also contains the position of the
 * %MetaMove equivalent object in PositionData::all_moves
 * 
 */

class Move
{
public:
    // default values to some members used in the constructor
    enum{
	/**
	 * The value of the pentomino id (see Move::pento_id) when the move is
	 * initialized and no value is given.
	 */
	UNDEFINED_PENTOID=-1};
    
    // the id of the used pentomino (between 0 and 11)
    /**
     * The identifier of a pentomino (between 0 and 11). Each value corresponds
     * to a different 'shape' of the pentomino. The matchings have been chosen
     * arbitrarily. Here they are:
     * 0: I pentomino ; 1: L pentomino; 2: Y ; 3: N ; 4: V; 5: P; 6: U ; 7: Z;
     * 8: F; 9: T ; 10: W ; 11: X
     */

    int pento_id;

    // the squares the pentomino will use if it is played
    /**
     * The position of each of the 5 pentomino square on the board (if the move
     * is played)
     * 
     */

    Coor pos[5];

    // the squares adjacent to this move's pentomino
    // the number of squares are between 1 and 16
    /**
     * The number of adjacent squares to the move. There can be between 1 and 16
     * adjacent squares.
     * 
     */

    vector<Coor> adj;

    /**
     * The position of the %MetaMove equivalent of this move, in
     * PositionData::all_moves. 
     * 
     */

    MetaMove* all_moves_pos;
    
    // default constructor
    Move()
    {
	pento_id=UNDEFINED_PENTOID;
	all_moves_pos=0;
    }
    
    // class constructor
    Move(int id,const Coor position[],const Coor board_size=Coor(8,8));
    
    // put all the squares in contact with the pentomino in the set (JUST AN
    // IDEA, TO BE DONE) (Move.cpp)
    // void getAdjacentSquares(const Coor& SIZE,set<Coor>& adjacent_squares) const;

    // the same move if the board is rotated of n quarters (Move.cpp). The
    // returned move's all_moves_pos is set to NULL
    /** 
     * Create a rotation of the move
     * 
     * @param SIZE 
     * The size of the board
     * @param quarters 
     * The number of quarters you want to turn the move position (clockwise)
     * 
     * @return The rotated move object
     * @warning The returned move's Move::all_moves_pos is set to NULL
     */
    Move getRotation(const Coor& SIZE, int quarters=1) const;

    // the symmetry of the Move with respect to the vertical axis
    // (Move.cpp). The returned move's all_moves_pos is set to NULL
    /** 
     * Get a symmetry of the move with respect to the vertical axis
     * 
     * @param SIZE The size of the board
     * 
     * @return The symmetrical object
     * @warning Move::all_moves_pos of the returned move is set to NULL
     */
    Move getVerticalSymmetry(const Coor& SIZE) const;

    // the symmetry of the Move with respect to the horizontal axis
    // (Move.cpp). The returned move's all_moves_pos is set to NULL
    /**
     * Same as Move::getVerticalSymmetry but get a symmetry of the Move with
     * respect to the horizontal axis
     * 
     */

    Move getHorizontalSymmetry(const Coor& SIZE) const;

    // assuming the move is played on an empty board, what other move will be
    // equivalent (symmetry, rotations...) fill equivalent_pos with the answers
    // (Move.cpp)
    /** 
     * Assuming the move is played on an empty board, get the other moves that
     * will be equivalent (e.g by symmetry, or rotation of the board)
     * 
     * @param SIZE 
     * The size of the board
     * @param equivalent_pos
     * This will be filled with the equivalent moves.
     */
    void getEquivalentPos(const Coor& SIZE,vector<Move>& equivalent_pos) const;

    // displaying the move as if it was played on the board. (Move.cpp)
    /** 
     * Display an empty board with the move played on it
     * 
     * @param SIZE 
     * The board's size
     */
    void displayShape(const Coor& SIZE) const;


    // shift horizontally of d units
    /** 
     * Shift horizontally
     * 
     * @param d 
     * The number of units you want your move to be shifted. A positive number
     * will make your move go right.
     * @warning The resulting positions are not checked, and could be out of range
     */
    void moveHor(int d)
    {
	for (int i=0;i<5;i++) pos[i].x+=d;
	for (vector<Coor>::iterator i=adj.begin();i!=adj.end();i++){ 
	    // if(!Coor(i->x+d,i->y).isOutOfRange(SIZE)){
		i->x+=d;
	   //  }
// 	    else {
// 		adj.erase(i);
// 	    }
	}
    }
    
    /** 
     * Shift vertically
     * 
     * @param d The number of unit you want your move to be shifted. A positive
     * number will make your move go up.  @warning The resulting move position
     * is not checked, and could be out of range.
     */
    // shift vertically of d units
    void moveVer(int d)
    {
	for (int i=0;i<5;i++) pos[i].y+=d;
	for (vector<Coor>::iterator i=adj.begin();i!=adj.end();i++){ 
	    // if(!Coor(i->x,i->y+d).isOutOfRange(SIZE)){
		i->y+=d;
	   //  }
// 	    else {
// 		adj.erase(i);
// 	    }
	}
    }

    // checks the adjacent squares of the move and removes an adj if it is out
    // of range
    /** 
     * Remove all the adjacent squares of the moves which are out of range
     * (using Coor::isOutOfRange).
     * 
     */
    void checkAdjValidity(){
	for (vector<Coor>::iterator i=adj.begin();i!=adj.end();i++){
	    if ((*i).isOutOfRange(SIZE)){
		adj.erase(i);
		i--;
	    }
	}
    }

    // Returns true if the move is out of (0,0) to (SIZE.x,SIZE.y) (Move.cpp)
    /** 
     * Check if the moves positions are out of the board range
     * 
     * @param SIZE 
     * The size of the board
     * 
     * @return 
     * True if the move is out of range, false otherwise.
     */
    bool isOutOfRange(const Coor& SIZE) const;

    // test-for-equality operator (Move.cpp)
    /** 
     * Check if one move is equal to another. Two moves are equal if _either_
     * - their Move::all_moves_pos are non-NULL and the same
     * - or they have the same positions (but not necessarily in the same order)
     * @return true if the two are equal, false otherwise
     */
    bool operator ==(const Move&) const;
    
    // defined according to operator==
    bool operator !=(const Move& M) const
    {
	return ! (*this == M);
    }

    // output stream operator (Move.cpp)
    friend std::ostream& operator <<(std::ostream&,const Move&);
    /**
     * This simply read five space-separated %Coor objects. They will be the
     * object's Move::pos elements.
     * 
     */

    friend std::istream& operator >>(std::istream& is,Move& m);
};

/**
 * Basically, a MetaMove object is a "heavy" version of a Move object. You
 * should only find MetaMove in PositionData::all_moves, and some of the member
 * functions that interact with it. This contain information on whether the move
 * is valid or invalid and whether it is "good" or "bad" to play it (ie its
 * heuristic evaluation). To understand the role of all the members of this
 * class, you might want to have a look at the documentation of %PositionData ,
 * especially PositionData::all_moves
 * @warning 
 * Beware that this class is actually quite low level, ie it cannot do much on
 * its own. Think twice before using any of the public functions it has. You
 * probably need to write a higher-level function (e.g in %PositionData) , which
 * looks at the board, and can access PositionData::all_moves . One of the only
 * function you might need to use directly is MetaMove::generatedACutoff
 */
    
class MetaMove : public Move 
{
private:
    /**
     * The maximum MetaMove::static_eval you can have
     * 
     */
    static const int INFINITY=10000000;
        
    // a move is valid (playable) if the number of reasons for it to be invalid
    // is 0. Else it is invalid. A reason can be that the pentomino has already
    // been played, or that the move oversteps some squares where a move has
    // already been played. For example if the move oversteps two already
    // occupied squares and that the pentomino has already been played,
    // reasons_invalid would be 3.
    /**
     * The number of "reasons" the move has to be invalid. If this is 0, the
     * move is valid. A reason can be that the pentomino has already been played
     * (ie the pentomino's id is already elsewhere on the board, or that some of
     * the move's Move::pos oversteps another pentomino. This is incremented and
     * decremented from %PositionData
     * 
     */

    int reasons_invalid;

    // Number of adjacent pentominoes if the move is played
    /**
     * The number of adjacent pentominoes on the board (if the move is
     * played). This is used when the katamino rules are used, to determine if
     * the move can be played or not (a move can only be played if it is in
     * contact with another pentomino).
     * 
     */

    int n_adjacents;
    
    // The move's estimated value. Goes from 0 to INFINITY
    /**
     * The move's estimated value. Goes from 0 to MetaMove::INFINITY this is set
     * by PositionData::getSortedList and should not be used by other functions,
     * as it changes frequently.  When it becomes 0, some functions in
     * %PositionData will see it and decrement #reasons_invalid . Same thing
     * when it becomes positive again.
     * 
     */

    int static_eval;
        
    // The number of times the move generated a cutoff, for each depth
    /**
     * This, by oposition to MetaMove::static_eval , is kept all throughout the
     * game. It contains the number of times the move generated a cutoff at each
     * depth and is also used by PositionData::getSortedList . The way the moves
     * are sorted using MetaMove::static_eval and MetaMove::adaptive_eval ,
     * depends on the user's settings (e.g whether it uses the killer heuristic
     * etc...). Generally, the adaptive evaluation is stronger for the n (n
     * being set by the users and defaulting to 2 . best moves in the list, the
     * other being sorted using static_eval only.
     * 
     */

    int adaptive_eval[12];
    

public:
    /**
     * In order to understand the role of this member and MetaMove::next_valid ,
     * you should first have a general understanding of how things work when a
     * move is played (PositionData::playMove) , and how %PositionData is
     * organized, especially PositionData::all_moves (as it is the only member
     * containing MetaMove objects. As the name indicates, this points to the
     * previous valid moves in PositionData::all_moves . If there are no
     * previous valid moves , this is set to NULL .
     * 
     */

    MetaMove* previous_valid;
    /**
     * See MetaMove::previous_valid
     * 
     */

    MetaMove* next_valid;

    /**
     * This is true if the move is equivalent (e.g symmetrical) to another move
     * (when the board is empty)
     * in PositionData::all_moves . This is set by PositionData::PositionData
     * and does not change afterward. When this is true, the move can still
     * theoretically be valid (as it can be played) but will not be taken into
     * consideration by analyzing functions such as PositionData::getSortedList
     * (but only if the board is empty).
     * 
     */

    bool is_equivalent;

    
    MetaMove():Move(),reasons_invalid(0),n_adjacents(0),static_eval(0)
	      ,previous_valid(0),next_valid(0),is_equivalent(false)
    {
	for (int i=0;i<12;i++)
	    adaptive_eval[i]=0;
    }

    void operator=(const Move& M)
    {
	pento_id=M.pento_id;
	all_moves_pos=M.all_moves_pos;
	for (int i=0;i<5;i++)
	    pos[i]=M.pos[i];
	for (unsigned int i=0;i<M.adj.size();i++)
	    adj.push_back(M.adj[i]);
    }

    // Return true if *this is greater or equal in evaluation than M
    /**
     * This is a >= operator taking a MetaMove pointer as argument. It uses
     * MetaMove::static_eval exclusively.
     *
     * @param M A pointer to the move to be compared with this
     * @return True if *this 's static_eval is greater or equal than that of *M
     */

    bool greater_equal(const MetaMove* M) const
    {
	return static_eval >= M->static_eval;
    }

    /** 
     * This is a >= operator, using MetaMove::adaptive_eval if it is defined in
     * either one of the two objects.
     * 
     * @param M A pointer to the move to be compared with *this
     * @param depth The depth at which you want to consider the
     * MetaMove::adaptive_equal member
     * 
     * @return True if *this 's adaptive evaluation at the given depth is
     * greater or equal than that of *M
     */

    bool greater_equal_adaptive(const MetaMove* M,int depth) const
    {
	if (adaptive_eval[depth] == 0 && M->adaptive_eval[depth] == 0)
	    return static_eval >= M->static_eval;
	return adaptive_eval[depth] >= M->adaptive_eval[depth];
    }

    // Return true if the move is valid (0 reason for it to be invalid)
    /** 
     * Check if the move is valid (ie its MetaMove::reasons_invalid member == 0)
     * 
     * 
     * @return True if the move is valid, false otherwise
     */
    bool isValid() const
    {
	return this->reasons_invalid == 0;
    }

    // Return true if the move is nearly valid: it means the move has just one
    // reason left that justify its invalidity.
    /** 
     * Check if the move has only one reason to be invalid
     * 
     * 
     * @return true if the move's MetaMove::reasons_invalid == 1
     */
    bool isNearlyValid() const
    {
	return this->reasons_invalid == 1;
    }

    /** 
     * Get the move's number of adjacent pentominoes on the board
     * 
     * 
     * @return the number of adjacent pentominoes to the move (on the board)
     */
    int getNAdjacents() const
    {
	return n_adjacents;
    }
    /** 
     * Return the number of replies to the move (assuming its static evaluation
     * has been set using the number of candidates)
     * 
     * 
     * @return The number of replies to the move
     */
    int getNCandEvaluation() const
    {
	return INFINITY-static_eval;
    }
	
    // The larger the number of candidates, the lower the evaluation
    /** 
     * Set the move's static evaluation using its number of replies.
     * 
     * @param n_cand The number of replies to the move
     */
    void setNCandEvaluation(int n_cand)
    {
	static_eval=INFINITY-n_cand;
    }

    // The larger the number of candidates, the higher the evaluation
    
    void setReverseNCandEvaluation(int n_cand)
    {
	static_eval=n_cand;
    }

    void setWinsRatioEvaluation(int wins_ratio)
    {
	static_eval=wins_ratio;
    }

    /** 
     * Increment the number of adjacent pentominoes the move will have, if it is
     * played. This is mainly used by PositionData::playMove for example.
     * 
     */
    void addAdjacent()
    {
	n_adjacents++;
    }
    /** 
     * The exact opposite of MetaMove::addAdjacent
     * 
     */
    void removeAdjacent()
    {
	n_adjacents--;
    }

    // Use this function in case you have found a new reason for the move to be
    // invalid. WARNING: If you are writing some code in PositionData, check
    // PositionData::addReasonToInvalid first before using this function
    /** 
     * Add a reason for the move to be invalid (concretely, increment
     * MetaMove::addReasonToInvalid)
     * 
     */
    void addReasonToInvalid() 
    {
	reasons_invalid++;
    }

    // Use this function in case a reason for the move to be invalid does not
    // apply anymore. WARNING: If you are writing some code in PositionData,
    // check PositionData::addReasonToValid first before using this function.
    /** 
     * The exact opposite of MetaMove::addReasonToInvalid
     * 
     */
    void addReasonToValid()
    {
	reasons_invalid--;
    }

    // Use this function to directly set the move to be valid.
    /** 
     * Directly declare the move as valid (0 reasons for it to be invalid)
     * 
     */
    void setToValid()
    {
	reasons_invalid=0;
    }

    // Use this function to directly set the number of reasons for the move to
    // be invalid to 1.
    /** 
     * Set the move to be "nearly valid" ie only one reason for it to be
     * invalid.
     * 
     */
    void setToNearlyValid()
    {
	reasons_invalid=1;
    }

    /** 
     * This is probably the only function you should need to use directly. This
     * increment the number of cutoff the move generated at the depth you
     * give. This number is then used e.g by PositionData::getSortedList to sort
     * the moves using the killer heuristic.
     * 
     * @param depth The depth at which the move generated a cutoff.
     */
    void generatedACutoff(int depth)
    {
	adaptive_eval[depth]++;
    }
};
    
#endif
