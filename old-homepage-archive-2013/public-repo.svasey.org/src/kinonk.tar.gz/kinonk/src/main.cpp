// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   main.cpp
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Mon Sep 17 17:43:15 2007
 * 
 * @brief 
 * Contains the main function, and some of the function it itself uses.
 * 
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#include <vector>
using std::vector;

#include <string>
using std::string;

#include <ctime>
#include <iostream>
#include <sstream>
#include <limits>
using std::cout;
using std::cerr;
using std::endl;
using std::cin;
#include <fstream>

#include "user.h"
#include "global.h"
#include "stats.h"
#include "PositionData.h"

namespace Stats{
    extern int return_status;

    extern int size_matrix;
    extern unsigned long long *analyzed_before_cutoff[12];
    extern unsigned long long *number_candidates[13];
    extern unsigned long long shape_cutoff[12][12];

    extern double total_time;
};
/** 
 * This function writes the collected statistics to an output file (if
 * applicable and exit kinonk.
 * 
 * @param ret 
 * The value kinonk will return upon exit. Should be 0 if everything went fine,
 * and another value otherwise.
 */
void exitKinonk(int ret)
{
    Stats::return_status=ret;

    if (STATS_FILE!="")
	outputStats(STATS_FILE);
    for (int i=0;i<12;i++){
	delete[] Stats::analyzed_before_cutoff[i];	
	delete[] Stats::number_candidates[i];
    }
    delete[] Stats::number_candidates[12];

    exit(ret);
}

int main(int argc,char* argv[])
{
    processOptions(argc,argv);
 
    // Disable debugging output if we are in ENGINE mode.
    if (ENGINE){
	message.seekp(std::ios_base::end);
    }

    message << "Board size: " << SIZE << endl;
    message << "Katamino rules: " << (KATAMINO_RULES ? "yes" : "no") << endl;

    for (int i=0;i<12;i++){
	if (EXCLUDE_PENTO[i]){
	    message << "The " << PENTO_ID_LETTER[i]
		    << " pentomino will be excluded from the game" << endl;
	}
    }    

    message << "Time limit: ";
    if (NO_TIME_LIMIT)
	message << "none";
    else
	message << PLAY_TIME << " seconds per move";
    message << endl;
    message << "Action: ";
    if (ONE_FIRST_MOVE)
	message << "Solve (find one winning move)";
    else if (ALL_FIRST_MOVES)
	message << "Solve (find all winning moves)";
    else if (NHUMANS == 1)
	if (COMPTURN == 1)
	    message << "Play (Machine vs Man)";
	else
	    message << "Play (Man vs Machine)";
    else
	message << "Play (Machine vs Machine)";
    message << endl;
    if (OPTIMIZED_SOLVING){
	message << "An optimized version of the solving function will be used"
		<< endl;
    }
    if (STATS_FILE != "")
	message << "Statistics file: " << STATS_FILE << endl;

    message << "Killer heuristic: "
	    << (Algo::USE_KILLERS ? "on" : "off");
    if (Algo::USE_KILLERS)
	message << " (" << Algo::N_KILLERS << " moves kept)" << endl;
    else
	message << endl;

    bool wr=false;
    bool improved_wr=false;
    
    message << "Method used to sort the moves: " << endl;
    for (int i=0;i<12;i++){
	message << "\t";
	switch (Algo::DEPTH_METHOD[i]){
	case Algo::NONE:
	    message << "As the moves come (";break;
	case Algo::RANDOM:
	    message << "Random (";break;
	case Algo::NCAND:
	    message << "Ascending number of replies (";break;
	case Algo::RNCAND:
	    message << "Descending number of replies (";break;
	case Algo::WINSRATIO:
	    wr=true;
	    message << "Wins ratio (";break;
	case Algo::IMPROVED_WINSRATIO:
	    improved_wr=true;
	    message << "Improved wins ratio (";break;
	}
	message << "depth " << i;
	
	int j=i+1;
	for (;j<12;j++){
	    
	    if (Algo::DEPTH_METHOD[i] != Algo::DEPTH_METHOD[j] || (j == 11)){
		if (j-1 == i){
		    message << ")";
		    break;
		}
		message << "-" << j << ")";
		break;
	    }
	}


	i=j-1;
	message << endl;
	if (j == 11)
	    break;
    }

    if (wr){
	message << "Method used to sort the moves when trying to find" \
	    " the wins ratio: ";
	switch (Algo::WINSRATIO_SORTING_METHOD){
	case Algo::NONE:
	    message << "As the moves come";break;
	case Algo::RANDOM:
	    message << "Random";break;
	case Algo::NCAND:
	    message << "Ascending number of candidates";break;
	case Algo::RNCAND:
	    message << "Descending number of candidates";break;
	case Algo::WINSRATIO:
	    cerr << "ERROR: You cannot specify wins ratio as a sorting method" \
	    " for the wins ratio, as it will recurse for ever...";return 1;
	case Algo::IMPROVED_WINSRATIO:
	    message << "Improved wins ratio";break;
	}
	message << endl;
	message << "Number of moves tested for each relative depth: ";
	for (int i=0;i<12;i++)
	    message << Algo::WINSRATIO_NMOVES[i] << " ";
	message << endl;
    }

    if (improved_wr){
	message << "Number of moves the program plays randomly before solving" \
	    " the position: " << Algo::IMPROVED_WINSRATIO_NRANDOM << endl;
	message << "Number of games the program plays for each candidates: "
		<< Algo::IMPROVED_WINSRATIO_NGAMES << endl;
    }
    
    if (MAX_DEPTH_DEBUG < 0)
	message << "No information will be displayed during the search";
    else	    
	message << "Max depth at which information on the search will be" \
	    " displayed: " << MAX_DEPTH_DEBUG;
    message << endl;

    message << endl;
        
    // Let the fun begin !
    PositionData game;

    // intitialize the Stats matrixes
    for (int i=0;i<12;i++){
	// Stats::number_candidates needs Stats::size_matrix elements, since
	// the possible values are [0;maxncand]. analyzed_before_cutoff does
	// not need the last element.
	Stats::analyzed_before_cutoff[i] = 
	    new unsigned long long[Stats::size_matrix-1];
	Stats::number_candidates[i] = 
	    new unsigned long long[Stats::size_matrix];
	for (int j=0;j<Stats::size_matrix;j++) {
	    if (j!=Stats::size_matrix-1)
		Stats::analyzed_before_cutoff[i][j]=0;
	    Stats::number_candidates[i][j]=0;
	}
	for (int j=0;j<12;j++)
	    Stats::shape_cutoff[i][j]=0;
    }
    // This is quirky: we need the number_candidates[12][0] element to exist, in
    // case all pentominoes are played, and PositionData::solve want to
    // increment it...
    Stats::number_candidates[12]=new unsigned long long[1];
    
    // Check the settings
    if (game.badSettings())
    	std::cerr << "Warning: board size too large or number of pentominoes" \
	    " too low" << std::endl;
    
    message << game.getBoard();
    message << "candidates: " << game.getNCand() << endl;

    // Whether the computer plays in first and second position
    bool comp_plays[2]={false,false};
    if (!ONE_FIRST_MOVE && !ALL_FIRST_MOVES && NHUMANS == 1)
	comp_plays[COMPTURN-1]=true;
    else
	comp_plays[0]=comp_plays[1]=true;

    bool first_compmove=true;
    bool keep_stats=((STATS_FILE == "") ? false : true);
    while (game.getNCand()){
	// The number of the player to play
	const int TO_PLAY=(game.firstPlayerMove() ? 1 : 2);
	if (comp_plays[TO_PLAY-1]){
	    if (!first_compmove && NO_TIME_LIMIT){
		MAX_DEPTH_DEBUG=-1;
	    }
	    first_compmove=false;

	    vector<Move> best_moves;
	    time_t start;
	    time(&start);

	    message << "The computer (player " << TO_PLAY << ") is working..."
		    << endl;
	    PositionData::Result result;
	    result=game.solve(best_moves,ALL_FIRST_MOVES,true,keep_stats);
	    keep_stats=false;
	    message << "Evaluation: ";
	    if (result == PositionData::TOMOVE_WINS)
		message << "the player to move (player " << TO_PLAY << ") wins"
			<< endl;
	    else if (result == PositionData::TOMOVE_LOSES)
		message << "the player to move (player " << TO_PLAY << ") loses"
			<< endl;
	    else
		message << "aborted because of time constraint" << endl;

	    if (ALL_FIRST_MOVES){
		if (result == PositionData::TOMOVE_LOSES)
		    message << "No winning moves found" << endl;
		else {
		    message << "There "
			    << (best_moves.size() > 1 ? "are" : "is")
			    << " " << best_moves.size() << " winning move"
			    << (best_moves.size() > 1 ? "s" : "") << endl;

		    for (int i=0;i<static_cast<int>(best_moves.size());i++){
			game.playMove(best_moves[i]);
			message << best_moves[i] << endl;
			message << game.getBoard() << endl;
			game.playLastMoveBack();
		    }
		}
	    }
	    else if (ONE_FIRST_MOVE && result == PositionData::TOMOVE_LOSES)
		message << "No winning moves found" << endl;
	    else {
		message << "best move: ";
		// It is necessary to use cout here, as the engine will need to
		// know the computer's move.
		std::cout << best_moves.back() << endl;
		game.playMove(best_moves.back());
		message << game.getBoard();
		if (!ONE_FIRST_MOVE)
		    message << "candidates: " << game.getNCand() << endl;
	    }
	    
	    time_t end;
	    time(&end);
	    Stats::total_time+=difftime(end,start);
	    message << "time: " << difftime(end,start) << " [s]" << endl;

	    if (ONE_FIRST_MOVE || ALL_FIRST_MOVES)
		break;
	}
	// A human plays
	else {
	    message << "It is your go, player " << TO_PLAY << " !" << endl;

	get_input: // gotos lead here if input hasn't been a move
	    bool check_input=false;

	    string input_string;
	    message << std::endl << "Enter a command (type 'h' for help):"
		    << std::endl << ">> ";
	    	   
	    // Redirects here in case 'p' is the first char in input_string
	move_input: 	
	    std::getline(cin,input_string);
	    char input=input_string[0];

	    if (input_string == "I am the architect."){
		message << std::endl << "Oh, you are obviously stronger than" \
		    " any AI. I resign." << std::endl;
		exitKinonk(1337);
	    }

	    // The move that will be played
	    Move current;

	    int n=atoi(input_string.c_str());
	    // If the first character is an integer, we assume the user is
	    // trying to input a move directly.
	    if ((n == 0 && input_string[0] == '0') || n != 0){
		std::istringstream input_stream(input_string);
		input_stream >> current;
		check_input=true;
	    }

	    vector<Move> win_moves; // in case 'c'

	    bool out=false;		
	    
	    if (!check_input){
		switch(input){
	        case 'p':
		    message << "Enter a move (5 coordinates):" << std::endl
			    << ">> ";
		    goto move_input;
		    break;

		case 'c':
		    time_t start;
		    time(&start);
		    game.solve(win_moves,false,true,keep_stats);
		    time_t end;
		    time(&end);
		    Stats::total_time+=difftime(end,start);
		    message << "time: " << difftime(end,start) << " [s]"
			    << endl;
		    keep_stats=false;

		    message << "best move: " << win_moves.back() << endl;
		    current=win_moves.back();
		    break;
		case 'r':
		    current=game.getRandomMove();
		    break;
		case 'u':
		    if (game.getPlayingOrder().size()>1){
			    game.playLastMoveBack();
			    game.playLastMoveBack();

			    message << endl << game.getBoard();
		    }
		    else message << "No move to be undone." << std::endl;
		    
		    goto get_input; 
		    break;
		case 'a':
		    message << std::endl << "You resigned.";
		    out=true;
		    break;
		case 'h':
		    message << std::endl;
		    message << "Enter directly a move using its " \
			"coordinates. (Same as 'p')" << std::endl;
		    message << "Type 'p' and input the 5 coordinates of the" \
			" pentomino you want to play." << std::endl;
		    message << "Type 'c' to make the computer play for you."
			    << std::endl;
		    message << "Type 'r' to play a random move." << std::endl;
		    message << "Type 'u' to undo your last move." << std::endl;
		    message << "Type 'a' to resign and quit the game."
			    << std::endl; 
		    message << "Type 'h' to display this help.";
		    message << std::endl;
		    goto get_input;

		    break;
		default:
		    std::cerr << "Wrong input. ";
		    if(ENGINE){
			cerr << endl;
			exitKinonk(1);
		    }
		    else {
			cerr << "Type 'h' for more information." << endl;
		    }
		    goto get_input;
		}
	    }
	    if (out)
		break;
	    
	    if (game.findMove(current)){
		message << current << endl;
		game.playMove(current);
		message << game.getBoard();
		message << "Candidates: " << game.getNCand() << endl;
	    }
	    else{
		cerr << "This move is either invalid or inexistant" << endl;
		if(ENGINE)
		    exitKinonk(1);
		goto get_input;
	    }
	} // End else
    } // End while(getNCand())
    if (!ALL_FIRST_MOVES && !ONE_FIRST_MOVE){
	message << std::endl;
	if (game.firstPlayerMove())
	    message << "Player 2 won !" << std::endl;
	else
	    message << "Player 1 won !" << std::endl;
    }
    
    exitKinonk(0);
}
