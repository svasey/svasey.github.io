// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   global.h
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Wed Sep 19 22:15:55 2007
 * 
 * @brief  Contains the definition of most global variables that e.g
 * %PositionData uses.
 * 
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#ifndef INCLUDE_GLOBAL
#define INCLUDE_GLOBAL

// Define all global variables and their default value

#include "Coor.h"
#include "PositionData.h"
#include "stats.h"

#include <vector>
using std::vector;

#include <string>
#include <iostream>

using std::string;

/**
 * Output debugging message. Its state will be set to eofbit if #ENGINE is true.
 * 
 */

std::ostream message(std::cout.rdbuf());

/**
 * A table matching each pentomino id with its respective letter.
 * 
 */

char PENTO_ID_LETTER[12]={'I','L','Y','N','V','P','U','Z','F','T','W','X'};

/**
 * The maximum number of players allowed to play at the same time.
 * 
 */
int MAX_NPLAYERS=2;

/**
 * If set to true, output only errors. Useful if kinonk is called from another
 * program, e.g a GUI
 * 
 */
bool ENGINE=false;

/**
 * Give the maximum depth at which the program will display any information on
 * what it is doing. Smaller than 0 if no information are wanted.
 */
int MAX_DEPTH_DEBUG=-1;

/**
 * If set to true, play with the rules of Katamino, see the man page or the
 * report for more information.
 */
bool KATAMINO_RULES=false;

/**
 * If set to true, the program will try to find one winning move, output it and
 * then exit.
 */
bool ONE_FIRST_MOVE=false;

/**
 * If set to true, the program will try to find and output *all* the winning
 * moves, output them and then exit.
 */
bool ALL_FIRST_MOVES=false;

/**
 * If set to true, special solve functions will be used (namely
 * PositionData::lightSolvePento and PositionData::lightSolveKatamino . This is
 * set to true by the program if some default values are used (e.g the sorting
 * method is Algo::DEFAULT_SORTING_METHOD at all depths), and no time limit is
 * given. 
 * 
 */
bool OPTIMIZED_SOLVING=false;

/**
 * File where stats are outputted. No stats if "".
 */
string STATS_FILE="";

/** 
 * File that will be parsed in order to get the customized #Algo variables.
 */
string ALGO_FILE="";

/**
 * Give the number of humans going to play the game.
 */
int NHUMANS=1;

/**
 * The place in which the computer will play. If 1, it will play first, if 2
 * second.
 */
int COMPTURN=2;

/** 
 * The default board's size.
 */
Coor SIZE(8,8);

/**
 * if EXCLUDE_PENTO[i] is true then the pentomino whose id is i cannot be used
 * during the game.
 */
bool EXCLUDE_PENTO[12]={false,false,false,false
 			,false,false,false,false
 			,false,false,false,false};

/**
 * The number of random games the function for checking the user settings
 * (PositionData::badSettings) will play.
 */
int N_CHECK_RANDOM_GAMES=100;

/*
 * If set to true, the program won't be restricted by any time limit.
 */
bool NO_TIME_LIMIT=false;

/* 
 * The maximum number of seconds the program can use before playing a move.
 */
int PLAY_TIME=60;

/*
 * The start of the program's thinking time. Usually initialized by
 * PositionData::solve 
 */
time_t _clock_start=0;


/*
 * contains variables related to the search algorithm performances. They can all
 * be changed from an external configuration file and are extensively documented
 * in the man page.
 */
namespace Algo {

    // Constant mapping to the different method the program uses to sort the
    // moves.

    // No method: the program just takes the moves as they come    
    /**
     * See PositionData::Method for the meaning of those values.
     * 
     */
    const int NONE=0;

    // The program randomly shuffles the moves
    const int RANDOM=1;

    // The program collects the number of possible moves the opponent has after
    // the candidate is played. It then sorts the candidates from the lowest
    // number of replies to the highest.
    const int NCAND=2;

    // The program plays each candidate, then tries only a small number of moves
    // at each level and divide the number of wins by the number of defeats. The
    // candidates are sorted from the highest ratio to the lowest.
    const int WINSRATIO=3;

    // The program plays each candidate, then plays n random moves before
    // solving the position completely. Repeat the process m times.
    const int IMPROVED_WINSRATIO=4;

    // Same as NCAND but in reversed order
    const int RNCAND=5;

    //! The maximum possible wins ratio (this is just to be changed if you want
    //! more (or less) precision
    int WINSRATIO_MAX=1000;

    /**
     * The default for #USE_KILLERS , used in the optimized versions of
     * PositionData::solve , namely PositionData::lightSolvePento and
     * PositionData::lightSolveKatamino . (see #OPTIMIZED_SOLVING)
     * 
     */

    extern const bool DEFAULT_USE_KILLERS=true;
    //! Whether the killer heuristic is used or not
    bool USE_KILLERS=DEFAULT_USE_KILLERS;

    /**
     * The default for the #N_KILLERS variable, used in the optimized versions
     * of PositionData::solve , namely PositionData::lightSolvePento and
     * PositionData::lightSolveKatamino . (see #OPTIMIZED_SOLVING)
     * 
     */

    extern const int DEFAULT_N_KILLERS=2;
    //! The number of killers that are put ahead of the other moves for each
    //! sorting
    int N_KILLERS=DEFAULT_N_KILLERS;

    //! The method used by the PositionData::findWinsRatio function to sort the
    //! move
    int WINSRATIO_SORTING_METHOD=RANDOM;

    //! Using the improved wins ratio method, The number of moves the program
    //! must play randomly before solving the position.
    int IMPROVED_WINSRATIO_NRANDOM=2;

    //! Using the improved wins ratio method, the number of games the program
    //! must play for each candidates.
    int IMPROVED_WINSRATIO_NGAMES=5;
            
    //! The number of moves that are tested at each 'relative' depth
    //! when partially solving the board (with the wins ratio method)
    int WINSRATIO_NMOVES[12]={10,5,5,5,2,2,2,2,2,2,2,2};

    /**
     * The default sorting method, used at each depth by default.
     * 
     */

    extern const int DEFAULT_SORTING_METHOD=NCAND;
    //! The method used at each depth to sort the moves
    int DEPTH_METHOD[12]={DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
			  ,DEFAULT_SORTING_METHOD
    };
}

#endif
