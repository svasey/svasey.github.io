/* 
   PositionData-light.cpp -- Contains the implementation of some similar
   function to PositionData::solve PositionData::getNReplies
   PositionData::getSortedList but that supports less options and hence faster.

   Copyright (c) 2007 Sebastien Vasey
   Copyright (c) 2007 Yann Schoenenberger
*/
/**
 * @file   PositionData-light.cpp
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Wed Sep 19 22:11:17 2007
 * 
 * @brief Contains all the "optimized" versions of PositionData::playMove ,
 * PositionData::playLastMoveBack , PositionData::solve and
 * PositionData::getNRepliesToMove
 * 
 * 
 */


/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "PositionData.h"
#include "Move.h"

#include <algorithm>

extern std::ostream message;
namespace Stats {
    extern unsigned long long *analyzed_before_cutoff[12];
    extern unsigned long long *number_candidates[13];
    extern unsigned long long shape_cutoff[12][12];
};

void PositionData::lightGetSortedListPento(vector<MetaMove*>& move_list)
{
    const int DEPTH=playing_order.size();
    const int NKILLERS=2;

    move_list.reserve(getNCand());

    // Add all the moves to move_list
    MetaMove* m=all_moves[0].isValid() ? &all_moves[0] :all_moves[0].next_valid;
    do {
	move_list.push_back(m);
	m=m->next_valid;
    } while (m != NULL);
    

    const vector<MetaMove*>::iterator END=move_list.end();
    for (vector<MetaMove*>::iterator it=move_list.begin();it!=END;++it){
	int n=getNRepliesToMovePento(**it);
	if (n == 0){
	    
	    std::swap(*it,*(move_list.begin()));
	    return;
	}
	(*it)->setNCandEvaluation(n);
    } // End of for each move

    // Sort the move list using the "static" (number of replies, wins ratio...)
    // evaluation.
    CmpMetaMovePtr cmp_nokil(DEPTH,false);

    // Sort the move list using the "adaptive" (killers) evaluation
    CmpMetaMovePtr cmp_kil(DEPTH,true);

    if (static_cast<int>(move_list.size()) < NKILLERS)
	return;

    // First put the killers on top of the list (the killers are those with the
    // greatest adaptive evaluation
    std::partial_sort(move_list.begin(),move_list.begin()+NKILLERS
		      ,move_list.end(),cmp_kil);

    // If the size of the move list was greater than the number of killers, go
    // on sorting the rest with their static evaluation.
    std::stable_sort(move_list.begin()+NKILLERS,move_list.end(),cmp_nokil);
//     int n=std::min(static_cast<int>(move_list.size()),NKILLERS);
//     std::partial_sort(move_list.begin(),move_list.begin()+n,move_list.end()
// 		      ,cmp_kil);
//     if (n < static_cast<int>(move_list.size()))
// 	std::stable_sort(move_list.begin()+n,move_list.end(),cmp_nokil);
}

void PositionData::lightGetSortedListKatamino(vector<MetaMove*>& move_list)
{
    const int DEPTH=playing_order.size();
    const int NKILLERS=2;

    move_list.reserve(getNCand());

    // Add all the moves to move_list
    MetaMove* m=all_moves[0].isValid() ? &all_moves[0] :all_moves[0].next_valid;
    do {
	move_list.push_back(m);
	m=m->next_valid;
    } while (m != NULL);
    

    const vector<MetaMove*>::iterator END=move_list.end();
    for (vector<MetaMove*>::iterator it=move_list.begin();it!=END;++it){
	int n=getNRepliesToMoveKatamino(**it);
	if (n == 0){
	    
	    std::swap(*it,*(move_list.begin()));
	    return;
	}
	(*it)->setNCandEvaluation(n);
    } // End of for each move

    // Sort the move list using the "static" (number of replies, wins ratio...)
    // evaluation.
    CmpMetaMovePtr cmp_nokil(DEPTH,false);

    // Sort the move list using the "adaptive" (killers) evaluation
    CmpMetaMovePtr cmp_kil(DEPTH,true);

    if (static_cast<int>(move_list.size()) < NKILLERS)
	return;

    // First put the killers on top of the list (the killers are those with the
    // greatest adaptive evaluation
    std::partial_sort(move_list.begin(),move_list.begin()+NKILLERS
		      ,move_list.end(),cmp_kil);

    // If the size of the move list was greater than the number of killers, go
    // on sorting the rest with their static evaluation.
    std::stable_sort(move_list.begin()+NKILLERS,move_list.end(),cmp_nokil);
}

int PositionData::getNRepliesToMovePento(const Move& M)
{
    // Moves Which would be invalidated if M is played
    vector<MetaMove*> would_invalid;
    const int NCAND=getNCand();

    // Reserve the maximum possible size (tests have proven this to be slightly
    // faster)
    would_invalid.reserve(NCAND);
    
    // Moves overstepping the played one
    for (int i=0;i<5;i++){
	const int POS_INT=(M.pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    if ((*it)->isValid()){
		would_invalid.push_back(*it);
		(*it)->setToNearlyValid();
	    }
	}
    }
    
    // Moves with the same pentomino id
    const int ID=M.pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[ID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[ID].begin()
	     ;it!=END;++it){	
	if ((*it)->isValid()){
	    would_invalid.push_back(*it);
	    (*it)->setToNearlyValid();
	}
    }

    // Re-valid all moves that have been invalidated
    const vector<MetaMove*>::iterator WI_END=would_invalid.end();
    for (vector<MetaMove*>::iterator it=would_invalid.begin();it!=WI_END;++it){
	(*it)->setToValid();
    }

    return NCAND-(would_invalid.size());
}

int PositionData::getNRepliesToMoveKatamino(const Move& M)
{
    // Moves which would be validated if M is played
    vector<MetaMove*> would_valid;
    const int NCAND=getNCand();
    // Tests have proven this to be slightly faster than not using it
    would_valid.reserve(NCAND);

    const int ADJ_SIZE=M.adj.size();
    for (int i=0;i<ADJ_SIZE;i++){
	const int POS_INT=(M.adj[i]).getInt(board.SIZE);
	const vector<MetaMove*>::iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    
	    if (((*it)->getNAdjacents() == 0) && ((*it)->isNearlyValid())){
		(*it)->setToValid();
		would_valid.push_back(*it);
	    }
	}
    }
    
    // Moves Which would be invalidated if M is played
    vector<MetaMove*> would_invalid;

    // Reserve the maximum possible size (tests have proven this to be slightly
    // faster)
    would_invalid.reserve(NCAND);
    
    // Moves overstepping the played one
    for (int i=0;i<5;i++){
	const int POS_INT=(M.pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    if ((*it)->isValid()){
		would_invalid.push_back(*it);
		(*it)->setToNearlyValid();
	    }
	}
    }
    
    // Moves with the same pentomino id
    const int ID=M.pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[ID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[ID].begin()
	     ;it!=END;++it){	
	if ((*it)->isValid()){
	    would_invalid.push_back(*it);
	    (*it)->setToNearlyValid();
	}
    }

    // Re-valid all moves that have been invalidated
    const vector<MetaMove*>::iterator WI_END=would_invalid.end();
    for (vector<MetaMove*>::iterator it=would_invalid.begin();it!=WI_END;++it){
	(*it)->setToValid();
    }

    // reswitch the reasons_invalid
    const vector<MetaMove*>::iterator WV_END=would_valid.end();
    for (vector<MetaMove*>::iterator it=would_valid.begin()
	     ;it!=WV_END;++it){
	(*it)->setToNearlyValid();
    }

    return NCAND+(would_valid.size())-(would_invalid.size());
}

void PositionData::playMoveKatamino(const Move& MOVE)
{
    board.playMove(MOVE);	// Physically play the move on the board

    // Get the played move id and register it as played
    MetaMove* m=getAllMovesPos(MOVE);
            
    playing_order.push_back(m);
    
    // Invalidate all moves overstepping the new pentomino
    for (int i=0;i<5;i++){
	const int POS_INT=(m->pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    
	    addReasonToInvalid(*it);
	}
    }

    // Invalidate all moves with the same pentomino id
    const int PID=MOVE.pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[PID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[PID].begin()
	     ;it!=END;++it){
	addReasonToInvalid(*it);
    }
    
    // Update all moves adjacent to the new pentomino (code specific to katamino
    // rules)
    const int ADJ_SIZE=MOVE.adj.size();
    for (int i=0;i<ADJ_SIZE;i++){
	const int POS_INT=(MOVE.adj[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END
	    =square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT]
		 .begin();it!=END;++it){
	    addAdjacent(*it);
	}
    }   
}

void PositionData::playMovePento(const Move& MOVE)
{
    board.playMove(MOVE);	// Physically play the move on the board

    // Get the played move id and register it as played
    MetaMove* m=getAllMovesPos(MOVE);
            
    playing_order.push_back(m);
    
    // Invalidate all moves overstepping the new pentomino
    for (int i=0;i<5;i++){
	const int POS_INT=(m->pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    
	    addReasonToInvalid(*it);
	}
    }

    // Invalidate all moves with the same pentomino id
    const int PID=MOVE.pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[PID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[PID].begin()
	     ;it!=END;++it){
	addReasonToInvalid(*it);
    }
}


void PositionData::playLastMoveBackPento()
{
    MetaMove* m=playing_order.back(); // Get the last played moves
                
    board.playMoveBack(*m);	// Physically play the move back

    // Erase from the lists of played moves
    playing_order.pop_back();
        
    // Decrement the invalidity of the moves that overstepped the pentomino

    for (int i=0;i<5;i++){
	const int POS_INT=(m->pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    // No move can be valid at that point, since it overstepped
	    // previously-played pentomino (and it overstepped itself...). Since
	    // the square_index does not change after initialization, we can be
	    // sure the move had been invalidated the same number of times as it
	    // is validated now, and hence is never valid before being
	    // validated...
	    addReasonToValid(*it);
	}
    }

    // Decrement the invalidity of the moves with the same pentomino id
    const int PID=m->pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[PID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[PID].begin()
	     ;it!=END;++it){
	// See the previous long comment for reasons why the move is _never_
	// valid before being validated.
	addReasonToValid(*it);
    }
}


void PositionData::playLastMoveBackKatamino()
{
    MetaMove* m=playing_order.back(); // Get the last played moves
                
    board.playMoveBack(*m);	// Physically play the move back

    // Erase from the lists of played moves
    playing_order.pop_back();
        
    // Decrement the invalidity of the moves that overstepped the pentomino

    for (int i=0;i<5;i++){
	const int POS_INT=(m->pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    // No move can be valid at that point, since it overstepped
	    // previously-played pentomino (and it overstepped itself...). Since
	    // the square_index does not change after initialization, we can be
	    // sure the move had been invalidated the same number of times as it
	    // is validated now, and hence is never valid before being
	    // validated...
	    addReasonToValid(*it);
	}
    }

    // Decrement the invalidity of the moves with the same pentomino id
    const int PID=m->pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[PID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[PID].begin()
	     ;it!=END;++it){
	// See the previous long comment for reasons why the move is _never_
	// valid before being validated.
	addReasonToValid(*it);
    }

    // Update all moves adjacent to the removed pentomino
    const int ADJ_SIZE=(*m).adj.size();
    for (int i=0;i<ADJ_SIZE;i++){
	const int POS_INT=((*m).adj[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END
	    =square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator 
		 it=square_index[POS_INT].begin();
	     it!=END;++it){
	    
	    removeAdjacent(*it);
	}
    }
}

PositionData::Result PositionData::lightSolvePento()
{
    const int ABSOLUTE_DEPTH=playing_order.size();
    if (!getNCand()){
	Stats::number_candidates[ABSOLUTE_DEPTH][0]++;
	return TOMOVE_LOSES;
    }

    vector<MetaMove*> move_list;
    
    lightGetSortedListPento(move_list);

    const int MOVE_LIST_SIZE=move_list.size();

    // It is more precise to use the list of moves to analyze's size instead of
    // the number of candidates. It takes into account symmetries and other
    // equivalent moves at absolute depth 0...
    Stats::number_candidates[ABSOLUTE_DEPTH][MOVE_LIST_SIZE]++;

    // Play each move and evaluate its result
    for (int i=0;i<MOVE_LIST_SIZE;i++){
 	playMovePento(*move_list[i]);

	Result result=UNKNOWN;

	// The result will be the opposite of what has been returned, since we
	// are interested in the other side.
	result=(lightSolvePento()==TOMOVE_LOSES) ? TOMOVE_WINS:TOMOVE_LOSES;

 	playLastMoveBackPento();
	
	if (result == TOMOVE_WINS){
	    Stats::shape_cutoff[ABSOLUTE_DEPTH][(*move_list[i]).pento_id]++;
	    Stats::analyzed_before_cutoff[ABSOLUTE_DEPTH][i]++;
	    move_list[i]->generatedACutoff(ABSOLUTE_DEPTH);
	    return TOMOVE_WINS;
	}
    }
    return TOMOVE_LOSES;
}

PositionData::Result PositionData::lightSolveKatamino()
{
    const int ABSOLUTE_DEPTH=playing_order.size();
    if (!getNCand()){
	Stats::number_candidates[ABSOLUTE_DEPTH][0]++;
	return TOMOVE_LOSES;
    }


    vector<MetaMove*> move_list;
    
    lightGetSortedListKatamino(move_list);

    const int MOVE_LIST_SIZE=move_list.size();

    // It is more precise to use the list of moves to analyze's size instead of
    // the number of candidates. It takes into account symmetries and other
    // equivalent moves at absolute depth 0...
    Stats::number_candidates[ABSOLUTE_DEPTH][MOVE_LIST_SIZE]++;

    // Play each move and evaluate its result
    for (int i=0;i<MOVE_LIST_SIZE;i++){
	playMoveKatamino(*move_list[i]);

	Result result=UNKNOWN;

	// The result will be the opposite of what has been returned, since we
	// are interested in the other side.
	result=(lightSolveKatamino()==TOMOVE_LOSES) ? TOMOVE_WINS:TOMOVE_LOSES;

	playLastMoveBackKatamino();
	
	if (result == TOMOVE_WINS){
	    Stats::shape_cutoff[ABSOLUTE_DEPTH][(*move_list[i]).pento_id]++;
	    Stats::analyzed_before_cutoff[ABSOLUTE_DEPTH][i]++;
	    move_list[i]->generatedACutoff(ABSOLUTE_DEPTH);
	    return TOMOVE_WINS;
	}
    }
    return TOMOVE_LOSES;
}
