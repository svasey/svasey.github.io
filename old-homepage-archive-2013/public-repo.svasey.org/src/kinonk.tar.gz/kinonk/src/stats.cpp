// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include <string>
#include <fstream>
#include <iostream>
#include <cmath>

#include "Coor.h"

using namespace std;

extern bool ONE_FIRST_MOVE;
extern bool ALL_FIRST_MOVES;
extern bool KATAMINO_RULES;
extern int PLAY_TIME;
extern Coor SIZE;
extern int NHUMANS;
extern int COMPTURN;
extern bool NO_TIME_LIMIT;
extern bool EXCLUDE_PENTO[12];

namespace Algo
{
    extern const int NONE;
    extern const int RANDOM;
    extern const int NCAND;
    extern const int WINSRATIO;
    extern const int IMPROVED_WINSRATIO;
    extern const int RNCAND;
    extern int WINSRATIO_MAX;
    extern bool USE_KILLERS;
    extern int N_KILLERS;
    extern int WINSRATIO_SORTING_METHOD;
    extern int IMPROVED_WINSRATIO_NRANDOM;
    extern int IMPROVED_WINSRATIO_NGAMES;
    extern int WINSRATIO_NMOVES[12];
    extern int DEPTH_METHOD[12];
    extern int WINSRATIO_NMOVES[12];
    extern int IMPROVED_WINSRATIO_NRANDOM;
    extern int IMPROVED_WINSRATIO_NGAMES;
}

namespace Stats {
    extern int return_status;
    extern int size_matrix;
    extern unsigned long long *analyzed_before_cutoff[12];
    extern unsigned long long *number_candidates[13];
    extern unsigned long long shape_cutoff[12][12];
    
    extern double total_time;
};

void outputStats(string file_name)
{
    ofstream fout(file_name.c_str());
    if (!fout.good()){
	std::cerr << "Error opening file " << file_name << std::endl;
	std::cerr << "I could not write any statistics" << std::endl;
	return;
    }

    fout << "\"statsfile\":\"" << file_name << "\"," << std::endl;

    fout << "\"game_info\": {" << std::endl;
    
    fout << "\t\"return_stat\":" << Stats::return_status << ","<< std::endl;
    
    fout << "\t\"board\": [" << SIZE.x << "," << SIZE.y << "]," 
	 << std::endl;

    fout << "\t\"katamino\":\"" << (KATAMINO_RULES ? "true" : "false") 
	 << "\"," << std::endl;
 
    fout << "\t\"excluded\": [";
    for (int i=0;i<12;i++){
	if (i%4==0) fout << std::endl << "\t\t";
	if(EXCLUDE_PENTO[i])
	    fout << "true";
	else
	    fout << "false";
	if (i<11) fout << ",";
    }
    fout << std::endl << "\t]," << std::endl;

    fout << "\t\"time_limit\":";
    if (NO_TIME_LIMIT)
	fout << "-1";
    else
	fout << PLAY_TIME;   
    fout << "," << std::endl;

    fout << "\t\"action\":\"";
    if (ONE_FIRST_MOVE)
	fout << "one_win";
    else if (ALL_FIRST_MOVES)
	fout << "all_win";
    else if (NHUMANS == 1)
	if (COMPTURN == 1)
	    fout << "comp_human";
	else
	    fout << "human_comp";
    else
	fout << "comp_comp";
    fout << "\"," << std::endl;

    fout << "\t\"killeristics\":";
    if(Algo::USE_KILLERS)
	fout << Algo::N_KILLERS;
    else
	fout << "0";
    fout << "," << std::endl;
    
    fout << "\t\"method\": [";
    bool wr=false;
    for (int i=0;i<12;i++){
	if (i%4==0) fout << std::endl << "\t\t";

	fout << "\"";
	if(Algo::DEPTH_METHOD[i]==0) 
	    fout << "NONE";
	else if(Algo::DEPTH_METHOD[i]==1) 
	    fout << "RANDOM";
	else if(Algo::DEPTH_METHOD[i]==2) 
	    fout << "NCAND";
	else if(Algo::DEPTH_METHOD[i]==3){
	    wr=true;
	    fout << "WINSRATIO";
	}
	else if(Algo::DEPTH_METHOD[i]==4){
	    wr=true;
	    fout << "IMROVED_WINSRATIO";
	}
	else if(Algo::DEPTH_METHOD[i]==5) 
	    fout << "RNCAND";
	fout << "\"";
	
	if (i<11) fout << ",";
    }
    fout << std::endl << "\t]," << std::endl;

    if (wr){
	fout << "\t\"winsratio_nmoves\": [";
	for (int i=0;i<12;i++){
	    fout << Algo::WINSRATIO_NMOVES[i];
	    if (i<11) fout << ",";
	}
	fout << "]," << std::endl;
	
	fout << "\t\"iwr_nrand\":" << Algo::IMPROVED_WINSRATIO_NRANDOM << "," 
	     << std::endl;
	
	fout << "\t\"iwr_ngames\":" << Algo::IMPROVED_WINSRATIO_NGAMES << "," 
	     << std::endl;
    }
    
    fout << "\t\"total_time\":" << Stats::total_time << std::endl;
	
    fout << "}," << std::endl << std::endl;

        
    fout << "\"analyzed_before_cutoff\": {" << std::endl;
    for (int i=0;i<12;i++){
	fout << "\t\"depth_" << i << "\": [" << std::endl << "\t\t";
	for (int j=0;j<Stats::size_matrix-1;j++){
	    fout << Stats::analyzed_before_cutoff[i][j];
	    if (j<Stats::size_matrix-2) fout << ",";
	    if ((j+1)%30==0) fout << std::endl << "\t\t";
	}

	fout << std::endl << "\t]";	
	if (i<11) fout << ",";
	fout << std::endl;
    }
    fout << "}," << endl << endl;

    fout << "\"number_candidates\": {" << std::endl;
    for (int i=0;i<12;i++){
	fout << "\t\"depth_" << i << "\": [" << std::endl << "\t\t";
	for (int j=0;j<Stats::size_matrix;j++){
	    fout << Stats::number_candidates[i][j];
	    if (j<Stats::size_matrix-1) fout << ",";
	    if ((j+1)%30==0) fout << std::endl << "\t\t";
	}
	fout << std::endl << "\t]";	
	if (i<11) fout << ",";
	fout << std::endl;
    }
    fout << "}," << std::endl << std::endl;

    fout << "\"pento_cutoff\": {" << endl;
    for (int i=0;i<12;i++){
	fout << "\t\"depth_" << i << "\": [";
	for (int j=0;j<12;j++){
	    fout << Stats::shape_cutoff[i][j];
	    if (j<11) fout << ",";
	}
	fout << "]";
	if (i<11)
	    fout << ",";
	fout << endl;
    }
    fout << "}," << endl << endl;

    // Average of the number of candidates at each depth
    unsigned long long average_ncand[12]={0};
    // Number of analyzed positions at each depth
    unsigned long long analyzed_pos[12]={0};
    // The total of all analyzed positions at all depths
    unsigned long long total_analyzed=0;
    // The maximum number of positions the program could have had analyzed at
    // each depth
    unsigned long long max_pos[12]={0};
    // The minimum number of positions the program could have had analyzed
    unsigned long long min_leaf_pos=1;
    // The maximum number of positions the program would have had analyzed if
    // doing a full bruteforce.
    unsigned long long max_leaf_pos=1;
    // Number of positions (ie nodes) processed each second by the program
    unsigned long long time_pos_sec=0;

    analyzed_pos[0]=1;
    max_pos[0]=1;
    for (int i=0;i<12;i++){
	double sum=0;
	double n=0;
	for (int j=0;j<Stats::size_matrix;j++){
	    n+=Stats::number_candidates[i][j];
	    sum+=j*Stats::number_candidates[i][j];
	    if (i > 0){
		max_pos[i]+=j*Stats::number_candidates[i-1][j];
		// Everytime the program has incremented the number_candidates
		// variable at depth i, it means one position was analyzed at
		// depth i...
		analyzed_pos[i]+=Stats::number_candidates[i][j];
	    }
	}
	if (n == 0)
	    average_ncand[i]=0;
	else
	    average_ncand[i]=static_cast<unsigned long long>((sum/n)+0.5);
    }
    for (int i=0;i<12;i++){
	if (average_ncand[i] == 0)
	    break;
	max_leaf_pos*=average_ncand[i];
	min_leaf_pos*=(i%2 == 0) ? 1 : average_ncand[i];

	total_analyzed+=analyzed_pos[i];
    }

    time_pos_sec=static_cast<unsigned long long>
	(static_cast<double>(total_analyzed)/Stats::total_time +0.5);
   
    fout << "\"average_ncand\": [";
    for (int i=0;i<12;i++){
	fout << average_ncand[i];
	if (i<11) fout << ",";
    }
    fout << "]," << std::endl;

    fout << "\"analyzed_pos\": [";
    for (int i=0;i<12;i++){
	fout << analyzed_pos[i];
	if (i<11) fout << ",";
    }
    fout << "]," << std::endl;
    fout << "\"max_pos\": [";
    for (int i=0;i<12;i++){
	fout << max_pos[i];
	if (i<11)
	    fout << ",";
    }
    fout << "]," << std::endl;

    fout << "\"max_leaf_pos\":" << max_leaf_pos << "," << std::endl;
    fout << "\"total_analyzed_pos\":" << total_analyzed << "," << std::endl;
    fout << "\"min_leaf_pos\":" << min_leaf_pos << "," << std::endl;
    // Number of positions (nodes) processed each second
    fout << "\"time_pos_sec\":"
	 << static_cast<unsigned long long>(static_cast<double>(total_analyzed)
					    /static_cast<double>(Stats::total_time)+0.5) << std::endl;

    fout << std::endl;

    fout.close();
}
