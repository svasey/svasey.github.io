// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   Board.h
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Tue Sep 18 17:00:23 2007
 * 
 * @brief  
 * Contains the declaration of the board class, and all of its functions'
 * prototype
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#ifndef INCLUDE_BOARD
#define INCLUDE_BOARD

// Contains the board and its size: a dynamically allocated matrix of integers
// and a Coor object holding the size of the matrix.

#include "Coor.h"
#include "Move.h"

#include <iostream> // output stream operator
/**
 * This holds the katamino/pentomino board and its size. It actually is a
 * dynamically allocated matrix of integer.
 * 
 */

class Board {
private:
    /**
     * This is a dynamically allocated two-dimensionnal array. The first
     * dimension is the "x" position, while the second one is the "y" position. 
     * The integer value is the id of the pentomino, going from 0 to 11. An
     * empty square has a value of Board::EMPTY
     */

    int** board;

    

    enum {
	/**
	 * Defines the integer value corresponding to an empty square. All
	 * elements of Board::board are initialized to that value.
	 */
	EMPTY=-1
    };
 
    Board& operator=(const Board&);
    
    /** 
     * Get the id of the pentomino overstepping a given square
     * 
     * @param C 
     * The Coordinates of the square you want to look at. 
     * 
     * @return 
     * The id of the pentomino overstepping C
     *
     * @warning the function does not do any range checking. It assumes the x
     * and y positions of C are set between 0 and the size's maximum values.
     */
    int getPentoId(const Coor& C) const {return board[C.x][C.y];}

    /** 
     * This is an overloaded version of #getPentoId(const Coor &) const. It
     * takes and x and y position instead of a coordinates but does exactly the
     * same thing and has the same limitations.
     *
     */
    int getPentoId(int x,int y) const {return board[x][y];}        
public:
    /** 
     * Initialize a board object
     * @param SIZE
     * The size you want for your board object
     * 
     */
    Board(const Coor& SIZE);
    Board(const Board& BOARD);
    ~Board();

    /**
     * The size of the board
     * 
     */

    const Coor SIZE;

    // output stream operator (Board.cpp)
    friend std::ostream& operator <<(std::ostream&,const Board&);
        
    /** 
     * Play a move on the board. This can be undone with the #playMoveBack
     * function
     * 
     * @param M 
     * The move you want to play
     * @warning As usual, no range checking are made, meaning that you risk a
     * crash if M is out of the board's range.
     */
    void playMove(const Move& M);
    /** 
     * Undo the playing of a move and set back all its positions to #EMPTY
     * 
     * @param M 
     * The positions of the move you want to undo (play back)
     * @warning No range checking is made on M...
     */
    void playMoveBack(const Move& M);


    
};

#endif
