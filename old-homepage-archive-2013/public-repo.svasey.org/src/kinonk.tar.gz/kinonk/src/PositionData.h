// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   PositionData.h
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Wed Sep 19 20:16:16 2007
 * 
 * @brief  Contains the declaration of the PositionData class and some of its
 * "helper" classes and functions.
 * 
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#ifndef INCLUDE_POSITIONDATA
#define INCLUDE_POSITIONDATA

// contain all the data concerning the position: board, candidate moves, and
// all moves that have been played so far. Take care of sorting the moves, and
// correctly listing the candidates. Update the board when a move is played.

#include "Coor.h"
#include "Move.h"
#include "Board.h"

#include <vector>

using std::vector;

// Used in getSortedList
/**
 * This is used in PositionData::getSortedList . It is used as a functor to
 * compare MetaMove pointers
 * 
 */

class CmpMetaMovePtr
{
private:
    /**
     * The depth the moves you are comparing will be played. This is useful to
     * get the number of times they have already generated a cutoff at that
     * depth.
     * 
     */

    int _depth;
    /**
     * Say whether we will use the number of cutoffs (ie the "adaptative"
     * evaluation) to sort the move.
     * 
     */

    bool _n_cutoffs;
        
public:
    CmpMetaMovePtr(int depth,bool n_cutoffs):_depth(depth),_n_cutoffs(n_cutoffs)
    {}
    /** 
     * Compare two MetaMove pointers
     * 
     * 
     * @return True if *a is greater or equal than b, false otherwise.
     */
    bool operator() (MetaMove* a,MetaMove* b)
    {
	// Sort using the number of cutoffs
	if (_n_cutoffs)
	    return a->greater_equal_adaptive(b,_depth);
	return a->greater_equal(b);
    }
};

/**
 * This is the most used (and hacked ;-) ) kinonk class. It contains all
 * data related to the game, namely the board, the candidate moves, the moves
 * that have been played, the number of candidates... 
 * It handles the board's solving (ie it looks for the best move), the moves
 * sorting (before they are analyzed) and the playing of the moves. This class
 * also heavily depends on the global variables set in global.h
 * 
 */

class PositionData {
    // Dynamically allocated arry containing all the candidate moves, valid or
    // not. It is filled only once, in the constructor
    /**
     * This is a dynamically array, containing all the candidate moves you might
     * be able to play at some point in the game (valid or not). It is filled
     * only once in PositionData::PositionData . The %MetaMove objects it
     * contains are often pointed to by other members, especially the indexes
     * #square_index and #pento_index . Although the position of the MetaMove
     * objects in all_moves does not change, each MetaMove object has a
     * MetaMove::next_valid and MetaMove::previous_valid pointer, pointing to
     * the respectively next/previous valid element in all_moves . This way
     * #getSortedList can quickly see which moves are valid, without iterating
     * through the whole array. You are strongly encouraged to look up %MetaMove
     * as well if you want to mess with that member.
     */

    MetaMove* all_moves;

    /**
     * The number of valid candidate moves in the current position, taking into
     * account symmetries and other equivalent moves , so there is a high
     * probability for this number to be actually overestimated compared to the
     * maximum number of moves kinonk will look at.  It is mainly used by #solve
     * to check whether there are no candidates remaining
     * 
     */

    int n_cand;
            
    // all the pentomino overstepping a given square
    /**
     * This is a dynamically allocated array of vectors. Given some %Coor
     * integer value (use Coor::getInt) , the vector will contain all the moves
     * overstepping this square (actually it will contain pointers to the
     * #all_moves elements). For example square_index[0] will contain a vector
     * of MetaMove pointers to the moves overstepping the <0,0> square . This is
     * filled only once (in #PositionData) and does not change afterward.  This
     * is used by #playMove and #playLastMoveBack to quickly know which moves
     * become valid/invalid when a move is (un)played
     * 
     */

    vector<MetaMove*>* square_index; 

    // moves using a given pentomino, for each of the 12 pentomino ids
    /**
     * This works the same way as #square_index . Only, given a pentomino id
     * (Move::pento_id) , this will return you a vector of pointers to all
     * #all_moves elements which have this id (ie it will return you all
     * moves with the same pentomino shape).
     * 
     */

    vector<MetaMove*> pento_index[12]; 

    // the addresses of all the moves that have been played on the board, 
    // in the order in which they have been played. 
    // [0] is the first move that was played.
    /**
     * Points to all the moves that have been played on the board, in the order
     * in which they have been played (playing_order.front() ) being the first
     * played move.
     * 
     */

    vector<MetaMove*> playing_order;  


    // the grid on which the game is played
    /**
     * This is the grid on which the game is played
     * 
     */

    Board board;

    // Return true if the time allowed is up.
    /** 
     * This checks whether the time the user allowed has been fully used.
     * 
     * 
     * @return True if the time has been fully used, or if no time limit has
     * been set.
     */
    bool timeIsUp()
    {
	extern time_t _clock_start;
	extern int PLAY_TIME;

	extern bool NO_TIME_LIMIT;
	
	if (NO_TIME_LIMIT)
	    return false;
	
	time_t end;
	time(&end);
	return (difftime(end,_clock_start) >= PLAY_TIME);
    }
        
    // get a pointer pointing to the move in all_moves
    /** 
     * Search for a move in #all_moves and returns its address. This is mainly
     * used when the user inputs a move, and we have to find its equivalent. In
     * most cases, Move::all_moves_pos is defined and this function just returns
     * it.
     * @warning The function assumes the move you look for is valid (ie it can
     * be played)
     * 
     * @param M The move you want to search for in #all_moves
     * 
     * @return The move address in #all_moves or 0 if the move hasn't been found
     */
    MetaMove* getAllMovesPos(const Move& M) const
    {
	if (M.all_moves_pos)
	    return M.all_moves_pos;
	
	MetaMove* m=all_moves[0].isValid() ? &all_moves[0]
	    :all_moves[0].next_valid;
	for (int i=0;i<getNCand();i++){
	    if (*m == M)
		return m;
	    m=m->next_valid;
	}
	return 0;		// Should not happen
    }

    // Use this function when a candidate move is going to be adjacent to
    // another pentomino if played.
    /** 
     * This is used when a move has just been played, and is adjacent to some
     * pentomino. In that case (if the katamino rules are enabled) you want to
     * increment the number of adjacent pentominoes of the move. This function
     * will add a reason for the move to be valid if the number of adjacent
     * pentominoes goes from 0 to 1. Also updates the number of candidates if
     * such thing happens. This is used e.g by #playMove and #playLastMoveBack
     * when the katamino rules are on.
     * 
     * @param m The move whose number of adjacent pentominoes you want to
     * increment.
     */
    void addAdjacent(MetaMove* m)
    {
	m->addAdjacent();
	if (m->getNAdjacents() == 1)
	    // If the number of adjacent is 1, then it was 0 before and hence
	    // the move can never be valid so we do not have to check that.
	    addReasonToValid(m);
    }
    
    // Use this when a candidate move is going to have one adjacent pentomino
    // less if played.
    /** 
     * This is the exact opposite of #addAdjacent
     * 
     * 
     */
    void removeAdjacent(MetaMove* m)
    {
	m->removeAdjacent();
	if (m->getNAdjacents() == 0)
	    addReasonToInvalid(m);
    }
    
    
    // Use this function if you have found a new reason for the move to be
    // invalid. The function update the MetaMove member in all_moves so that
    // everything is in order even though it might not be valid anymore. Also
    // update the ncand member.
    /** 
     * This adds a reason for the move to be invalid. Use this function when a
     * new move has bee n played which oversteps or has the same pentomino shape
     * as another one. The function will invalidate (ie make sure no valid moves
     * in #all_moves points it) the move if it goes from valid to invalid
     * because of that operation. Used by #playMove and #playLastMoveBack very
     * often. This will also update the number of candidates.
     * 
     * @param m The move whose reasons to invalid you want to increment.
     */
    void addReasonToInvalid(MetaMove* m);

    // Same as above, if you found a reason for the move to be invalid which
    // does not apply anymore. This does not behave correctly if the move is
    // already valid, so by all means check it before if you are unsure.
    /**
     * This is the exact opposite of #addReasonToInvalid @warning For efficiency
     * reasons, this does _not_ behave correctly if the move is already valid,
     * so by all means check it before if you are unsure.
     * 
     */

    void addReasonToValid(MetaMove* m);

    // gets the number of replies to a given move (PositionData.cpp)
    /** 
     * This gets the number of replies they will be to a given move, if it is
     * played on the board. This was created because simply using #playMove ,
     * #getNCand and #playLastMoveBack was taking too much time... Although this
     * function is not declared as const, no class member will have different
     * values before and after you called the function.
     * 
     * @param M The move you want to check the number of replies of.
     * 
     * @return The number of replies to the move
     */
    int getNRepliesToMove(const Move& M);

    // Same as above, but specifically for pentomino/katamino rules (used when
    // #OPTIMIZED_SOLVING is true)
    /** 
     * Same as #getNRepliesToMove but to be used only when you are sure the
     * pentominoes rules are used. This will probably be faster than
     * #getNRepliesToMove .
     * 
     */
    int getNRepliesToMovePento(const Move& M);
    /** 
     * Same as #getNRepliesToMove but to be used only when you are sure the
     * katamino rules are used. This will probably be faster than
     * #getNRepliesToMove .
     * 
     * 
     */
    int getNRepliesToMoveKatamino(const Move& M);

    // the method used for evaluating a position
    // - NONE means taking the moves as they are generated
    // - RANDOM means sorting the moves randomly
    // - NCAND means the number of candidates (in ascending order) 
    // - WINSRATIO means looking at the wins ratio: n_d moves are played at each
    // depth d, and the wins/n ratio is calculated. See the doc for more
    // information.
    // - IMPROVED_WINSRATIO is slightly different from the original wins
    // ratio: n random games are played from the current position, and the
    // wins/n ratio is calculated. See the doc for more information.
    // - RNCAND is the same as NCAND but in descending order
    /**
     * All the methods #getSortedList can use to sort the moves. See also the
     * man page and, if you are really interested the complete report, for more
     * information on which one to use.
     */

    enum Method{
	/**
	 * The moves are taken as they come (no sorting is made)
	 */
	NONE=0
	/**
	 * The move are shuffled randomly.
	 * 
	 */

	,RANDOM=1
	/**
	 * The moves are sorted in ascending order using their number of
	 * replies (#getNReplies).
	 * 
	 */

	,NCAND=2
	/**
	 * The moves are sorted in ascending order using their "wins ratio"
	 * (#findWinsRatio). This is a time-taking method, meaning that
	 * #getSortedList can give up and throw a %TimeOutError if the time has
	 * ran out.
	 * 
	 */

	,WINSRATIO=3
	/**
	 * The moves are sorted in ascending order using their "improved wins
	 * ratio" (#improvedWinsRatio). This is a time-taking method, meaning
	 * that #getSortedList can give up and throw a %TimeOutError if the time
	 * has ran out.
	 * 
	 */

	,IMPROVED_WINSRATIO=4
	/**
	 * The moves are sorted in _descending_ order using their number of
	 * replies (#getNReplies).
	 * 
	 */

	,RNCAND=5};
   
    // list. Do not change this parameter unless you have a good reason to.
    // Requirements: the current position needs to have AT LEAST ONE valid move
    // so that getSortedList can be used.
    // getSortedList can throw a TimeOutError if a time-taking method is
    // given.
    // (PositionData.cpp)
    /** 
     * Get all the valid moves. They are sorted using a given method (see
     * #Method). The function will also use some global variables (see global.h)
     * , like Algo::USE_KILLERS or Algo::N_KILLERS. Unless specified otherwise,
     * the symmetries and other equivalent moves will be removed so that you do
     * not have any "duplicates" . A %TimeOutError will be thrown if a
     * time-taking method (Method::WINSRATIO or Method::IMPROVED_WINSRATIO) is
     * given and the time has ran out.  

     * @warning The function assumes there are
     * *at least one* valid move. The behavior is undefined if there are not
     * any.
     * 
     * @param method The method the function will use to sort the moves.
     * @param move_list An _empty_ vector where the function will put the sorted
     * valid moves it has found.
     */
    void getSortedList(Method method,vector<MetaMove*>& move_list);
    /** 
     * This is an optimized version of #getSortedList for some special cases
     * (when #OPTIMIZED_SOLVING is true) . It assumes the pentominoes rules are
     * used, and sort the moves in ascending order using thenumber of candidates
     * (Method::NCAND). It assumes the killer heuristic is used and put two
     * killers in front of the list (the default settings). See also
     * Algo::USE_KILLERS and Algo::N_KILLERS
     */
    void lightGetSortedListPento(vector<MetaMove*>& move_list);
    /**
     * Same as #lightGetSortedListPento , but assumes the katamino rules are
     * used.
     * 
     */
    void lightGetSortedListKatamino(vector<MetaMove*>& move_list);

    // Find the position wins ratio. 1000 is the highest possible, 0 the
    // lowest.
    // Throw a TimeOutError if the time spent since _clock_start is greater than
    // PLAY_TIME
    // The 'rel_depth' parameter is only used internally.
    /** 
     * Get the wins ratio of the current position. Refer to the man page or the
     * report if you want to know what that actually is ;-) . Throws a
     * %TimeOutError if the time has ran out.
     * 
     * @param rel_depth This is only used internally (the function calls itself
     * recursively). You should not change that parameter
     * 
     * @return The position's wins ratio
     */
    int findWinsRatio(int rel_depth=0);

    // Use a slightly different method to get the wins ratio.
    // Throw a TimeOutError if the time spent since _clock_start is greater than
    // PLAY_TIME
    /** 
     * Get the position's improved wins ratio (a slightly different method than
     * the wins ratio (but not necessarily better). See the man page or the
     * report to know what that actually is ;-) .
     * 
     * 
     * @return The position's improved wins ratio.
     */
    int improvedWinsRatio();
    
public:  
    // (default) constructor(s) and destructor (PositionData-constructor.cpp)
    /**
     * The default (and only constructor). The board's size (#SIZE) should be
     * defined before you call it, as well as the values of #EXCLUDE_PENTO and
     * #KATAMINO_RULES . This basically builds the indexes and #all_moves , so
     * it might take some time
     * 
     */

    PositionData();
        
    ~PositionData()
    {
	delete[] all_moves;
	delete[] square_index;
    }
    
    // returns the grid on which the game is being played
    /** 
     * Get the board on which the game takes place
     * 
     * 
     * @return The board member
     */
    const Board& getBoard() const
    {
	return board;
    }
    
    // returns the number of candidates in this position (symmetries included)
    /** 
     * Get the number of candidates
     * 
     * 
     * @return The number of candidates (symmetries included)
     */
    int getNCand() const
    {
        return n_cand;
    }
    /** 
     * Get a random move. Although this function is not const, there is no
     * difference between the members before and after the call.
     * 
     * 
     * @return A random (valid) move.
     */
    Move getRandomMove()
    {
	vector<MetaMove*> moves;

	getSortedList(Method(NONE),moves);
	
	int min=0;
	int max=moves.size()-1;
	
	return *moves[(int)(min+((double)rand()/RAND_MAX*(max-min+1)))];
    }
        
    // Returns true if the first player is to move
    /**
     * Get which player is to move
     * @return True if the first player (the one who began the game) is to play.
     */

    bool firstPlayerMove() const
    {
	return playing_order.size() % 2 == 0;
    }
    
    // returns a vector holding all the moves that have been played
    /**
     * Return The moves that have been played so far.
     * 
     */

    const vector<MetaMove*>& getPlayingOrder() const
    {
	return playing_order;
    }   

    // Check whether the settings (size of the board, number of pentominoes) are
    // good enough so that most games do not end because of a shortage of
    // pentominoes.
    // Returns false if the settings are okay.
    /** 
     * Check whether the settings (ie the board's size and the number of
     * pentominoes) are okay, that is if they do not seem to extreme (e.g a size
     * of 20x20 with only one pentomino makes no sense.)
     * 
     * 
     * @return True if it thinks the settings are "bad" , false otherwise.
     */
    bool badSettings();

    
    /** 
     * Returns true if a move is valid and update it so that it can be passed to
     * PositionData::playMove
     * 
     * @param m The move to be checked. Members other than its positions (e.g
     * pentomino id, adjacent squares...) do not matter and will be updated if
     * the move is found to be valid.
     * 
     * @return true if the move is valid nad was updated, false otherwise.
     */
    bool findMove(Move& m);
                
    // plays a move on the board and updates all the related data 
    // (PositionData.cpp)
    /** 
     * Plays a move on the board and update all the related data (e.g the move's
     * validity in #all_moves).
     * 
     * @param M The move to be played.
     */
    void playMove(const Move& M);

    // Same as above, but specifically using katamino/pentomino rules (used when
    // #OPTIMIZED_SOLVING is true)
    /**
     * Same as #playMove, but assumes the katamino rules are used. This is
     * slightly faster than #playMove.
     * 
     */

    void playMoveKatamino(const Move&);
    /**
     * Same as #playMoveKatamino but assume the pentominoes rules are used.
     * 
     */

    void playMovePento(const Move&);

    // undoes the last move and updates the related data (PositionData.cpp)
    /**
     * This is the exact opposite of #playMove
     * 
     */

    void playLastMoveBack();

    // Same as above, but specifically using katamino/pentomino rules (used when
    // #OPTIMIZED_SOLVING is true)
    /**
     * This is the exact opposite of #playMovePento
     * 
     */

    void playLastMoveBackPento();
    /**
     * This is the exact opposite of #playMoveKatamino
     * 
     */

    void playLastMoveBackKatamino();
    
    // Result in a given position. TOMOVE_STUCK is only used for game with more
    // than 2 players. It means the side to move lost because it does not have
    // any more possible moves (by opposition to losing simply because someone
    // else won). It is currently not used.
    /**
     * The different results the #solve function can return.
     * 
     */

    enum Result{
	/**
	 * This is returned when a %TimeOutError occured. This simply means the
	 * analyze could not complete and hence the position cannot be evaluated
	 * correctly.
	 * 
	 */

	UNKNOWN
	/**
	 * The side which is to move wins
	 * 
	 */

	,TOMOVE_WINS
	/**
	 * Opposite of Result::TOMOVE_WINS
	 * 
	 */

	,TOMOVE_LOSES};
    
        
    // solves the position, returning the result if both sides play optimally
    // and updates the best_moves vector (REQUIREMENT: must be empty)
    // The best_moves vector will be added at most one element unless the
    // 'all' argument is set to true. If set to true, restart_timer shall make
    // sure the global variable _clock_start (indicating the moment in time
    // when we began to keep track of the time limit) is set to the current
    // time. Otherwise, the old value is kept.
    // The 'rel_depth' parameter is used internally and shall not be changed.
    // If stats is true, the function will put some statistics in some Stats::
    // variables.
    /** 
     * This analyze the position using a backtracking algorithm, and return the
     * best move(s) and the result (ie who wins) assuming both sides play
     * optimally (see #Result).
     * 
     * @param best_moves An _empty_ vector where the best move(s) will be put
     * when they are found
     * @param all If set to true, the function will not stop when it finds a
     * winning move, but instead will go on finding _all_ winning moves
     * @param restart_timer If set to true, the "timer" will be set when the
     * function is called for the first time and the time limit will take effect
     * from that time. Otherwise, the old value will be kept.
     * @param stats If set to true, this will keep some statistics (see #Stats)
     * e.g about the number of candidate at each depth. 
     * @param rel_depth This is only used internally (the function recursively
     * call itself and should _not_ be changed.
     * 
     * @return The result of the game assuming both sides play optimally.
     */
    Result solve(vector<Move>& best_moves,bool all=false, 
		 bool restart_timer=true,bool stats=false,int rel_depth=0);

    // This is the same as above, but it only supports the board solving without
    // time limit. This is used if #OPTIMIZED_SOLVING is true,
    // see the manual for more information.
    /**
     * This is the same as #solve , but optimized for some default values (see
     * #OPTIMIZED_SOLVING ) and assuming the katamino rules are used. You should
     * not have to bother with this directly, as this function are called from
     * #solve when #OPTIMIZED_SOLVING is true.
     * 
     */

    Result lightSolveKatamino();
    /**
     * This is the same as #lightSolveKatamino but assumes the pentomino rules
     * are used.
     * 
     */
    Result lightSolvePento();
};

#endif
