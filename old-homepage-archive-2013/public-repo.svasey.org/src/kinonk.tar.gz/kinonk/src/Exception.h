// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   Exception.h
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Tue Sep 18 17:46:30 2007
 * 
 * @brief  
 * Contains all user-defined exception types kinonk uses
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#ifndef INCLUDE_EXCEPTION
#define INCLUDE_EXCEPTION

// Contains all custom exceptions

#include "Move.h"

#include <exception>

// Thrown in case the time given to play a move is over
/**
 * This is thrown in case the time you give the program to play a move is
 * over. If you just call PositionData::solve , then you probably don't have to
 * catch it, as it handles it automatically.
 * 
*/

class TimeOutError : public std::exception
{
public:
    TimeOutError(){}

    virtual ~TimeOutError() throw (){}
};
    

// thrown in case a move that wins immediately has been found in the examined
// position. A pointer to the move is thrown so that the caller can use it 
// immediately.
// class WinningMoveError : public std::exception
// {
// private:
//     Move* winning_move;
// public:
//     WinningMoveError(Move* M):winning_move(M)
//     {}
    
//     virtual ~WinningMoveError() throw(){}
//     Move* getWinningMove() const
//     {
// 	return winning_move;
//     }
// };

#endif
