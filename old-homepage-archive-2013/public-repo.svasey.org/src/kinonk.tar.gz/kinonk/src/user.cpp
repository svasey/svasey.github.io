// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   user.cpp
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Mon Sep 17 18:00:10 2007
 * 
 * @brief  
 * Contains the implementation of functions used for parsing the command line,
 * and parsing some configuration files
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "tclap/CmdLine.h"
using namespace TCLAP;
#include "ConfigFile/ConfigFile.h"

#include "user.h"
#include "Coor.h"

#include <vector>
using std::vector;

#include <iostream>
using std::cerr;
using std::endl;

#include <string>
using std::string;

extern bool ENGINE;
extern bool ONE_FIRST_MOVE;
extern bool ALL_FIRST_MOVES;
extern bool KATAMINO_RULES;
extern int PLAY_TIME;
extern string STATS_FILE;
extern string ALGO_FILE;
extern Coor SIZE;
extern char PENTO_ID_LETTER[12];
extern int MAX_DEPTH_DEBUG;
extern int NHUMANS;
extern int COMPTURN;
extern bool NO_TIME_LIMIT;
extern bool EXCLUDE_PENTO[12];
extern bool OPTIMIZED_SOLVING;
// The maximum currently supported number of players
extern int MAX_NPLAYERS;

namespace Algo
{
    extern const int DEFAULT_SORTING_METHOD;
    extern const bool DEFAULT_USE_KILLERS;
    extern const int DEFAULT_N_KILLERS;
    extern const int DEFAULT_SORTING_METHOD;
    extern int WINSRATIO_MAX;
    extern bool USE_KILLERS;
    extern int N_KILLERS;
    extern int WINSRATIO_SORTING_METHOD;
    extern int IMPROVED_WINSRATIO_NRANDOM;
    extern int IMPROVED_WINSRATIO_NGAMES;
    extern int WINSRATIO_NMOVES[12];
    extern int DEPTH_METHOD[12];
}
/**
 * This just contains a vector and an istream operator. Some file parsing
 * functions needs it
 */

struct ArrayOfInt
{
    vector<int> v;

    ArrayOfInt(){}

    friend std::istream& operator>>(std::istream& is,ArrayOfInt& aa)
    {
	for (int i=0;i<12 && is.good();i++){
	    int n;
	    is >> n;
	    aa.v.push_back(n);
	}
	
	return is;
    }
};
/**
 * Used by the command-line parsing library. The class only contains
 * instructions on how to check and describe the board size.
 * 
 */
class SizeConstraint : public Constraint<Coor>
{
public:
    virtual ~SizeConstraint() {}
    virtual string description() const;
    virtual string shortID() const;
    virtual bool check(const Coor& C) const;
};

/**
 * Used by the command-line parsing library. The class only contains
 * instructions on how to check and describe the --details argument.
 * 
 */

class DebugConstraint: public Constraint<int>
{
public:
    virtual ~DebugConstraint(){}
    virtual string description() const;
    virtual string shortID() const;
    virtual bool check(const int& n) const;
};

/**
 * Used by the command-line parsing library. The class only contains
 * instructions on how to check and describe the --humans argument.
 * 
 */


class PlayersConstraint: public Constraint<int>
{
public:
    virtual ~PlayersConstraint() {}
    virtual string description() const;
    virtual string shortID() const;
    virtual bool check(const int& n) const;
};


string SizeConstraint::description() const
{
    return "4 < x*y < 121";
}
string SizeConstraint::shortID() const
{
    return "SIZE";
}
bool SizeConstraint::check(const Coor& C) const
{
    return C.x*C.y > 4 && C.x*C.y < 121;
}


string DebugConstraint::description() const
{
    return "-1 <= n <= 11";
}
string DebugConstraint::shortID() const
{
    return "DEPTH";
}
bool DebugConstraint::check(const int& n) const
{
    return n >=-1 && n<=11;
}


string PlayersConstraint::description() const
{
    // For the moment (08.19.2007) the program does not support more than two
    // players.
    return "0 <= n < 2";
}
string PlayersConstraint::shortID() const
{
    return "NHUMANS";
}
bool PlayersConstraint::check(const int& n) const
{
    return n >= 0 && n < MAX_NPLAYERS;
}

void processOptions(int argc,char* argv[]){
    // Process the command-line options
    
    try{
	CmdLine cmd("Pentominoes and Katamino playing software",' '
		    ,"1.1-cvs_prerelease");
	
	SwitchArg argEngine("q","engine","Make the program only output errors"
			   ,cmd,ENGINE);
	SwitchArg argSolve("s","solve","Try to output one winning move and exit"
			   ,cmd,ONE_FIRST_MOVE);
	SwitchArg argSolveall("A","solveall"
			      ,"Output all the winning moves and exit"
			      ,cmd,ALL_FIRST_MOVES);
	SwitchArg argKatamino("k","katamino","Use the katamino rules"
			      ,cmd,KATAMINO_RULES);
	
	SwitchArg argNotime("T","notime"
			    ,"Do not restrict the program to any time limit"
			    ,cmd,(PLAY_TIME == 0 ? true : false));

// 	SwitchArg argQuick("Q","quicksolve"
// 			   ,"Equivalent to --solve but quicker"
// 			   ,cmd,QUICKSOLVE);
		
	ValueArg<string> argStats("f","stats",
				  "Give a file where the program will write" \
				  " statistics",false,STATS_FILE,"FILE",cmd);
	ValueArg<string> argAlgo("a","algo",
				 "Set the file to source to customize the" \
				 " variables used in the search algorithm"
				 ,false,ALGO_FILE,"FILE",cmd);
	
	SizeConstraint constraintSize;
	
	ValueArg<Coor> argSize("S","size",
			       "Set the board's size",
			       false,SIZE,&constraintSize,cmd);
	ValueArg<unsigned int> argTime("t","time"
				       ,"Set a time limit (sec) after which" \
				       " the program must play",false,PLAY_TIME
				       ,"SECONDS",cmd);

	// Used only to hold the values of PENTO_ID_LETTER, since the
	// constraintPento function needs a vector as argument
	vector<char> tmp;
	for (int i=0;i<12;i++)
	    tmp.push_back(PENTO_ID_LETTER[i]);
	ValuesConstraint<char> constraintPento(tmp);
	
	MultiArg<char> argExclude("e","exclude","Add a pentomino to be excluded"
				  ,false,&constraintPento,cmd);
	
	DebugConstraint constraintDebug;
	
	ValueArg<int> argDetails("d","details",
				 "Set the maximum depth where the program" \
				 " outputs information on what it is analyzing"
				 ,false,MAX_DEPTH_DEBUG,&constraintDebug,cmd);
	
	PlayersConstraint constraintPlayers;
	ValueArg<int> argHumans("p","humans"
				,"Set the number of humans going to play"
				,false,NHUMANS,&constraintPlayers,cmd);
	
	ValueArg<int> argTurn("c","compturn"
			      ,"Place in which the computer will play"
			      ,false,COMPTURN,"N",cmd);
	
	cmd.parse(argc,argv);
	ENGINE=argEngine.getValue();
	ONE_FIRST_MOVE=argSolve.getValue();
	ALL_FIRST_MOVES=argSolveall.getValue();
	KATAMINO_RULES=argKatamino.getValue();



	PLAY_TIME=argTime.getValue();
	if (PLAY_TIME <= 0 || ALL_FIRST_MOVES || ONE_FIRST_MOVE
	    || argNotime.getValue())
	    
	    NO_TIME_LIMIT = true;
	else
	    NO_TIME_LIMIT = false;
	
	STATS_FILE=argStats.getValue();
	ALGO_FILE=argAlgo.getValue();
	SIZE=argSize.getValue();
	MAX_DEPTH_DEBUG=argDetails.getValue();
	NHUMANS=argHumans.getValue();
	COMPTURN=argTurn.getValue();

	if (COMPTURN > MAX_NPLAYERS || COMPTURN < 1){
	    throw CmdLineParseException("the computer's place in which it has" \
					" to play is out of range.");
	}
	    
	
	vector<char> v=argExclude.getValue();
	for (int i=0;i<static_cast<int>(v.size());i++){
	    for (int j=0;j<12;j++){
		if (PENTO_ID_LETTER[j] == v[i]){
		    EXCLUDE_PENTO[j]=true;
		    break;
		}
	    }
	}

	// sets the Algo variables
	if (ALGO_FILE!=""){
	    try {
		ConfigFile conf(ALGO_FILE);

		
		int tmp=conf.read<int>
		    ("WINSRATIO_MAX",Algo::WINSRATIO_MAX);

		if (tmp < 10){
		    cerr << "Warning: WINSRATIO_MAX must an integer greater" \
			"or equal to 10." << endl;
		}
		else {
		    Algo::WINSRATIO_MAX=tmp;
		}


		Algo::USE_KILLERS=conf.read<bool>
		    ("USE_KILLERS",Algo::USE_KILLERS);

		
		tmp=conf.read<int>
		    ("N_KILLERS",Algo::N_KILLERS);
		if (tmp <= 0){
		    cerr << "Warning: N_KILLERS must be an integer greater" \
			" than 0." << endl;
		}
		else {
		    Algo::N_KILLERS=tmp;
		}
		
		tmp=conf.read<int>
		    ("WINSRATIO_SORTING_METHOD",Algo::WINSRATIO_SORTING_METHOD);
		if (tmp < 0 || tmp > 5){
		    cerr << "Warning: WINSRATIO_SORTING_METHOD must be an" \
			" integer between 0 and 5" << endl;
		}
		else {
		    Algo::WINSRATIO_SORTING_METHOD=tmp;
		}

		tmp=conf.read<int>
		    ("IMPROVED_WINSRATIO_NRANDOM"
		     ,Algo::IMPROVED_WINSRATIO_NRANDOM);
		if (tmp <= 0){
		    cerr << "Warning: IMPROVED_WINSRATIO_NRANDOM must be an" \
			" integer greater than 0." << endl;
		}
		else 
		    Algo::IMPROVED_WINSRATIO_NRANDOM=tmp;
		    

		tmp=conf.read<int>
		    ("IMPROVED_WINSRATIO_NGAMES"
		     ,Algo::IMPROVED_WINSRATIO_NGAMES);

		if (tmp <= 0){
		    cerr << "Warning: IMPROVED_WINSRATIO_NGAMES must be an" \
			" integer greater than 0" << endl;
		}
		else
		    Algo::IMPROVED_WINSRATIO_NGAMES=tmp;

		ArrayOfInt n_moves;
		conf.readInto(n_moves,"WINSRATIO_NMOVES");
		for (int i=0;i<static_cast<int>(n_moves.v.size());i++){
		    if (n_moves.v[i] <= 0){
			cerr << "Warning: WINSRATIO_NMOVES[" << i << "]"
			     << " must be an integer greater than 0" << endl;
		    }
		    else {
			Algo::WINSRATIO_NMOVES[i]=n_moves.v[i];
		    }
		}
		ArrayOfInt depth_method;
		conf.readInto(depth_method,"DEPTH_METHOD");
		for (int i=0;i<static_cast<int>(depth_method.v.size());i++){
		    if (depth_method.v[i] < 0 || depth_method.v[i] > 5){
			cerr << "Warning: DEPTH_METHOD[" << i << "]"
			     << " must be an integer between 0 and 5" << endl;
		    }
		    else {
			Algo::DEPTH_METHOD[i]=depth_method.v[i];
		    }
		}
	    }
	    catch(ConfigFile::file_not_found) {
		throw CmdLineParseException("The file does not exist"
					    ,"-a (--algo)");
	    }
	}

	// Check whether optimized solve functions can be used.
	bool optimized_solving=true;
	for (int i=0;i<12;i++){
	    if (Algo::DEPTH_METHOD[i] != Algo::DEFAULT_SORTING_METHOD){
		optimized_solving=false;
		break;
	    }
	}
	if (optimized_solving && NO_TIME_LIMIT
	    && Algo::USE_KILLERS == Algo::DEFAULT_USE_KILLERS
	    && Algo::N_KILLERS == Algo::DEFAULT_N_KILLERS){

	    OPTIMIZED_SOLVING=true;
	}
    }
    catch (ArgException& e){
	std::cerr << "error: " << e.error() << " for " << e.argId()
		  << std::endl;
	exit(1);
    }
}
