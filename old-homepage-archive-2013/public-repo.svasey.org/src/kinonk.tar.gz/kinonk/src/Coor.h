// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   Coor.h
 * @author Sebastien Vasey & Yann Schoenenberger
 * @date   Tue Sep 18 17:26:04 2007
 * 
 * @brief  
 * Contains the Coor class declaration
 * 
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#ifndef INCLUDE_COOR
#define INCLUDE_COOR

// Simple 2D coordinates (x,y) and simple functions and operators

#include <cstdlib>
#include <iostream>
#include <string>
using std::string;

/**
 * Contains a position on the katamino/pentomino board. This is simply a x and y
 * coordinate.
 * 
 */

struct Coor {
    // parameters of the default constructor
    /**
     * Contains the values at which #x and #y are intialized.
     * 
     */

    enum {UNDEFINED_X=-1,UNDEFINED_Y=-1};
    
    // horizontal and vertical coordinates
    /**
     * The horizontal position. It must be between 0 and the maximum size
     * of the board, see the %Board class for more information.
     * 
     */

    int x;
    /**
     * The vertical position. It must be between 0 and the maximum size of the
     * board, see the %Board class for more information.
     * 
     */

    int y;
    
    // (default) constructor
    Coor(int xx=UNDEFINED_X,int yy=UNDEFINED_Y):x(xx),y(yy)
    {}

    /** 
     * This returns an integer representation of the object. This is useful when
     * using index members in %PositionData for example (e.g you want to have
     * all the moves stepping on a given Coor object, you will do:
     * moves=indexname[coor.getInt(SIZE)]
     * 
     * @param SIZE 
     * The size of the katamino/pentomino board.
     * 
     * @return An integer representation of the object. If you use this function
     * on different Coor objects with the same size, the return value will
     * always be different.
     */
    int getInt(const Coor& SIZE) const
    {
	return SIZE.x*y+x;
    }
  
    // return 'true' if 'this' is beyond (0,0) and (SIZE.x,SIZE.y)
    /** 
     * Check if the object is not out of range (ie not a valid square on the
     * board)
     * 
     * @param SIZE 
     * The size of the board
     * 
     * @return true if the move is out of range, false otherwise.
     */
    bool isOutOfRange(const Coor& SIZE) const
    {
	return x<0 || y<0 || x>=SIZE.x || y>=SIZE.y;
    }

    // return 'true' if 'this' is in contact with C (sides or edges)
    /** 
     * Check if the object is in contact with another Coor object. This
     * concretely means the Coor::x and Coor::y members of both objects must
     * have a difference of one or less.
     * 
     * @param C 
     * The object you want to check
     * 
     * @return 
     * true if *this is in contact with C, false otherwise
     */
    bool inContactWith(const Coor& C) const 
    {
	return std::abs(C.x-x)<=1 && std::abs(C.y-y)<=1;
    }  

    // test-for-equality operator
    bool operator==(const Coor& C) const
    {
	return x==C.x && y==C.y;
    }

    // test-for-inequality operator
    bool operator !=(const Coor& C) const
    {
	return x!=C.x || y!=C.y;
    }

    // output stream operator
    friend std::ostream& operator <<(std::ostream& os,const Coor& C)
    {
	return os << "<" << C.x << "," << C.y << ">";
    }

    // Support either the horizontal x vertical notation (e.g 8x8) or the space
    // separated one (e.g 8 8)
    /** 
     * The input stream operator. This accepts both a space-separated listing of
     * the x and y coordinates or an x separated one, e.g 7x8 or 7 8)
     */
    friend std::istream& operator >>(std::istream& is,Coor& C)
    {
	string s;
	is >> s;
	for (int i=0;i<static_cast<int>(s.length());i++){
	    if (s[i] == 'x'){
		string left="";
		string right="";
		for (int j=0;j<i;j++)
		    left+=s[j];
		for (int j=i+1;j<static_cast<int>(s.length());j++)
		    right+=s[j];

		C.x=atoi(left.c_str());
		C.y=atoi(right.c_str());
		return is;
	    }
	}
	C.x=atoi(s.c_str());
	is >> C.y;
	return is;
    }
    	    
    
};

#endif
