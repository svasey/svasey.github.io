// Move.cpp -- Implementation of the functions declared in Move.h
// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#include "Move.h"
#include "Coor.h"

#include <iostream>

#include <vector>
using std::vector;

// If set to true, the Move object will be outputted in a different,
// parser-friendly format.
extern bool ENGINE;

Move::Move(int id,const Coor position[],const Coor board_size):pento_id(id),
							       all_moves_pos(0)
{
    // these two are used later when generating adj
    Coor top_left(board_size.x+1,-1);
    Coor bottom_right(-1,board_size.y+1);
    
    for (int i=0;i<5;i++){
	pos[i]=position[i];
	
	// generate the "frame" in which the adjacent moves are
	if (pos[i].x <= top_left.x) top_left.x=pos[i].x-1;
	if (pos[i].y >= top_left.y) top_left.y=pos[i].y+1;
	
	if (pos[i].x >= bottom_right.x) bottom_right.x=pos[i].x+1;
	if (pos[i].y <= bottom_right.y) bottom_right.y=pos[i].y-1;
    }
	
    // generate the adjacent squares
    for (int i=0;i<=bottom_right.x-top_left.x;i++){
	for (int j=0;j<=top_left.y-bottom_right.y;j++){
	    bool add_this = true;
	    bool isolated = true;
	    
	    Coor ij(top_left.x+i,top_left.y-j);
		
	    // a square occupied by the pentomino is not adjacent
	    // squares not adjacent to any position have to be eliminated
	    for (int h=0;h<5;h++){
		if (ij.inContactWith(pos[h])) isolated=false;
		if (ij==pos[h]){
		    add_this = false;
		    h=5;
		}
	    }
	    
	    // it is an adjacent square
	    if (add_this && !isolated) adj.push_back(ij);
	}		
    }
}	 

Move Move::getHorizontalSymmetry(const Coor& S) const
{
    Move M = *this;
    M.all_moves_pos=0;
    for (int i=0;i<5;i++) M.pos[i]=Coor(S.x-pos[i].x-1,pos[i].y); 
    for (unsigned int i=0;i<M.adj.size();i++) 
	M.adj[i]=Coor(S.x-adj[i].x-1,adj[i].y);
	
    return M;
}

Move Move::getVerticalSymmetry(const Coor& S) const
{
    Move M = *this;
    M.all_moves_pos=0;
    for (int i=0;i<5;i++) M.pos[i]=Coor(pos[i].x,S.y-pos[i].y-1);
    for (unsigned int i=0;i<M.adj.size();i++) 
	M.adj[i]=Coor(adj[i].x,S.y-adj[i].y-1);
    
    return M;
}

Move Move::getRotation(const Coor& S, int quarters) const
{
    Move M = *this;
    M.all_moves_pos=0;
    for (int i=0;i<quarters;i++){
	for (int j=0;j<5;j++)
	    M.pos[j]=Coor(pos[j].y,S.x-pos[j].x-1);    
	for (unsigned int j=0;j<M.adj.size();j++)
	    M.adj[j]=Coor(adj[j].y,S.x-adj[j].x-1);    
    }
    
    return M;
}

void Move::getEquivalentPos(const Coor& S,vector<Move>& equivalent_pos) const
{
    Move M=*this;

    if (S.x==S.y){ // the board is a square
	
	// get the three first rotations	
	for (int i=0;i<3;i++){
	    M=M.getRotation(S);
	    equivalent_pos.push_back(M);
	}
	
	// get the symmetry of one of the positions 
	// (doesn't matter which one here it is the last one for simplicity)
	M=M.getVerticalSymmetry(S);
	equivalent_pos.push_back(M);

	// get the three last rotations (of the move we just got)
	for (int i=0;i<3;i++){
	    M=M.getRotation(S);
	    equivalent_pos.push_back(M);
	}
    }
    else{ // the board is a rectangle
	
	// get the three equivalences directly
	M=M.getVerticalSymmetry(S);
	equivalent_pos.push_back(M);
	M=M.getHorizontalSymmetry(S);
	equivalent_pos.push_back(M);
	M=M.getVerticalSymmetry(S);
	equivalent_pos.push_back(M);
    }
}
    
 
void Move::displayShape(const Coor& S) const 
{
    std::clog << *this << std::endl;

    // Display the move on the lower left corner of the board
    for (int y=S.y-1;y>=0;y--){
	for (int x=0;x<S.x;x++){
	    int i=0;
	    for (;i<5;i++){
		if (pos[i].x==x && pos[i].y==y){
		    std::clog << 1;
		    break;
		}
		
	    }
	    if (i==5)
		std::clog << 0;
	    std::clog << " ";
	}
	std::clog << std::endl;
    }
}


bool Move::isOutOfRange(const Coor& S) const
{
    int i=0;
    while (i<5 && !pos[i].isOutOfRange(S))
	i++;

    if (i != 5)
	return true;
    return false;
}

bool Move::operator==(const Move& M) const 
{
    // If the position in all_moves is equal, the moves are equal
    if (this->all_moves_pos && M.all_moves_pos)
	return this->all_moves_pos == M.all_moves_pos;

    // This is not as simple as comparing each coordinates: the order may be
    // different but there still might be the same values.

    // The following code was written in a rush and could definitely be more
    // efficient
    int i=0,j=0;

    for (;i<5 && j<5;i++){
	for (j=0;j<5 && pos[i]!=M.pos[j];j++);
    }
        
    if (i != 5 || j == 5)
	return false;
    return true;
}


std::ostream& operator<<(std::ostream& os,const Move& Base)
{
    Move M=Base;

    if (ENGINE){
	for (int i=0;i<5;i++)
	    os << M.pos[i].x << " " << M.pos[i].y << " ";
	return os;
    }

    os << "Pentomino id " << M.pento_id << " (";
    for (int i=0;i<5;i++)
	os << "(" << M.pos[i].x << "," << M.pos[i].y << ")";
    
    os << ")" << std::endl;

    // Not needed anymore I think
    // os << "Adjacent squares: {";
//     for (vector<Coor>::iterator it=M.adj.begin();it!=M.adj.end();it++)
// 	os << "(" << it->x << "," << it->y << ");";

//     os << "}" << std::endl;
        
    return os;
}

std::istream& operator>>(std::istream& is,Move& m)
{
    for (int i=0;i<5;i++)
	is >> m.pos[i];
    return is;
}


