// Board.cpp -- Implementation of the functions described in Board.h
// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#include "Board.h"
#include "Coor.h"

extern char PENTO_ID_LETTER[12];
extern bool EXCLUDE_PENTO[12];

#include <iostream>

Board::Board(const Coor& S):SIZE(S)
{
    // Dynamically allocate memory
    board=new int*[SIZE.x];
    for (int i=0;i<SIZE.x;i++)
	board[i]=new int[SIZE.y];

    // Initialize all square to EMPTY
    for (int x=0;x<SIZE.x;x++){
	for (int y=0;y<SIZE.y;y++)
	    board[x][y]=EMPTY;
    }
}

Board::~Board() 
{
    for (int i=0;i<SIZE.x;i++)
	delete[] board[i];
    delete[] board;
}



Board::Board(const Board& B):SIZE(B.SIZE)
{
    board=new int*[SIZE.x];
    for (int i=0;i<SIZE.x;i++)
	board[i]=new int[SIZE.y];
        
    *this=B;
}

Board& Board::operator=(const Board& B)
{
    // Delimitate the part of B that will be copied to *this
    const Coor MAXSIZE=Coor(B.SIZE.x < this->SIZE.x ? B.SIZE.x : this->SIZE.x
			    ,B.SIZE.y < this->SIZE.y ? B.SIZE.y : this->SIZE.y);

    for (int x=0;x<MAXSIZE.x;x++){
	for (int y=0;y<MAXSIZE.y;y++)
	    board[x][y]=B.getPentoId(x,y);
    }
    return *this;
}


void Board::playMove(const Move& M)
{
    for (int i=0;i<5;i++)
	board[M.pos[i].x][M.pos[i].y]=M.pento_id;
}

void Board::playMoveBack(const Move& M)
{
    for (int i=0;i<5;i++)
	board[M.pos[i].x][M.pos[i].y]=EMPTY;
}

std::ostream& operator <<(std::ostream& os,const Board& B)
{
    // for (int y=B.SIZE.y-1;y>=0;y--){
// 	for (int x=0;x<B.SIZE.x;x++){
// 	    int pento_id=B.getPentoId(x,y);
// 	    if (pento_id == Board::EMPTY)
// 		os << 0;
// 	    else if (pento_id+1 > 9)
// 		os << char(int('a')+pento_id-9);
// 	    else
// 		os << pento_id+1;
// 	    os << " ";
// 	}
// 	os << std::endl;
//     }

//     os << "  +";
//     if (SIZE.y > 10)
// 	os << " ";
//     for (int i=0;i<B.SIZE.x;i++){
// 	os << "--";
// 	if (SIZE.x > 10)
// 	    os << "-";
//     }
//     os << "+" << std::endl;
    bool available_pentos[12];
    for (int i=0;i<12;i++){
	available_pentos[i]=true;
    }
    
    for (int y=B.SIZE.y-1;y>=0;y--){
	if (y < 10 && SIZE.y > 10)
	    os << 0;
	os << y << "  ";
	for (int x=0;x<B.SIZE.x;x++){
	    if (B.SIZE.x > 10)
		os << " ";
	    if (B.getPentoId(x,y) == Board::EMPTY)
		os << ". ";
	    else {
		available_pentos[B.getPentoId(x,y)]=false;
		if (B.getPentoId(x,y) > 9)
		    os << char(int('a')+B.getPentoId(x,y)-9);
		else 
		    os << B.getPentoId(x,y);
		os << " ";
	    }
	}
	os << " " << std::endl;
    }
//     os << "  +";
//     if (SIZE.y > 10)
// 	os << " ";
//     for (int i=0;i<B.SIZE.x;i++){
// 	os << "--";
// 	if (SIZE.x > 10)
// 	    os << "-";
//     }

//     os << "+" << std::endl;
    os << std::endl;
    os << "   ";
    if (SIZE.y > 10)
	os << " ";
    for (int x=0;x<B.SIZE.x;x++){
	if (x < 10 && SIZE.x > 10)
	    os << 0;
	os << x << " ";
    }
    os << std::endl;
    
    // Print what pentominoes remain to be played
    os << "Available pentominoes: ";
    for (int i=0;i<12;i++){
	if (available_pentos[i] && !EXCLUDE_PENTO[i]){
	    os << PENTO_ID_LETTER[i];
	    if (i < 11)
		os << ",";
	}
    }
    os << std::endl;
	
    return os;
}
