/* 
   PositionData.cpp -- Contains the implementation of the functions
   described in PositionData.h, except the constructor (implemented in
   PositionData-constructor.cpp)

   Copyright (c) Sebastien Vasey
   Copyright (c) Yann Schoenenberger
*/

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#include "PositionData.h"
#include "Move.h"
#include "Exception.h"
// It is necessary not to compile the file separately, as important optimization
// would not be possible
#include "PositionData-light.cpp"
#include <set>
using std::set;
using std::multiset;

#include <vector>
using std::vector;

#include <iterator>
#include <functional>
#include <cstdlib>
#include <cmath>
#include <iostream>		// For debugging only
using std::endl;

extern bool KATAMINO_RULES;
extern bool OPTIMIZED_SOLVING;
extern int NHUMANS;
extern std::ostream message;
extern time_t _clock_start;

namespace Algo
{
    extern int DEPTH_METHOD[12];
};

namespace Stats {
    extern unsigned long long *analyzed_before_cutoff[12];
    extern unsigned long long *number_candidates[13];
    extern unsigned long long shape_cutoff[12][12];
};

void PositionData::addReasonToInvalid(MetaMove* m)
{
    if (m->isValid()){
	n_cand--;
	m->setToNearlyValid();

	// If m is all_moves[0], then nothing should happen: all_moves[0] is
	// kind of an "entry point to the list"; valid or not, it should always
	// remain linked to the next valid move.
	if (m != &all_moves[0]){
	    (m->previous_valid)->next_valid=m->next_valid;
	    if (m->next_valid)
		(m->next_valid)->previous_valid=m->previous_valid;
	}
    }
    else 
	m->addReasonToInvalid();
}


void PositionData::addReasonToValid(MetaMove* m)
{
    if (m->isNearlyValid()){
	n_cand++;
	m->setToValid();

	// m is inserted just after all_moves[0] (which always stay in the list
	// (it is the "entry point"))
	if (m != &all_moves[0]){
	    m->previous_valid=&all_moves[0];
	    m->next_valid=all_moves[0].next_valid;
	    if (all_moves[0].next_valid)
		(m->next_valid)->previous_valid=m;
	    all_moves[0].next_valid=m;
	}
    }
    // New behavior: the move passed as a paremeter must NOT be valid
//     else if (! (m->isValid()) )
// 	m->addReasonToValid();
    
    else
	m->addReasonToValid();
}

namespace Algo
{
    extern int N_KILLERS;
    extern bool USE_KILLERS;
};

	

void PositionData::getSortedList(Method method,vector<MetaMove*>& move_list)
{
    const int DEPTH=playing_order.size();

    move_list.reserve(getNCand());

    // Add all the moves to move_list
    MetaMove* m=all_moves[0].isValid() ? &all_moves[0] :all_moves[0].next_valid;
    if (DEPTH != 0){    
	do {
	    move_list.push_back(m);
	    m=m->next_valid;
	} while (m != NULL);
    }
    else {
	do {
	    if (! m->is_equivalent)
		move_list.push_back(m);
	    m=m->next_valid;
	} while (m != NULL);
    }
    
    // If no method specified: no need to sort the moves
    if (method == NONE)
	return;
    if (method == RANDOM){
	srand(time(0));
	std::random_shuffle(move_list.begin(),move_list.end());
	return;
    }

    const vector<MetaMove*>::iterator END=move_list.end();
    for (vector<MetaMove*>::iterator it=move_list.begin();it!=END;++it){
	try{
	    switch (method){
	    case NCAND:
		{
		    int n=getNRepliesToMove(**it);
		    if (n == 0){
			
			std::swap(*it,*(move_list.begin()));
			return;
		    }
		    (*it)->setNCandEvaluation(n);
		    break;
		}
	    case RNCAND:
		{
		    int n=getNRepliesToMove(**it);
		    if (n == 0){
			std::swap(*it,*(move_list.begin()));
			return;
		    }
		    (*it)->setReverseNCandEvaluation(n);
		    break;
		}
	    case WINSRATIO:
		{
		    playMove(**it);
		    int n=0;
		    try{
			n=findWinsRatio();
			playLastMoveBack();
			(*it)->setWinsRatioEvaluation(n);
			break;
		    }
		    catch (TimeOutError){
			playLastMoveBack();
			(*it)->setWinsRatioEvaluation(0);
			throw;
		    }
		}
		
	    case IMPROVED_WINSRATIO:
		{
		    playMove(**it);
		    int n=0;
		    try{
			n=improvedWinsRatio();
			playLastMoveBack();
			(*it)->setWinsRatioEvaluation(n);
			break;
		    }
		    catch (TimeOutError){
			playLastMoveBack();
			(*it)->setWinsRatioEvaluation(0);
			throw;
		    }
		}
	    
	    default:
		break;
	    }
	} // End Try
	catch (TimeOutError){
	    
	    // Happens only with winsratio-like methods. Set all remaining
	    // moves' wins ratio to 0.
	    for (;it!=move_list.end();it++)
		(*it)->setWinsRatioEvaluation(0);
	    break;
	}
    } // End of for each move
    
    // Sort the move list using the "static" (number of replies, wins ratio...)
    // evaluation.
    CmpMetaMovePtr cmp_nokil(DEPTH,false);

    // Sort the move list using the "adaptive" (killers) evaluation
    CmpMetaMovePtr cmp_kil(DEPTH,true);

    // n is the number of killers we will put on top of the list
    int n=std::min(static_cast<int>(move_list.size()),Algo::N_KILLERS);

    if (!Algo::USE_KILLERS)
	n=0;
    
    // First put the killers on top of the list (the killers are those with the
    // greatest adaptive evaluation
    std::partial_sort(move_list.begin(),move_list.begin()+n,move_list.end()
		      ,cmp_kil);

    // If the size of the move list was greater than the number of killers, go
    // on sorting the rest with their static evaluation.
    if (n < static_cast<int>(move_list.size()))
	std::stable_sort(move_list.begin()+n,move_list.end(),cmp_nokil);


    if (timeIsUp())
	throw TimeOutError();
}

PositionData::Result PositionData::solve(vector<Move>& best_moves,bool all
					 ,bool restart_timer,bool stats
					 ,int rel_depth)
{
    extern int MAX_DEPTH_DEBUG;
    
    if (!getNCand()){
	if (stats)
	    Stats::number_candidates[rel_depth][0]++;
	return TOMOVE_LOSES;
    }

    const int ABSOLUTE_DEPTH=playing_order.size();

    if (restart_timer){
	time(&_clock_start);
    }
    
    // Check whether the time limit has been exceeded. This should _not_ be
    // necessary, since it is done a few lines below
//     if (rel_depth && timeIsUp())
// 	throw TimeOutError();


    // The method that will be used at that depth to sort the moves
    Method method=Method(Algo::DEPTH_METHOD[ABSOLUTE_DEPTH]);

    vector<MetaMove*> move_list;
    
    try{
	getSortedList(method,move_list);
    }
    catch (TimeOutError){
	if (rel_depth == 0){
	    best_moves.push_back(*move_list.front());
	    return UNKNOWN;
	}
	throw;
    }
    const int MOVE_LIST_SIZE=move_list.size();

    // It is more precise to use the list of moves to analyze's size instead of
    // the number of candidates. It takes into account symmetries and other
    // equivalent moves at absolute depth 0...
    if (stats)
	Stats::number_candidates[rel_depth][MOVE_LIST_SIZE]++;
                
    const bool VERBOSE=MAX_DEPTH_DEBUG >= 0
	&& (static_cast<int>(ABSOLUTE_DEPTH) <= MAX_DEPTH_DEBUG);
        
    if (VERBOSE){
	message << "Relative depth " << rel_depth << std::endl;
	message << "there are " << MOVE_LIST_SIZE
		<< " moves to solve" << std::endl;
    }

    // Whether the optimized function (ie lightSolvePento or lightSolveKatamino)
    // will be used instead of this one.
    const bool USE_LIGHTSOLVE=(!VERBOSE && OPTIMIZED_SOLVING);
    
    // Play each move and evaluate its result

    for (int i=0;i<MOVE_LIST_SIZE;i++){
	playMove(*move_list[i]);
	if (VERBOSE){
	    message << "solving move number " << i+1
		    << " at relative depth "   << rel_depth << " (" 
		    << move_list.size()-(i+1)
		    << " moves remaining)" << std::endl;
	    message << board;
	}

	Result result=UNKNOWN;

	try {
	    if (USE_LIGHTSOLVE){
		if (KATAMINO_RULES){
		    result=(lightSolveKatamino()==TOMOVE_LOSES) ? TOMOVE_WINS
			: TOMOVE_LOSES;
		}
		else {
		    result=(lightSolvePento()==TOMOVE_LOSES) ? TOMOVE_WINS
			: TOMOVE_LOSES;
		}
	    }
	    else {
		// The result will be the opposite of what has been returned,
		// since we are interested in the other side.
		result=(solve(best_moves,all,false,stats,rel_depth+1))
			==TOMOVE_LOSES ? TOMOVE_WINS : TOMOVE_LOSES;
	    }
	}
	catch (TimeOutError){
	    playLastMoveBack();
	    if (rel_depth==0){
		best_moves.push_back(*move_list[i]);
		return UNKNOWN;
	    }
	    throw;
	}
	playLastMoveBack();
	
	if (result == TOMOVE_WINS){
	    if(stats){
		Stats::shape_cutoff[ABSOLUTE_DEPTH][move_list[i]->pento_id]++;
		Stats::analyzed_before_cutoff[rel_depth][i]++;
	    }
	    move_list[i]->generatedACutoff(ABSOLUTE_DEPTH);
	    if (rel_depth != 0)
		return TOMOVE_WINS;
	    else {
		best_moves.push_back(*move_list[i]);
		if (!all)
		    return TOMOVE_WINS;
		else if (VERBOSE)
		    message << "Winning move !" << std::endl;
	    }
	}
    }
	
	
    // If no good move was found, play a random move
    if (rel_depth == 0){
	if (best_moves.size() == 0){
	    srand(time(0));
	    random_shuffle(move_list.begin(),move_list.end());
	    best_moves.push_back(*move_list[0]);
	}
	else
	    return TOMOVE_WINS;
    }
    return TOMOVE_LOSES;
}

int PositionData::getNRepliesToMove(const Move& M)
{
    // Moves which would be validated if M is played
    vector<MetaMove*> would_valid;
    const int NCAND=getNCand();

    // Tests have proven this to be slightly faster than not using it
    would_valid.reserve(NCAND);

    if (KATAMINO_RULES){
	const int ADJ_SIZE=M.adj.size();
	for (int i=0;i<ADJ_SIZE;i++){
	    const int POS_INT=(M.adj[i]).getInt(board.SIZE);
	    const vector<MetaMove*>::iterator END=square_index[POS_INT].end();
	    for (vector<MetaMove*>::iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
		
		if (((*it)->getNAdjacents() == 0) && ((*it)->isNearlyValid())){
		    (*it)->setToValid();
		    would_valid.push_back(*it);
		}
	    }
	}
    }
    
    // Moves Which would be invalidated if M is played
    vector<MetaMove*> would_invalid;

    // Reserve the maximum possible size (tests have proven this to be slightly
    // faster)
    would_invalid.reserve(NCAND);
    
    // Moves overstepping the played one
    for (int i=0;i<5;i++){
	const int POS_INT=(M.pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    if ((*it)->isValid()){
		would_invalid.push_back(*it);
		(*it)->setToNearlyValid();
	    }
	}
    }
    
    // Moves with the same pentomino id
    const int ID=M.pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[ID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[ID].begin()
	     ;it!=END;++it){	
	if ((*it)->isValid()){
	    would_invalid.push_back(*it);
	    (*it)->setToNearlyValid();
	}
    }

    // Re-valid all moves that have been invalidated
    const vector<MetaMove*>::iterator WI_END=would_invalid.end();
    for (vector<MetaMove*>::iterator it=would_invalid.begin();it!=WI_END;++it){
	(*it)->setToValid();
    }

    // reswitch the reasons_invalid
    const vector<MetaMove*>::iterator WV_END=would_valid.end();
    for (vector<MetaMove*>::iterator it=would_valid.begin()
	     ;it!=WV_END;++it){
	(*it)->setToNearlyValid();
    }

    return NCAND+(would_valid.size())-(would_invalid.size());
}



bool PositionData::findMove(Move& m)
{
    Move* p=getAllMovesPos(m);
    if (p){
	m=*p;
	return true;
    }
    else {
	return false;
    }
}


void PositionData::playMove(const Move& MOVE)
{
    board.playMove(MOVE);	// Physically play the move on the board

    // Get the played move id and register it as played
    MetaMove* m=getAllMovesPos(MOVE);
            
    playing_order.push_back(m);
    
    // Invalidate all moves overstepping the new pentomino
    for (int i=0;i<5;i++){
	const int POS_INT=(m->pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    
	    addReasonToInvalid(*it);
	}
    }

    // Invalidate all moves with the same pentomino id
    const int PID=MOVE.pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[PID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[PID].begin()
	     ;it!=END;++it){
	addReasonToInvalid(*it);
    }
    
    if (KATAMINO_RULES){	
	// Update all moves adjacent to the new pentomino
	const int ADJ_SIZE=MOVE.adj.size();
	for (int i=0;i<ADJ_SIZE;i++){
	    const int POS_INT=(MOVE.adj[i]).getInt(board.SIZE);
	    const vector<MetaMove*>::const_iterator END
		=square_index[POS_INT].end();
	    for (vector<MetaMove*>::const_iterator it=square_index[POS_INT]
		     .begin();it!=END;++it){
		addAdjacent(*it);
	    }
	}
    }   
}


void PositionData::playLastMoveBack()
{
    MetaMove* m=playing_order.back(); // Get the last played moves
                
    board.playMoveBack(*m);	// Physically play the move back

    // Erase from the lists of played moves
    playing_order.pop_back();
        
    // Decrement the invalidity of the moves that overstepped the pentomino

    for (int i=0;i<5;i++){
	const int POS_INT=(m->pos[i]).getInt(board.SIZE);
	const vector<MetaMove*>::const_iterator END=square_index[POS_INT].end();
	for (vector<MetaMove*>::const_iterator it=square_index[POS_INT].begin()
		 ;it!=END;++it){
	    // No move can be valid at that point, since it overstepped
	    // previously-played pentomino (and it overstepped itself...). Since
	    // the square_index does not change after initialization, we can be
	    // sure the move had been invalidated the same number of times as it
	    // is validated now, and hence is never valid before being
	    // validated...
	    addReasonToValid(*it);
	}
    }

    // Decrement the invalidity of the moves with the same pentomino id
    const int PID=m->pento_id;
    const vector<MetaMove*>::const_iterator END=pento_index[PID].end();
    for (vector<MetaMove*>::const_iterator it=pento_index[PID].begin()
	     ;it!=END;++it){
	// See the previous long comment for reasons why the move is _never_
	// valid before being validated.
	addReasonToValid(*it);
    }

    if (KATAMINO_RULES){	
	// Update all moves adjacent to the removed pentomino
	const int ADJ_SIZE=(*m).adj.size();
	for (int i=0;i<ADJ_SIZE;i++){
	    const int POS_INT=((*m).adj[i]).getInt(board.SIZE);
	    const vector<MetaMove*>::const_iterator END
		=square_index[POS_INT].end();
	    for (vector<MetaMove*>::const_iterator 
		     it=square_index[POS_INT].begin();
		 it!=END;++it){
		
		removeAdjacent(*it);
	    }
	}
    }
}


namespace Algo
{
    extern int WINSRATIO_SORTING_METHOD;
    extern int WINSRATIO_NMOVES[12];
    extern int WINSRATIO_MAX;
};


// Find the wins ratio for the side to move
int PositionData::findWinsRatio(int rel_depth)
{
    if (!getNCand())
	return 0;
    
    if (timeIsUp())
	throw TimeOutError();

    // get a list of moves to try
    vector<MetaMove*> move_list;

    getSortedList(static_cast<Method>(Algo::WINSRATIO_SORTING_METHOD)
		  ,move_list);
    
    int wr_sum=0;
    int n_moves=1;
    // call recursively for all the sample moves and update the data ...
    const vector<MetaMove*>::iterator END=move_list.end();
    for (vector<MetaMove*>::iterator it=move_list.begin();it!=END&&
	     n_moves<=Algo::WINSRATIO_NMOVES[rel_depth];++it,++n_moves){
	playMove(**it);
	try {
	    wr_sum+=Algo::WINSRATIO_MAX-findWinsRatio(rel_depth+1);
	}
	catch (TimeOutError){
	    playLastMoveBack();
	    throw;
	}
			
	playLastMoveBack();
    }

    return wr_sum/n_moves;
}

namespace Algo
{
    extern int IMPROVED_WINSRATIO_NGAMES;
    extern int IMPROVED_WINSRATIO_NRANDOM;
};


int PositionData::improvedWinsRatio()
{
    int wr_sum=0;
       
    const int DEPTH=playing_order.size();
    for (int i=0;i<Algo::IMPROVED_WINSRATIO_NGAMES;i++){

	if (timeIsUp())
	    throw TimeOutError();
				
	for (int j=0;j<Algo::IMPROVED_WINSRATIO_NRANDOM && getNCand();j++){
	    vector<MetaMove*> move_list;
	    getSortedList(RANDOM,move_list);
	    
	    playMove(**move_list.begin());
	}

	const int N_PLAYED=static_cast<int>(playing_order.size())-DEPTH;

	// Say if the solved game is won or not by root (the side having played
	// the candidate move.
	bool root_wins=(N_PLAYED % 2 == 0);
		
	if (getNCand()){
	    vector<Move> tmp;
	    // Do not reset the timer.
	    Result r=solve(tmp,false,false);
	    root_wins=((r == TOMOVE_WINS) != (N_PLAYED % 2 == 0));
	}
	
	for (int j=0;j<N_PLAYED;j++)
	    playLastMoveBack();
	
	if (root_wins)
	    wr_sum+=Algo::WINSRATIO_MAX;
    }
    
    return wr_sum/Algo::IMPROVED_WINSRATIO_NGAMES;
}




// The function will exit if it finds a single possibility of ending the game
// without a shortage of pentominoes

bool PositionData::badSettings()
{
    extern bool EXCLUDE_PENTO[12];
    extern int N_CHECK_RANDOM_GAMES;
        
    // Number of available pentominoes
    int n_pentominoes=0;
    
    for (int i=0;i<12;i++){
	if (!EXCLUDE_PENTO[i])
	    n_pentominoes++;
    }

    for (int i=0;i<N_CHECK_RANDOM_GAMES;i++){
	// Play a random game until there is no more moves
	while (getNCand()){
	    vector<MetaMove*> move_list;
	    
	    getSortedList(RANDOM,move_list);
	    playMove(*move_list[0]);
	}

	const int N_MOVES=playing_order.size();
		
	// Get back to the starting position
	while (playing_order.size())
	    playLastMoveBack();

	// If the game ends without shortage of pentominoes, the settings are
	// assumed okay
	if (N_MOVES < n_pentominoes)
	    return false;
	
    } // End for each game

    // All games ended with all pieces used: something is wrong
    return true;
}

