// Copyright (c) 2007 Sebastien Vasey
// Copyright (c) 2007 Yann Schoenenberger
/**
 * @file   stats.h
 * @author  Sebastien Vasey & Yann Schoenenberger
 * @date   Wed Sep 19 22:32:36 2007
 * 
 * @brief Contains the Stats namespace and the related functions.
 * 
 * 
 */

/*
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License along
   with this program; if not, write to the Free Software Foundation, Inc.,
   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
 
#ifndef INCLUDE_STATS
#define INCLUDE_STATS

#include <string>
using std::string;

extern string STATS_FILE;
/** 
 * Output statistics in a file. 
 * @warning Exit kinonk in case of error
 * 
 * @param file_name The file where you want to write the statistics.
 */
void outputStats(string file_name=STATS_FILE);

/**
 * Contains statistics filled during the analyze (ie PositionData::solve) that
 * will be written to a file is #STATS_FILE is not null.
 * 
 */

namespace Stats{
    /**
     * The program's return status (useless as of now)
     * 
     */

    int return_status;

    // 12 x size_matrix is the size of the matrixes below
    /**
     * The size of the second dimension of #analyzed_before_cutoff and
     * #number_candidates . This corresponds to the _maximum_ number of
     * candidates there can be on the board.
     * 
     */

    int size_matrix;

    //! The distribution of the number of analyzed moves before a cutoff at each
    //! depth e.g analyzed_before_cutoff[2][34] are the number of times there
    //! was 34 moves analyzed before a cutoff occured, at depth 2.
    unsigned long long *analyzed_before_cutoff[12];
    //! The distribution of the number of candidates at each depth. It has a
    //! size of 13, because there might be some situations where all pentominoes
    //! have been played and in that case, PositionData::solve will enter in a
    //! depth of 13, and will want to increment number_candidates[13][0] (as
    //! there are no candidates left).
    unsigned long long *number_candidates[13];
    //! The number of times each pentomino shape generates a cutoff at each
    //! depth, the first index being the depth and the second the pentomino id.
    unsigned long long shape_cutoff[12][12];
    
    /**
     * The total time in seconds the PositionData::solve function took to run.
     * 
     */

    double total_time=0;
};

#endif
