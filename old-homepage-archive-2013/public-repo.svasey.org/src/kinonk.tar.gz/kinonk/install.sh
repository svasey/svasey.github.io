#!/bin/sh
# Shell script used to install kinonk under linux and other unix-like systems.
# To use, simply invoke it without any argument.

INSTALL=`which install`
CP=`which cp`
MKDIR=`which mkdir`
AWK=`which awk`
TR=`which tr`

INSTALL_DIR="/usr/local/bin"
MANDIR="/usr/local/share/man/man6"
DOCDIR="/usr/local/share/doc"

if [ ! -f "build/kinonk" ]; then
    echo "No kinonk executable was found in the current directory. You must" \
	"build kinonk before calling that script.\n" 1>&2
    exit 1
fi
       
VERSION="$(./build/kinonk --version | $AWK '{print $3}' | $TR -d '\n')"

echo "Version: ${VERSION}"

if [ ! -d $INSTALL_DIR ]; then
    echo "The installation directory $INSTALL_DIR was not found. You can" \
    " change it by editing the INSTALL_DIR variable in install.sh" 1>&2
    exit 1
fi
if [ ! -d $MANDIR ]; then
    echo "The manual directory $MANDIR was not found. You can change it" \
    " by editing the MANDIR variable in install.sh" 1>&2
    exit 1
fi

if [ -f "doc/report/main.pdf" ] && [ ! -d "${DOCDIR}" ]; then
    echo "The documentation directory $DOCDIR was not found. You can change" \
	" it by editing the DOCDIR variable in install.sh" 1>&2
    exit 1
fi

$INSTALL --verbose "build/kinonk" "${INSTALL_DIR}" || exit 1
$INSTALL --verbose "man.kinonk" "${MANDIR}/kinonk.6" || exit 1
$MKDIR -p "${DOCDIR}/kinonk" && $CP -r --verbose doc/* "${DOCDIR}/kinonk" \
    || exit 1

echo "Installation succeeded"
exit 0
