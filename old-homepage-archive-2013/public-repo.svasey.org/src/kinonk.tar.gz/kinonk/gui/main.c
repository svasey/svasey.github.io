#include <gtk/gtk.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>


/* static gboolean destroy(GtkWidget* widget */
/*                         ,GdkEvent* data) */
/* { */
/*     return ; */
/* } */
/* static gboolean delete_event(GtkWidget* widget */
/*                             ,GdkEvent* event */
/*                             ,gpointer data) */
/* { */
/*     GtkWidget* dialog; */

/*     g_print("Delete event\n"); */

/*     dialog=gtk_dialog_new_with_buttons("Are you sure ?" */
/*                                        ,GTK_WINDOW(widget) */
/*                                        ,GTK_DIALOG_DESTROY_WITH_PARENT,"gruh","grah"); */

/*     gtk_widget_show(dialog); */



/* /\*     if (data && strcmp((gchar*)(data),(char*)"CANCEL") == 0){ *\/ */
/* /\*         g_print("Cancelling\n"); *\/ */
/* /\*         return TRUE; *\/ */
/* /\*     } *\/ */
/* /\*     else if (data){ *\/ */
        
/* /\*         g_print("Quiting: %s\n",(gchar*)data); *\/ */
/* /\*         gtk_main_quit(); *\/ */
/* /\*         return FALSE; *\/ */
/* /\*     } *\/ */
/* /\*     g_print("Entering function\n"); *\/ */
/* /\*     window=gtk_window_new(GTK_WINDOW_TOPLEVEL); *\/ */
/* /\*     g_signal_connect(G_OBJECT(window),"delete_event" *\/ */
/* /\*                      ,G_CALLBACK(delete_event),(char*)"CANCEL"); *\/ */
    
/* /\*     gtk_window_set_title(GTK_WINDOW(window),"Are you sure ?"); *\/ */
/* /\*     box=gtk_hbox_new(FALSE,0); *\/ */
/* /\*     gtk_container_add(GTK_CONTAINER(window),box); *\/ */
/* /\*     button=gtk_button_new_with_label("Yes"); *\/ */
/* /\*     g_signal_connect(G_OBJECT(button),"clicked" *\/ */
/* /\*                      ,G_CALLBACK(delete_event),(char*)"YES"); *\/ */
/* /\*     gtk_box_pack_start(GTK_BOX(box),button,TRUE,TRUE,0); *\/ */
/* /\*     gtk_widget_show(button); *\/ */
/* /\*     button=gtk_button_new_with_label("No"); *\/ */
/* /\*     g_signal_connect(G_OBJECT(button),"clicked" *\/ */
/* /\*                      ,G_CALLBACK(delete_event),(char*)"YES"); *\/ */
/* /\*     gtk_box_pack_start(GTK_BOX(box),button,TRUE,TRUE,0); *\/ */
/* /\*     gtk_widget_show(button); *\/ */
/* /\*     gtk_widget_show(box); *\/ */
/* /\*     gtk_widget_show(window); *\/ */
    
/* /\*     gtk_main(); *\/ */
/* /\*     g_print("Cancelling\n"); *\/ */
/*     gtk_main_quit(); */

/*     return FALSE; */
/* } */

/* static void destroy(GtkWidget* widget */
/*                     ,gpointer data) */
/* { */
/*     g_print("Destroy event !\n"); */
/*     gtk_main_quit(); */
/* } */

struct move_t
{
    GtkFixed* fixed;
    int x;
    int y;
};

struct block_t
{
    GtkWidget* widget;
    gulong sigid;
};


static gboolean move_button(GtkWidget* widget,GdkEventMotion* event
                            ,struct move_t* move)
{
    int x_child=((GtkFixedChild*)(move->fixed->children->data))->x;
    int y_child=((GtkFixedChild*)(move->fixed->children->data))->y;

/*     x=rand()%200; */
/*     y=rand()%200; */

    int x=event->x;
    int y=event->y;

/*     g_print("Calling move_button, event type: %d, pos child: %d,%d move:%d,%d\n" */
/*             ,event->type,x_child,y_child,x,y); */

    gtk_fixed_move(GTK_FIXED(move->fixed),widget,x_child+x-widget->
                   allocation.width/2,y_child+y-widget->allocation.height/2);

    gtk_button_pressed((GtkButton*) widget);

    return TRUE;

}

/* static gboolean block_dnd(GtkWidget* widget,GdkEventButton* event */
/*                           ,struct block_t* data) */
/* { */
/*     g_print("Move button blocked\n"); */
/*     if (g_signal_handler_is_connected(G_OBJECT(data->widget),data->sigid)){ */
/*         g_signal_handler_block(G_OBJECT(data->widget),data->sigid); */
/*     } */
/*     return TRUE; */
/* } */

/* static gboolean enable_dnd(GtkWidget* widget,GdkEventButton* event */
/*                            ,struct block_t* data) */
/* { */
/*     g_print("Move button unblocked\n"); */
/*     if (!g_signal_handler_is_connected(G_OBJECT(data->widget),data->sigid)){ */
/*         g_signal_handler_unblock(G_OBJECT(data->widget),data->sigid); */
/*     } */
/*     return TRUE; */
/* } */

 
 


int main(int argc,char* argv[])
{

    GtkWidget* window;
    GtkWidget* button;
    GtkWidget* fixed;
    struct move_t my_move;
    struct move_t my_2nd_move;
    GtkAllocation allocation;
/*     struct block_t block; */




    srand(time(NULL));


    gtk_init(&argc,&argv);


    window=gtk_window_new(GTK_WINDOW_TOPLEVEL);

    gtk_window_set_title(GTK_WINDOW(window),"Kinonk\n\n");
    

    g_signal_connect(G_OBJECT(window),"delete_event"
                     ,G_CALLBACK(gtk_main_quit),NULL);

    gtk_container_set_border_width(GTK_CONTAINER(window),10);

    button=gtk_button_new();

    allocation.width=200;
    allocation.height=200;
    
    gtk_widget_size_allocate(window,&allocation);
    
    allocation.x=allocation.width/2;
    allocation.y=allocation.height/2;
    allocation.width=50;
    allocation.height=50;

    gtk_widget_size_allocate(button,&allocation);

    fixed=gtk_fixed_new();

    my_move.fixed=(GtkFixed*)(fixed);
    my_move.x=100;
    my_move.y=100;

    my_2nd_move.fixed=(GtkFixed*)(fixed);
    my_2nd_move.x=-100;
    my_2nd_move.y=-100;

    gtk_container_add(GTK_CONTAINER(window),fixed);
    gtk_widget_show(fixed);
    gtk_fixed_put(GTK_FIXED(fixed),button,0,0);

    gtk_widget_set_events(button,GDK_BUTTON_MOTION_MASK);
/*     gtk_widget_add_events(button,GDK_BUTTON_MOTION_MASK); */
    
    g_signal_connect(G_OBJECT(button),"motion-notify-event"
                     ,G_CALLBACK(move_button),&my_move);
    
/*     block.widget=(GtkWidget*)(button); */
/*     g_signal_connect(G_OBJECT(button),"button-press-event" */
/*                      ,G_CALLBACK(enable_dnd),&block); */
/*     g_signal_connect(G_OBJECT(button),"button-release-event" */
/*                      ,G_CALLBACK(block_dnd),&block); */

/*     block_dnd(button,NULL,&block); */

    gtk_widget_show(button);


/*     button=gtk_button_new_with_label("Quit\nGruh\n"); */
/*     g_signal_connect(G_OBJECT(button),"clicked" */
/*                      ,G_CALLBACK(delete_event),(gpointer)"Hello world"); */
/*     gtk_box_pack_end(GTK_BOX(box1),button,TRUE,TRUE,0); */
    gtk_widget_show(window);

    gtk_main();

    return 0;
}
