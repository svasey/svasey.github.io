#!/bin/sh 
# This converts the kinonk manual page to 'manual.tex' in the doc/report
# directory. 

SED=`which sed`
MAN=`which man`
CAT=`which cat`

OUTPUT="doc/report/manual.txt"
INPUT="./man.kinonk"

# The '^H' things are actually some weird special characters that we do not
# want.
$MAN -P "${CAT} -v" "${INPUT}" | $SED 's/.\^H//g' > "${OUTPUT}"

exit $?
