/* Contains functions or predicates performing basic operations on the
   filesystem  */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_FS_H
#define INCLUDE_FS_H

#include <sys/stat.h>

#include "dt.h"


/* What gets appended to the name of backup files */
#define FS_BACKUP_SUFFIX ".bckp"


/* 
NOTE ON RETURN VALUES 

Unless otherwise noted, those functions always return -1 if something went wrong
setting urpkg_errno appropriately (see error.h). It is up to you to check the
function's return value. Otherwise, most functions will return 0 in case of
success. Functions whose name end with a _p are predicates i.e they return
either true (1) or false (0) still as said before some can return -1 in case of
error.
*/

/* Copy src to dest, _not_ preserving permissions, owners and groups */
int
fs_copy_file (const char *src,const char *dest);

/* Change a file's metadata (i.e permission, owner and group) */
int
fs_set_metadata (const char *dest,const struct stat *fst);

/* Copy src to dest, preserving permissions, owners and groups */
int
fs_copy_preserve (const char *src,const char *dest);

/* Do a backup of src. Use fs_restore_backup to restore it. */
int
fs_make_backup (const char *src);

/* Restore the backup of src, i.e src.bckp */
int
fs_restore_backup (const char *src);

/* Separate the files in file_list into regular files and directories */
int
fs_find_directories (const struct string_list *file_list,
		     struct string_list *files,struct string_list *directories);

/* Create an empty file */
int
fs_file_create (const char *filename,mode_t mode,uid_t uid,gid_t gid);

/* Create an empty directory */
int
fs_dir_create (const char *path,mode_t mode,uid_t uid,gid_t gid);

/* Put the name of the filename's group in group (which must be large enough to
   hold it i.e at least FS_GROUP_LENGTH large). If filename is a symbolic link,
   then the link itself is checked, not the file it points to */
int
fs_file_group (const char *filename,char *group);

/* Put the name of the filename's owner in owner (which must be large enough to
   hold it i.e at least FS_USER_LENGTH large). If filename is a symbolic link,
   then the link itself is checked, not the file it points to. */
int
fs_file_owner (const char *filename,char *owner);

/* Set the owner of filename to the given owner */
int
fs_file_chown (const char *filename,const char *owner);

/* Set the group of filename to the given group */
int
fs_file_chgrp (const char *filename,const char *group);

/* Remove a file or a directory (recursively) from the filesystem. Return
   success in case the file does not exist */
int
fs_file_delete (const char *filename);

/* Turn the sticky bit on in the file's permissions if sticky is true, remove
   it otherwise */
int
fs_file_set_sticky (const char *filename,int sticky);

/* Turn the group write bit on in the file's permission if gw is true, remove
   it otherwise */
int
fs_file_set_gw (const char *filename,int gw);

/* Return true if we can change the owner or group of the given file */
int
fs_can_chown_p (const char *filename);

/* Return true if we can write in filename, false otherwise */
int
fs_can_write_p (const char *filename);

/* Return true if we have read permission on the file, false otherwise */
int
fs_can_read_p (const char *filename);

/* Return true if the file exists, isn't a directory (more precisely, is a
   regular file) and has executable permission  */
int
fs_can_run_p (const char *filename);

/* Return true if f1 and f2 are the same file. If either of f1 or f2 is a
   symlink, then the symlink is _not_ dereferenced. */
int
fs_samefile_p (const char *f1,const char *f2);

/* Return true if the basename of filename is either . or .. 
This function is always successful (i.e it never returns -1) */
int
fs_is_dirbase_p (const char *filename);

/* Return true if filename is in the path described in path. */
int
fs_is_inpath_p (const char *path,const char *filename);

/* Return true if filename is a directory. filename must exist otherwise an
   error is returned. If filename is a symlink, then it is not a directory. */
int
fs_is_directory_p (const char *filename);

/* Return true if the file is a non-empty directory. Our definition of empty:
   no standard file in the directory and its subdirectories (i.e the directory
   can only contain empty directories) */
int
fs_is_nonempty_dir_p (const char *filename);

/* Return true if the string that is given looks like an absolute path. Makes
   no check on the existence of the path. This function is always successful */
int
fs_abspath_p (const char *path);

/* Return true if the given file exists. Always successful. If we cannot know
   whether the file exists or not (i.e because we cannot see what is in the
   directory), then the function will return false. If the file is a symbolic
   link, it is enough for it to exist (i.e it doesn't have to point to any
   valid file) */
int
fs_file_exists_p (const char *filename);

/* Return true if the file has the sticky bit set */
int
fs_is_sticky_p (const char *filename);

/* Return true if the directory (or file) has group write permission */
int
fs_is_gw_p (const char *filename);

/* True if the file has the given group as its group */
int
fs_in_group_p (const char *filename,const char *group);

#endif	/* INCLUDE_FS_H */
