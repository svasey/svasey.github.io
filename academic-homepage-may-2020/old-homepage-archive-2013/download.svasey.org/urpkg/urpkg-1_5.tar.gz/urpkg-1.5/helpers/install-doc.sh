#!/bin/bash

# Install the documentation that was built. Argument: project root directory,
# project doc build directory, system documentation directory, system
# man directory

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 project_root_dir documentation_build_dir" \
    "documentation_dir man_dir" 1>&2
}

if [ $# -ne 4 ]; then
    usage
    exit 1
fi

PROJECT_ROOT="$1"
DOCBUILD_ROOT="$2"
DOCDIR="$3"
MANDIR="$4"

VERSION="$(${PROJECT_ROOT}/helpers/version.sh $PROJECT_ROOT)"
DEST_DOCDIR="${DOCDIR}/urpkg-${VERSION}"

echo "Creating documentation directory..."
install -v -d -m0755 $DEST_DOCDIR

txt_files=$(ls ${PROJECT_ROOT}/{README,TODO,INSTALL,FAQ,BUGS,COPYING,FDL,NEWS})
html_files=$(ls ${DOCBUILD_ROOT}/*.html 2>/dev/null || true)
prebuilt_html=$(ls ${PROJECT_ROOT}/doc/html/*.html 2>/dev/null || true)
man_files=$(ls ${DOCBUILD_ROOT}/*.{1,2,3,4,5,6,7,8,9,0p,3p} 2>/dev/null || true)
prebuilt_man=$(ls ${PROJECT_ROOT}/doc/man/* 2>/dev/null || true)

echo "Installing html documentation files..."
install -v -m0644 $txt_files $html_files $prebuilt_html $DEST_DOCDIR

echo "Install manpages..."

for f in $man_files $prebuilt_man ; do
    EXT="$(echo $f | sed -r 's/.+\.//')"
    DEST="${MANDIR}/man${EXT}"

    install -v -m0644 $f $DEST
done

echo "Documentation installed"

exit 0
