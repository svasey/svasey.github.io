/* Contains prototypes of functions dealing with process (i.e spawning and
   killing them) */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_PROC_H
#define INCLUDE_PROC_H

#include <stdio.h>

/* Maximum number of process we can run simultaneously */
#define MAX_PROCESS 32

struct process
{
	/* Pid of the process. A pid of 0 implies an empty element */
	int pid;
	/* Stream where stderr is redirected. */
	FILE *err_stream;
	/* Stream where stdout is redirected */
	FILE *out_stream;
};

struct process process_table[MAX_PROCESS];

/* Run a command using proc_run , and check its error status. If < 0, return
   -1. If != 0 set urpkg_errno and return -1. Otherwise, do nothing. */
#define PROC_RUN_CHECK(cmd,argv)	\
	do {					\
		int r = proc_run (cmd,argv);	\
		if (r < 0){			\
			return -1;		\
		}				\
		else if (r != 0){		\
			error_set (CMD_ERROR,cmd,argv,r);	\
			return -1;				\
		}						\
	} while (0)

/* Add an entry to the process table */
void
proc_table_add (int pid,FILE *out,FILE *err);

/* Remove an entry from the proc_table, closing the streams in the process). If
   pid is non-zero, consider the pid as a criteria, otherwise if either one of
   out or err is non-NULL they will be considered. The element we want to delete
   _must_ exist. */
void
proc_table_remove (int pid,const FILE *out,const FILE *err);

/* Set the proc table to reasonnable values */
void
proc_table_init (void);

/* This will run a command with some argument in a forked process. The pid of
   the new process will be put in the pid pointer. The function will return a
   stream open for reading containing the process' stdout. If err is non NULL,
   then stderr is redirected to *err additionaly. Note that args
   must be terminated by a NULL pointer. argv[0] should contains the command
   itself. A return value of NULL implies an error, and urpkg_errno will be set
   accordingly. execvp is used for launching the command. */
FILE *
proc_open (const char *cmd,char *const argv[],int *pid,FILE **err);

/* This closes all streams associated with pid, and wait for the process to
   finish. Return its exit status, or -1 if some error happened */
int
proc_close (int pid);

/* Close all process in the stream table. Even if an error happens, continue to
   close the other process. */
int
proc_close_all (void);

/* Terminate (first by sending sigterm and then sigkill) a process opened by
   xpopen_pid , and close all streams associated with it */
int
proc_kill (int pid);

/* Run a command with some arguments (args has to end with a NULL element) in a
   forked process. Do not redirect any outputs, wait until the process finishes
   and return its exit status, or -1 if an error occured. */
int
proc_run (const char *cmd,char *const argv[]);

/* Return a dynamicaly allocated string with each element of args,
   space-separated. args is a NULL-ended array of arguments */
const char *
proc_args_to_str (char *const args[]);

#endif	/* INCLUDE_PROC_H */


