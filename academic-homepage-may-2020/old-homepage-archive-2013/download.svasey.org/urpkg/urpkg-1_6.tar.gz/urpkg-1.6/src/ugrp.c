/* Contains the implementation of the functions declared in ugrp.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <sys/types.h>
#include <grp.h>
#include <ctype.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>

#include "ugrp.h"
#include "io.h"
#include "error.h"
#include "str.h"
#include "mem.h"

int
ugrp_userchar_p (char c)
{
	if ((! islower (c)) && (! isdigit (c)) && (c != '_') && (c != '-')
	    && (c != '$')){
		return 0;
	}
	else {
		return 1;
	}
}

int
ugrp_check_format (const char *name)
{
	int i;
	
	xdebug ("%s (%s)\n",__FUNCTION__,name);

	/* Check the length */
	if (strlen (name) >= UGRP_CR_MAX_LENGTH){
		error_set (UGNAME_ERROR,name,"Too long");
		return -1;
	}

	/* Check that there is no forbidden character. According to the groupadd
	   and useradd man page, the name format must be [a-z_][a-z0-9_-]*[$]
	   This is simple enough to be checked without compiling the regular
	   expression */
	if ((! islower (name[0])) && (name[0] != '_')){
		error_set (UGNAME_ERROR,name,"Must begin with a lowercase "
			   "letter or an underscore (_)");
		return -1;
	}
	for (i = 1;i < strlen (name);i++){
		if (! ugrp_userchar_p (name[i])){
			error_set (UGNAME_ERROR,name,"Only lowercase letters, "
				   "dashes, underscores, numbers and dollars "
				   "are allowed");
			return -1;
		}
	}

	return 0;	
}

void
ugrp_replace_weirdchar (char *user)
{
	/* The character that will replace any nonvalid char */
	const char GENERIC_CHAR = '_';
	int i;

	if ((! islower (user[0])) && (user[0] != '_')){
		user[0] = GENERIC_CHAR;
	}

	xassert (ugrp_userchar_p (user[0]));
	for (i = 0;user[i] != '\0';i++){
		if (! ugrp_userchar_p (user[i])){
			user[i] = GENERIC_CHAR;
		}
		xassert (ugrp_userchar_p (user[i]));
	}
}

int
ugrp_group_exists_p (const char *gname,struct group **gd)
{
	int errno_old = errno;
	int ret;
	struct group *ret_gd;
	
	xdebug ("%s (%s,%p)\n",__FUNCTION__,gname,gd);

	errno = 0;
	if ( (ret_gd = getgrnam (gname)) != NULL){
		ret = 1;

	}
	else {
		/* Differentiate between non-existent group, or errors while
		   looking for it */
		if ((errno == EINTR) || (errno == EIO) || (errno == EMFILE)
		    || (errno == ENFILE) || (errno == ENOMEM)
		    || (errno == ERANGE)){
			error_set (UGFIND_ERROR,gname,strerror (errno));
			return -1;
		}
		else {
			ret = 0;
		}
	}
	errno = errno_old;
	if (gd != NULL){
		*gd = ret_gd;
	}

	xdebug ("%s : %d\n",__FUNCTION__,ret);
	return ret;
}

int
ugrp_user_exists_p (const char *uname,struct passwd **ud)
{
	int errno_old = errno;
	int ret;
	struct passwd *ret_ud;

	xdebug ("%s (%s,%p)\n",__FUNCTION__,uname,ud);

	errno = 0;
	if ( (ret_ud = getpwnam (uname)) != NULL){
		ret = 1;
	}
	else {
		/* Differentiate between non-existent user or errors while
		   looking it up */
		if ((errno == EINTR) || (errno == EIO) || (errno == EMFILE)
		    || (errno == ENFILE) || (errno == ENOMEM)
		    || (errno == ERANGE)){
			error_set (UGFIND_ERROR,uname,strerror (errno));
			return -1;
		}
		else {
			ret = 0;
		}
	}
	errno = errno_old;
	if (ud != NULL){
		*ud = ret_ud;
	}

	xdebug ("%s : %d\n",__FUNCTION__,ret);
	return ret;
}

const char *
ugrp_user_homedir (const char *username)
{
	struct passwd *ud;

	xdebug ("%s (%s)\n",__FUNCTION__,username);

	xassert (ugrp_user_exists_p (username,NULL) == 1);

	if ( (ud = getpwnam (username)) == NULL){
		error_set (UGFIND_ERROR,username,strerror (errno));
		return NULL;
	}

	xdebug ("%s : %s\n",__FUNCTION__,ud->pw_dir);
	return ud->pw_dir;
}

int
ugrp_save_gid (void)
{
	static int first = 1;
	
	ugrp_old_supgid_size = 0;
	if (!first){
		free (ugrp_old_supgid);
	}
	ugrp_old_supgid = NULL;

	first = 0;
	ugrp_old_primgid = getgid ();
	ugrp_old_supgid_size = getgroups (0,NULL);


	if (ugrp_old_supgid_size < 0){
		error_set (CUSTOM_ERROR,"Could not save supplementary gids: %s "
			   "\n",strerror (errno));
		return -1;
	}

	ugrp_old_supgid = xmalloc (ugrp_old_supgid_size * sizeof(gid_t));
	getgroups (ugrp_old_supgid_size,ugrp_old_supgid);

	return 0;
}

int
ugrp_restore_gid (void)
{
	if (setregid (ugrp_old_primgid,ugrp_old_primgid) < 0){
		error_set (CUSTOM_ERROR,"Could not set primary gids: %s "
			   "\n",strerror (errno));
		return -1;
	}
	
	if (ugrp_old_supgid_size == 0){
		return 0;
	}
	
	if (setgroups (ugrp_old_supgid_size,ugrp_old_supgid) < 0){
		error_set (CUSTOM_ERROR,"Could not set supplementary gids: %s "
			   "\n",strerror (errno));
		return -1;
	}

	return 0;
}

int
ugrp_restore_privilleges (void)
{
	int r;

	xlog ("Restoring privilleges...\n");

#ifdef _POSIX_SAVED_IDS
	r = seteuid (getuid ());
#else
	r = setreuid (-1,getuid ());
#endif
/* 	if (r >= 0){ */
/* 		r = setregid (getgid (),getgid ()); */
/* 	} */

	if (r < 0){
		error_set (PRIV_ERROR,strerror (errno));
		return -1;
	}

	/* Restore the supplementary group ids */
	if (ugrp_restore_gid () < 0){
		return -1;
	}

	ugrp_dropped_privilleges = 0;
	
	xlog ("Privilleges restored\n");
	return 0;
}

int
ugrp_drop_privilleges (const char *user)
{
	struct passwd *ud;
	int uid;
	int gid;
	int r;
	
	xlog ("Dropping privilleges: running as user %s\n",user);

	ugrp_dropped_privilleges = 1;
	r = ugrp_user_exists_p (user,&ud);

	if (r < 0){
		return -1;
	}
	else if (!r){
		error_set (UGNEXIST_ERROR,user);
		return -1;
	}
	
	uid = ud->pw_uid;
	gid = ud->pw_gid;

	/* Save supplementary group ids */
	if (ugrp_save_gid () < 0){
		return -1;
	}


	/* We have to start by changing the group ids since we must keep our uid
	   privillege for doing that */

	/* Set supplementary group ids */
	if (initgroups (ud->pw_name,-1) < 0){
		error_set (CUSTOM_ERROR,"Could not set the supplementary gids "
			   "for user %s : %s\n",ud->pw_name,strerror (errno));
		return -1;
	}

	/* We set both our group id, since otherwise the real one might be used
	   by some shells. */
	r = setregid (gid,gid);

#ifdef _POSIX_SAVED_IDS
	if (r >= 0){
		r = seteuid (uid);
	}
#else
	if (r >= 0){
		r = setreuid (-1,uid);
	}
#endif
	
	if (r < 0){
		error_set (PRIV_ERROR,strerror (errno));
		return -1;
	}

	xlog ("Privilleges dropped\n");
	return 0;
}

int
ugrp_have_privilleges_p (void)
{
	const int ROOT_UID = 0;

	if (getuid () == ROOT_UID){
		return 1;
	}
	else {
		return 0;
	}
}

const char *
ugrp_read_comment (const char *username)
{
	struct passwd *ud;

	errno = 0;
	if ( (ud = getpwnam (username)) == NULL){
		if (errno != 0){
			error_set (UGFIND_ERROR,username,strerror (errno));
		}
		else {
			error_set (UGNEXIST_ERROR,username);
		}
		return NULL;
	}
	xassert (ud->pw_gecos != NULL);

	return ud->pw_gecos;
}

