/* Declarations of a few data types that are used in the program */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#ifndef INCLUDE_DT_H
#define INCLUDE_DT_H

#include <getopt.h>
#include <stdarg.h>

#include "stdlib.h"

/* Match a string to another string */
struct dictionary
{
	/* Number of elements we allocate everytime we run out of memory */
	int alloc_step;
	int size;
	/* Number of elements for which memory has been
	   allocated */
	int allocated_size;
	char **keys;
	char **values;
};

struct string_list_el
{
	char *string;
	struct string_list_el *next;
};

/* Singly linked list of character strings */
struct string_list
{
	int size;
	struct string_list_el *last;
	struct string_list_el *first;
};

/* Dynamically allocated string */
struct alloc_string
{
	/* Number of characters that were allocated */
	size_t size;
	char *str;
};

/* Initialize before use. Size is a guess on how many characters we are going to
   need */
void
alloc_string_init (struct alloc_string *astr,size_t size);

/* Add another string to str. (as strcat, but take care of dynamical
   allocations) */
void
alloc_string_push (struct alloc_string *astr,const char *fmt,...)
	__attribute__ ((format (printf,2,3)));

/* Same as alloc_string_push but using a variadic list of argument directly */
void
alloc_string_push_valist (struct alloc_string *astr,const char *fmt,va_list ap);

/* Free everything that has been allocated */
void
alloc_string_free (struct alloc_string *astr);

/* Get the string we have built. */
const char *
alloc_string_read (const struct alloc_string *astr);

/* Initialize a given dictionary */
void
dictionary_init (struct dictionary *dict);

/* Free all elements of a dictionary */
void
dictionary_free (struct dictionary *dict);

/* Add a key value pair to the dictionary */
void
dictionary_add (struct dictionary *dict,const char *key,const char *value);

/* Put the content of a dictionary in a list. The first key is followed by the
   first value, followed by the second key etc...  */
void
dictionary_to_list (const struct dictionary *dict,struct string_list *l);

/* Return true if dict is empty, false otherwise */
int
dictionary_empty_p (const struct dictionary *dict);

/* Print each key / value pair of the dictionary, separated by a new line. The
   key and value are separated by sep */
void
dictionary_print (void (*formatf)(const char *fmt,...),
		  const struct dictionary *dict,const char *sep);


/* Get the value for a given key, or NULL if the key does not exist */
const char *
dictionary_get_val (const struct dictionary *dict,const char *key);

/* Get the key for a given value. If there is more than one possibility, return
   any of them. If no match was found, return NULL */
const char *
dictionary_get_key (const struct dictionary *dict,const char *value);

/* Get at most n keys for the given value; put them in list */
void
dictionary_get_n_keys (const struct dictionary *dict,const char *value,
		       struct string_list *dest,int n);

/* Initialize a given string list */
void
string_list_init (struct string_list *l);

/* Free all the elements of l to get back to the state of a new list after
   string_list_init_ */
void
string_list_free (struct string_list *l);

void
string_list_add (struct string_list *l,const char *str);

/* Remove an element el from the list, knowing that its previous element is
   prev */
void
string_list_remove_fast (struct string_list *l,struct string_list_el *el,
			 struct string_list_el *prev);

/* Remove an element from a list */
void
string_list_remove (struct string_list *l,struct string_list_el *el);

/* Return an iterator to get the content of each element */
struct string_list_el *
string_list_it (const struct string_list *l);

/* Return the first element of the list */
const char *
string_list_first (const struct string_list *l);

/* Return the number of elements in l */
int
string_list_size (const struct string_list *l);

/* Find an occurence of key in list using the given function to compare
   elements. Set pos to indicate the position of the first matching
   occurence. If pos is null, this either means the key was not found (returns
   0) or that some error happened using the given predicate (return -1) */
int
string_list_find (const struct string_list *l,const char *key,
		  struct string_list_el **pos,
		  int (*equal_p)(const char *el1,const char *el2));

/* Same as string_list_find, but starting from start */
int
string_list_find_at (struct string_list_el *start, const char *key,
		     struct string_list_el **pos,
		     int (*equal_p)(const char *el1,const char *el2));

/* Remove duplicate entries from the list, so that all remaining strings are
   unique. Two strings are considered equal if predicate(string1,string2)
   returns 1. If it returns a negative value, this is taken as an error and the
   function will return -1 */
int
string_list_remove_dup (struct string_list *l,
			int (*equal_p)(const char *el1,const char *el2));

/* Return true if l has no element */
int
string_list_empty_p (const struct string_list *l);

/* Print each element of l separated by a new line using formatf */
void
string_list_print (void (*formatf)(const char *fmt,...),
		   const struct string_list *l);

/* Cat b at the end of a, and put the new list in dest */
void
string_list_cat (const struct string_list *a,const struct string_list *b,
		 struct string_list *dest);

/* Given an array of pointers, get its size assuming it is
   terminated by the NULL element. el_size is the size of one element */
int
nullarray_size (const void *array,size_t el_size);

/* Get the size of an option array */
int
optarray_size (const struct option opt[]);


#endif	/* INCLUDE_DT_H */
