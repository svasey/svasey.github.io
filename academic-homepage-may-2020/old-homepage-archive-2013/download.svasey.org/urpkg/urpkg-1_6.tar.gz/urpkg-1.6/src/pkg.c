/* Contains implementation of the functions declared in pkg.h */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "pkg.h"
#include "urpkg.h"
#include "io.h"
#include "error.h"
#include "str.h"

int
pkg_user_name_table_build (void)
{
	struct passwd *ud;
	int r;

	xdebug ("%s ()\n",__FUNCTION__);
	dictionary_init (&pkg_user_name_table);
	
	setpwent ();
	errno = 0;
	while ( (ud = getpwent ()) != NULL){
		r = pkguser_p (ud->pw_name);
		if (r < 0){
			return -1;
		}
		else if (r){
			const char *username = ud->pw_name;
			const char *pkgname = ugrp_read_comment (username);

			if (pkgname == NULL){
				return -1;
			}
			pkg_user_name_add_match (username,pkgname);

		}
		errno = 0;
	}
	endpwent ();
	if (errno != 0){
		error_set (UGFIND_ERROR,NULL,strerror (errno));
		return -1;
	}

	pkg_built_table = 1;

	return 0;
}

void
pkg_user_name_add_match (const char *username,const char *pkgname)
{
	dictionary_add (&pkg_user_name_table,username,pkgname);
}

int
pkg_guess (char *name)
{
	char cwd[PATH_MAX];
	char *base;

	xlog ("Guessing package name\n");

	if (getcwd (cwd,PATH_MAX) == NULL){
		error_set (DIR_ERROR,"Current directory",strerror (errno));
		return -1;
	}

	if (strlen (cwd) == 0){
		error_set (CUSTOM_ERROR,"Could not guess package name: no "
			   "current directory");
		return -1;
	}

	base = strrchr (cwd,'/') + 1;
	if (base == NULL){
		error_set (CUSTOM_ERROR,"No / in current directory %s",cwd);
		return -1;
	}
	if (strchr (base,'-') == NULL){
		time_t timer = time (NULL);
		struct tm *date;
		/* Version string: -yyymmdd + null byte: 10 characters */
		char datestr[10];

		date = localtime (&timer);
		sprintf (datestr,"-%.4d%.2d%.2d",date->tm_year + 1900,
			 date->tm_mon + 1,date->tm_mday);
		xassert ((strlen (cwd) + strlen (datestr)) < PATH_MAX);
		strcat (cwd,datestr);
	}

	if (strlen (base) >= PKG_MAX_LENGTH){
		error_set (CUSTOM_ERROR,"Cannot guess package name from "
			   "current directory: too long (%s has more than "
			   "%d characters)",base,PKG_MAX_LENGTH - 1);
		return -1;
	}

	string_up_to_low (name,base);
	
	xlog ("Guess: package name: '%s'\n",name);
	
	return 0;
}

int
pkg_next_username (char *user)
{
	/* We expect the following: the username is never full length,
	   unless it has already been incremented. If it has already
	   been incremented, the name is terminated with a _ and some
	   number. In regular expression term: '.+_[0-9]+' The _
	   determines when the increment number in the username
	   begins. */

	/* Get cursor position */
	char *cursor = strrchr (user,'_');
	/* Get increment number */
	long long increment;
	char increment_string[UGRP_CR_MAX_LENGTH];
	
	/* Username has not yet been incremented */
	if ((strlen (user) + 1) < UGRP_CR_MAX_LENGTH){
		/* Fill the last letters with _ and begin to increment */
		int i;

		for (i = strlen (user) - 1;i < (UGRP_CR_MAX_LENGTH - 1);i++){
			user[i] = '_';
		}
		user[UGRP_CR_MAX_LENGTH - 1] = '\0';
		user[UGRP_CR_MAX_LENGTH - 2] = '0';
		user[UGRP_CR_MAX_LENGTH - 3] = '_';

		return 0;
	}
	
	sscanf (cursor + 1,"%lld",&increment);
	
	increment++;
	/* Print the increment at the end */
	sprintf (increment_string,"%lld",increment);
	if (strlen (increment_string) == strlen (cursor)){
		strcpy (cursor,increment_string);
		*(cursor - 1) = '_';
	}
	else {
		strcpy (cursor + 1,increment_string);
	}
	if (! string_beginwith_p (user,USER_PREFIX)){
		error_set (UGNAME_ERROR,user,"Name was incremented "
			   "too much and does not begin with %s "
			   "anymore. This is probably a bug, unless "
			   "you really have tons of package usernames",
			   USER_PREFIX);
		return -1;
	}

	return 0;
}

int
pkg_build_user (const char *name,char *user)
{
	int prefix_length;
	int r;
	
	xlog ("Building user from package name %s\n",name);

	xassert (name != NULL);
	/* Add as many letters of the package name as possible to the
	   username */
	strcpy (user,USER_PREFIX);
	prefix_length = strlen (USER_PREFIX);
	strncpy (user + prefix_length,name,
		 UGRP_CR_MAX_LENGTH - prefix_length - 2);
	/* Notice that we have saved one space for an eventual digit */
	user[UGRP_CR_MAX_LENGTH - 2] = '\0';
	ugrp_replace_weirdchar (user);
	r = pkguser_p (user);
	if (r < 0){
		return -1;
	}
	while (r){
		if (pkg_next_username (user) < 0){
			return -1;
		}
		r = pkguser_p (user);
		if (r < 0){
			return -1;
		}
	}

	xlog ("Built user %s from package name %s\n",user,name);
	return 0;
}

int
pkg_name_to_user (const char *name,char *user,int in_db)
{
	struct string_list resolve_list;
	struct string_list_el *it;
	int n_match = 0; /* Number of match found */
	/* Resolved package name */
	const char *res_pkgname = NULL;
	const char *username;
	const char *pkgname;

	xdebug ("%s (%s,%p)\n",__FUNCTION__,name,user);
	if (!pkg_built_table){
		if (pkg_user_name_table_build () < 0){
			return -1;
		}
	}
	
	if (!in_db){
		if (name == NULL){
			char pkgname[PKG_MAX_LENGTH];
			if (pkg_guess (pkgname) < 0){
				return -1;
			}
			name = pkgname;
		}
		if (dictionary_get_key (&pkg_user_name_table,name) != NULL){
			error_set (CUSTOM_ERROR,"Package %s already "
				   "exists",name);
			return -1;
		}
		if (pkg_build_user (name,user) < 0){
			return -1;
		}
		if (check_pkgname (user) < 0){
			return -1;
		}

		pkg_user_name_add_match (user,name);
		
		return 0;
	}
	
	xlog ("Resolving package name %s\n",name);
	/* Try to find a full match first */
	username = dictionary_get_key (&pkg_user_name_table,name);
	if (username != NULL){
		xassert (strlen (username) < UGRP_RE_MAX_LENGTH);
		strcpy (user,username);
		xlog ("Resolved to user %s (full match)\n",user);
		return 0;
	}

	string_list_init (&resolve_list);
	dictionary_to_list (&pkg_user_name_table,&resolve_list);
	n_match = 0;
	for (it = string_list_it (&resolve_list);it != NULL
		     ;it = it->next->next){
		username = it->string;
		pkgname = it->next->string;
		
		if (string_beginwith_p (pkgname,name)){
			n_match++;
			if (n_match > 1){
				error_set (CUSTOM_ERROR,"Ambiguous "
					   "package name %s: "
					   "%s or %s ?",
					   name,res_pkgname,pkgname);
				return -1;
			}
			xassert (strlen (username) < UGRP_RE_MAX_LENGTH);
			strcpy (user,username);
			res_pkgname = pkgname;
		}
	}
	/* No match found */
	if (n_match == 0){
		error_set (CUSTOM_ERROR,"No match found for package "
			   "name %s",name);
		return -1;
	}
	xlog ("Resolved to user %s (partial match)\n",user);
	string_list_free (&resolve_list);
	
	return 0;
}

int
pkg_user_to_name (const char *username,char *pkgname)
{
	/* Resolved package name */
	const char *res_pkgname;

	xdebug ("%s (%s)\n",__FUNCTION__,username);
	if (!pkg_built_table){
		if (pkg_user_name_table_build () < 0){
			return -1;
		}
	}

	res_pkgname = dictionary_get_val (&pkg_user_name_table,username);

	if (res_pkgname == NULL){
		error_set (CUSTOM_ERROR,"No matching package name found for "
			   "user %s",username);
		return -1;
	}

	xassert (strlen (res_pkgname) < PKG_MAX_LENGTH);
	strcpy (pkgname,res_pkgname);

	xdebug ("%s : %s\n",__FUNCTION__,pkgname);

	return 0;
}

int
pkguser_p (const char *username)
{
        /* If username is a package user, it must begin with
	   UGRP_PREFIX and exist. It must also have less than
	   UGRP_RE_MAX_LENGTH characters */

	int r;

	xdebug ("%s (%s)\n",__FUNCTION__,username);

	if (pkg_built_table){
		int ret;
		if (dictionary_get_val (&pkg_user_name_table,username) != NULL){
			ret = 1;
		}
		else {
			ret = 0;
		}
		xdebug ("%s : %d\n",__FUNCTION__,ret);
		return ret;
	}

	if (! string_beginwith_p (username,USER_PREFIX)){
		xdebug ("%s : 0\n",__FUNCTION__);
		return 0;
	}

	r = ugrp_user_exists_p (username,NULL);
	if (r < 0){
		return -1;
	}
	else if (!r){
		xdebug ("%s : %d\n",__FUNCTION__,0);
		return 0;
	}

	/* Check the length */
	if (strlen (username) >= UGRP_RE_MAX_LENGTH){
		xwarn ("User name %s is not a package user because it "
		       "has more than %d characters. Did you create it using "
		       "urpkg ?\n",username,UGRP_RE_MAX_LENGTH - 1);
		xdebug ("%s : %d\n",__FUNCTION__,0);
		return 0;
	}

	return 1;
}

int
pkgrp_p (const char *name)
{
	int r;

	if (! string_beginwith_p (name,GROUP_PREFIX)){
		return 0;
	}

	r = ugrp_group_exists_p (name,NULL);
	if (r < 0){
		return -1;
	}
	else if (!r){
		return 0;
	}

	/* Check the length */
	if (strlen (name) >= UGRP_RE_MAX_LENGTH){
		xwarn ("Group %s is not a package group because it "
		       "has more than %d characters. Did you create it using "
		       "urpkg ?\n",name,UGRP_RE_MAX_LENGTH - 1);
		return 0;
	}

	return 1;
}
