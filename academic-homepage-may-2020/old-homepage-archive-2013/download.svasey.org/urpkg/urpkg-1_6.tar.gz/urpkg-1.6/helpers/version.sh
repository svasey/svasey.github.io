#!/bin/bash
# Print the program's version number and write it to the VERSION file
# if it is actually different than what was in that file. Argument: project root
# directory

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 project_root_directory" 1>&2
}

PROJECT_ROOT="$1"

if [ $# -ne 1 ]; then
    usage
    exit 1
fi

VERSION="unknown"
if [ -f ${PROJECT_ROOT}/VERSION ]; then
    VERSION="$(cat ${PROJECT_ROOT}/VERSION)"
fi
if (which git && which sed && ( git status || [ $? -eq 1 ])) &>/dev/null ; then
    VERSION="$(git-describe --tags)"
    VERSION="$(echo $VERSION | sed 's/^v//')"
    CLEAN="$( { git --no-pager status || true; } | \
	grep 'nothing to commit (working' || true)"
    if [ "$CLEAN" ]; then
	true
    else
	VERSION="${VERSION}-+"
    fi
fi

if [ ! -f ${PROJECT_ROOT}/VERSION ]; then
    echo "$VERSION" > ${PROJECT_ROOT}/VERSION
elif [ "$(cat ${PROJECT_ROOT}/VERSION)" != "$VERSION" ]; then
    # Necessary, in case VERSION is owned by root and we are only an
    # unprivileged user.
    rm -f ${PROJECT_ROOT}/VERSION
    echo "$VERSION" > ${PROJECT_ROOT}/VERSION
fi

echo "$VERSION"

exit 0