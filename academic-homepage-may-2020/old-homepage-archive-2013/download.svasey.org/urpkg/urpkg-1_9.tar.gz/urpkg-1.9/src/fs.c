/* Implementation of the functions declared in fs.h  */

/*
  Copyright (C) 2008 Sebastien Vasey

  This file is part of urpkg
  
  urpkg is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3, or (at your option)
  any later version.
  
  urpkg is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with urpkg; see the file COPYING.  If not, write to
  the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
  Boston, MA 02110-1301, USA.  
*/

#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <limits.h>
#include <grp.h>
#include <errno.h>

#include "fs.h"
#include "io.h"
#include "error.h"
#include "ugrp.h"
#include "str.h"

int
fs_copy_file (const char *src,const char *dest)
{
	FILE *from;
	FILE *to;
	int c;

	xdebug ("%s (%s,%s)\n",__FUNCTION__,src,dest);

	if (! (from = fopen (src,"r"))){
		error_set (FREAD_ERROR,src,strerror (errno));
		return -1;
	}
	if (! (to = fopen (dest,"w"))){
		error_set (FWRITE_ERROR,dest,strerror (errno));
		return -1;
	}

	/* Read and write character by character */
	while ((c = fgetc (from)) != EOF){
		if ((fputc (c,to)) == EOF){
			error_set (FWRITE_ERROR,dest,strerror (errno));
			return -1;
		}
	}
	
	fclose (to);
	fclose (from);

	return 0;
}

int
fs_set_metadata (const char *dest,const struct stat *fst)
{
	xdebug ("%s (%s,[mod=%o,uid=%d,gid=%d])\n",__FUNCTION__,
		dest,fst->st_mode,fst->st_uid,fst->st_gid);
	
	if (chown (dest,fst->st_uid,fst->st_gid) < 0){
		error_set (FPERM_ERROR,dest,strerror (errno));
		return -1;
	}
	
	if (chmod (dest,fst->st_mode) < 0){
		error_set (FPERM_ERROR,dest,strerror (errno));
		return -1;
	}

	return 0;	
}

int
fs_copy_preserve (const char *src,const char *dest)
{
	struct stat fst;
	
	xdebug ("%s (%s,%s)\n",__FUNCTION__,src,dest);

	/* Get metadata of source */
	if (stat (src,&fst) < 0){
		error_set (FSTAT_ERROR,src,strerror (errno));
		return -1;
	}

	if (fs_copy_file (src,dest) < 0){
		error_set (CUSTOM_ERROR
				 ,"Could not copy %s to %s : %s"
				 ,src,dest,error_describe ());
		return -1;
	}

	if (fs_set_metadata (dest,&fst) < 0){
		error_set (CUSTOM_ERROR
				 ,"Could not set metadata of %s : %s"
				 ,dest,error_describe ());
		return -1;
	}

	return 0;
}

int
fs_make_backup (const char *src)
{
	char backup_path[PATH_MAX];

	xdebug ("%s (%s)\n",__FUNCTION__,src);

	xassert ((strlen (src) + strlen (FS_BACKUP_SUFFIX)) < PATH_MAX);
	strcpy (backup_path,src);
	strcat (backup_path,FS_BACKUP_SUFFIX);
	xdebug ("backup_path: %s\n",backup_path);

	if (fs_copy_preserve (src,backup_path) < 0){
		error_set (CUSTOM_ERROR
				 ,"Could not backup %s : %s",src
				 ,error_describe ());
		return -1;
	}

	return 0;
}

int
fs_restore_backup (const char *src)
{
	char backup_path[PATH_MAX];

	xdebug ("%s (%s)\n",__FUNCTION__,src);

	xassert ((strlen (src) + strlen (FS_BACKUP_SUFFIX) + 1) > PATH_MAX);
	strcpy (backup_path,src);
	strcat (backup_path,FS_BACKUP_SUFFIX);
	xdebug ("backup_path: %s\n",backup_path);

	if (fs_copy_preserve (backup_path,src) < 0){
		error_set (CUSTOM_ERROR
				 ,"Could not restore backup of %s : %s"
				 ,error_describe ());
		return -1;
	}

	return 0;
}

int
fs_find_directories (const struct string_list *file_list,
		     struct string_list *regfiles,
		     struct string_list *directories)
{
	struct string_list_el *it;

	for (it = string_list_it (file_list);it != NULL;it = it->next){
		int r = fs_is_directory_p (it->string);

		if (r < 0){
			return -1;
		}
		else if (r){
			string_list_add (directories,it->string);
		}
		else {
			string_list_add (regfiles,it->string);
		}
	}

	return 0;
}

int
fs_file_create (const char *filename,mode_t mode,uid_t uid,gid_t gid)
{
	FILE *stream = fopen (filename,"w");

	xdebug ("%s (%s,%o,%d,%d)\n",__FUNCTION__,filename,mode,uid,gid);

	if (stream == NULL){
		error_set (FCREATE_ERROR,filename,strerror (errno));
		return -1;
	}
	if (chown (filename,uid,gid) < 0){
		error_set (FPERM_ERROR,filename,strerror (errno));
		return -1;
	}
	if (chmod (filename,mode) < 0){
		error_set (FPERM_ERROR,filename,strerror (errno));
		return -1;
	}
	fclose (stream);
	
	return 0;
}

int
fs_dir_create (const char *path,mode_t mode,uid_t uid,gid_t gid)
{
	xdebug ("%s (%s,%o,%d,%d)\n",__FUNCTION__,path,mode,uid,gid);
	
	if (mkdir (path,mode) < 0){
		error_set (FCREATE_ERROR,path,strerror (errno));
		return -1;
	}
	if (chown (path,uid,gid) < 0){
		error_set (FPERM_ERROR,path,strerror (errno));
		return -1;
	}

	return 0;
}

int
fs_file_group (const char *filename,char *group)
{
	struct stat fst;
	struct group *grp;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	xassert (group != NULL);

	if (lstat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	if (! (grp = getgrgid (fst.st_gid))){
		error_set (GID_ERROR,fst.st_gid);
		return -1;
	}

	xassert (strlen (grp->gr_name) < UGRP_RE_MAX_LENGTH);
	group = strcpy (group,grp->gr_name);

	xdebug ("%s : %s\n",__FUNCTION__,group);
	return 0;
}

int
fs_file_owner (const char *filename,char *owner)
{
	struct stat fst;
	struct passwd* user;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	xassert (owner != NULL);

	if (lstat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	if (! (user = getpwuid (fst.st_uid))){
		error_set (UID_ERROR,fst.st_uid);
		return -1;
	}

	xassert (strlen (user->pw_name) < UGRP_RE_MAX_LENGTH);
	owner = strcpy (owner,user->pw_name);

	xdebug ("%s : %s\n",__FUNCTION__,owner);
	return 0;
}

int
fs_file_chown (const char *filename,const char *owner)
{
	struct passwd *ud;

	xdebug ("%s (%s,%s)\n",__FUNCTION__,filename,owner);
	
	errno = 0;
	if ( (ud = getpwnam (owner)) == NULL){
		if (errno != 0){
			error_set (UGFIND_ERROR,owner,strerror (errno));
		}
		else {
			error_set (UGNEXIST_ERROR,owner);
		}
		return -1;
	}

	if (chown (filename,ud->pw_uid,-1) < 0){
		error_set (FPERM_ERROR,filename,strerror (errno));
		return -1;
	}

	return 0;
}

int
fs_file_chgrp (const char *filename,const char *group)
{
	struct group *grp;

	xdebug ("%s (%s,%s)\n",__FUNCTION__,filename,group);

	errno = 0;
	if ( (grp = getgrnam (group)) == NULL){
		if (errno != 0){
			error_set (UGFIND_ERROR,group,strerror (errno));
		}
		else {
			error_set (UGNEXIST_ERROR,group);
		}
		return -1;
	}

	if (chown (filename,-1,grp->gr_gid) < 0){
		error_set (FPERM_ERROR,filename,strerror (errno));
		return -1;
	}

	return 0;
}

int
fs_file_delete (const char *filename)
{
	int r;
	
	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	if (! fs_file_exists_p (filename)){
		return 0;
	}
	r = fs_is_directory_p (filename);
	if (r < 0){
		return -1;
	}
	else if (r){
		DIR *dp;
		struct dirent *ep;
		char path[PATH_MAX];

		if (! (dp = opendir (filename))){
			error_set (FREAD_ERROR,filename,strerror (errno));
			return -1;
		}

		while ((ep = readdir (dp))){
			if (! fs_is_dirbase_p (ep->d_name)){
				xassert ((strlen (filename)
					  + strlen (ep->d_name) + 1)
					 < PATH_MAX);
				strcpy (path,filename);
				strcat (path,"/");
				strcat (path,ep->d_name);
				if (fs_file_delete (path) < 0){
					return -1;
				}
			}
		}
		closedir (dp);
	}
	if (remove (filename) < 0){
		error_set (FREMOVE_ERROR,filename,strerror (errno));
		return -1;
	}
		
	return 0;	
}

int
fs_file_set_sticky (const char *filename,int sticky)
{
	struct stat fst;
	mode_t nm;

	xdebug ("%s (%s,%d)\n",__FUNCTION__,filename,sticky);

	/* File must be a directory */
	xassert (fs_is_directory_p (filename) > 0);

	if (stat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	if (sticky){
		nm = fst.st_mode | S_ISVTX;
	}
	else {
		nm = fst.st_mode & (~ S_ISVTX);
	}

	if (chmod (filename,nm) < 0){
		error_set (FPERM_ERROR,filename,strerror (errno));
		return -1;
	}

	return 0;
}

int
fs_file_set_gw (const char *filename,int gw)
{
	struct stat fst;
	mode_t nm;

	xdebug ("%s (%s,%d)\n",__FUNCTION__,filename,gw);
	
	if (stat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	if (gw){
		nm = fst.st_mode | S_IWGRP;
	}
	else {
		nm = fst.st_mode & (~ S_IWGRP);
	}

	if (chmod (filename,nm) < 0){
		error_set (FPERM_ERROR,filename,strerror (errno));
		return -1;
	}

	return 0;
}

int
fs_can_chown_p (const char *filename)
{
	struct stat fs;
	int r;
	int ret;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	r = stat (filename,&fs);
	
	if ((r < 0) && (errno != EACCES)){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}
	else if (r < 0){
		ret = 0;
	}
	else if (ugrp_have_privilleges_p ()){
		ret = 1;
	}
	else if (fs.st_uid == getuid ()){
		ret = 1;
	}
	else {
		ret = 0;
	}

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_can_write_p (const char *filename)
{
	int r;
	int ret;
	
	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	r =  access (filename,W_OK);

	if ((r < 0) && (errno != EACCES) && (errno != EROFS)
	    && (errno != ETXTBSY)){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}
	else if (r < 0){
		ret = 0;
	}
	else {
		ret = 1;
	}

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

/* Return true if we have read permission on the file, false otherwise */
int
fs_can_read_p (const char *filename)
{
	int r;
	int ret;
	
	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	r = access (filename,R_OK);
	if ((r < 0) && (errno != EACCES)){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}
	else if (r < 0){
		ret = 0;
	}
	else {
		ret = 1;
	}

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_can_run_p (const char *filename)
{
	struct stat fst;
	int r;
	int ret;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	if (stat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	if (!S_ISREG (fst.st_mode)){
		ret = 0;
	}
	else {
		r = access (filename,X_OK);
		if ((r < 0) && (errno != EACCES)){
			error_set (FSTAT_ERROR,filename,strerror (errno));
			return -1;
		}
		else if (r < 0){
			ret = 0;
		}
		else {
			ret = 1;
		}
	}
	
	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_samefile_p (const char *f1,const char *f2)
{
	struct stat fst1;
	struct stat fst2;

	if (lstat (f1,&fst1) < 0){
		error_set (FSTAT_ERROR,f1,strerror (errno));
		return -1;
	}
	if (lstat (f2,&fst2) < 0){
		error_set (FSTAT_ERROR,f2,strerror (errno));
		return -1;
	}

	if (fst1.st_ino == fst2.st_ino){
		return 1;
	}
	else {
		return 0;
	}
}

int
fs_is_dirbase_p (const char *filename)
{
	int ret;
	int len;
	int count;
	int i;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);
	xassert (filename != NULL);
	len = strlen (filename);

	count = 0;
	for (i = len - 1;(i >= 0) && (count < 3) && (filename[i] != '/');i--){
		char c = filename[i];

		if (c == '.'){
			count++;
		}
		else {
			count = 0;
			break;
		}
	}

	if ((count == 0) || (count == 3)){
		ret = 0;
	}
	else {
		ret = 1;
	}

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_is_inpath_p (const char *path,const char *filename)
{
	char path_resolved[PATH_MAX];
	char filename_resolved[PATH_MAX];
	int ret;

	xdebug ("%s (%s,%s)\n",__FUNCTION__,path,filename);
	
	if (realpath (path,path_resolved) == NULL){
		error_set (RPATH_ERROR,path,strerror (errno));
		return -1;
	}
	if (realpath (filename,filename_resolved) == NULL){
		error_set (RPATH_ERROR,filename,strerror (errno));
		return -1;
	}

	if (string_beginwith_p (filename,path)){
		ret = 1;
	}
	else {
		ret = 0;
	}

	xdebug ("%s : %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_is_directory_p (const char *filename)
{
	struct stat fst;
	int ret;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	if (lstat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	ret = (S_ISDIR (fst.st_mode));

	xdebug ("%s : %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_is_nonempty_dir_p (const char *filename)
{
	DIR *dp;
	struct dirent *ep;
	char path[PATH_MAX];
	int r;
	int ret;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);
	if (! fs_is_directory_p (filename)){
		xdebug ("%s: %d\n",__FUNCTION__,0);
		return 0;
	}

	if (! (dp = opendir (filename))){
		error_set (FREAD_ERROR,filename,strerror (errno));
		return -1;
	}

	ret = 0;
	while ((ep = readdir (dp))){
		/* If there are other files than . and .., the directory is not
		   empty. */
		if (! fs_is_dirbase_p (ep->d_name)){
			/* Check the given file/directory */
			xassert ((strlen (filename) + strlen (ep->d_name) + 1)
				 < PATH_MAX);
			
			strcpy (path,filename);
			strcat (path,"/");
			strcat (path,ep->d_name);

			/* If this is not a directory, the containing directory
			   is not empty */
			if (! fs_is_directory_p (path)){
				ret = 1;
				break;
			}
			/* Otherwise, check recursively that the directory is
			   also empty. */
			else {
				r = fs_is_nonempty_dir_p (path);
				if (r < 0){
					return -1;
				}
				else if (r){
					ret = 1;
					break;
				}
			}
		}
	}
	closedir (dp);

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_abspath_p (const char *path)
{
	int len = strlen (path);
	int ret;
	int i;

	xdebug ("%s (%s)\n",__FUNCTION__,path);
	
	if ((len < 1) || (len >= PATH_MAX) || (path[0] != '/')){
		xdebug ("%s: 0\n",__FUNCTION__);
		return 0;
	}

	/* Check whether spaces are properly escaped */
	ret = 1;
	for (i = 0;i < len;i++){
		char c = path[i];
		char p = '\0';

		if (i != 0){
			p = path[i - 1];
		}
		if ((c == ' ') && (p != '\\')){
			ret = 0;
			break;
		}
	}

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_file_exists_p (const char *filename)
{
	struct stat fst;
	int ret;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	/* Be careful to check the symbolic link itself, not the file it points
	   to. */
	if (lstat (filename,&fst) < 0){
		ret = 0;
	}
	else {
		ret = 1;
	}

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_is_sticky_p (const char *filename)
{
	struct stat fst;
	int ret;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	if (stat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	/* S_ISVTX is the sticky bit */
	ret = (fst.st_mode & S_ISVTX);

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_is_gw_p (const char *filename)
{
	struct stat fst;
	int ret;

	xdebug ("%s (%s)\n",__FUNCTION__,filename);

	if (stat (filename,&fst) < 0){
		error_set (FSTAT_ERROR,filename,strerror (errno));
		return -1;
	}

	/* S_IWGRP is the group write permission bit */
	ret = (fst.st_mode & S_IWGRP);

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}

int
fs_in_group_p (const char *filename,const char *group)
{
	char fgrp[UGRP_RE_MAX_LENGTH];
	int ret;

	xdebug ("%s (%s,%s)\n",__FUNCTION__,filename,group);

	if (fs_file_group (filename,fgrp) < 0){
		error_set (CUSTOM_ERROR
				 ,"Could not determine in what group %s was : "
				 "%s",filename,error_describe ());
		return -1;
	}
	ret = ! (strcmp (group,fgrp));

	xdebug ("%s: %d\n",__FUNCTION__,ret);
	return ret;
}
