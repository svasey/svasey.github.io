#!/bin/bash

### Create a slackware package of urpkg, assuming it has been installed on the
### system by itself. First argument: project root directory. Second argument:
### package name. If unspecified, will guess.

# Copyright (C) 2008 Sebastien Vasey

# This file is part of urpkg

# urpkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# urpkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with urpkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 project_root_directory [pkgname]" 1>&2
}

if [ $# -eq 1 ]; then
    LONGNAME="$(urpkg --list --quiet | grep -E ^urpkg)"
    VERSION=$(echo $LONGNAME | sed -r 's/urpkg-(.+)/\1/' | tr '-' '_')
    BASENAME=$(echo $LONGNAME | sed -r 's/([^-]+)-.+/\1/')
    ARCH="$(uname --machine | tr - _)"
    BUILD="1"
    BUILDER="sev"
    PKGNAME="${BASENAME}-${VERSION}-${ARCH}-${BUILD}${BUILDER}.tgz"
elif [ $# -eq 2 ]; then
    PKGNAME="$2"
else
    usage
    exit 1
fi

PROJECT_ROOT="$1"

VERSION=$(echo $PKGNAME | sed -r 's/[^-]+-([^-]+).+/\1/')

DESC="$(mktemp -t slack-desc.XXXXXX)"

(echo "     |-----handy-ruler------------------------------------------------------|"
echo "urpkg: urpkg $VERSION (installs programs in a safe and undoable way)"
echo "urpkg: "
echo "urpkg: Urpkg is a software to install programs so that we can easily "
echo "urpkg: uninstall them afterward. It does so by creating a new user for each " 
echo "urpkg: package that gets installed on the system. The package is then "
echo "urpkg: installed with this user's privileges instead of root's. This "
echo "urpkg: guarantees a much better security during installation."
echo "urpkg: "
echo "urpkg: Package created by Sebastien Vasey, using list2pkg"
echo "urpkg: Contact: sebastien dot vasey at gmail dot com"
echo "urpkg: For more information on list2pkg: http://www.svasey.org/list2pkg"
) > $DESC

urpkg --list --quiet urpkg | list2pkg --slack-desc=$DESC \
    --changetree=${PROJECT_ROOT}/helpers/add-pkgdir.sh $PKGNAME

rm -v $DESC

exit 0
