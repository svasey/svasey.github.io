#!/bin/sh
# Copyright (c) 2007 Sebastien Vasey
#
# Given a number of playlists file as arguments,
# this will start mplayer with the first playlist, and make it switch to the
# second one if it quits for some reasons. WARNING: This will be run as root

#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#  
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#  
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.

MPLAYER=/usr/bin/mplayer
ALSACTL=/usr/sbin/alsactl
AMIXER=/usr/bin/amixer

customExit () {
    $ALSACTL restore &>/dev/null
    exit $1
}

# Volumes for pcm output (alsa), between 0 and 255
RADIO_VOLUME=150
LOCAL_VOLUME=120

$ALSACTL store &>/dev/null
$AMIXER sset PCM ${RADIO_VOLUME} &>/dev/null
for el in $@; do
    $MPLAYER -prefer-ipv4 -shuffle -playlist \
	$el </dev/null &>/dev/null &
    trap 'kill ${!};customExit 0' SIGINT SIGTERM
    wait
    $AMIXER sset PCM ${LOCAL_VOLUME} &>/dev/null
done

customExit 1
