#!/usr/bin/perl
# Copyright (C) 2007 Sebastien Vasey
#
# A script executed before the login screen comes up, only at a precise time of
# the day. It is used when I set up my computer to turn on automatically so that
# it acts as an alarm clock. Basically, it starts mplayer and load a playlist.
# A popup is then opened and mplayer quits once the user clicks "ok".

#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#  
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#  
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.

use strict;
use Time::Local;
use Proc::Simple;

my $XDIALOG="/usr/bin/Xdialog";
my $MPLAYERSTART="/usr/local/sbin/startup-mplayer.sh";
my $SH="/bin/sh";

# The different playlists in the order they must be played.
# Web-radios will be tried first.
# If it does not work, then local songs will be played.
# All playlists are played in shuffle mode.
my @PLAYLISTS=("/home/john/multimedia/music/playlists/wakeup-radios.m3u"
	       ,"/home/john/multimedia/music/playlists/wakeup-local.m3u");


my $DEBUG=0;

# The time the music will run before stopping, in seconds
my $TIME=3600;

# Contain the time interval in which the script will be run. A member with a
# value of -1 will be ignored.
my $REGTIME = {
	       day=>[-1,-1]
	       # WARNING: months begin with 0 ie January is 0, Februrary is 1...
	       ,month=>[-1,-1]

	       ,min=>[0,0]
	       ,hour=>[7,8]
	       ,wday=>[1,5]
};



# This file takes precedence over REGTIME. The script will NOT be ran
# in the interval it specifies.
# If defined is false, the object will be ignored.
my $EXCLUDETIME = {
		   defined=>0
		   ,day=>[29,27]
		   ,month=>[6,7]

		   ,min=>[-1,-1]
		   ,hour=>[-1,-1]
		   ,wday=>[-1,-1]
};

# A time in which the script must be ran, even though  not in the regtime
# interval. This file takes precedence over the other two.
# If defined is false, the object will be ignored.
my $OTHERTIME = {
		 defined=>1
		 ,day=>[31,31]
		 ,month=>[7,7]

		 ,min=>[0,0]
		 ,hour=>[0,23]
		 ,wday=>[-1,-1]
};

if (!rightTime()){
    debug("Won't be executed: it is not the right time");
    exit 0;
}
else {
    debug("Will be executed: it is the right time");
}


my $proc=Proc::Simple->new();

debug("playlists: @PLAYLISTS");

$proc->start("$MPLAYERSTART @PLAYLISTS") || debug("$!");

my $pid=$proc->pid;

debug("mplayer pid: $pid");

system("$XDIALOG --infobox 'Click OK to stop the music' 0x0 "
       . ($TIME*1000));

debug("mplayer will be killed immediately");

system("kill $pid");

exit 0;

sub debug {
    my $message=$_[0];

    if ($DEBUG){
	print "$message \n";
    }
}

sub rightTime {
    my @CURRENT=localtime(time());

    # Return 1 if the the first argument is in the interval described by the
    # second one.

    sub inInterval{
	my ($sec,$min,$hour,$day,$month,$year,$wday)=@{$_[0]};

	my $obj=$_[1];

	my @day_range=@{$obj->{day}};
	my @min_range=@{$obj->{min}};
	for (my $i=0;$i<2;$i++){
	    $day_range[$i]+=32*$obj->{month}[$i];
	    $min_range[$i]+=60*$obj->{hour}[$i];
	}
	my @wday_range=@{$obj->{wday}};

	# Return 0 if not in the range, 1 if in the range or < 0 (undefined)
	sub checkRange {
	    my @range=@{$_[0]};
	    my $n=$_[1];

	    if ($range[0] < 0 || ($range[0] <= $n && $range[1] >= $n)){
		return 1;
	    }
	    return 0;
	}

	if (!(checkRange(\@wday_range,$wday)
	      && checkRange(\@min_range,$min+60*$hour)
	      && checkRange(\@day_range,$day+32*$month))){

	    return 0;
	}
	return 1;
    }

    if ($OTHERTIME->{defined} && inInterval(\@CURRENT,$OTHERTIME)){
	return 1;
    }
    elsif ($EXCLUDETIME->{defined} && inInterval(\@CURRENT,$EXCLUDETIME)){
	return 0;
    }
    elsif (inInterval(\@CURRENT,$REGTIME)){
	return 1;
    }
    else {
	return 0;
    }
}
