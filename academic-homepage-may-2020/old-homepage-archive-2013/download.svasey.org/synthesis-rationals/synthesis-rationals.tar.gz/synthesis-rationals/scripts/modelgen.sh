#!/bin/bash

### Generate the necessary constraints for the rocket program

set -o errexit

source ./scripts/variables.sh

mkdir -p tmp/synthetized

scala -cp $BINDIR rocket.modeling.ModelGenerator $@
