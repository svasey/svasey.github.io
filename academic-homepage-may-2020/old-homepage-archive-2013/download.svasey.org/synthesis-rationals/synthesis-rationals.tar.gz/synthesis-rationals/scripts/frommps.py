#!/usr/bin/env python

### Convert a MPS file to a RChoose statement

import sys
from subprocess import call, Popen, PIPE
from fractions import Fraction

def parsecl ():
    # Quick and dirty
    return (sys.argv[1], sys.argv[2])


def toRational (r):
    """Output a string representing the fraction r as a rational number"""
    if r < 0:
        return "(0 - " + str(abs(r)) + ")"
    else:
        return str (r)
    

def linearCombination (variables, vector):
    ret = " + ".join (map (lambda (v, coeff): toRational (coeff) + " * " + v,
                            filter (lambda (v, coeff): coeff != 0, zip (variables, vector))))
    # This can happen if the vector contains only zeroes (yes it happens !) 
    if not ret:
        return "0"
    else:
        return ret
    
def main ():
    (mpsFile, rchFile) = parsecl ()
    out = open (rchFile, 'w')
    converted = Popen (['lp_solve', '-plp', '-mps', mpsFile], stdout=PIPE).communicate ()[0]
    lines = converted.split ('\n')
    varLine = lines[1]
    # Rename the variables for easier reading
    variables = map (lambda (i,x): "x" + str(i),enumerate (varLine.split ()))

    nVariables = len(variables)
    out.write ("RChoose (" + ','.join(variables) + ")\n")
    objLine = lines[2].split ()
    c = map (lambda r: Fraction(r), objLine[1:])
    if objLine[0] == 'Minimize':
        c = map (lambda x: -1 * x, c)
    
    maximizeV = linearCombination (variables, c)
    if not maximizeV:
        maximizeV = "0"
        
    out.write ("[" + maximizeV + "]\n{\n")
    curId = 3
    while lines[curId].split ()[0] != 'Type':
        if (curId != 3):
            out.write ("&& ")
        line = lines[curId].split ()
        print "DEBUG: line", line
        lc = linearCombination (variables, map (lambda r: Fraction(r), line[1:nVariables + 1]))
        rel = '==' if line[nVariables + 1] == '=' else line[nVariables + 1]
        bound = toRational (Fraction(line[nVariables + 2]))
        print "DEBUG: lc: ", lc, "rel: ", rel, "bound: ", bound
        if (rel == '>='):
            out.write (bound + " <= " + lc + "\n")
        else:
            out.write (lc + " " + rel + " " + bound + "\n")
            
        curId = curId + 1
    
    upBound = lines[curId + 1].split ()[1:]
    lowBound = lines[curId + 2].split ()[1:]
    varUpBound = filter (lambda b: "Inf" not in b, zip (variables,upBound))
    varLowBound = filter (lambda b: "Inf" not in b, zip (variables,lowBound))
    for (v, b) in varUpBound:
        out.write ("&& " + v + " <= " + toRational(Fraction(b)) + "\n")
    for (v, b) in varLowBound:
        out.write ("&& " + toRational(Fraction(b)) + " <= " + v + "\n")

    out.write ("}")
            
    out.close()
    
    return 0

if __name__ == '__main__':
    sys.exit (main ())
