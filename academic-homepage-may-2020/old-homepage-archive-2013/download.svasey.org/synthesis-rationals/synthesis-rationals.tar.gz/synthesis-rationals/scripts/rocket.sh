#!/bin/bash

### Run the rocket example . Takes a lot of arguments: First, all options
### (beginning with --) are passed to modelgen.sh . Then must come, in order: 
### * The booster maximal acceleration
### * The gravitational acceleration
### * The initial fuel
### * The initial position
### * The initial speed
### * The number of samples to use
### * The time one simulated second will take in the real world
### * The time simulated in a simulation step
### * The number of disjunction to use in the constraints
### * The initial acceleration
###
### If some parameters are not given, then all those that follow must not be
### given, and they are given defaults shown below

set -o errexit

source ./scripts/variables.sh

OLDOPTS=""
while echo "$1" | grep -q '^--' ; do
    OLDOPTS="${OLDOPTS} ${1}"
    shift
done

BOOSTER_ACCELERATION="20.0"
GRAV="10.0"
INIT_FUEL="10.0"
INIT_POS="500.0"
INIT_SPEED="0.0"
NSAMPLES="10"
SIMSEC="1.0"
STEP="0.001"
NDISJ="1"
INIT_ACCEL=""

if [ $# -ge 1 ]; then
    BOOSTER_ACCELERATION="$1"
fi
if [ $# -ge 2 ]; then
    GRAV="$2"
fi
if [ $# -ge 3 ]; then
    INIT_FUEL="$3"
fi
if [ $# -ge 4 ]; then
    INIT_POS="$4"
fi
if [ $# -ge 5 ]; then
    INIT_SPEED="$5"
fi
if [ $# -ge 6 ]; then
    NSAMPLES="$6"
fi
if [ $# -ge 7 ]; then
    SIMSEC="$7"
fi
if [ $# -ge 8 ]; then
    STEP="$8"
fi
if [ $# -ge 9 ]; then
    NDISJ="$9"
fi
if [ $# -ge 10 ]; then
    INIT_ACCEL="$120"
fi

./scripts/modelgen.sh $OLDOPTS $NSAMPLES $NDISJ

scala -cp $BINDIR rocket.Main $BOOSTER_ACCELERATION $GRAV $INIT_FUEL $INIT_POS $INIT_SPEED $NSAMPLES $SIMSEC $STEP $INIT_ACCEL
