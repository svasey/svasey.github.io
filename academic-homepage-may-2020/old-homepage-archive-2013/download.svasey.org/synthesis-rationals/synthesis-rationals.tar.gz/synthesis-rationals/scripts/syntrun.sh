#!/bin/bash

### Synthetize some RChoose code, compile the resulting scala file, and run
### it. Takes as first argument the RChoose file to compile, and as second
### optional argument the path to the scala output file. Must be run from the
### project's root directory (one level below this file)

set -o errexit


source ./scripts/variables.sh

OLDOPTS=""
while echo "$1" | grep -q '^--' ; do
    OLDOPTS="${OLDOPTS} ${1}"
    shift
done

if [ $# -lt 1 ]; then
    echo "Takes at least one argument" 1>&2
    exit 1
fi

INFILE="$1"

mkdir -p "$OUTDIR"

if [ $# -gt 1 ]; then
    OUTFILE="$2"
fi

scala -cp $BINDIR choosec.Main $OLDOPTS $INFILE $OUTFILE
echo "Compiling synthetized file..."
scalac -d "$OUTDIR" -cp "$BINDIR" "$OUTFILE"
./scripts/rerun.sh
