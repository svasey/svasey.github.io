#!/bin/bash

### Rerun a synthetized scala file that was previously compiled. Must be run
### from the project's root directory (one level below this file)

set -o errexit

source ./scripts/variables.sh

echo "Running synthetized file..."
scala -cp "${BINDIR}:$OUTDIR" LATest

