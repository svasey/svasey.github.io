### Defines some variables that are used all the time

export JAVA_OPTS="-Djava.library.path=${PWD}/lib/ ${JAVA_OPTS}"
export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${PWD}/lib/"
BINDIR="bin/scala_2.8.1/classes/:lib/smartfloat_2.8.1-0.0.jar:tmp/synthetized/root"
OUTDIR=/tmp/LATest
OUTFILE=/tmp/LATest.scala
