package rocket.synthetized

import choosec.numbers._
import choosec.simplex._
import smartfloats._
import choosec.synthesis.NoSolutionException

/*
Variables: List(b1, b2, b3, b4, b5, b6, b7, b8, b9)
Original constraints: (((((0 <= b1) && (b1 <= B)) && ((0 <= b4) && (b4 <= B)) && ((0 <= b6) && (b6 <= B)) && ((0 <= b5) && (b5 <= B)) && ((0 <= b7) && (b7 <= B)) && ((0 <= b9) && (b9 <= B)) && ((0 <= b8) && (b8 <= B)) && ((0 <= b2) && (b2 <= B)) && ((0 <= b3) && (b3 <= B))) && true) && (((0 == 6 * b4 + 3 * b7 + -45 * G + 9 * b1 + X0 + 2 * b8 + 5 * b5 + 8 * b2 + 4 * b6 + 10 * A0 + 7 * b3 + 10 * V0 + b9) && (0 == b4 + b7 + -9 * G + b1 + b8 + b5 + b2 + b6 + A0 + b3 + V0 + b9) && ((0 <= b4 + -10 * G + 4 * b1 + X0 + 3 * b2 + 5 * A0 + 2 * b3 + 5 * V0) && (0 <= -6 * G + 3 * b1 + X0 + 2 * b2 + 4 * A0 + b3 + 4 * V0) && (0 <= 2 * b4 + -15 * G + 5 * b1 + X0 + b5 + 4 * b2 + 6 * A0 + 3 * b3 + 6 * V0) && (0 <= 4 * b4 + b7 + -28 * G + 7 * b1 + X0 + 3 * b5 + 6 * b2 + 2 * b6 + 8 * A0 + 5 * b3 + 8 * V0) && (0 <= 5 * b4 + 2 * b7 + -36 * G + 8 * b1 + X0 + b8 + 4 * b5 + 7 * b2 + 3 * b6 + 9 * A0 + 6 * b3 + 9 * V0) && (0 <= -1 * G + b1 + X0 + 2 * A0 + 2 * V0) && (0 <= X0 + V0 + A0) && (0 <= -3 * G + 2 * b1 + X0 + b2 + 3 * A0 + 3 * V0) && (0 <= 3 * b4 + -21 * G + 6 * b1 + X0 + 2 * b5 + 5 * b2 + b6 + 7 * A0 + 4 * b3 + 7 * V0)))))
Maximize: Some(-1 * b4 + -1 * b7 + -1 * b1 + -1 * b8 + -1 * b5 + -1 * b2 + -1 * b6 + -1 * b3 + -1 * b9)
Parameters: Set(A0, V0, X0, G, B)
Pre-condition: (?unknown? && (-1 * X0 + -1 * V0 + -1 * A0 <= 0))
*/

object MinimizeFuel {
val r29__ : Rational = Rational(18,1)
val r14__ : Rational = Rational(-10,1)
val r26__ : Rational = Rational(36,1)
val r8__ : Rational = Rational(-2,1)
val r__ : Rational = Rational(-45,1)
val r24__ : Rational = Rational(-36,1)
val r22__ : Rational = Rational(72,1)
val mOne__ : Rational = Rational(-1,1)
val r11__ : Rational = Rational(4,1)
val r28__ : Rational = Rational(-72,1)
val r7__ : Rational = Rational(2,1)
val r9__ : Rational = Rational(3,1)
val r18__ : Rational = Rational(-15,1)
val r16__ : Rational = Rational(-57,1)
val r20__ : Rational = Rational(27,1)
val r30__ : Rational = Rational(-3,1)
val r19__ : Rational = Rational(6,1)
val one__ : Rational = Rational(1,1)
val r2__ : Rational = Rational(10,1)
val r31__ : Rational = Rational(3,2)
val r15__ : Rational = Rational(5,1)
val r25__ : Rational = Rational(9,1)
val r23__ : Rational = Rational(-18,1)
val r6__ : Rational = Rational(-3,2)
val zero__ : Rational = Rational(0,1)
val r3__ : Rational = Rational(-9,1)
val r27__ : Rational = Rational(-27,1)
val r13__ : Rational = Rational(8,1)
val r10__ : Rational = Rational(-6,1)
val r12__ : Rational = Rational(-28,1)
val r4__ : Rational = Rational(-1,2)
val r17__ : Rational = Rational(16,1)
val r5__ : Rational = Rational(1,2)
val r21__ : Rational = Rational(-8,1)
val id_7__ : Matrix[Rational] = BaseMatrix(IndexedSeq(IndexedSeq(one__,zero__,zero__,zero__,zero__,zero__,zero__),IndexedSeq(zero__,one__,zero__,zero__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,one__,zero__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,one__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,zero__,one__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,zero__,zero__,one__,zero__),IndexedSeq(zero__,zero__,zero__,zero__,zero__,zero__,one__)))
val zero_7x1__ : Matrix[Rational] = BaseMatrix(IndexedSeq(IndexedSeq(zero__),IndexedSeq(zero__),IndexedSeq(zero__),IndexedSeq(zero__),IndexedSeq(zero__),IndexedSeq(zero__),IndexedSeq(zero__)))
val m__ : Matrix[Rational] = BaseMatrix(IndexedSeq(IndexedSeq(one__,zero__,zero__,zero__,zero__,zero__,zero__),IndexedSeq(zero__,one__,zero__,zero__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,one__,zero__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,one__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,zero__,one__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,zero__,zero__,one__,zero__),IndexedSeq(zero__,r7__,zero__,mOne__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,zero__,zero__,zero__,one__),IndexedSeq(r8__,zero__,zero__,zero__,r31__,r5__,r31__),IndexedSeq(mOne__,zero__,mOne__,zero__,r7__,zero__,zero__),IndexedSeq(zero__,mOne__,zero__,zero__,zero__,zero__,zero__),IndexedSeq(zero__,zero__,mOne__,zero__,zero__,zero__,zero__),IndexedSeq(mOne__,r30__,mOne__,r7__,r7__,zero__,zero__),IndexedSeq(r7__,r7__,r7__,mOne__,r30__,zero__,zero__),IndexedSeq(mOne__,zero__,zero__,zero__,r5__,r4__,r5__),IndexedSeq(r7__,zero__,zero__,zero__,r6__,r4__,r6__),IndexedSeq(r8__,r8__,r8__,one__,r9__,zero__,zero__),IndexedSeq(zero__,zero__,zero__,zero__,zero__,zero__,mOne__),IndexedSeq(one__,zero__,zero__,zero__,r4__,r5__,r4__),IndexedSeq(zero__,one__,zero__,zero__,zero__,zero__,zero__),IndexedSeq(one__,r9__,one__,r8__,r8__,zero__,zero__),IndexedSeq(r7__,zero__,zero__,zero__,mOne__,zero__,mOne__),IndexedSeq(zero__,zero__,zero__,zero__,zero__,mOne__,zero__),IndexedSeq(one__,zero__,zero__,zero__,r4__,r5__,r4__),IndexedSeq(zero__,zero__,zero__,mOne__,zero__,zero__,zero__)))
val zero_1x1__ : Matrix[Rational] = BaseMatrix(IndexedSeq(IndexedSeq(zero__)))
val roof__ : Seq[Int] = List(1,2,3,4,5,6,8)
val dummySolver__ : SimplexImpl[Rational] = SimplexImpl(zero_1x1__)

def minimizeFuel (A0 : Rational, B : Rational, G : Rational, V0 : Rational, X0 : Rational) : List[Rational] = 
{
  val finalRes__ : LPResult[Rational] = 
    if ((((mOne__) * (X0)) + (((mOne__) * (V0)) + ((mOne__) * (A0)))) <= (zero__))
      {
        val synthProbRes__ : LPResult[Rational] = ((dummySolver__).init(m__,zero_7x1__,(BaseMatrix).colV(((r10__) * (G)) + ((X0) + (((r11__) * (A0)) + ((r11__) * (V0)))),((r12__) * (G)) + ((X0) + (((r13__) * (A0)) + ((r13__) * (V0)))),B,B,((r14__) * (G)) + ((X0) + (((r15__) * (A0)) + ((r15__) * (V0)))),B,((r16__) * (G)) + (((r7__) * (X0)) + (((r17__) * (A0)) + ((r17__) * (V0)))),B,zero__,((r18__) * (G)) + ((X0) + (((r19__) * (A0)) + ((r19__) * (V0)))),((r20__) * (G)) + (((mOne__) * (X0)) + ((B) + (((r21__) * (A0)) + ((r21__) * (V0))))),zero__,((r22__) * (G)) + (((r8__) * (X0)) + (((r23__) * (A0)) + ((r23__) * (V0)))),((r24__) * (G)) + ((X0) + (((r25__) * (A0)) + ((r25__) * (V0)))),B,B,((r26__) * (G)) + (((mOne__) * (X0)) + ((B) + (((r3__) * (A0)) + ((r3__) * (V0))))),zero__,((mOne__) * (G)) + ((X0) + (((r7__) * (A0)) + ((r7__) * (V0)))),((r27__) * (G)) + ((X0) + (((r13__) * (A0)) + ((r13__) * (V0)))),((r28__) * (G)) + (((r7__) * (X0)) + ((B) + (((r29__) * (A0)) + ((r29__) * (V0))))),((r30__) * (G)) + ((X0) + (((r9__) * (A0)) + ((r9__) * (V0)))),zero__,zero__,zero__))).simplexWithStrict(roof__,id_7__,id_7__,25)
        if ((synthProbRes__).hasSolution)
          {
            val b3___ : Rational = ((synthProbRes__).optimalVector).get(1,1)
            val b4___ : Rational = ((synthProbRes__).optimalVector).get(2,1)
            val b5___ : Rational = ((synthProbRes__).optimalVector).get(3,1)
            val b6___ : Rational = ((synthProbRes__).optimalVector).get(4,1)
            val b7___ : Rational = ((synthProbRes__).optimalVector).get(5,1)
            val b8___ : Rational = ((synthProbRes__).optimalVector).get(6,1)
            val b9___ : Rational = ((synthProbRes__).optimalVector).get(7,1)
            val b1___ : Rational = ((r__) * (G)) + ((X0) + (((r2__) * (A0)) + ((r2__) * (V0))))
            val b2___ : Rational = ((r3__) * (G)) + ((A0) + (V0))
            val b1_new__ : Rational = ((r4__) * (b8___)) + (((r5__) * (b7___)) + (((r5__) * (b9___)) + ((mOne__) * (b3___))))
            val b3_new__ : Rational = ((r4__) * (b8___)) + (((r6__) * (b7___)) + (((r6__) * (b9___)) + ((r7__) * (b3___))))
            val b6_new__ : Rational = ((r8__) * (b5___)) + ((b1___) + (((r9__) * (b7___)) + (((mOne__) * (b2___)) + (((r8__) * (b4___)) + ((b6___) + ((r8__) * (b3___)))))))
            val b7_new__ : Rational = (b5___) + (((r8__) * (b1___)) + (((r8__) * (b7___)) + (((r7__) * (b2___)) + (((r9__) * (b4___)) + (((r8__) * (b6___)) + (b3___))))))
            val b9_new__ : Rational = (b1___) + (((r8__) * (b2___)) + ((mOne__) * (b4___)))
            MaximizedLPRes(b2___,(BaseMatrix).colV(b1_new__,b8___,b3_new__,b9___,b5___,b6_new__,b7_new__,b6___,b9_new__))
          }
        else
          synthProbRes__

      }
    else
      throw(new NoSolutionException("Pre-condition not satisfied"))

  if ((finalRes__).hasSolution)
    ((finalRes__).optimalVector).toList
  else
    throw(new NoSolutionException((finalRes__).toString))

}

def main (args: Array[String])
{
  val A0 = (Rational(0,1)).fromString(Console.readLine("Please enter A0 : "))
  val B = (Rational(0,1)).fromString(Console.readLine("Please enter B : "))
  val G = (Rational(0,1)).fromString(Console.readLine("Please enter G : "))
  val V0 = (Rational(0,1)).fromString(Console.readLine("Please enter V0 : "))
  val X0 = (Rational(0,1)).fromString(Console.readLine("Please enter X0 : "))
  smartfloats.tools.AffineForm.printComparisonFailure = 
    true
  val tstart__ = System.currentTimeMillis
  val resList__ : List[Rational] = minimizeFuel(A0,B,G,V0,X0)
  val tend__ = System.currentTimeMillis
  println(("Total time: ") + (((tend__) - (tstart__)) + (" ms")))
  println(resList__)
}
}
