package choosec
package trees

import ScalaCode._

// Print scala code
object ScalaPrinter {
  // Number of spaces per level of indentation
  private val SPACES_PER_LEVEL = 2

  // General toString method for any binary operator
  private def binToString (op: String, lhs: Expr, rhs: Expr): String =
    multToString (op, List (lhs, rhs))

  private def multToString (op: String, values: Seq[Expr]): String =
    "(" ++ values.mkString (") " ++ op ++ " (") ++ ")"

  private def selectorToString (xs: Seq[Expr], name: String): String = {
    require (!xs.isEmpty)
    if (xs.tail.isEmpty) xs.head.toString
    else DotExpr (seqCode ("List", xs), Identifier (name), List ()).toString
  }

  
  // Return a string containing the given string repeated n times.
  private def repeatString (n: Int, str: String): String =
    ((1 to n).map (x => str)).mkString ("")

  // Return a string with the given number of new lines.
  private def nlString (n: Int): String =
    repeatString (n, System.getProperty ("line.separator"))
  private def nlString: String = nlString (1)
  private def indentString (n: Int): String = 
    repeatString (n * SPACES_PER_LEVEL, " ")

  def prettyPrint (expr: Expr, indent: Int): String = expr match {
    case True => indentString (indent) ++ "true"
    case False => indentString (indent) ++ "false"
    case Skip => indentString (indent) ++ ";"
    case Or (exprs) => indentString (indent) ++ multToString ("||", exprs.toSeq)
    case And (exprs) => indentString (indent) ++ multToString ("&&", exprs.toSeq)
    case Not (expr) => indentString (indent) ++ "!(" ++ prettyPrint (expr) ++ ")"
    case Identifier (name) => indentString (indent) ++ name
    case Assign (lhs, rhs) => indentString (indent) ++ lhs.toString ++ " = " ++ "\n" ++
      prettyPrint (rhs, indent + 1)
    case Equals (lhs, rhs) => indentString (indent) ++ binToString ("==", lhs, rhs)
    case Lt (lhs, rhs) => indentString (indent) ++ binToString ("<", lhs, rhs)
    case LtEq (lhs, rhs) => indentString (indent) ++ binToString ("<=", lhs, rhs)
    case Plus (lhs, rhs) => indentString (indent) ++ binToString ("+", lhs, rhs)
    case Times (lhs, rhs) => indentString (indent) ++ binToString ("*", lhs, rhs)
    case Minus (lhs, rhs) => indentString (indent) ++ binToString ("-", lhs, rhs)
    case DividedBy (lhs, rhs) => indentString (indent) ++ binToString ("/", lhs, rhs)
    case Min (xs) => indentString (indent) ++ selectorToString (xs, "min")
    case Max (xs) => indentString (indent) ++ selectorToString (xs, "max")
    case New (id, args) => indentString (indent) ++ "new " ++ prettyPrint (Apply (id, args))
    case Apply (id, args) => {
      val argString = if (args.isEmpty) "" else "(" ++ args.mkString (",") ++ ")"

      indentString (indent) ++ prettyPrint (id) ++ argString
    }
    case StringLit (value) => indentString (indent) ++ "\"" ++ value ++ "\""
    case IntLit (value) => indentString (indent) ++ value.toString
    case DoubleLit (value) => indentString (indent) ++ value.toString
    case ByteLit (value) => indentString (indent) ++ value.toString ++ ":Byte"
    case bl @ Block (_, _) => {
      val toPrint = flattenBlock (bl).stats.map (el => prettyPrint (el, indent + 1))
      indentString (indent) ++ "{" ++ nlString ++ toPrint.mkString (nlString) ++
        nlString ++ indentString (indent) ++ "}"
    }
    case If (ifExpr, ifPart, elsePart) => {
      indentString (indent) ++ "if (" ++ prettyPrint (ifExpr) ++ ")" ++ nlString ++
        prettyPrint (ifPart, indent + 1) ++ nlString ++ {
          if (!elsePart.isEmpty){
            indentString (indent) ++ "else" ++ nlString ++
              prettyPrint (elsePart.get, indent + 1) ++ nlString
          }
          else {
            ""
          }
        }
    }
    case DotExpr (receiver, method, args) => {
      val recvString = receiver match {
        case Block (_, _) | If (_, _, _)  => {
          "(" ++ nlString ++ prettyPrint (receiver, indent) ++ ")"
        }
        case _ => indentString (indent) ++ "(" ++ prettyPrint (receiver) ++ ")"
      }
      recvString ++ "." ++ prettyPrint (Apply (method, args))
    }
    case Val (id, e, t, isLazy) => {
      val typstr = t match {
        case None => ""
        case Some (r) => " : " + r.toString
      }
      val lazystr = if (isLazy) "lazy " else ""
      val exprString = e match {
        case Block (_, _) | If (_, _, _) =>
          nlString ++ prettyPrint (e, indent + 1)
        case _ => prettyPrint (e)
      }
        
      indentString (indent) ++ lazystr ++ "val " ++ id.toString ++ typstr ++ " = " ++ exprString
    }
    case NoneSym => indentString (indent) ++ "None"
  }
    
  def prettyPrint (expr: Expr): String = prettyPrint (expr, 0)
}
