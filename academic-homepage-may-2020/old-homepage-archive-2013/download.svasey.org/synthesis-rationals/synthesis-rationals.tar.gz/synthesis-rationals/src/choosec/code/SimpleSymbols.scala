package choosec
package code

import SimpleType._
import SimpleAST._
import SimpleSymbols._
  
object SimpleSymbols {
  private var id: Int = 0
  def nextID: Int = {id = id + 1; id}
  
  // Variable symbol
  class Symbol (val name: String) extends Typed {
    val id: Int = nextID
  }

  object Symbol {
    def apply (name: String): Symbol = new Symbol (name)
  }
  
  trait Symbolic {
    self =>

    private var _sym: Option[Symbol] = None

    def setSymbol (sym: Symbol): self.type = {
      _sym = Some (sym)
      this
    }
    
    def hasSymbol: Boolean = !_sym.isEmpty
    
    def getSymbol: Symbol = {
      require (hasSymbol, "No symbol attached to object")
      _sym.get
    }
  }

  def attachSymbols (scope: Map[String, Symbol], expr: SimpleExpr): Unit = {
    def attachSyms (e: SimpleExpr): Unit = attachSymbols (scope, e)
      
    expr match {
      case If (cond, then, els) => { attachSyms (cond); attachSyms (then);
                                     attachSyms (els)}
      case Plus (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case Minus (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case Times (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      // case DividedBy (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case And (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case Or (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case Not (e) => attachSyms (e)
      case Lt (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case LtEq (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case Eq (lhs, rhs) => { attachSyms (lhs); attachSyms (rhs) }
      case Max (exprs) => exprs.foreach (attachSyms)
      case Min (exprs) => exprs.foreach (attachSyms)
      case UpTo (from, to) => { attachSyms (from); attachSyms (to) }
      case MaximizedRes (sol, bound) => { sol.foreach (attachSyms); attachSyms (bound) }
      case BoundedRes (bound) => attachSyms (bound)
      case IsFeasible (res) => attachSyms (res)
      case HasSolution (res) => attachSyms (res)
      case GetSolution (res, _) => attachSyms (res)
      case SetBound (res, _) => attachSyms (res)
      case MultiplySol (res, _) => attachSyms (res)
      case GetBound (res) => attachSyms (res)
      case id @ Identifier (name) => {
        assert (scope.contains (name), "Undeclared identifier: " + name)
        id.setSymbol (scope (name))
      }
      case CallSolver (_, _, _, _, _, _, bound) => bound.foreach (attachSyms)
      case Block (vals, ret) => {
        if (vals.isEmpty){
          attachSyms (ret)
        }
        else vals.head match {
          case Val (id, expr, typ, _) => {
            attachSyms (expr)
            val sym = Symbol (id.name)
            id.setSymbol (sym).setType (typ)
            val newScope = scope + ((id.name, sym))
            attachSymbols (newScope, Block (vals.tail, ret))
          }
        }
      }
      case True | False | UnboundedRes | UnfeasibleRes | ErrorRes (_) | FieldEl (_) => ;
    }
  }

  def attachSymbols (externalVariables: Traversable[Identifier], expr: SimpleExpr): SimpleExpr = {
    val initialScope = externalVariables.map (v => (v.name, Symbol (v.name))).toMap
    // Also attach type to the external variables
    initialScope.values.foreach (sym => sym.setType (TField))
    
    attachSymbols (initialScope, expr)
    expr
  }
}


