package choosec
package numbers

import scala.collection.immutable.Queue
import trees.ScalaCode._
import trees.ScalaExpressible

// Base class for a matrix over any field.
trait Matrix[D <: ExpressibleField[D]] extends ScalaExpressible {
  val field: D
  // FIXME: remove field val
  // def field: D = this.get (1,1)
  def nLines: Int
  def nCols: Int

  // One might want to override `equals` and `hashCode` if this is something
  // else than componentwise equality
  def ==(that: Matrix[D]): Boolean
  // Get the element at the lineth line and the colth column (indices are
  // one-based)
  def get (line: Int, col: Int): D
  // Get line i as a line vector
  def getLine (i: Int): Matrix[D]
  // Get column i as a column vector
  def getCol (i: Int): Matrix[D]
  // Get all the elements in the matrix as a sequence of rows
  def getElems: IndexedSeq[IndexedSeq[D]]
  // Return the matrix as a list of element, as if read from left to right and
  // top to bottom.
  def toList: List[D] = getElems.flatten.toList
  // Create a new matrix whose columns are given in order.
  def init (elems: Seq[Seq[D]]): Matrix[D]

  // Convert to a matrix using field E, using the given conversion method
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): Matrix[E]
  
  // Return a short string describing the matrix
  def shortString: String = {
    if (isZero) "zero_" + nLines.toString + "x" + nCols.toString
    else if (isIdentity) "id_" + nLines.toString
    else "m"
  }
  
  // Return the matrix containing only the rows in the given sequence, in the
  // order indicated, from top to bottom.
  def getLines (lines: Seq[Int]): Matrix[D] = {
    require (!lines.isEmpty, "Trying to get zero lines")
    lines.toList match {
      case Nil => error ("This should not happen")
      case x::Nil => getLine (x)
      case x::y::ys => getLine (x).appendBottom (getLines (y::ys))
    }    
  }

  // Get the submatrix containing only the rows from `first` to `last` included.
  def getLines (first: Int, last: Int): Matrix[D] = 
    getLines (List.range (first, last + 1))
  def getCols (first: Int, last: Int): Matrix[D] = 
    getCols (List.range (first, last + 1))

  def getCols (cols: Seq[Int]): Matrix[D] = {
    require (!cols.isEmpty)
    cols.toList match {
      case Nil => error ("This should not happen")
      case x::Nil => getCol (x)
      case x::y::ys => getCol (x).appendRight (getCols (y::ys))
    }
  }

  def removeCols (cols: Set[Int]): Matrix[D] = {
    require (!List.range (1, nCols + 1).toSet.subsetOf (cols),
             "Trying to remove all the columns")
    getCols (List.range (1, nCols + 1).filter (id => !cols.contains (id)))
  }
  def removeLines (lines: Set[Int]): Matrix[D] = {
    require (!List.range (1, nLines + 1).toSet.subsetOf (lines),
             "Trying to remove all the lines")
    getLines (List.range (1, nLines + 1).filter (id => !lines.contains (id)))
  }
  def removeLines (first: Int, last: Int): Matrix[D] = {
    removeLines (List.range (first, last + 1).toSet)
  }
  def removeCols (first: Int, last: Int): Matrix[D] = {
    removeCols (List.range (first, last + 1).toSet)
  }
  def removeCol (col: Int): Matrix[D] = removeCols (Set (col))
  def removeLine (line: Int): Matrix[D] = removeLines (Set (line))

  // Initialize a matrix by giving its number of lines (m) and columns (n), and
  // giving the matrix from left to right and top to bottom.
  def init (m: Int, n: Int, elems: Seq[D]): Matrix[D] = {
    init (IndexedSeq.tabulate (m) (j => elems.slice (n * j, (n * j) + n)))
  }
  
  def +(right: Matrix[D]): Matrix[D]
  def *(right: Matrix[D]): Matrix[D]
  // Scalar multiplication
  def scale (c:D): Matrix[D]
  def negate: Matrix[D] = scale (field.one.negate)

  // This assumes `this` and `that are vectors
  def innerProduct (that: Matrix[D]): D = {
    require (this.isVector && that.isVector)
    this.toList.zip (that.toList).map (pair => pair._1 * pair._2).foldLeft (field.zero) ((a,b) => a + b)
  }

  // Return true if `this` is a line or column vector
  def isVector: Boolean = 
    this.nCols == 1 || this.nLines == 1
  
  // Append the given matrix on the right of `this`. The dimensions must match,
  // i.e we must have right.nLines ==  this.nLines
  def appendRight (right: Matrix[D]): Matrix[D]
  def appendLeft (left: Matrix[D]): Matrix[D] = left.appendRight (this)
  def appendTop (top: Matrix[D]): Matrix[D] = top.appendBottom (this)
  def appendBottom (bottom: Matrix[D]): Matrix[D]
  
  // Return the m by n zero matrix
  def zero (m: Int, n: Int): Matrix[D] = {
    init (IndexedSeq.fill (m) {IndexedSeq.fill (n) { field.zero }})
  }
  // Return the n by n zero matrix
  def zero (n: Int): Matrix[D] = zero (n, n)
  // Return the zero matrix for the current size
  def zero: Matrix[D] = zero (nLines, nCols)

  def isZero: Boolean = this == (zero)
  
  // Return the n by n identity matrix
  def identity (n: Int): Matrix[D] = {
    init (IndexedSeq.tabulate (n) (j => IndexedSeq.tabulate (n) (i => {
      if (i == j) field.one else field.zero
    })))
  }
  // Return the identity matrix for the current size (matrix must be square)
  def identity: Matrix[D] = {
    require (nLines == nCols)
    identity (nLines)
  }

  def isIdentity: Boolean = this == (identity (nCols))

  // Print a 0 when an element is zero, a + when it is positive, and a - when it is negative
  def printSign[F <: ExpressibleOrderedField[F]] (matrix: Matrix[F]): String = {
    matrix.getElems.map (r => {
      r.map (el => if (el.signum > 0) "+" else if (el.signum < 0) "-" else "0").mkString (" ")
    }).mkString (System.getProperty ("line.separator"))    
  }

  // fullTranspose must permute the entries, whereas transpose is allowed to
  // just change some flag so that the other operations behave differently. 
  def transpose: Matrix[D] = fullTranspose
  def fullTranspose: Matrix[D]
  def swapRows (i: Int, j: Int): Matrix[D]
  def rescaleRow (c: D, i: Int): Matrix[D]
  // Add c * row j to row i
  def addMultipleOfRow (i: Int, c: D, j: Int): Matrix[D]
  // Add a multiple of `firstLine` to `elimLine`, so that its `col`th element is
  // zero. This assumes this is possible, i.e the `col`th element of `firstLine`
  // is non-zero.
  def addMultipleOfRowElim (firstLine: Int, elimLine: Int, col: Int): Matrix[D] = {
    val el = get (elimLine, col)
    if (el.isZero)
      this
    else {
      require (firstLine != elimLine)
      val topEl = get (firstLine, col)
      require (!topEl.isZero)
      this.addMultipleOfRow (elimLine, el.negate / topEl, firstLine)
    }
  }
  // Given a column, find its first non-zero entry, and make the entry below it
  // zero by elementary row operations. If there is no non-zero entry in the
  // column, return the matrix itself
  def elimColumn (col: Int): Matrix[D] = {
    nonZeroLine (col) match {
      case None => this
      case Some (lineID) => {
        List.range (lineID + 1, this.nLines + 1).foldLeft (this) ((cur, id) => {
          cur.addMultipleOfRowElim (lineID, id, col)
        })
      }
    }
  }

  // Given a non-zero position, eliminate the elements above and below it, and
  // if `normalize` is true, make it 1 by doing elementary row operations
  def elimColumnFromElem (col: Int, line: Int, normalize: Boolean): Matrix[D] = {
    val el = get (line, col)
    require (!el.isZero)
    val newMat = List.range (1, this.nLines + 1).filter (id => id != line).foldLeft (this) ((cur, id) => {
      cur.addMultipleOfRowElim (line, id, col)
    })
    if (normalize)
      newMat.rescaleRow (el.inverse, line)
    else
      newMat
  }
  def elimColumnFromElem (col: Int, line: Int): Matrix[D] = 
    elimColumnFromElem (col, line, true)

  def swapCols (i: Int, j: Int): Matrix[D]
  def rescaleCol (c: D, i: Int): Matrix[D]
  // Add c * column j to column i
  def addMultipleOfCol (i: Int, c: D, j: Int): Matrix[D]
  // Return as a pair (U,A') the unique row-reduced echelon form A' of this
  // matrix A, and a matrix U s.t A' = U * A.
  def rowReduce: (Matrix[D],Matrix[D]) = {
    val (rank, transf, newMat) = this.rowReduceWithRank
    (transf, newMat)
  }


  
  // Also return the rank of the matrix from its row-reduced form
  def rowReduceWithRank: (Int, Matrix[D], Matrix[D])
  // Return true if the given matrix is invertible
  def isInvertible: Boolean = {
    (nLines == nCols) && (rowReduce._2 == identity)
  }

  // Return the inverse of the matrix. The matrix must be square and invertible
  def inverse: Matrix[D] = {
    optInverse.get
  }

  // Return the inverse of the matrix if it is invertible, None otherwise. The
  // matrix must be square.
  def optInverse: Option[Matrix[D]] = {
    require (nLines == nCols)
    val (u, m) = this.rowReduce
    if (m == identity)
      Some (u)
    else
      None
  }

  // Return the left inverse of the matrix, i.e the matrix B s.t B * A = I. The
  // matrix must be full-rank
  def leftInverse: Matrix[D] = {
    val transp = this.transpose
    (transp * this).inverse * transp
  }

  // Given the row reduced form of `this` (or a larger matrix containing this
  // row-reduced form in its top left corner), return a basis for the kernel of
  // `this`. `m` is the number of lines, and `n` the number of columns we have
  // to consider in the row reduced form
  protected def constructKernel (rowReducedForm: Matrix[D], m: Int, n: Int): Set[Matrix[D]] = {
    // `pivots` is the set of pivots above curLine, represented using their (line,col)
    // coordinate, and in lexicographical order.
    def iter (curLine: Int, curCol: Int, pivots: Queue[(Int, Int)], curBasis: Set[Matrix[D]]): Set[Matrix[D]] = {
      if (curLine > m || curCol > n){
	// We haven't found a pivot in the first line. This implies the matrix
	// is the zero matrix, so a basis are the columns of the identity matrix
	if (curLine == 1){
	  val id = this.identity (n)
	  List.range (1, n + 1).map (j => id.getCol (j)).toSet
	}
	else {
	  curBasis
	}
      }
      else {
	val el = rowReducedForm.get (curLine, curCol)
	// We have found a pivot
	if (!el.isZero){
	  assert (el.isOne)
	  val newPivots = pivots :+ (curLine, curCol)
	  // Collect all basis vector that can be built from this line. Also
	  // return the column of the next pivot, or n + 1 if no such column
	  // exists.
	  def collect (curB: Set[Matrix[D]], i: Int): (Set[Matrix[D]], Int) = {
	    if ((curLine == m) || i > n || !rowReducedForm.get (curLine + 1, i).isZero){
	      (curB, i)
	    }
	    else {
	      // Build the basis vector
	      def buildVector (col: Int, curPiv: Queue[(Int, Int)]): List[D] = {
		if (col > n){
		  Nil
		}
		else if (col == i){
		  el.one :: buildVector (col + 1, curPiv)
		}
		else {
		  val (pivLine, pivCol) = if (curPiv.isEmpty) (0, 0) else curPiv.head
		  if (col == pivCol){
		    rowReducedForm.get (pivLine, i).negate :: buildVector (col + 1, curPiv.tail)
		  }
		  else {
		    el.zero :: buildVector (col + 1, curPiv)
		  }
		}
	      }
	      val v = buildVector (1, newPivots)
	      collect (curB + init (IndexedSeq (v.toIndexedSeq).transpose), i + 1)
	    }
	  }
	  val (newBasis, nextCol) = collect (curBasis, curCol + 1)
	  iter (curLine + 1, nextCol, newPivots, newBasis)
	}
	else {				// el.isZero
	  iter (curLine, curCol + 1, pivots, curBasis)
	}
      }
    }
    iter (1, 1, Queue (), Set ())
  }

  // Given a row-reduced form of A | b, return a particular solution of Ax = b
  // if it exists (as a column vector)
  def constructSolution (rowReducedForm: Matrix[D]): Option[Matrix[D]] = {
    def iter (curLine: Int, curCol: Int, curB: Queue[D]): Option[Queue[D]] = {
      if (curLine > rowReducedForm.nLines){
	Some (curB)
      }
      else {
	// We are at the bottom of the row-reduced form, at the column of b. We
	// must check all the components of b are zero, otherwise there is no
	// solution.
	assert (curCol <= rowReducedForm.nCols)
	val el = rowReducedForm.get (curLine, curCol)
	if (curCol == rowReducedForm.nCols){
	  if (!el.isZero){
	    None
	  }
	  else {
	    iter (curLine + 1, curCol, curB)
	  }
	}
	else {
	  if (!el.isZero){
	    assert (el.isOne)
	    val bEl = rowReducedForm.get (curLine, rowReducedForm.nCols)
	    iter (curLine + 1, curCol + 1, curB :+ bEl)
	  }
	  else {
	    iter (curLine, curCol + 1, curB :+ el.zero)
	  }
	}
      }
    }
    iter (1, 1, Queue ()) match {
      case None => None
      case Some (res) => Some (init (IndexedSeq (res)).transpose)
    }
  }

  // Return a basis for the kernel of the matrix, and a particular solution of
  // Ax = b if one exists.
  def fullSolveRight (b: Matrix[D]): (Set[Matrix[D]], Option[Matrix[D]]) = {
    val rr = this.appendRight (b).rowReduce._2
    (constructKernel (rr, nLines, nCols), constructSolution (rr))
  }
  
  // Return a solution of the equation Ax = b for A mxn, x nx1, b mx1
  def solveRight (b: Matrix[D]): Matrix[D] = {
    val rr = this.appendRight (b).rowReduce._2
    val sol = constructSolution (rr)
    require (!sol.isEmpty)
    sol.get
  }

  // Return a basis for the (right) kernel of the matrix
  def kernel: Set[Matrix[D]] = {
    val rr = this.rowReduce._2
    constructKernel (rr, nLines, nCols)
  }

  // Return true iff the matrix is full rank
  def isFullRank: Boolean = kernel.isEmpty

  // Return the indices of linearly-independent lines that span the row space
  def rowSpace: Set[Int] = {
    this.transpose.columnSpace
  }

  def columnSpace: Set[Int] = {
    rowReduceWithPivots._3
  }

  def sparseRatio: Double = {
    1.0 - (countNonZero.toDouble / (nLines * nCols))
  }
  
  // Return the number of non-zero element of the matrix
  def countNonZero: Int = {
    toList.count (el => !el.isZero)
  }

  def columnRank: Int = columnSpace.size
  def lineRank: Int = rowSpace.size
  def rank: Int = rowReduceWithRank._1

  // Return (U, A'), and the set of pivot columns, where A' is the row-reduced version
  // of A, and U is s.t A' = U * A .
  def rowReduceWithPivots: (Matrix[D], Matrix[D], Set[Int]) = {
    val (transf, rr) = this.rowReduce
    // Find the pivot columns
    def iterate (curLine: Int, curCol: Int, curSet: Set[Int]): Set[Int] = {
      if (curLine > nLines || curCol > nCols)
	curSet
      else {
	val el = rr.get (curLine, curCol)
	if (!el.isZero){
	  assert (el.isOne)
	  // A pivot has been found
	  iterate (curLine + 1, curCol + 1, curSet + curCol)
	}
	else {
	  iterate (curLine, curCol + 1, curSet)
	}
      }
    }
    (transf, rr, iterate (1, 1, Set ()))
  }

  // Return the id of the first line where the entry at the given column is
  // non-zero. Return None if there is no such line
  def nonZeroLine (col: Int): Option[Int] = {
    List.range (1, nLines + 1).find (id => {
      !get (id, col).isZero
    })
  }

  def toScalaCode (fieldExpr: D => Expr): Expr
  def toScalaCode: Expr = toScalaCode (el => el.toScalaCode)
  // Produce scala code for a column vector
  def toScalaCodeCol (els: Seq[Expr]): Expr 
  
  def getType: Type = Type ("Matrix[" + field.getType.name + "]")
}

// Base implementation for a matrix over any field.
class BaseMatrix[D <: ExpressibleField[D]] (fieldElem: D,
				 matrix: IndexedSeq[IndexedSeq[D]]) extends Matrix[D] {
  require (matrix.length > 0 && matrix (0).length > 0)
  val field = fieldElem
  def nLines = matrix.length
  def nCols = matrix(0).length

  def get (line: Int, col: Int): D =
    matrix (line - 1) (col - 1)
  def getLine (i: Int): Matrix[D] =
    fastInit (IndexedSeq(matrix (i - 1)))
  def getCol (i: Int): Matrix[D] = 
    fastInit (IndexedSeq.tabulate (nLines) (j => IndexedSeq (matrix (j) (i - 1))))
  // Get all the elements in the matrix as a sequence of rows
  def getElems: IndexedSeq[IndexedSeq[D]] = matrix
  def init (elems:Seq[Seq[D]]): BaseMatrix[D] =
    BaseMatrix (field, elems)

  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): BaseMatrix[E] =
    BaseMatrix (conv (field), matrix.map (s => s.map (e => conv (e))))
  private def fastInit (elems: IndexedSeq[IndexedSeq[D]]): BaseMatrix[D] =
    new BaseMatrix (field, elems)

  // FIXME: better formatting, move this to upper class ?
  override def toString: String = 
    matrix.map (r => r.mkString (" ")).mkString (System.getProperty ("line.separator"))

  override def equals (any: Any): Boolean = any match {
    // FIXME: We hope we never compare matrices of different types...
    case mat:Matrix[d] => {
      mat.asInstanceOf[Matrix[D]] == this
    }
    case _ => false
  }
  override def hashCode: Int = {
    matrix.hashCode
  }

  def ==(that: Matrix[D]): Boolean =
    matrix == that.getElems

  def +(right: Matrix[D]): Matrix[D] = {
    require (nLines == right.nLines && nCols == right.nCols)
    val newMatrix = matrix.zipWithIndex.map (_ match {
      case (r, i) => r.zipWithIndex.map (_ match {
	case (el, j) => el + right.get (i + 1, j + 1)
      })
    })
    fastInit (newMatrix)
  }

  def scale (c: D): Matrix[D] = 
    fastInit (matrix.map (r => r.map (el => c * el)))

  def *(right: Matrix[D]): Matrix[D] = {
    require (nCols == right.nLines)
    // Compute entry (i,j) of the result. Indices are 0-based
    def compute (i: Int, j: Int): D = {
      List.range (0,nCols).foldLeft (field.zero) ((cur, k) =>
	cur + get (i + 1, k + 1) * right.get (k + 1, j + 1))
    }

    val newMatrix = IndexedSeq.tabulate (nLines) (i => {
      IndexedSeq.tabulate (right.nCols) (j => compute (i,j))
    })
    fastInit (newMatrix)
  }

  def appendBottom (bottom: Matrix[D]): Matrix[D] = {
    require (nCols == bottom.nCols)
    fastInit (matrix ++ bottom.getElems)
  }

  def appendRight (right: Matrix[D]): Matrix[D] = {
    require (nLines == right.nLines)
    fastInit (matrix.zip (right.getElems).map (pair => pair._1 ++ pair._2))
  }


  def rowReduceWithRank: (Int, Matrix[D], Matrix[D]) = {
    // Try to put a 1 at line `candLine`, at the given column.
    def rowReduceCol (curU: Matrix[D], curRR: Matrix[D], candLine: Int,
                      col: Int): (Int, Matrix[D], Matrix[D]) = {
      if (col > nCols || candLine > nLines)
        (candLine - 1, curU, curRR)
      else {
        val id =
          List.range (candLine, nLines + 1).find (i => !curRR.get (i, col).isZero)
        id match {
          case Some (rowId) => {
            val topElInv = curRR.get (rowId, col).inverse

            val newU = {
              curU.swapRows (candLine, rowId).
                rescaleRow (topElInv, candLine)
            }
            val newRR = {
              curRR.swapRows (candLine, rowId).
                rescaleRow (topElInv, candLine)
            }

            def eliminate (origLine: Int) (cur: (Matrix[D], Matrix[D]), line: Int): (Matrix[D],Matrix[D]) = cur match {
              case (u, a) => {
                val negEl = a.get (line, col).negate
                (u.addMultipleOfRow (line, negEl, origLine),
                 a.addMultipleOfRow (line, negEl, origLine))
              }
            }

            val (u, rr) = {
              (List.range (1, candLine) ++ List.range (candLine + 1, nLines + 1)).
                foldLeft ((newU, newRR)) (eliminate (candLine))
            }

            rowReduceCol (u, rr, candLine + 1, col + 1)
          }
          case None => {
            rowReduceCol (curU, curRR, candLine, col + 1)
          }
        }
      }
    }

    
    val t0 = System.currentTimeMillis ()
    val res = rowReduceCol (identity (nLines), this, 1, 1)
    val t2 = System.currentTimeMillis ()
    println ("DEBUG: Row-reducing " + nLines + " by " + nCols + " matrix took " +
           (t2 - t0) + " ms")
    res
  }


    
  
  def fullTranspose: BaseMatrix[D] = {
    val newMatrix = IndexedSeq.tabulate (nCols) (i => {
      matrix.map (r => r (i))
    })
    fastInit (newMatrix)
  }

  def swapRows (i: Int, j: Int): Matrix[D] = {
    fastInit (matrix.zipWithIndex.map (_ match {
      case (el, k) =>
        if (k == i - 1) matrix (j - 1)
        else if (k == j - 1) matrix (i - 1)
        else el
    }))
  }
  def rescaleRow (c: D, i: Int): Matrix[D] = {
    fastInit (matrix.zipWithIndex.map (_ match {
      case (el, k) =>
        if (k == i - 1) el.map (x => c * x)
        else el
    }))
  }
  // Add c * row j to row i
  def addMultipleOfRow (i: Int, c: D, j: Int): Matrix[D] = {
    val newMatrix = {
      matrix.zipWithIndex.map (_ match {
        case (r, k) => {
          if (k == i - 1){
            r.zip (matrix (j - 1)).map (p => {
              (c * p._2) + p._1
            })
          }
          else
            r
        }
      })
    }
    fastInit (newMatrix)
  }

  def swapCols (i: Int, j: Int): Matrix[D] = {
    fastInit (matrix.map (r => r.zipWithIndex.map (_ match {
      case (el, k) =>
        if (k == i - 1) r (j - 1)
        else if (k == j - 1) r (i - 1)
        else el
    })))
  }

  def rescaleCol (c: D, i: Int): Matrix[D] = {
    fastInit (matrix.map (r => r.zipWithIndex.map (_ match {
      case (el, k) => if (k == i - 1) c * el else el
    })))
  }

  // Add c * column j to column i
  def addMultipleOfCol (i: Int, c: D, j: Int): Matrix[D] = {
    val colJ = matrix.map (r => r (j - 1))
    val newMatrix = {
      matrix.zipWithIndex.map (_ match {
	case (r, id) => r.zipWithIndex.map (_ match {
          case (el, k) => {
            if (k == i - 1){
              (c * colJ (id)) + el
            }
            else
              el
          }
	})
      })
    }
    fastInit (newMatrix)
  }


  def toScalaCodeCol (els: Seq[Expr]): Expr = {
    DotExpr (Identifier ("BaseMatrix"), Identifier ("colV"), els)
  }

  def toScalaCode (fieldExpr: D => Expr): Expr = {
    val elemList = Apply (Identifier ("IndexedSeq"),
			  matrix.map (line => {
			    Apply (Identifier ("IndexedSeq"),
				   line.map (fieldExpr).toList)
			  }).toList)

    Apply (Identifier ("BaseMatrix"), List (elemList))
  }
}

object BaseMatrix {
  def apply[D <: ExpressibleField[D]] (fieldElem: D, elems: Seq[Seq[D]]): BaseMatrix[D] = {
    new BaseMatrix (fieldElem, elems.map (x => x.toIndexedSeq).toIndexedSeq)
  }
  def apply[D <: ExpressibleField[D]] (elems: IndexedSeq[IndexedSeq[D]]): BaseMatrix[D] = {
    require (!elems.isEmpty && !elems.head.isEmpty)
    new BaseMatrix (elems.head.head, elems)
  }
  def apply[D <: ExpressibleField[D]] (elems: Seq[Seq[D]]): BaseMatrix[D] = {
    BaseMatrix (elems.map (x => x.toIndexedSeq).toIndexedSeq)
  }

  // Initialize a column vector
  def colV[D <: ExpressibleField[D]] (els: D*): BaseMatrix[D] = {
    require (!els.isEmpty)
    BaseMatrix (els.map (e => IndexedSeq (e)).toIndexedSeq)
  }
}
