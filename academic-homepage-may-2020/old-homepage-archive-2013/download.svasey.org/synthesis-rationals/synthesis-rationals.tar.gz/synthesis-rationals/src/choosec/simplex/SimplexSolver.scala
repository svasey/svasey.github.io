package choosec
package simplex

import numbers._
import trees.ScalaCode._
import trees.ScalaExpressible

import scala.collection.mutable.HashMap

// Solver for linear programs of the form "maximize c^T * x under constraint A*x <= b
trait SimplexSolver[D <: ExpressibleOrderedField[D]] extends ScalaExpressible {
  // FIXME; make sure to make this a method
  val field: D

  val matrix: Matrix[D]
  val maximize: Matrix[D]
  val bound: Matrix[D]

  def init (constrMatrix: Matrix[D], goal: Matrix[D], b: Matrix[D]): SimplexSolver[D]

  // Return a solver for the field E using the given conversion method
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): SimplexSolver[E]
  
  // To call when the matrix is not necessarily full rank
  def fullSimplexWithStrict (nNonStrict: Int): LPResult[D] = {
    transformToFullRank match {
      case Left ((transform, solv)) => solv.simplexWithStrict (nNonStrict).multiplySol (transform)
      case Right (res) => res
    }
  }

  def simplexWithStrict (nNonStrict: Int): LPResult[D] = {
    findRoof match {
      case Left (roof) => simplexWithStrict (roof, nNonStrict)
      case Right (res) => res
    }
  }
  
  def simplexWithStrict (initialRoof: Seq[Int], nNonStrict: Int): LPResult[D] = {
    val roofMatrix = matrix.getLines (initialRoof)
    val inverseRoofMatrix = roofMatrix.inverse
    simplexWithStrict (initialRoof, roofMatrix, inverseRoofMatrix, nNonStrict)
  }

  // Return a solver that checks for the feasibility of the LP with strict
  // inequalities. This solver will maximize a variable delta, and the final
  // variable is greater than zero iff the LP is feasible.
  def strictIneqFeasibleSolver (nNonStrict: Int): SimplexSolver[D] = {
    // Bound for delta. We want to make this as small as possible, since we
    // are not interested on the real maximum of delta, only on what happens
    // when it is larger than zero. FIXME: try to determine a reasonnable
    // choice analytically 
    val EPS = field.one

    // delta = (0, 0, ...,0, 1,...,1)^T, where the first one is at position
    // `nNonStrict` + 1.
    val delta = {
      matrix.init (matrix.nLines, 1,
                   IndexedSeq.tabulate (matrix.nLines) (x => {
                     if (x > nNonStrict - 1) field.one else field.zero
                   }))
    }

    // Construct an equivalent linear program with only non-strict
    // inequalities. We will add an additional variable delta s.t 0 <= delta
    // <= EPS, add it to each line to make it a non-strict inequality.      
    val withDelta = matrix.appendRight (delta)
    val bottom = {
      val toAppend = matrix.init (2,1, List (field.one.negate, field.one))
      matrix.zero (2, matrix.nCols).appendRight (toAppend)
    }
    val deltaMatrix = withDelta.appendBottom (bottom)
    val maximizeDelta = maximize.zero.appendBottom (matrix.identity (1))   

    val deltaBound = bound.appendBottom (matrix.init (IndexedSeq (IndexedSeq (field.zero), IndexedSeq (EPS))))
    this.init (deltaMatrix, maximizeDelta, deltaBound)
  }

  // Return a solver that tries to solve the LP with strict inequalities. The
  // extra-variable delta will be greater than zero at the end if and only if
  // the LP has a maximum point. `leastUpperBound` give the inferred least upper
  // bound for this LP, it is only necessary to know whether it is a maximum or
  // not. `firstSolver` is obtained by calling `strictIneqFeasibleSolver`.
  def strictIneqMaximizeSolver (nNonStrict: Int, leastUpperBound: D,
				firstSolver: SimplexSolver[D]): SimplexSolver[D] = {
    val maxConstr = maximize.transpose.appendRight (matrix.zero (1)).scale (field.one.negate)
    val deltaConstrMatrix = firstSolver.matrix.appendBottom (maxConstr)
    val deltaConstrBound =
      firstSolver.bound.appendBottom (matrix.init (IndexedSeq (IndexedSeq (leastUpperBound.negate))))
    this.init (deltaConstrMatrix, firstSolver.maximize, deltaConstrBound)
  }
    
  
  // Solve a modified linear problem with `nNonStrict` nonstrict inequalities
  // (the first lines of the matrix). The parameters are those for a simplex
  // without any strict inequalities. The matrix is assumed to be full rank.
  def simplexWithStrict (initialRoof: Seq[Int], roofMatrix: Matrix[D],
			 inverseRoofMatrix: Matrix[D], nNonStrict: Int): LPResult[D] = {
    val nStrict = matrix.nLines - nNonStrict
    // println ("DEBUG: running simplexWithStrict")
    // println ("DEBUG: matrix:\n" + matrix)
    // println ("DEBUG: bound:\n" + bound)
    // println ("DEBUG: maximize:\n" + maximize)
    if (nStrict == 0){
      this.simplex (initialRoof, roofMatrix, inverseRoofMatrix)
    }
    else {
      assert (nStrict > 0)

      lazy val feasibilitySolver = strictIneqFeasibleSolver (nNonStrict)

      def relaxedLP: LPResult[D] = this.simplex (initialRoof, roofMatrix,
                                                 inverseRoofMatrix)
      def feasibleRes (roof: Seq[Int]): LPResult[D] = {
        val res = feasibilitySolver.simplex (roof)
        if (res.hasSolution && res.leastUpperBound > field.zero){
	  LPRes (field, Some (field.zero), None, Some (res.optimalVector), true).projectSol (matrix.nCols)
	}
	else {
	  LPRes (field, None, None, None, false)
	}
      }
      def lpWithMax (lub: D, roof: Seq[Int]): LPResult[D] = {
	val maxSolver = strictIneqMaximizeSolver (nNonStrict, lub, feasibilitySolver)
	val deltaRes = maxSolver.simplex (roof)
	assert (deltaRes.hasSolution)
	if (deltaRes.leastUpperBound > field.zero){
	  LPRes (field, Some (lub), None, Some (deltaRes.optimalVector), true).projectSol (matrix.nCols)
	}
        // We still don't know whether the problem is feasible or not
	else {
          val feasRes = feasibleRes (roof)
          if (feasRes.isFeasible)
            LPRes (field, Some (lub), None, None, true)
          else
            feasRes
        }
      }

      if (maximize.isZero){
        feasibleRes (feasibilitySolver.matrix.nLines +: initialRoof)
      }
      else {
	val firstRes = relaxedLP 
	// println ("DEBUG: first result:\n" + firstRes)
	if (firstRes.hasSolution){
	  val lub = firstRes.leastUpperBound
          lpWithMax (lub, feasibilitySolver.matrix.nLines +: firstRes.optimalRoof)
        }
        else {
	  firstRes
	}
      }
    }
  }
  
  // Returns an optimal roof, or the empty set if such a roof does not exist
  // (because either the program is unbounded, or it is unfeasible). This
  // assumes the constraint matrix has linearly independent columns. Use
  // `transformToFullRank` before initializing your matrix, or use `fullSimplex`.
  def simplex (initialRoof: Seq[Int], roofMatrix: Matrix[D],
	       inverseRoofMatrix: Matrix[D]): LPResult[D]

  def simplex (initialRoof: Seq[Int]): LPResult[D] = {
    // println ("DEBUG: Running simplex...")
    // println ("DEBUG: matrix:\n" + matrix)
    // println ("DEBUG: maximize:\n" + maximize)
    // println ("DEBUG: bound:\n" + bound)
    // println ("DEBUG: initial roof: " + initialRoof)
    val roofMatrix = matrix.getLines (initialRoof)
    val inverseRoofMatrix = roofMatrix.inverse
    simplex (initialRoof, roofMatrix, inverseRoofMatrix)
  }

  def simplex: LPResult[D] = {
    findRoof match {
      case Left (initialRoof) => simplex (initialRoof)
      case Right (res) => res
    }
  }

  def fullSimplex: LPResult[D] = {
    transformToFullRank match {
      case Left ((transform, solv)) => solv.simplex.multiplySol (transform)
      case Right (res) => res
    }
  }

  // Given that we know the linear program is either unbounded or unfeasible,
  // determine which by solving the linear program with the zero objective
  // vector.
  private def unboundedOrUnfeasible: LPResult[D] = {
    // Cannot be unbounded, so is unfeasible
    if (maximize.isZero){
      LPRes (field, None, None, None, false)
    }
    else {
      val res = this.init (matrix, maximize.zero, bound).fullSimplex
      if (res.isFeasible){
	LPRes (field, None, None, None, true)
      }
      else {
	LPRes (field, None, None, None, false)
      }
    }
  }

  // Return a new solver with a full-rank matrix on which we can use the simplex
  // algorithm. Also return a matrix with which to multiply the solution to get
  // back the original one (use res.multiplySol, where res is the solution to
  // the modified problem). If we can already solve the problem, return the
  // result right away.
  def transformToFullRank: Either[(Matrix[D],SimplexSolver[D]), LPResult[D]] = {
    if (matrix.isZero){
      // LP is unfeasible
      if (List.range (1, bound.nLines + 1).exists (i => bound.get (i, 1) < field.zero))
	Right (UnfeasibleLPRes (field))
      // LP is feasible, unbounded iff c != 0
      else if (!maximize.isZero)
	Right (UnboundedLPRes (field))
      else
	Right (MaximizedLPRes (field.zero, maximize))
    }
    else {
      val (rank, transformMatrix, rrMat) = matrix.transpose.rowReduceWithRank
      val newMat = rrMat.getLines (List.range (1, rank + 1)).transpose
      val transformedObj = transformMatrix * maximize
      // println ("DEBUG: original matrix:\n" + matrix)
      // println ("DEBUG: bound:\n" + bound)
      // println ("DEBUG: original objective:\n" + maximize)
      // println ("DEBUG: new Matrix:\n" + newMat)
      // println ("DEBUG: new Matrix sign:\n" + newMat.printSign (newMat))
      // Either the linear program is not admissible, or it is unbounded.
      if ((matrix.nCols > rank) && !transformedObj.getLines (List.range (rank + 1, matrix.nCols + 1)).isZero){
	Right (unboundedOrUnfeasible)
      }
      else {
	val newObj = transformedObj.getLines (List.range (1, rank + 1))
	// println ("DEBUG: new objective:\n" + newObj)
	val newSolver = this.init (newMat, newObj, bound)
	Left (transformMatrix.transpose, newSolver)
      }
    }
  }
    
  // Try to find an initial roof for the linear program. If no roof can be
  // found, the program is either unbounded or unfeasible: return the
  // corresponding LPResult object.
  def findRoof: Either[Seq[Int],LPResult[D]] = {
    // println ("DEBUG: trying to find initial roof")
    // println ("DEBUG: matrix:\n" + matrix)
    // println ("DEBUG: maximize:\n" + maximize)
    // println ("DEBUG: bound:\n" + bound)
    val rowSpace = matrix.rowSpace
    // println ("DEBUG: row space: " + rowSpace)
    // println ("DEBUG: finding roof for matrix:\n" + matrix)
    if (maximize.isZero){
      // Return any linearly independent set of rows
      Left (rowSpace.toSeq.sorted)
    }
    else {
      val newMat = matrix.appendBottom (maximize.transpose)
      // [0,0, ..., 0, 1]^T
      val bound =
	matrix.zero (matrix.nLines, 1).appendBottom (matrix.identity (1))

      val firstRoof = {
	val rowSpaceMatrix = matrix.getLines (rowSpace.toSeq.sorted).transpose
	val sol = rowSpaceMatrix.solveRight (maximize)
	// Find a row that will exit the linearly independent set, to be replaced by c^T
	val toExit = List.range (1, sol.nLines + 1).find (i => !sol.get(i, 1).isZero)
	assert (!toExit.isEmpty)
        // println ("DEBUG: toExit: " + toExit)
        val toExitID = rowSpace.toSeq.sorted.apply (toExit.get - 1)
	((rowSpace - toExitID) + (matrix.nLines + 1)).toSeq
      }
      // println ("DEBUG: firstRoof: " + firstRoof)

      val solvInst = this.init (newMat, maximize, bound)
      val initialRes = solvInst.simplex (firstRoof)
      assert (initialRes.hasOptimalRoof)
      val initialRoof = initialRes.optimalRoof
      // println ("DEBUG: found initial roof: " + initialRoof)
      if (initialRoof.contains (matrix.nLines + 1)){
	// The linear program is either unbounded or unfeasible.
	Right (unboundedOrUnfeasible)
      }
      else {
	Left (initialRoof)
      }
    }
  }

  // Return the "top" of a roof.
  def roofTop (roof: Seq[Int]): Matrix[D] = {
    matrix.getLines (roof).solveRight (bound.getLines (roof))
  }

  // Return true iff the given set is an optimal roof. We must have that `roof`
  // is a subset of {1, ..., m}, where m is the number of lines of the matrix.
  def isOptimal (roof: Seq[Int]): Boolean = {
    println ("DEBUG: checking optimality of roof")
    val roofMatrix = matrix.getLines (roof)
    if (roofMatrix.isFullRank && roof.size == matrix.nCols){
      val roofVertex = roofMatrix.solveRight (bound.getLines (roof))
      val cone = roofMatrix.transpose.solveRight (maximize)
      val maxT = maximize.transpose

      val lambdaList = {
        IndexedSeq.range (1, matrix.nLines + 1).map (el => {
          if (roof.contains (el))
            cone.get (roof.indexOf (el) + 1,1)
          else
            field.zero
        })
      }      
      val lambda = matrix.init (IndexedSeq (lambdaList))
      
      // println ("DEBUG: lambda:\n" + lambda)
      // println ("DEBUG: matrix:\n" + matrix)
      // println ("DEBUG: maxT:\n" + maxT)
      // println ("DEBUG: bound:\n" + bound)
      // println ("DEBUG: roof vertex:\n" + roofVertex)
      
      def inPolyhedra = {
        (matrix * roofVertex).toList.zipWithIndex.forall (_ match {
          case (el, id) => el <= bound.get (id + 1, 1)
        })
      }
      def lambdaPos = lambdaList.forall (x => x >= field.zero)

      inPolyhedra && lambdaPos &&
      lambda * matrix == maxT &&
      lambda * bound == maxT * roofVertex
    }
    else
      false
  }
  // Return a new roof containing `entering`, and n - 1 elements of
  // `currentRoof`. If this is not possible, return the empty set. The elements
  // of the returned roof must be in the same order as the given one.
  def simplexPivot (initialRoof: Seq[Int], currentRoof: Seq[Int], roofMatrix: Matrix[D],
		    inverseRoofMatrix: Matrix[D], roofBound: Matrix[D],
		    entering: Int): Seq[Int]


  // Produce a dummy solver
  def toScalaCodeDummy (matCode: Expr): Expr
}

// Describe a roof as a set of lines, the corresponding matrix, and the
// inverse of the corresponding matrix.
case class RoofDescr[D <: ExpressibleOrderedField[D]] (roof: Seq[Int], roofMatrix: Matrix[D], inverseRoofMatrix: Matrix[D]) {
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): RoofDescr[E] = {
    RoofDescr (roof, roofMatrix.convert (conv), inverseRoofMatrix.convert (conv)) 
  }
}

// Keeps track of the "best" roofs for a given problem
trait RoofKeeper[D <: ExpressibleOrderedField[D]] {
  // Add a new best roof
  def addRoof (descr: RoofDescr[D]): RoofKeeper[D]
  def getBestRoof: RoofDescr[D]
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): RoofKeeper[E]
}

class LastUsedKeeper[D <: ExpressibleOrderedField[D]] (val lastUsed: RoofDescr[D]) extends RoofKeeper[D] {
  def addRoof (descr: RoofDescr[D]): RoofKeeper[D] = new LastUsedKeeper (descr)
  def getBestRoof: RoofDescr[D] = lastUsed
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): RoofKeeper[E] = {
    new LastUsedKeeper (lastUsed.convert (conv))
  }
}

// A simple implementation based on the lexicographical pivot rule
class SimplexImpl[D <: ExpressibleOrderedField[D]] (fieldEl: D, matrixEl: Matrix[D], maximizeEl: Matrix[D], boundEl: Matrix[D], prevRes: HashMap[(Matrix[D], Matrix[D], Matrix[D]), LPResult[D]], prevRoofs:HashMap[(Matrix[D], Matrix[D]), RoofKeeper[D]]) extends SimplexSolver[D] {
  require (maximizeEl.nLines == matrixEl.nCols)
  require (boundEl.nLines == matrixEl.nLines)
  val field = fieldEl
  val matrix = matrixEl
  val maximize = maximizeEl
  val bound = boundEl

  // Keep previously computed results
  var previousResults:HashMap[(Matrix[D], Matrix[D], Matrix[D]), LPResult[D]] = prevRes

  // This can be overriden if one wants to use another keeper (that e.g keeps
  // track of frequencies)
  def initRoofKeeper (descr: RoofDescr[D]): RoofKeeper[D] = {
    new LastUsedKeeper (descr)
  }

  // Keep previous optimal roofs, as inverses of the matrix . They only depend
  // on A and c.
  var previousRoofs:HashMap[(Matrix[D], Matrix[D]), RoofKeeper[D]] = prevRoofs

  def getResult: Option[LPResult[D]] =  
    previousResults.get ((matrix, bound, maximize))

  def addResult (res: LPResult[D]): Unit = {
    previousResults.put ((matrix, bound, maximize), res)
  }

  def getBestRoof: Option[RoofDescr[D]] = previousRoofs.get ((matrix, maximize)) match {
    case Some (keeper) => // None
      Some (keeper.getBestRoof)
    case None => None
  }

  def addRoof (descr: RoofDescr[D]): Unit = {
    previousRoofs.get ((matrix, maximize)) match {
      case Some (keeper) => 
        previousRoofs.put ((matrix, maximize), keeper.addRoof (descr))
      case None => 
        previousRoofs.put ((matrix, maximize), initRoofKeeper (descr))
    }
  }
  

  def init (constrMatrix: Matrix[D], goal: Matrix[D], b: Matrix[D]): SimplexImpl[D] = {
    new SimplexImpl (fieldEl, constrMatrix, goal, b, previousResults, previousRoofs)
  }

  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): SimplexImpl[E] = {
    val newPrevRes = previousResults.toList.map (pair =>
      ((pair._1._1.convert (conv), pair._1._2.convert (conv), pair._1._3.convert (conv)),
       pair._2.convert (conv)))
    
    val newPrevRoofs = prevRoofs.toList.map (pair => {
      ((pair._1._1.convert (conv), pair._1._2.convert (conv)),
       pair._2.convert (conv))
    })

    new SimplexImpl (conv (fieldEl), matrix.convert (conv), maximize.convert
		     (conv), bound.convert (conv), HashMap () ++= newPrevRes,
                     HashMap () ++= newPrevRoofs)
  }

  def simplex (initialRoof: Seq[Int], roofMatrix: Matrix[D],
               inverseRoofMatrix: Matrix[D]): LPResult[D] = {
    getResult match {
      case Some (res) => res
      case None => {
        val (res, descr) = getBestRoof match {
          case Some (RoofDescr (roof, roofMat, invRoofMat)) => {
            simplex0 (roof, roofMat, invRoofMat)
          }
          case None =>
            simplex0 (initialRoof, roofMatrix, inverseRoofMatrix)
        }
        addResult (res)
        if (!descr.isEmpty)
          addRoof (descr.get)
        res
      }
    }
  }

  def simplex0 (initialRoof: Seq[Int], roofMatrix: Matrix[D],
	       inverseRoofMatrix: Matrix[D]): (LPResult[D], Option[RoofDescr[D]]) = {
    val roofBound = bound.getLines (initialRoof)
    var nIter = 0
    def iterate (currentRoof: Seq[Int], curRoofMatrix: Matrix[D],
		 curInverseRoofMatrix: Matrix[D], curRoofBound: Matrix[D]): (LPResult[D],Option[RoofDescr[D]]) = {
      nIter = nIter + 1
      if (nIter % 10 == 0){
        println ("DEBUG: starting iteration " + nIter + " of simplex")
      }
      
      val roofVertex = curInverseRoofMatrix * curRoofBound
      // println ("DEBUG: roof vertex:\n" + roofVertex)
      // println ("DEBUG: current roof: " + currentRoof)
      val entering = List.range (1, matrix.nLines + 1).find (i => {
	(matrix.getLine (i) * roofVertex).get (1,1) > bound.get (i, 1)
      })
      // Roof is optimal
      if (entering.isEmpty){
        // FIXME: does not work for floats
        // It is also slow, so I disable it for now.
        // if (field.isExact)
        //   assert (isOptimal (currentRoof))
	(LPRes (field, Some ((maximize.transpose * roofVertex).get (1,1)),
	        Some (currentRoof), Some (roofVertex), true),
         Some (RoofDescr (currentRoof, curRoofMatrix, curInverseRoofMatrix)))
      }
      else {
	val newRoof = simplexPivot (initialRoof, currentRoof, curRoofMatrix,
				    curInverseRoofMatrix, curRoofBound, entering.get)
	// No solutions
	if (newRoof.isEmpty){
	  // FIXME: check it with a certificate
	  (LPRes (field, None, None, None, false), None)
	}
	else {
	  val newRoofMatrix = matrix.getLines (newRoof)
	  val newRoofBound = bound.getLines (newRoof)
	  val newInverseRoofMatrix =
	    SimplexImpl.updateInverseBasisMatrix (newRoof, newRoofMatrix, entering.get,
							curInverseRoofMatrix)

          // FIXME: Doesn't work when working with floats
          // if (field.isExact)
          //   assert ((newInverseRoofMatrix * newRoofMatrix).isIdentity)
	  iterate (newRoof, newRoofMatrix, newInverseRoofMatrix, newRoofBound)
	}
      }
    }
    // println ("DEBUG: running simplex on:")
    // println ("DEBUG: A = \n"+ matrix + "\nc =\n" + maximize + "\nb =\n" + bound)
    // println ("DEBUG: With initial roof: " + initialRoof)
    val t0 = System.currentTimeMillis ()
    val res = iterate (initialRoof, roofMatrix, inverseRoofMatrix, roofBound)
    val t2 = System.currentTimeMillis ()
    println ("DEBUG: Simplex did " + nIter + " iterations in " +
             (t2 - t0) + " ms [m = " + matrix.nLines + ", " + "n = " +
	     matrix.nCols + "]")
    // println ("DEBUG: A:\n" + matrix)
    // println ("DEBUG: b: " + bound.transpose)
    // println ("DEBUG: c: " + maximize.transpose)
    res
  }

  // Implement the lexicographical rule. FIXME: can probably be simplified or
  // written more elegantly.
  def simplexPivot (initialRoof: Seq[Int], currentRoof: Seq[Int], roofMatrix: Matrix[D],
		    inverseRoofMatrix: Matrix[D], roofBound: Matrix[D],
		    entering: Int): Seq[Int] = {
    val y = inverseRoofMatrix.transpose * (matrix.getLine (entering).scale (field.one.negate).transpose)
    // println ("DEBUG: roof matrix:\n" + roofMatrix)
    // println ("DEBUG: inverse roof matrix:\n" + inverseRoofMatrix)
    // println ("DEBUG: entering: " + entering)
    val roofWithPos = currentRoof.zip (List.range (1, currentRoof.size + 1)).toSet
    val ltZero = roofWithPos.filter (pair => y.get (pair._2, 1) < field.zero)
    if (ltZero.isEmpty){
      Seq ()
    }
    else {
      val multMatrix = maximize.appendRight (matrix.getLines (initialRoof).transpose)
      val invT = inverseRoofMatrix.transpose
      def findMin (candidates: Set[(Int, Int)], currentCol: Int): Int = {
	assert (currentCol <= multMatrix.nCols)
	assert (!candidates.isEmpty)
	
	val col = multMatrix.getCol (currentCol)

	val candVal = candidates.map (pair => {
	  (pair, (invT.getLine (pair._2) * col).get (1,1) / (y.get (pair._2, 1).negate))
	})
	// Find all the minimum values
	def accuMin (minCand: (Set[(Int, Int)],D), candVal: ((Int, Int), D)): (Set[(Int, Int)], D) = (minCand, candVal) match {
	  case ((oldCand, curMin), (cand, v)) => {
	    if (v < curMin)
	      (Set (cand), v)
	    else if (v == curMin)
	      (oldCand + cand, curMin)
	    else
	      (oldCand, curMin)
	  }
	}
	val newCandidates = candVal.foldLeft (Set[(Int, Int)](), candVal.head._2) (accuMin)._1

	assert (newCandidates.size >= 1)
	if (newCandidates.size == 1){
	  newCandidates.head._1
	}
	else {
	  findMin (newCandidates, currentCol + 1)
	}
      }
      val leaving = findMin (ltZero, 1)

      currentRoof.map (el => if (el == leaving) entering else el)
    }
  }

  def toScalaCode: Expr = {
    Apply (Identifier ("SimplexImpl"), List (field.toScalaCode,
					     matrix.toScalaCode,
					     maximize.toScalaCode,
                                             bound.toScalaCode))
  }
  def toScalaCodeDummy (matCode: Expr): Expr = {
    Apply (Identifier ("SimplexImpl"), List (matCode))
  }
  
  def getType: Type = Type ("SimplexImpl[" + field.getType.name + "]")
}

object SimplexImpl {
  // Initialize a "dummy" instance
  def apply[D <: ExpressibleOrderedField[D]] (fieldEl: D, matrixEl: Matrix[D]): SimplexImpl[D] = {
    val scal = matrixEl.init (1, 1, List (fieldEl))
    SimplexImpl (fieldEl, scal, scal, scal)
  }
  def apply[D <: ExpressibleOrderedField[D]] (matrixEl: Matrix[D]): SimplexImpl[D] = {
    val scal = matrixEl.zero (1, 1)
    SimplexImpl (scal.get (1,1), scal, scal, scal)
  }
  
  def apply[D <: ExpressibleOrderedField[D]] (field:D, matrix: Matrix[D], maximize:
                                              Matrix[D], bound: Matrix[D]): SimplexImpl[D] = {
    new SimplexImpl (field, matrix, maximize, bound, HashMap[(Matrix[D], Matrix[D], Matrix[D]),LPResult[D]] (), HashMap[(Matrix[D], Matrix[D]), RoofKeeper[D]] ())
  }

  // Return the new inverse basis matrix given the old one, if the new set is
  // actually a basis, None otherwise.
  def updateInverseBasisMatrixTry[D <: ExpressibleOrderedField[D]]
    (newBasis: Seq[Int],  newBasisMatrix: Matrix[D], entering: Int,
     inverseBasisMatrix: Matrix[D]): Option[Matrix[D]] = {
    // Compute newInverseBasisMatrix.inverse` in a more efficient way.
    val enteringID = newBasis.findIndexOf (el => el == entering)
    assert (enteringID != -1)
    val u = (newBasisMatrix.getLine (enteringID + 1) * inverseBasisMatrix).transpose
    val appendedInverse = inverseBasisMatrix.transpose.appendRight (u)
    if (appendedInverse.get (enteringID + 1, appendedInverse.nCols).isZero)
      None
    else
      Some (appendedInverse.elimColumnFromElem (appendedInverse.nCols,
						enteringID + 1).getCols (1,
	                                                           appendedInverse.nCols - 1).transpose)
  }

  // Return the new inverse basis matrix given the old one.
  def updateInverseBasisMatrix[D <: ExpressibleOrderedField[D]]
    (newBasis: Seq[Int],  newBasisMatrix: Matrix[D], entering: Int,
     inverseBasisMatrix: Matrix[D]): Matrix[D] = {
      
    val res = updateInverseBasisMatrixTry (newBasis, newBasisMatrix, entering, inverseBasisMatrix)
    require (!res.isEmpty)
    res.get
  }
}
