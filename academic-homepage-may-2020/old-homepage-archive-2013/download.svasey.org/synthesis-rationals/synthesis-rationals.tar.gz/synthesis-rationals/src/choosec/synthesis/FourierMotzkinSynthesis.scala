package choosec
package synthesis

import trees.Formulas._
import trees.FormulaTransforms._
import trees.ScalaExpressible
import code.SimpleAST
import code.SimpleAST.SimpleExpr
import code.SimpleAST.Max
import code.SimpleAST.Min
import code.SimpleAST.Plus
import code.SimpleAST.Minus
import code.SimpleAST.FieldEl
import code.SimpleAST.UpTo
import code.SimpleAST.If
import code.SimpleAST.Block
import code.SimpleAST.BoundedRes
import code.SimpleAST.SetBound
import code.SimpleAST.GetBound
import code.SimpleAST.uniqueID
import code.SimpleAST.Val
import code.SimpleAST.UnfeasibleRes
import code.SimpleType._
import numbers._

class FourierMotzkinSynthesis[D <: ExpressibleOrderedField[D]] (fieldElem: D) extends LASynthesisMethod[D] {
  val field = fieldElem

   def synthetizeConj (variables: Seq[Variable], formula: LAFormula[D]): (LAFormula[D], SimpleExpr) = {
     synthetizeMultiVariables (variables, formula, synthetizeConjSingle)
   }

  // This assumes the formula is only a (flattened) conjunction. The code should
  // return a number.
  def synthetizeConjSingle (variable: Variable, formula: LAFormula[D]): (LAFormula[D], SimpleExpr) = {
    // println ("DEBUG: synthetizing conj for single variable " + variable + " " + formula)
    val litt = formula match {
      case And (formulas) => formulas.map (x => x match {
	case Rel (r) => r
	case _ => error ("Formula should be in flattened DNF: " + formula)
      })
      case x @ _ => x match {
	case Rel (r) => Set (r)
      }
    }
    // Put all inequalities and equalities in canonical form
    val newLitt =
      litt.map (r => rearrangeRelation (r))

    val (withVar,
	 withoutVar) = newLitt.partition (x => x.containsVariable (variable))
    val withEqual = withVar.find (x => x match {
      case Equals (_, _) => true ; case _ => false })
    val (pre0, code) = withEqual match {
      case Some (Equals (lhs, rhs)) => {
	val lhs2 = lhs.asInstanceOf[LinearCombination[D]]
	val rhs2 = rhs.asInstanceOf[LinearCombination[D]]
	val sol = lhs2.solveEquality (variable, rhs2)
	sol match {
	  case Some (term) => {
	    val forms:Set[LAFormula[D]] = withVar.map (r =>
	      Rel[LAFunction[D],ArithmeticRelation] (r.replaceVariable (variable, term)))
	    (And[LAFunction[D],ArithmeticRelation](forms),  term.toSimpleExpr)
	  }
	  // This shouldn't happen, as we have put everything in canonical form.
	  case None => error ("Could not solve equality " + withEqual.get)
	}
      }
      case None => {
	if (withVar.isEmpty){
	  (Rel(True):LAFormula[D], FieldEl (field.zero))
	}
	else {
	  synthetizeLt (variable, withVar)
	}
      }
    }

    (LAsimplify (And (pre0, And(withoutVar.map (r => Rel[LAFunction[D], ArithmeticRelation] (r))))), code)
  }

  // Synthetize for the given variable to satisfy all the given
  // inequalities. The given inequalities are assumed to be of the form t < 0,
  // t <= 0, 0 <= t, or 0 < t, where t contains (a non-zero multiple of) x. The
  // code should return a number.
  private def synthetizeLt (variable: Variable, inequalities: Set[ArithmeticRelation]): (LAFormula[D], SimpleExpr) = {
    // Compute strict and non-strict lower and upper bounds for `variable` in
    // each of the given inequalities, and add them to the sets of lower or
    // upper bounds.
    def computeBounds (ineq: List[ArithmeticRelation], strictLower: List[LinearCombination[D]],
		       nonStrictLower: List[LinearCombination[D]],
		       strictUpper: List[LinearCombination[D]],
		       nonStrictUpper: List[LinearCombination[D]]): (List[LinearCombination[D]], List[LinearCombination[D]], List[LinearCombination[D]], List[LinearCombination[D]]) = {
      def addBound (lhs: LinearCombination[D], rhs: LinearCombination[D], lower: List[LinearCombination[D]], upper: List[LinearCombination[D]]): (List[LinearCombination[D]], List[LinearCombination[D]]) = {
	val bound = lhs.solveEquality (variable, rhs) match {
	  case Some (x) => x
	  case None => error ("Expected inequality to contain " + variable)
	}
	// Look at the sign of `variable` in lhs to determine whether it is an
	// upper or a lower bound
	assert (lhs.containsVariable (variable))
	val sign = lhs.coeff(Some (variable)).signum
	assert (sign != 0)
	if (sign > 0)
	  (lower, bound::upper)
	else
	  (bound::lower, upper)
      }

      ineq match {
	case Nil => (strictLower, nonStrictLower, strictUpper, nonStrictUpper)
	case rel::tail => rel match {
	  case Lt (lhs, rhs) => {
	    val (newLower, newUpper) = addBound (lhs.asInstanceOf[LinearCombination[D]],
						 rhs.asInstanceOf[LinearCombination[D]],
						 strictLower, strictUpper)
	    computeBounds (tail, newLower, nonStrictLower, newUpper, nonStrictUpper)
	  }
	  case LtEqual (lhs, rhs) => {
	    val (newLower, newUpper) = addBound (lhs.asInstanceOf[LinearCombination[D]],
						 rhs.asInstanceOf[LinearCombination[D]],
						 nonStrictLower, nonStrictUpper)
	    computeBounds (tail, strictLower, newLower, strictUpper, newUpper)
	  }
	}
      }
    }
  
    // Set of lower and upper bounds
    val (strictLower, nonStrictLower, strictUpper, nonStrictUpper) = computeBounds (inequalities.toList, List (), List (), List (), List ())
    val lower = strictLower ++ nonStrictLower
    val upper = strictUpper ++ nonStrictUpper
    // println ("DEBUG: strict lower bounds: " + strictLower)
    // println ("DEBUG: non-strict lower bounds: " + nonStrictLower)
    // println ("DEBUG: strict upper bounds: " + strictUpper)
    // println ("DEBUG: non-strict upper bounds: " + nonStrictUpper)
    val code = {
      def lowerMax = Max (lower.map (b => b.toSimpleExpr))
      def upperMin = Min (upper.map (b => b.toSimpleExpr))

      if (lower.isEmpty){
	// min(upper) - 1
	Minus (upperMin, FieldEl (field.one))
      }
      else if (upper.isEmpty) {
	// max(lower) + 1
	Plus (lowerMax, FieldEl (field.one))
      }
      else {
	// Choose any x s.t max(lower) < x < min(upper) .
        UpTo (upperMin, lowerMax)
      }
    }
    val pre = {
      // Essentially produce all the possible cross-terms
      val rels1 =
	for (low <- strictLower; up <- strictUpper) yield (Rel (Lt (low, up))):LAFormula[D]
      val rels2 =
	for (low <- nonStrictLower; up <- strictUpper) yield (Rel (Lt (low, up))):LAFormula[D]
      val rels3 =
	for (low <- strictLower; up <- nonStrictUpper) yield (Rel (Lt (low, up))):LAFormula[D]
      val rels4 =
	for (low <- nonStrictLower; up <- nonStrictUpper) yield (Rel (LtEqual (low, up))):LAFormula[D]
      flatten (And ((rels1 ++ rels2 ++ rels3 ++ rels4).toSet))
    }
    
    (pre, code)
  }

  // Synthetize the linear problem "maximize c * x under constraint Ax [<=/<]
  // b". The first `nNonStrict` constrains of the matrix are non-strict
  // inequalities, and the rest are strict. This assumes the matrix is full
  // rank, and the problem is bounded (if it is feasible). The pre-condition
  // should be true if and only if the problem is feasible.
  def synthetize (matrix: Matrix[D], bound: List[LinearCombination[D]], maximize: Matrix[D], nNonStrict: Int): (LAFormula[D], SimpleExpr) = {
    val parameters = bound.flatMap (lc => lc.allVariables).toSet
    val prefix = findPrefix ("x", parameters.map (p => p.name))
    val variables = List.fill (matrix.nCols) {Variable (uniqueID (prefix).name)}
    assert (variables.length == maximize.nLines)

    // println ("DEBUG: matrix:\n" + matrix)
    // println ("DEBUG: bound:\n" + bound)
    // println ("DEBUG: nNonStrict: " + nNonStrict)
    // println ("DEBUG: maximize: " + maximize.transpose)
    val forms = List.range (1, matrix.nLines + 1).map (id => {
      def rel (lhs: LinearCombination[D], rhs: LinearCombination[D]): LAFormula[D] = {
        if (id <= nNonStrict)
          Rel (LtEqual (lhs, rhs))
        else
          Rel (Lt (lhs, rhs))
      }
      rel (LinearCombination (variables, matrix.getLine (id)), bound (id - 1))
    })
    val formula = And (forms.toSet)

    if (maximize.isZero)
      synthetize (variables, formula, None)
    else {
      val maxID = uniqueID ("lambda")
      val maxVariable = Variable (maxID.name)
      val maxFormula = And (formula, Rel (LtEqual (LinearCombination (maxVariable,
								      field.one),
						   LinearCombination (variables, maximize))):LAFormula[D])
      val (equivFormula, code0) = synthetize (variables, maxFormula, None)

      def synth (equivForm: LAFormula[D]): (LAFormula[D], SimpleExpr) = {
	equivForm match {
	  case And (litt) => {
	    val (litt1, litt2) = litt.partition (f => f.containsVariable (maxVariable))
	    val pre = simplify (And (litt2))
	    val code = {
	      val upperBounds = litt1.flatMap (_ match {
		case Rel (r0) => {
		  val (lc, isStrict) = rearrangeRelation (r0) match {
		    case Lt (lhs, _) => (lhs.asInstanceOf[LinearCombination[D]], true)
		    case LtEqual (lhs, _) => (lhs.asInstanceOf[LinearCombination[D]], false)
		    case _ => error ("Unexpected relation in equivalent formula")
		  }
		  val isUpper = lc.getCoeff (field, maxVariable).signum > 0
		  if (isUpper){
		    val upperBound = lc.solveEquality (maxVariable, LinearCombination (field.zero)).get
		    Set ((upperBound, isStrict))
		  }
		  else
		    Set[(LinearCombination[D], Boolean)] ()
		}
		case _ => error ("Unexpected formula")
	      }):Set[(LinearCombination[D], Boolean)]
	      assert (!upperBounds.isEmpty)
	      val (strictBounds, nonStrictBounds) = upperBounds.partition (ub => ub._2)

	      val strictBoundID = uniqueID ("lambda_strict")
	      def compute (xs: Set[(LinearCombination[D], Boolean)]): SimpleExpr = {
		if (xs.isEmpty)
		  FieldEl (field.zero)
		else
		  Min (xs.map (b => b._1.toSimpleExpr).toSeq)
	      }
	      val strictBoundVal = Val (strictBoundID, compute (strictBounds), TField)
	      val maxVal = Val (maxID, compute (nonStrictBounds), TField)

	      val maximizedRes = {
		val resID = uniqueID ("tmpres")
		val resVal = Val (resID, code0, TResult)
		Block (resVal, SetBound (resID, maximize))
	      }
	      val boundedRes = BoundedRes (strictBoundID)

	      if (strictBounds.isEmpty)
		Block (maxVal, maximizedRes)
	      else if (nonStrictBounds.isEmpty)
		Block (strictBoundVal, boundedRes)
	      else {
		val decls = List (strictBoundVal, maxVal)

		Block (decls, If (SimpleAST.Lt (maxID, strictBoundID),
				  maximizedRes,
				  boundedRes))
	      }
	    }
	    (pre, code)
	  }
	  case Rel (False) => (Rel (False), UnfeasibleRes)
	  case Rel (_) => synth (And (Set (equivForm)))
	  case _ => error ("Unexpected equivalent formula " + equivForm)
	}
      }
      
      synth (simplify (equivFormula))
            
    }
  }
  // Old, inefficient code for Fourier-Motzkin that uses the complementary
  // slackness theorem.
    // val forms = 
    // if (maximize.isZero){
    //   val forms = List.range (1, matrix.nLines + 1).map (id => {
    // 	def rel (lhs: LinearCombination[D], rhs: LinearCombination[D]): LAFormula[D] = {
    //       if (id <= nNonStrict)
    //         Rel (LtEqual (lhs, rhs))
    //       else
    //         Rel (Lt (lhs, rhs))
    // 	}
    // 	rel (LinearCombination (variables, matrix.getLine (id)), bound (id - 1))
    //   })
    //   val formula = And (forms.toSet)

    //   // println ("DEBUG: formula: " + formula)
    //   synthetize (variables, formula, None)
    // }
    // else {
    //   // Use duality to find the maximum when there is one
    //   val fullYVariables = List.fill (matrix.nLines) {Variable (uniqueID (prefix).name)}
    //   val yVariables = fullYVariables.take (nNonStrict)
    //   val strictForms:List[LAFormula[D]] = {
    // 	List.range (nNonStrict + 1, matrix.nLines + 1).map (id => {
    // 	  Rel (Lt (LinearCombination (variables, matrix.getLine (id)), bound (id - 1))):LAFormula[D]
    // 	})
    //   }
    //   val equalForms:List[LAFormula[D]] = {
    //     if (nNonStrict == 0){
    //       List ()
    //     }
    //     else {
    // 	  List.range (1, matrix.nCols + 1).map (id => {
    // 	    Rel (Equals (LinearCombination (yVariables,
    // 					    matrix.getCol (id).getLines (1, nNonStrict)),
    // 		         LinearCombination (maximize.get (id, 1)))):LAFormula[D]
    // 	  })
    //     }
    //   }

    //   val fullDualDisj:List[LAFormula[D]] = {
    // 	List.range (1, matrix.nLines + 1).map (id => {
    // 	  val ax = LinearCombination (variables, matrix.getLine (id))
    // 	  val b = bound (id - 1)
    // 	  val y = LinearCombination (fullYVariables (id - 1), field.one)
    // 	  val z = LinearCombination (field.zero)

    // 	  Or (And (Rel (Equals (ax, b)):LAFormula[D], Rel (LtEqual (z, y)):LAFormula[D]),
    // 	      And (Rel (Lt (ax, b)):LAFormula[D], Rel (Equals (z, y)):LAFormula[D]))
    // 	})
    //   }
    //   val dualDisj = fullDualDisj.take (nNonStrict)
      
    //   val initialFormula:LAFormula[D] = {
    // 	if (nNonStrict == 0){
    // 	  Rel (False)
    // 	}
    // 	else {
    // 	  quantify (Existential, yVariables, And (strictForms.toSet ++ equalForms.toSet ++ Set (And (dualDisj.toSet))))
    // 	}
    //   }

    //   // println ("DEBUG: initial formula: " + initialFormula)

    //   val (pre, maximizeInitial) = synthetize (variables, initialFormula, None)
    //   // Even if the original problem has no solution, it might still be
    //   // feasible and bounded above: check this.
    //   val feasiblePre = {
    // 	if (nNonStrict == matrix.nLines) pre
    // 	else synthetize (matrix, bound, maximize.zero, nNonStrict)._1
    //   }
    //   val fullEqualForms:List[LAFormula[D]] = {
    // 	List.range (1, matrix.nCols + 1).map (id => {
    // 	  Rel (Equals (LinearCombination (fullYVariables, matrix.getCol (id)),
    // 		       LinearCombination (maximize.get (id, 1)))):LAFormula[D]
    // 	})
    //   }

    //   val nonStrictFormula:LAFormula[D] = {
    // 	if (nNonStrict == matrix.nLines) Rel (False)
    // 	else quantify (Existential, fullYVariables, And (fullEqualForms.toSet ++ Set (And (fullDualDisj.toSet))))

    //   }
    //   // println ("DEBUG: nonStrictFormula: " + nonStrictFormula)
      
    //   val (nonStrictPre, maximizeNonStrict) = synthetize (variables, nonStrictFormula, None)
    //   val code = {
    // 	val solName = uniqueID ("fullSolution")
    // 	val nonStrictSolName = uniqueID ("nonStrictSolution")

    //     val maxSol = Block (Val (solName, maximizeInitial,TResult),
    //                         SetBound (solName, maximize))
    //     val boundedSol = {
    //       Block (Val (nonStrictSolName, maximizeNonStrict, TResult),
    //              BoundedRes (GetBound (SetBound (nonStrictSolName, maximize))))
    //     }

    //     // We assume `feasiblePre` holds at that point.
    //     if (nNonStrict == matrix.nLines) maxSol
    //     else If (pre.toSimpleExpr, maxSol, boundedSol)
    //   }
    //   (feasiblePre, code)
}

object RFourierMotzkinSynthesis extends FourierMotzkinSynthesis[Rational] (Rational.r)
