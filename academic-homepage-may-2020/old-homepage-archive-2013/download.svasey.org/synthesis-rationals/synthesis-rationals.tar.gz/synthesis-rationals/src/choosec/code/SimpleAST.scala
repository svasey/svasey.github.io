package choosec
package code

import numbers._
import simplex._
import SimpleType._
import SimpleSymbols._

import trees.ScalaCode

// AST for a simple intermediate language

object SimpleAST {

  def uniqueID (prefix: String): Identifier =
    Identifier (ScalaCode.uniqueIdentifier (prefix).name)

  trait SimpleExpr extends Typed {
    // Recursively transform any of the subexpression of the node with
    // transf. `transf` is assumed not to change the types of the expressions.
    def recTransform0 (transf: SimpleExpr => SimpleExpr): SimpleExpr
    def recTransform (transf: SimpleExpr => SimpleExpr): SimpleExpr = {
      require (this.isTyped)
      val oldExpr = this
      val newExpr = oldExpr.recTransform0 (transf)
      newExpr.copyType (oldExpr)
      assert (newExpr.isTyped)
      newExpr
    }
  }
  trait Leaf extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) = this
  }

  case class If (cond: SimpleExpr, then: SimpleExpr, els:SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      If (transf (cond), transf (then), transf (els))
  }

  case class Plus (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Plus (transf (lhs), transf (rhs))
  }
  case class Minus (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Minus (transf (lhs), transf (rhs))
  }
  case class Times (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Times (transf (lhs), transf (rhs))
  }
  // case class DividedBy (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
  //   def recTransform0 (transf: SimpleExpr => SimpleExpr) =
  //     DividedBy (transf (lhs), transf (rhs))
  // }

  case class Max (exprs: Seq[SimpleExpr]) extends SimpleExpr {
    require (!exprs.isEmpty)
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Max (exprs.map (transf))
  }
  case class Min (exprs: Seq[SimpleExpr]) extends SimpleExpr {
    require (!exprs.isEmpty)
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Min (exprs.map (transf))
  }
  case class UpTo (from: SimpleExpr, to: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      UpTo (transf (from), transf (to))
  }
  case class Lt (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Lt (transf (lhs), transf (rhs))
  }
  case class LtEq (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      LtEq (transf (lhs), transf (rhs))
  }
  case class Eq (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Eq (transf (lhs), transf (rhs))
  }
  case class And (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      And (transf (lhs), transf (rhs))
  }
  case class Or (lhs: SimpleExpr, rhs: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Or (transf (lhs), transf (rhs))
  }
  case class Not (e: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      Not (transf (e))
  }

  def fromBoolean (b: Boolean): SimpleExpr =
    if (b) True.setType (TBool) else False.setType (TBool)
  
  case object True extends SimpleExpr with Leaf
  
  case object False extends SimpleExpr with Leaf

  trait Result extends SimpleExpr

   case class CallSolver[D <: ExpressibleOrderedField[D]] (solver: SimplexSolver[D], initialRoof: Seq[Int], roofMatrix: Matrix[D], inverseRoofMatrix: Matrix[D], canBeUnbounded: Boolean, nNonStrict: Int, bound: Seq[SimpleExpr]) extends Result {
     def recTransform0 (transf: SimpleExpr => SimpleExpr) =
       CallSolver (solver, initialRoof, roofMatrix, inverseRoofMatrix,
                   canBeUnbounded, nNonStrict, bound.map (transf))
   }
  case class MaximizedRes (sol: Seq[SimpleExpr], bound: SimpleExpr) extends Result {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      MaximizedRes (sol.map (transf), transf (bound))
  }
  case class BoundedRes (bound: SimpleExpr) extends Result {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      BoundedRes (transf (bound))
  }
  // Result when we know something is wrong, but we do not know what, e.g when
  // the pre-condition is not satisfied
  case class ErrorRes (msg: String) extends Result with Leaf
  case object UnboundedRes extends Result with Leaf
  case object UnfeasibleRes extends Result with Leaf

  case class IsFeasible (res: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      IsFeasible (transf (res))
  }
  case class HasSolution (res: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      HasSolution (transf (res))
  }
  // Get the ith component (1-based) of the solution. 
  case class GetSolution (res: SimpleExpr, id: Int) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      GetSolution (transf (res), id)
  }
  case class SetBound[D <: ExpressibleOrderedField[D]] (res: SimpleExpr, maximize: Matrix[D]) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      SetBound (transf (res), maximize)
  }
  case class MultiplySol[D <: ExpressibleOrderedField[D]] (res: SimpleExpr,
                                                           matrix: Matrix[D]) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      MultiplySol (transf (res), matrix)
  }
  case class GetBound (res: SimpleExpr) extends SimpleExpr {
    def recTransform0 (transf: SimpleExpr => SimpleExpr) =
      GetBound (transf (res))
  }

  case class FieldEl[D <: ExpressibleOrderedField[D]] (value: D) extends SimpleExpr with Leaf

  case class Identifier (name: String) extends SimpleExpr with Leaf with Symbolic {
    override def setType (tpe: Type) = {
      this.getSymbol.setType (tpe); this }
    override def getType: Type = this.getSymbol.getType
    // override def setPossibleRes (res: Set[Result]) = {
    //   // println ("DEBUG: setting possible result of identifier: " + this)
    //   this.getSymbol.setPossibleRes (res); this
    // }
    // override def getPossibleRes: Set[Result] = this.getSymbol.getPossibleRes
    // override def hasPossibleRes: Boolean = this.getSymbol.hasPossibleRes
  }
  
  case class Block (vals: Seq[Val], ret: SimpleExpr) extends SimpleExpr {
    private def typed: Boolean =
      this.isTyped && vals.forall (v => v.id.isTyped && v.expr.isTyped) && ret.isTyped
    override def recTransform (transf: SimpleExpr => SimpleExpr): SimpleExpr = {
      require (typed)
      val r = Block (vals.map (v => Val (v.id, transf (v.expr).copyType (v.expr), v.typ)),
		     transf (ret).copyType (ret)).copyType (this)
      assert (typed)
      r
    }
    def recTransform0 (transf: SimpleExpr => SimpleExpr): SimpleExpr = {
      assert (false, "Should never be called edirectly")
      this
    }
  }
  
  object Block {
    def apply (firstVal: Val, ret: SimpleExpr): Block = {
      Block (List (firstVal), ret)
    }
  }

  case class Val (id: Identifier, expr: SimpleExpr, typ: Type, useLazy: Boolean)

  object Val {
    def apply (id: Identifier, expr: SimpleExpr, typ: Type): Val =
      Val (id, expr, typ, false)
  }

  def runTransform (postTransf: SimpleExpr => SimpleExpr,
                    expr: SimpleExpr): SimpleExpr = 
    runTransform ((e: SimpleExpr) => e, postTransf, expr)
  
  // Recursively run a transformation on the input expression. Note
  // that type annotation should stay preserved under this transformation.
  def runTransform (preTransf: SimpleExpr => SimpleExpr,
		    postTransf: SimpleExpr => SimpleExpr,
                    expr: SimpleExpr): SimpleExpr = {
    require (expr.isTyped, "Expression: " + expr + " is not typed")
    val toRet = {
      val afterExpr = preTransf (expr).copyType (expr)
      val newExpr = afterExpr.recTransform (e => runTransform (preTransf, postTransf, e))
      postTransf (newExpr).copyType (newExpr)
    }

    assert (toRet.isTyped)
    toRet
  }

  def replaceIdentifier (id: Identifier, withExpr: SimpleExpr, inExpr: SimpleExpr): SimpleExpr = {
    def transf (exp: SimpleExpr): SimpleExpr = exp match {
      case ident @ Identifier (_) => if (ident.getSymbol == id.getSymbol) withExpr else exp
      case _ => exp
    }
    runTransform (transf, inExpr)
  }
}
