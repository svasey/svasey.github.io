package choosec
package synthesis

import simplex._
import numbers._
import trees.Formulas._

// Still use the simplex to try to solve the problem, but synthetized code
// according to the Fourier Motzkin method only
class MixedFMSynthesis[D <: ExpressibleOrderedField[D]] (fieldElem: D,
                                                         matrixElem: Matrix[D], solverEl: SimplexSolver[D]) extends MixedSynthesis (fieldElem, matrixElem, solverEl) {
  override def canUseFM (matrix: Matrix[D], bound: List[LinearCombination[D]],
                maximize: Matrix[D], nNonStrict: Int): Boolean = true
}

// Pure simplex synthesis, does not use the Fourier-motzkin method at all
class PureSimplexSynthesis[D <: ExpressibleOrderedField[D]] (fieldElem: D,
  matrixElem: Matrix[D], solverEl: SimplexSolver[D]) extends MixedSynthesis (fieldElem, matrixElem, solverEl){
  override def canUseFM (matrix: Matrix[D], bound: List[LinearCombination[D]],
                maximize: Matrix[D], nNonStrict: Int): Boolean = false
}
