package choosec
package trees

import Formulas._
import numbers._

// Various methods to transform the formula AST
object FormulaTransforms {
  // Return true if the formula is a litteral, false otherwise
  def isLitteral[F <: Function,R <: Relation] (formula: Formula[F,R]): Boolean = formula match {
    case Rel(_) => true
    case Unknown () => true
    case _ => false
  }

  // Return true if the formula is a litteral or the negation of a litteral,
  // false otherwise
  def isAtom[F <: Function,R <: Relation] (formula: Formula[F,R]): Boolean = formula match {
    case Not (form) => isLitteral (form)
    case _ => isLitteral (formula)
  }

  // Return true if the formula has "Unkown" in its tree
  def hasUnknown[F <: Function, R <: Relation] (formula: Formula[F,R]): Boolean = formula match {
    case Or (formulas) => formulas.exists (x => hasUnknown (x))
    case And (formulas) => formulas.exists (x => hasUnknown (x))
    case Not (form) => hasUnknown (form)
    case Quantifier (v, t, form) => hasUnknown (form)
    case Rel (_) => false
    case Unknown () => true
  }
  // Return a formula equivalent to a implies b
  def implies[F <: Function, R <: Relation] (a: Formula[F,R], b: Formula[F,R]): Formula[F,R] = 
    Or (b, Not (a))

  // Return a formula equivalent to a iff b
  def equiv[F <: Function, R <: Relation] (a: Formula[F,R], b: Formula[F,R]): Formula[F,R] =
    And (implies (a, b), implies (b, a))

  // Given a formula and a collection of variables, quantify the formula for
  // those variables.
  def quantify[F <: Function, R <: Relation] (quant: QuantifierType,
					      variables: Traversable[Variable], 
					      formula: Formula[F,R]): Formula[F,R] = {
    variables.foldLeft (formula) ((form, v) => Quantifier (v, quant, form))
  }

  // Given a formula, transform it to negation-normal-form, i.e push the
  // negations inside the formula and eliminate double negations
  def negationNormalForm[F <: Function, R <: Relation] (formula: Formula[F,R]): Formula[F,R] = formula match {
    case Or (formulas) => Or (formulas.map (f => negationNormalForm (f)))
    case And (formulas) => And (formulas.map (f => negationNormalForm (f)))
    case Quantifier (v, t, form) => Quantifier (v, t, negationNormalForm (form))
    case Not (form) => form match {
      case Or (formulas) => And (formulas.map (f => negationNormalForm (Not (f))))
      case And (formulas) => Or (formulas.map (f => negationNormalForm (Not (f))))
      case Quantifier (v, t, f) => Quantifier (v, t.dual,
                                               negationNormalForm (Not (f)))
      case Not (f) => negationNormalForm (f)
      case Rel (_) => Not (form)
      case Unknown () => Unknown ()
    }
    case Rel (_) => formula
    case Unknown () => formula
  }

  // Check the given candidate against all string in the name. If no string
  // begins with the candidate, return the candidate, else augment
  // the candidate so that no string in the name set begins with it.
  def findPrefix (candidate: String, nameSet: Set[String]): String = {
    nameSet.foldLeft (candidate) ((cand, str) => {
      def rec (c: String): String = {
        if (str.startsWith (c))
          rec (c ++ "0")
        else
          c
      }
      rec (cand)
    })
  }

  // Return a short string such that no variable in the formula (quantified or
  // not) begins with this string.
  def uniquePrefix (formula: FormulaAST): String = {
    findPrefix ("g", formula.allVariables.map (v => v.name))
  }

  // Convert a formula in negation-normal form to its prenex form. Rename
  // quantified variables to avoid conflicts.
  def prenexForm[F <: Function, R <: Relation] (formula: Formula[F,R]): Formula[F,R] = {
    val prefix = uniquePrefix (formula)
    // Given formulas in prenex form, push their quantifier outside, using the
    // given compose function to combine two formulas. Return the resulting
    // formula and the new ID to append to the next variables to be renamed.
    def pushOutside (compose: (Formula[F,R], Formula[F,R]) => Formula[F,R],
                     formulas: Set[Formula[F,R]], id: Int): (Formula[F,R], Int) = {
      assert (formulas.size >= 1)
      if (formulas.size == 1){
	(formulas.head, id)
      }
      else {
	val left = formulas.head
	val (right, nextId) =
	  if (formulas.size > 2)
	    pushOutside (compose, formulas - left, id)
	  else
	    (formulas.tail.head, id)
	    
	    
	left match {
          case Quantifier (v, t, f) => {
	    val newF = f.renameVariables (v.name, prefix + nextId)
            val (res, newId) = pushOutside (compose, Set (newF) + right, nextId + 1)
            (Quantifier (Variable (prefix + nextId), t, res), newId)
          }
          case _ => right match {
            case Quantifier (_, _, _) => pushOutside (compose, Set (right) + left, nextId)
            case _ => (compose (left, right), nextId)
          }
	}
      }
    }
    def prenexForm0 (formula: Formula[F,R], id: Int): (Formula[F,R], Int) = {
      def rec (formulas: Set[Formula[F,R]], cur: Set[Formula[F,R]],
	       curId: Int): (Int, Set[Formula[F,R]]) = {
	if (formulas.isEmpty)
	  (curId, cur)
	else {
	  val f = formulas.head
	  val (newF, newId) = prenexForm0 (f, curId)
	  rec (formulas - f, cur + newF, newId)
	}
      }
	
      formula match {
	case Or (formulas) => {
	  val (id2, newFormulas) = rec (formulas, Set (), id)
	  
          pushOutside ((l, r) => Or (l, r), newFormulas, id2)
	}
	case And (formulas) => {
	  val (id2, newFormulas) = rec (formulas, Set (), id)
	  
          pushOutside ((l, r) => And (l, r), newFormulas, id2)
	}
	case Quantifier (v, t, f) => {
          val (newF, newId) = prenexForm0 (f, id)
          (Quantifier (v, t, newF), newId)
	}
	case Not (_) |  Rel (_) | Unknown () => (formula, id)
      }
    }

    prenexForm0 (formula, 1)._1
  }
  // Transform a formula in prenex, negation-normal form to a formula in
  // disjunctive normal prenex form. Flatten the formula (c.f flattenDNF)
  def disjunctiveNormalForm[F <: Function, R <: Relation] (formula: Formula[F,R]): Formula[F,R] = {
    formula match {
      case Or (formulas) =>
        simplifyDNF (flatten (Or (formulas.map (f => disjunctiveNormalForm (f)))))
      case And (formulas) => {
	assert (formulas.size >= 1)
	val newFormulas = formulas.map (f => disjunctiveNormalForm (f))
	if (newFormulas.size == 1){
	  newFormulas.head
	}
	else {
          assert (newFormulas.size >= 2)
          val dnfLhs = newFormulas.head
          val dnfRhs = {
	    if (newFormulas.size > 2)
	      disjunctiveNormalForm (And (newFormulas - dnfLhs))
	    else
	      newFormulas.tail.head
	  }
          dnfLhs match {
            // Use the distributive law
            case Or (forms) => {
	      simplifyDNF (flatten (Or (forms.map (f => disjunctiveNormalForm (And (f, dnfRhs))))))
	    }
            case _ => dnfRhs match {
              // Just swap the two sides (this is done to avoid duplicating code)
              case Or (_) => disjunctiveNormalForm (And (dnfRhs, dnfLhs))
              case _ => simplifyDNF (flatten (And (dnfLhs, dnfRhs)))
            }
          }
	}
      }
      case Quantifier (v, t, form) => Quantifier (v, t, disjunctiveNormalForm (form))
      // Because the formula is in NNF, we can ignore negations too 
      case Not (_) | Rel (_) | Unknown () => formula
    }
  }
  
  // Given a formula, "flatten" it, i.e make sure there are no nested Ors and
  // Ands in its AST. 
  def flatten[F <: Function, R <: Relation] (formula: Formula[F,R]): Formula[F,R] = formula match {
    case Or (formulas) => {
      val newFormulas = formulas.flatMap (f => flatten (f) match {
	case Or (forms) => forms
	case x @ _ => Set (x)
      })
      if (newFormulas.size == 1)
	newFormulas.head
      else
	Or (newFormulas)
    }
    case And (formulas) => {
      val newFormulas = formulas.flatMap (f => flatten (f) match {
	case And (forms) => forms
	case x @ _ => Set (x)
      })
      if (newFormulas.size == 1)
	newFormulas.head
      else
	And (newFormulas)
    }
    case Not (form) => Not (flatten (form))
    case Quantifier (v, t, f) => Quantifier (v, t, flatten (f))
    case _ => formula
  }

  // Given a formula in flattened DNF, try to compactify it, i.e (a && b) || a
  // is equivalent to a.
  def simplifyDNF[F <: Function, R <: Relation] (formula: Formula[F,R]): Formula[F,R] = formula match {
    case Or (formulas) => {
      // Since the formula is flattened, we can require this
      require (formulas.size >= 2)
      val first = formulas.head
      val rhs =
	if (formulas.size == 2)
	  formulas.tail.head
	else
	  Or (formulas - first)
      
      val rest = simplifyDNF (rhs) match {
	case Or (f) => f
	case x @ _ => Set (x)
      }

      first match {
	case And (forms) => {
	  if (rest.exists (x => {
	    x match { case And (f) => f.subsetOf (forms);
		     case x @ _ => forms.contains (x) }}))
	    if (rest.size == 1)
	      rest.head
	    else
	      Or (rest)
	  else
	    Or (rest + first)
	}
	case _ => Or (rest + first)
      }
    }
    case _ => formula
  }

  // Given a formula which is a disjunction of at least two formulas, return the
  // first formula, and the rest of the disjunctions, i.e if f = a_1 || a_2 ||
  // a_3 ... || a_n, return (a_1,a_2 || a_3 ... || a_n).
  def recSplit[F <: Function, R <: Relation] (disj: Or[F,R]): (Formula[F,R], Formula[F,R]) = disj match {
    case Or (formulas) => {
      require (formulas.size >= 2)
      val lhs = formulas.head
      val rhs = {
	if (formulas.size > 2)
	  Or (formulas - lhs)
	else
	  formulas.tail.head
      }
      (lhs, rhs)
    }
  }

  // Remove the negations and the relations true and false from a formula of
  // linear arithmetic in negation normal form, so that in the end we obtain
  // either True, False, or a formula in NNF without true, false, or negations
  def removeNegations[D <: ExpressibleOrderedField[D]] (formula: LAFormula[D]): LAFormula[D] = formula match {
    case Or (formulas) => {
      val newFormulas =
        formulas.map (f => removeNegations (f)).filter (f => f match {
          case Rel (False) => false
          case _ => true
        })
      if (newFormulas.exists (f => f match { case Rel (True) => true ; case _ => false }))
	Rel (True)
      else if (newFormulas.isEmpty)
        Rel (False)
      else
	Or (newFormulas)
    }
    case And (formulas) => {
      val newFormulas = formulas.map (f => removeNegations (f)).filter (f => f match {
        case Rel (True) => false
        case _ => true
      })
      if (newFormulas.exists (f => f match { case Rel (False) => true ; case _ => false }))
	Rel (False)
      else if (newFormulas.isEmpty)
        Rel (True)
      else
	And (newFormulas)
    }
    case Not (form) => {
      require (isLitteral (form))
      form match {
        case Rel (Equals (lhs, rhs)) => Or (Rel (Lt (lhs, rhs)),
                                            Rel (Lt (rhs, lhs)))
        case Rel (LtEqual (lhs, rhs)) => Rel (Lt (rhs, lhs))
        case Rel (Lt (lhs, rhs)) => Rel (LtEqual (rhs, lhs))
        case Rel (True) => Rel (False)
        case Rel (False) => Rel (True)
	case Unknown () => Unknown ()
        case _ => error ("Formula should be a litteral" )
      }
    }
    case Quantifier (v, t, form) => Quantifier (v, t, removeNegations (form))
    case Rel (_) => formula
    case Unknown () => formula
  }

  // Given a formula, preferrably in disjunctive negation-normal form, try to
  // find subformulas of the form x <= y && y <= x to replace them by x = y.
  def findEq[D <: ExpressibleOrderedField[D]] (formula: LAFormula[D]): LAFormula[D] = formula match {
    case Or (formulas) => Or (formulas.map (f => findEq (f)))
    case And (formulas) => {
      val (ltEqs, forms) = formulas.partition (_ match {
        case Rel (LtEqual (_, _)) => true
        case _ => false
      })

      val newLtEqs = {
        // Return true iff r1 is r2 reversed, i.e r1 = x <= y , and r2 = y <= x
        def reversedIneq (r1: LAFormula[D], r2: LAFormula[D]): Boolean = {
          r1 match {
            case Rel (ar1 @ LtEqual (_, _)) => {
              r2 match {
                case Rel (ar2 @ LtEqual (_, _)) => {
                  val lhs1 = rearrangeRelation (ar1).asInstanceOf[LtEqual].lhs
                  val lhs2 = rearrangeRelation (ar2).asInstanceOf[LtEqual].lhs
                  lhs1.asInstanceOf[LinearCombination[D]] == lhs2.asInstanceOf[LinearCombination[D]].negate
                }
                case _ => false
              }
            }
            case _ => false
          }
        }

        def iterate (cur: Set[LAFormula[D]], elems: Set[LAFormula[D]]): Set[LAFormula[D]] = {
          if (elems.isEmpty){
            cur
          }
          else {
            val head = elems.head
            elems.tail.find (el => reversedIneq (head, el)) match {
              case Some (rev) => {
                val newHead = head match {
                  case Rel (LtEqual (lhs, rhs)) => Rel (Equals (lhs, rhs)):LAFormula[D]
                  case _ => error ("Should not happen")
                }
                iterate (cur + newHead, elems.tail - rev)
              }
              case None => iterate (cur + head, elems.tail)
            }
          }
        }
        
        iterate (Set (), ltEqs)
      }

      // println ("DEBUG: ltEqs: " + ltEqs)
      // println ("DEBUG: forms: " + forms)
      // println ("DEBUG: newLtEqs: " + newLtEqs)
        
      And (forms ++ newLtEqs)
    }
    case Not (form) => Not (findEq (form))
    case Quantifier (v, t, form) => Quantifier (v, t, findEq (form))
    case Rel (_) => formula
    case Unknown () => formula
  }

  // Remove the <= relation from a formula of linear arithmetic, replacing it
  // with equivalent < and = relations.
  def removeLeq[D <: ExpressibleOrderedField[D]] (formula: LAFormula[D]): LAFormula[D] = formula match {
    case Or (formulas) => Or (formulas.map (f => removeLeq (f)))
    case And (formulas) => And (formulas.map (f => removeLeq (f)))
    case Not (form) => Not (removeLeq (form))
    case Quantifier (v, t, form) => Quantifier (v, t, removeLeq (form))
    case Rel (LtEqual (lhs, rhs)) => Or (Rel (Lt (lhs, rhs)),
                                         Rel (Equals (lhs, rhs)))
    case Rel (_) => formula
    case Unknown () => formula
  }

  // Simplify a formula of linear arithmetic by evaluating some relations, e.g x
  // == x is equivalent to True, 0 == 1 is equivalent to false, etc... Remove
  // negatios from, and flatten, the result.
  def LAsimplify[D <: ExpressibleOrderedField[D]] (formula: LAFormula[D]): LAFormula[D] = {
    def simplify (form: LAFormula[D]): LAFormula[D] = flatten (removeNegations
							       (negationNormalForm (form)))
    def getLC (lhs: Term, rhs: Term): (LinearCombination[D],LinearCombination[D]) = {
      (lhs.asInstanceOf[LinearCombination[D]], rhs.asInstanceOf[LinearCombination[D]])
    }
    // println ("DEBUG: Calling LAsimplify on " + formula)
    formula match {
      case Or (formulas) => {
        val newFormulas = formulas.map (f => LAsimplify (f))
        simplify (Or (newFormulas))
      }
      case And (formulas) => {
        val newFormulas = formulas.map (f => LAsimplify (f))
        simplify (And (newFormulas))
      }
      case Not (form) => {
        val newForm = LAsimplify (form)
        simplify (Not (newForm))
      }
      case Quantifier (v, t, form) => {
        val newForm = LAsimplify (form)
        if (!newForm.containsVariable (v)){
          newForm
        }
        else {
          Quantifier (v, t, newForm)
        }
      }
      case Rel (rel) => {
        val r = rearrangeRelation (rel)
        r match {
          case Equals (lhs, rhs) => {
            val (lhs2, rhs2) = getLC (lhs, rhs)
            if (lhs2.equals (rhs2))
              Rel (True)
            else if (lhs2.isConstant && rhs2.isConstant)
              Rel (False)
            else
              Rel (r)
          }
          case Lt (lhs, rhs) => {
            val (lhs2, rhs2) = getLC (lhs, rhs)
            if (lhs2.equals (rhs2))
              Rel (False)
            else if (lhs2.isConstant && rhs2.isConstant){
              // Since they are not equal, at least one of the two must have a
              // non-empty map
              val field =
                if (lhs2.coeff.contains (None))
                  lhs2.coeff (None)
                else
                  rhs2.coeff (None)
              if (lhs2.getConstantCoeff (field) <
                  rhs2.getConstantCoeff (field))
                Rel (True)
              else
                Rel (False)
            }
            else
              Rel (r)
          }
          case LtEqual (lhs, rhs) => {
            val (lhs2, rhs2) = getLC (lhs, rhs)
            if (lhs2.equals (rhs2))
              Rel (True)
            else {
              val newForm = LAsimplify (Rel (Lt (lhs, rhs)):LAFormula[D])
              newForm match {
                case Rel (Lt (_, _)) => Rel (r)
                case x @ _ => x
              }
            }
          }
          case True | False => Rel (r)
        }
      }
      case Unknown () => formula
    }
  }

  // Rearrange a binary relation so that it has a zero on the right
  // hand-side. Leave the others unchanged. For example, given x == y, return
  // x - y == 0.
  def rearrangeRelation[D <: ExpressibleOrderedField[D]] (rel: ArithmeticRelation): ArithmeticRelation = {
    def rearrange (lhs: Term, rhs: Term): (LinearCombination[D], LinearCombination[D]) = {
      val lhs2 = lhs.asInstanceOf[LinearCombination[D]]
      val rhs2 = rhs.asInstanceOf[LinearCombination[D]]

      if (lhs2.coeff.isEmpty && rhs2.coeff.isEmpty)
	(lhs2, rhs2)
      else {
	val zero =
	  if (!lhs2.coeff.isEmpty)
	    lhs2.coeff.head._2.zero
	  else
	    rhs2.coeff.head._2.zero
	(lhs2.subtract (rhs2), LinearCombination (zero))
      }
    }
    rel match {
      case Lt (lhs, rhs) => {
	val (newLhs, newRhs) = rearrange (lhs, rhs)
	Lt (newLhs, newRhs)
      }
      case LtEqual (lhs, rhs) => {
	val (newLhs, newRhs) = rearrange (lhs, rhs)
	LtEqual (newLhs, newRhs)
      }
      case Equals (lhs, rhs) => {
	val (newLhs, newRhs) = rearrange (lhs, rhs)
	Equals (newLhs, newRhs)
      }
      case True | False => rel
    }
  }

  // Given a quantifier-free formula without unknown, evaluate the formula,
  // assuming that the values describe the values for the variables in the
  // formula, in 
  def evaluate[D <: ExpressibleOrderedField[D]] (formula: LAFormula[D],
						 values: Map[Variable,D]): Boolean = {
    require (!hasUnknown (formula))
    def toLC (t: Term): LinearCombination[D] = t.asInstanceOf[LinearCombination[D]]
    formula match {
      case Or (formulas) => formulas.map (f => evaluate (f, values)).exists (el
									     => el)
      case And (formulas) => formulas.map (f => evaluate (f, values)).forall (el
									      => el)
      case Quantifier (v, t, form) =>
	{ require (false, "No quantifiers allowed") ; false }
      case Not (f) => !evaluate (f, values)
      case Rel (Lt (lhs, rhs)) =>
	toLC (lhs).evaluate (values) < toLC (rhs).evaluate (values)
      case Rel (LtEqual (lhs, rhs)) =>
	toLC (lhs).evaluate (values) <= toLC (rhs).evaluate (values)
      case Rel (Equals (lhs, rhs)) =>
	toLC (lhs).evaluate (values) == toLC (rhs).evaluate (values)
      case Rel (True) => true
      case Rel (False) => false
      case Unknown () => { assert (false, "Requirement not satisfied"); false }
    }
  }
}

