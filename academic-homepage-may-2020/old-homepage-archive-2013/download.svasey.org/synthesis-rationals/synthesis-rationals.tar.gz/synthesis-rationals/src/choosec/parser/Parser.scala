package choosec
package parser

import scala.io.Source

import numbers._
import Tokens._
import Trees._
import trees.Formulas.LAFormula
import trees.Formulas.Variable
import trees.Formulas.LinearCombination
import trees.Formulas.QuantifierType
import trees.Formulas.Existential
import trees.Formulas.Universal
 
// LL parser for the Tool grammar. The grammar has been rewritten to the
// be equivalent to the original , while embedding operator priorities and
// factoring common alternatives. The new grammar is in doc/grammar.txt
trait Parser[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]]
  extends Lexer[D, E] {
  self: LASynthetizer[D,E] =>

  // Read the parse tree and return the relevant information: the variables to
  // synthetize, the constraint formula, and optionally an expression to maximize.
  private def readTree (tree: Tree): (List[Variable], LAFormula[D], Option[LinearCombination[D]]) = {
    import trees.Formulas._

    // Transform the given expression into an element of the field. If it cannot
    // be done, return None
    def readNumber (expr: ExprTree): Option[D] = {
      def binOp (lhs: ExprTree, rhs: ExprTree, op: (D, D) => D): Option[D] = {
	val lNum = readNumber (lhs)
	val rNum = readNumber (rhs)

	if (!lNum.isEmpty && !rNum.isEmpty){
	  Some (op (lNum.get, rNum.get))
	}
	else {
	  None
	}
      }

      expr match {
	case IntLit (num) => Some (field.fromInt (num))
	case Plus (lhs, rhs) => binOp (lhs, rhs, (x, y) => x + y)
	case Minus (lhs, rhs) => binOp (lhs, rhs, (x, y) => x - y)
	case Times (lhs, rhs) => binOp (lhs, rhs, (x, y) => x * y)
	case Divides (lhs, rhs) => binOp (lhs, rhs, (x, y) => x / y)
	case Trees.Identifier (_) | Trees.Quantifier (_, _, _) | Trees.And (_, _) | Trees.Or (_, _) | Trees.Not (_) | Trees.Equals (_, _) | Trees.LessThan (_, _) | Trees.LessThanEq (_, _) | Trees.True | Trees.False => {
	  None
      }
      }
    }
  
    // Transform the given expression into a linear combination. It is an error
    // if this cannot be done.
    def readLComb (expr: ExprTree): LinearCombination[D] = expr match {
      case Identifier (name) => LinearCombination (Variable (name), field.one)
      case IntLit (num) => LinearCombination (field.fromInt (num))
      case Plus (lhs, rhs) => readLComb (lhs).add (readLComb (rhs))
      case Minus (lhs, rhs) => readLComb (lhs).subtract (readLComb (rhs))
      case Times (lhs, rhs) => {
	// At least one side must be a number
	readNumber (lhs) match {
	  case Some (r) => readLComb (rhs).scale (r)
	  case None => readNumber (rhs) match {
	    case Some (r) => readLComb (lhs).scale (r)
	    case None => error ("Expected a number on at least one side of " +
				"the multiplication", expr); LinearCombination (field.zero)
	  }
	}
      }
      case Divides (lhs, rhs) => {
	// The left hand side can be any linear combination, but the right hand
	// side must be a non-zero number
	readNumber (rhs) match {
	  case Some (r) => {
	    if (r.isZero) {
	      error ("Division by zero", rhs)
	      LinearCombination (field.zero)
	    }
	    else readLComb (lhs).dividedBy (r)
	  }
	  case None => {
	    error ("Dividing a linear combination by something which is not a " +
		   "number is not permitted", expr)
	    LinearCombination (field.zero)
	  }
	}
      }
      case Trees.Quantifier (_, _, _) | Trees.And (_, _) | Trees.Or (_, _) | Trees.Not (_) | Trees.Equals (_, _) | Trees.LessThan (_, _) | Trees.LessThanEq (_, _) | Trees.True | Trees.False => {
	error ("Unexpected element in linear combination", expr)
	LinearCombination (field.zero)
      }
    }

    // Transform the given expression into a boolean formula. It is an error if
    // this cannot be done.
    def readFormula (expr: ExprTree): LAFormula[D] = expr match {
      case Trees.Quantifier (typ, Identifier (v), form) => {
	Quantifier (Variable (v), typ, readFormula (form))
      }
      case Trees.And (lhs, rhs) => And (readFormula (lhs), readFormula (rhs))
      case Trees.Or (lhs, rhs) => Or (readFormula (lhs), readFormula (rhs))
      case Trees.Not (form) => Not (readFormula (form))
      case Trees.Equals (lhs, rhs) => Rel (Equals (readLComb (lhs), readLComb (rhs)))
      case Trees.LessThan (lhs, rhs) => Rel (Lt (readLComb (lhs), readLComb (rhs)))
      case Trees.LessThanEq (lhs, rhs) => Rel (LtEqual (readLComb (lhs), readLComb (rhs)))
      case Trees.True => Rel (True)
      case Trees.False => Rel (False)
      case Identifier (_) | IntLit (_) | Plus (_, _) | Minus (_, _) | Times (_, _) | Divides (_, _) => {
	error ("Unexpected element in formula", expr)
	Rel (False)
      }
    }

    tree match {
      case RChoose (variables, maximize, form) => {
	val vars = variables.map (v => Variable (v.value))
	val lcomb = maximize match {
	  case Some (e) => Some (readLComb (e))
	  case None => None
	}
	val formula = readFormula (form)
	terminateIfErrors
	(vars, formula, lcomb)
      }
      case _ => scala.Predef.error ("Parse tree should always begin with RChoose")
    }
  }



  
  def parseSource: (List[Variable], LAFormula[D], Option[LinearCombination[D]]) = {
    readToken // initializes the parser by calling the method in the Lexer.
    val tree: Tree = parseGoal
    terminateIfErrors
    readTree (tree)
  }
  
  /** Store the current token, as read from the lexer. */
  private var currentToken: Token = Token(BAD)
  
  def readToken: Unit = {
    /* update currentToken using nextToken in the Lexer. */
    currentToken = this.nextToken
  }
  
  /** Call readToken, ''Eats'' the expected token, or terminates with an
   error. */
  private def eat(tokenClass: TokenClass): Unit = {
    //readTokeni
    if (currentToken.tokenClass == tokenClass){
      readToken
    }
    else {
      expected (tokenClass)
    }
  }
  
  /** Complains that what was found was not expected. The method accepts arbitrarily many arguments of type TokenClass */
  private def expected(tokenClass: TokenClass, more: TokenClass*): Nothing = {
    fatalError("expected: " + (tokenClass::more.toList).mkString(" or ") + ", found: " + currentToken, currentToken)
  }
  
  // CONVENTION: ALL parseX functions should set the next token, i.e once
  // parseX exits, this.currentToken must contain the next token to be read [it
  // should NOT be necessary to call readToken again]

  private def parseGoal: Tree = {
    val firstToken = currentToken
    val rChoose = parseRChoose

    eat(EOF);

    rChoose.setPos (firstToken)
  }

  private def parseRChoose: RChoose = {
    // RChoose (vars) [Maximize] {LForm}
    val firstToken = currentToken

    eat (RCHOOSE)
    val vars = parseArgList
    val maximize = parseMaximize
    val form = parseChooseForm

    RChoose (vars, maximize, form).setPos (firstToken)
  }

  private def parseArgList: List[Identifier] = {
    eat (LPAREN)
    currentToken.tokenClass match {
      case RPAREN => { readToken; Nil }
      case _ => { parseIdentifier ::parseArgListNext }
    }
  }

  private def parseIdentifier: Identifier = currentToken.info match {
    case ID(value) => { val ret = Identifier(value).setPos(currentToken); readToken; ret }
    case _ => expected(IDCLASS)
  }

  private def parseArgListNext:  List[Identifier] = {
    currentToken.tokenClass match {
      case RPAREN => { readToken; Nil }
      case COMMA => { readToken; parseIdentifier :: parseArgListNext }
      case _ => { expected(RPAREN, COMMA);  }
    }
  }

  private def parseMaximize: Option[ExprTree] = {
    currentToken.tokenClass match {
      case LSQUARE => { readToken; val expr = parseExpr ; eat (RSQUARE);
                       Some (expr) }
      case _ => None
    }
  }

  private def parseChooseForm: ExprTree = {
    eat (LBRACE)
    val ret = parseExpr
    eat (RBRACE)
    ret
  }

  private def parseExpr: ExprTree = {
    // Expression  ::= orExpr orExprNext

    val or1 = parseOrExpr
    
    // Positions will be set by *Next functions
    parseOrExprNext (or1);
  }

  private def parseOrExprNext (accu: ExprTree): ExprTree = {
    //orExprNext  ::= ''
    //   //                || orExpr orExprNext
    val firstToken = currentToken
    
    currentToken.tokenClass match {
      case OR => { readToken; parseOrExprNext (Or (accu, parseOrExpr).setPos (currentToken)) }
      case _ => { accu }
    }
  }

  private def parseOrExpr: ExprTree = {
    //orExpr      ::= andExpr andExprNext

    val and1 = parseAndExpr;
    parseAndExprNext (and1)
  }

  
  private def parseAndExprNext (accu: ExprTree): ExprTree = {

    //andExprNext ::= ''
    //                && andExpr andExprNext

    val firstToken = currentToken
    
    currentToken.tokenClass match {
      case AND => { readToken; parseAndExprNext (And (accu, parseAndExpr).setPos (firstToken)) }
      case _ => { accu }
    }
  }


  private def parseAndExpr: ExprTree = {
    //andExpr     ::= ltExpr ltExprNext

    val lt1 = parseLtExpr;
    parseLtExprNext (lt1)
  }

  private def parseLtExprNext(accu: ExprTree): ExprTree = {
    //ltExprNext  ::= ''
  //   //                < ltExpr ltExprNext
  //   //                == ltExpr ltExprNext

    val firstToken = currentToken
    
    currentToken.tokenClass match {
      case LESSTHAN  => { readToken; parseLtExprNext (LessThan(accu,
        						       parseLtExpr).setPos (firstToken)) }
      case LESSTHANEQ  => { readToken; parseLtExprNext (LessThanEq (accu,
        							    parseLtExpr).setPos (firstToken))  }
      case EQUALS  => { readToken; parseLtExprNext (Equals (accu,
        						    parseLtExpr).setPos (firstToken))  }
      case _ => { accu }
    }
  }

  private def parseLtExpr: ExprTree = {
    // ltExpr      ::= plusExpr plusExprNext

    val p1 = parsePlusExpr;
    parsePlusExprNext (p1)
  }


  private def parsePlusExprNext(accu: ExprTree):  ExprTree = {
    //plusExprNext    ::= ''
    //                    + plusExpr plusExprNext
    //                    - plusExpr plusExprNext

    val firstToken = currentToken
    
    currentToken.tokenClass match {
      case PLUS  => { readToken; parsePlusExprNext (Plus(accu,
        						 parsePlusExpr).setPos (firstToken))  }
      case MINUS  => { readToken; parsePlusExprNext (Minus(accu,
        						   parsePlusExpr).setPos (firstToken))  }
      case _ => { accu }
    }
  }


  private def parsePlusExpr: ExprTree = {
    // plusExpr    ::= timesExpr timesExprNext
    
    val t1 = parseTimesExpr;
    parseTimesExprNext (t1)
  }


  private def parseTimesExprNext(accu: ExprTree):  ExprTree = {
    //timesExprNext   ::= ''
  //   //                    * timesExpr timesExprNext
  //   //                    / timesExpr timesExprNext

    val firstToken = currentToken
    
    currentToken.tokenClass match {
      case TIMES  => { readToken; parseTimesExprNext (Times(accu,
        						    parseTimesExpr).setPos (firstToken))  }
      case DIVIDES  => { readToken; parseTimesExprNext (Divides(accu,
        							parseTimesExpr).setPos (firstToken))  }
      case _ => { accu }
    }
  }

  private def parseTimesExpr: ExprTree = {
    //timesExpr   ::= ! timesExpr
    //                dotExpr

    val firstToken = currentToken
    currentToken.tokenClass match {
      case NOT => { readToken; Not(parseTimesExpr).setPos (firstToken)  }
      case _ => { parseSimpleExpr }
    }
  }

  private def parseNum: IntLit = {
    val firstToken = currentToken
    
    currentToken.info match {
      case NUM(value) => { readToken; IntLit(value).setPos (firstToken)  }
      case _ => expected(NUMCLASS)
    }
  }
  
  private def parseSimpleExpr: ExprTree = {
    /*
     simpleExpr  ::= <INTEGER_LITERAL>
        	     " <STRING_LITERAL> "
        	     true
        	     false
        	     Identifier
        	     this
        	     ( Expression )
        	     new newComplement
    */
    
    val firstToken = currentToken
    currentToken.tokenClass match {
      case NUMCLASS => { parseNum }
      case TRUE => { readToken; True.setPos (firstToken) } 
      case FALSE => { readToken; False.setPos (firstToken) } 
      case IDCLASS => { parseIdentifier }
      case LPAREN => { readToken; val r = parseExpr; eat(RPAREN); r }
      case FORALL => { readToken; parseQuantifier (Universal).setPos (firstToken) }
      case EXISTS => { readToken; parseQuantifier (Existential).setPos (firstToken) }
      case _ => { expected(NUMCLASS, TRUE, FALSE, IDCLASS, LPAREN, FORALL, EXISTS); }
    }
  }

  private def parseQuantifier (typ: QuantifierType): ExprTree = {
    eat (LPAREN)
    val v = parseIdentifier
    eat (COMMA)
    val e = parseExpr
    eat (RPAREN)
    Quantifier (typ, v, e)
  }
}

