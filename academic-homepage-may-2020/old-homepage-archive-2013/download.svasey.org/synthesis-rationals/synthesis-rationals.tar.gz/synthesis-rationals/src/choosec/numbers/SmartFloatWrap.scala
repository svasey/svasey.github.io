package choosec
package numbers

import trees.ScalaCode._
  
import smartfloats._


case class SmartFloatWrap (r: SmartFloat) extends ExpressibleOrderedField[SmartFloatWrap]
{
  def +(that: SmartFloatWrap) = SmartFloatWrap (this.r + that.r)
  def *(that: SmartFloatWrap) = SmartFloatWrap (this.r * that.r)
  def one = SmartFloatWrap (1.0)
  def zero = SmartFloatWrap (0.0)
  def == (that: SmartFloatWrap) = this.r == that.r
  override def equals (any: Any): Boolean = {
    if (any.isInstanceOf[SmartFloatWrap]){
      any.asInstanceOf[SmartFloatWrap] == this
    }
    else {
      false
    }
  }
  override def hashCode: Int = r.hashCode
  override def toString: String = r.toString
  
  def negate = SmartFloatWrap (- r)
  def inverse = {
    require (!isZero)
    SmartFloatWrap (SmartFloat (1.0) / r)
  }
  def signum = r.compare (0.0)
  def isExact = false
  override def compare (that: SmartFloatWrap) = r.compare (that.r)
  def fromString (str: String) = {
    SmartFloatWrap (SmartFloat (java.lang.Double.parseDouble (str)))
  }
  // FIXME: do something if n is too large
  override def fromInt (n: BigInt) = SmartFloatWrap (n.toDouble)

  def getType: Type = Type ("SmartFloatWrap")
  def toScalaCode: Expr = {
    val center = r.d
    val diff = r.aa.radius

    Apply (Identifier ("SmartFloatWrap"), List (Apply (Identifier ("SmartFloat"),
                                                       List (DoubleLit (center),
							     DoubleLit (diff)))))
  }

  def toDouble: Double = r.toDouble
  def fromDouble_approx (x: Double, n: BigInt): SmartFloatWrap = 
    SmartFloatWrap (SmartFloat (x))
    
  
  // override def upTo (that: SmartFloatWrap): SmartFloatWrap = {
  //   if (this == that) this
  //   else {
  //     def btw (begin: SmartFloat, end: SmartFloat): SmartFloat = {
  // 	assert (begin < end)
  // 	val beginHigh = begin.aa.interval.xhi
  // 	// FIXME: this does not work well, the SmartFloat's interval still
  // 	// includes other values...
  // 	SmartFloat (java.lang.Math.nextUp (beginHigh))
  //     }
  //     if (this.r < that.r) SmartFloatWrap (btw (this.r, that.r))
  //     else SmartFloatWrap (btw (that.r, this.r))
  //   }
  // }
}

object SmartFloatWrap {
  val r = SmartFloatWrap (0.0)
  val rmat = BaseMatrix[SmartFloatWrap] (r, List (List (r.zero)))
  
  def zero: SmartFloatWrap = r.zero
  def one: SmartFloatWrap = r.one

  def rationalToSmartFloatWrap (r: Rational): SmartFloatWrap =
    r.toSmartFloatWrap
}
