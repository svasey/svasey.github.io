package choosec
package numbers

trait WithInfinitesimals[T <: Ordered[T]] extends Ordered[WithInfinitesimals[T]]
case class MINUS_INFINITY[T <: Ordered[T]] () extends WithInfinitesimals[T] {
  def compare (that: WithInfinitesimals[T]): Int = that match {
    case MINUS_INFINITY () => 0
    case _ => -1
  }
}
case class PLUS_INFINITY[T <: Ordered[T]] () extends WithInfinitesimals[T] {
  def compare (that: WithInfinitesimals[T]): Int = that match {
    case PLUS_INFINITY () => 0
    case _ => 1
  }
}

trait Direction extends Ordered[Direction] {
  def compare (that: Direction) = {
    if (this == that) 0
    else (this, that) match {
      case (_, Smaller) => 1
      case (Smaller, Same) => -1
      case (_, Same) => 1
      case (_, Larger) => -1
    }
  }
}
case object Larger extends Direction 
case object Smaller extends Direction
case object Same extends Direction

case class Element[T <: Ordered[T]] (r: T, direction: Direction) extends WithInfinitesimals[T] {
  def compare (that: WithInfinitesimals[T]): Int = that match {
    case MINUS_INFINITY () => 1
    case Element (v, dir) => {
      if (v > r) -1
      else if (r > v) 1
      else direction.compare (dir)
    }
    case PLUS_INFINITY () => -1
  }
}
