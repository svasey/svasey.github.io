package choosec
package synthesis

import trees.Formulas._
import trees.FormulaTransforms._
import code.SimpleAST.SimpleExpr
import code.SimpleAST.uniqueID
import code.SimpleAST.UnfeasibleRes
import code.SimpleAST.UnboundedRes
import code.SimpleAST.MaximizedRes
import code.SimpleAST.IsFeasible
import code.SimpleAST.If
import code.SimpleAST.Max
import code.SimpleAST.Block
import code.SimpleAST.FieldEl
import code.SimpleAST.CallSolver
import code.SimpleAST.MultiplySol
import code.SimpleAST.Val
import code.SimpleType._
import trees.Constraint._
import trees.Constraint
import numbers._
import simplex._

// Synthetize conjunctions using the simplex method. This also permits efficient
// synthetizing with a function to maximize. This may return a pre-condition
// with "Unknown" inside, meaning what will happen depends on the parameters
class SimplexSynthesis[D <: ExpressibleOrderedField[D]] (fieldElem: D,
							 matrixElem: Matrix[D],
							 solverEl: SimplexSolver[D]) extends LASynthesisMethod[D] {
  val field = fieldElem
  val matrixEl = matrixElem
  val solver = solverEl


  override def simplexSolver = solverEl
  
  // override def canonicalDNF (formula: LAFormula[D]): LAFormula[D] =
  //   // Do not remove <= inequalities.
  //   simplify (findEq (simplify (disjunctiveNormalForm (prenexForm (removeNegations (negationNormalForm (formula)))))))

  def synthetize (variables: Seq[Variable], formula: LAFormula[D],
                  goal: LinearCombination[D]): (LAFormula[D], SimpleExpr) = {


    val canonicalForm = canonicalDNF (eliminateQuantifiers (formula))
    // println ("DEBUG: canonical form: " + canonicalForm)
    require (!hasUnknown (canonicalForm))
    // True iff there is nothing to maximize, in which case some more
    // optimizations are possible
    val zeroGoal = {
      val goalVariables = goal.variables
      variables.forall (v => !goalVariables.contains (v))
    }
    val goalV = goal.toVector (variables, matrixEl)
    def recSynth (form: LAFormula[D]): (LAFormula[D], SimpleExpr) = form match {
      case f @ Or (_) => {

	val (lhs, rhs) = recSplit (f)
        val (preL, computeL) = synthetizeConj (variables, lhs, goal)
        // println ("DEBUG: result of synthesis for " + lhs)
        // println ("DEBUG: pre: " + preL)
        val (preR, computeR) = recSynth (rhs)
	val pre = simplify (Or (preL, preR))
        val lRes = uniqueID ("lrecSyntRes")
        val rRes = uniqueID ("rrecSyntRes")
        val lResVal = If (preL.toSimpleExpr, computeL,
			  UnfeasibleRes)
        val rResVal = If (preR.toSimpleExpr, computeR,
                          UnfeasibleRes)
        val code = {
          if (zeroGoal){
            val compute = {
              If (IsFeasible (lRes),
		  lRes,
                  rResVal)
            }
            Block (Val (lRes, lResVal, TResult), compute)
          }
	  else {
	    val res = Max (List (lRes, rRes))
            Block (List(Val (lRes, lResVal, TResult), Val (rRes, rResVal, TResult)),
                   res)
	  }
	}
        
	(pre, code)
      }

      case Quantifier (_, _, _) => 
        error ("Formula should have been transformed to a quantifier-free form")
      case Rel (False) => (Rel (False), UnfeasibleRes)
      case _ => recSynth (Or (form, Rel (False)))
    }

    recSynth (canonicalForm)
  }

  // Given a formula (not in any canonical form), return an equivalent
  // quantifier-free formula. Use Fourier-Motzkin synthesis for this. 
  override def eliminateQuantifiers (formula: LAFormula[D]): LAFormula[D] = {
    val synth = new FourierMotzkinSynthesis (field)
    
    formula match {
      case Or (formulas) => Or (formulas.map (eliminateQuantifiers))
      case And (formulas) => And (formulas.map (eliminateQuantifiers))
      case Not (form) => Not (eliminateQuantifiers (form))
      case Rel (_) => formula
      case Unknown () => formula
      case Quantifier (variable, typ, form) => typ match {
        case Existential => synth.synthetize (List (variable), form)._1
        case Universal => Not (synth.synthetize (List (variable), Not (form))._1)
      }
    }
  }

  override def synthetize (variables: Seq[Variable], formula: LAFormula[D]): (LAFormula[D], SimpleExpr) = {
    synthetize (variables, formula, LinearCombination (field.zero))
  }

  override def synthetize (variables: Seq[Variable], formula: LAFormula[D],
			   maximize: Option[LinearCombination[D]]): (LAFormula[D], SimpleExpr) = {
    maximize match {
      case Some (goal) => synthetize (variables, formula, goal)
      case None => synthetize (variables, formula)
    }
  }

  // Given arbitrary constraints, return a function that takes the parameters as
  // argument (as a list), and return the variables satisfying the constraints,
  // or None if none exists. This does not do much specialization: just call the
  // simplex.
  def getSolverForConstraints (variables: Seq[Variable], formula: LAFormula[D],
			       maximize: LinearCombination[D]): (Seq[D] =>  Option[Seq[D]]) = {

    val goalV = maximize.toVector (variables, matrixEl)
    val parameters:Seq[Variable] = {
      val asSet = (formula.unquantifiedVariables -- variables.toSet)
      asSet.toSeq.sortWith ((a, b) => a.name < b.name)
    }
    val canonicalForm = canonicalDNF (eliminateQuantifiers (formula))
    
    
    // Input formula is a conjunction
    def getResultSolverConj (conj: LAFormula[D]): Seq[D] => LPResult[D] = {
      val constr = Constraints (matrixEl, variables, conj)

      val (withoutVar, nonStrictMat, nonStrictV, strictMat, strictV) = constr.toOldCanonicalForm
      
      val (fullMatrix, fullBound) = nonStrictMat match {
	case Some (m1) => strictMat match {
	  case Some (m2) => (m1.appendBottom (m2), nonStrictV.get ::: strictV.get)
	  case None => (m1, nonStrictV.get)
	}
	case None => (strictMat.get, strictV.get)
      }
      val nNonStrict = if (nonStrictMat.isEmpty) 0 else nonStrictMat.get.nLines
      def call (input: Seq[D]): LPResult[D] = {
	require (input.length == parameters.length)
	val valueMap = parameters.zip (input).toMap
	if (withoutVar.isEmpty || evaluate (withoutVar.get, valueMap)){
	  val bound =
	    matrixEl.init (fullMatrix.nLines, 1, fullBound.map (b => b.evaluate (valueMap)))
	  solverEl.init (fullMatrix, goalV, bound).fullSimplexWithStrict (nNonStrict)
	}
	else {
	  UnfeasibleLPRes (field)
	}
      }
      call
    }

    def getResultSolver (form: LAFormula[D]): Seq[D] => LPResult[D] = {
      require (!hasUnknown (form))
      form match {
	case f @ Or (_) => {
	  val (lhs, rhs) = recSplit (f)
	  val firstSolver = getResultSolverConj (lhs)
	  val restSolver = getResultSolver (rhs)

	  (input:Seq[D]) => firstSolver (input).max (restSolver (input))
	}
	case Quantifier (_, _, _) => {
	  assert (false, "Formula should have been transformed to QF form");
	  (xs:Seq[D]) => UnfeasibleLPRes (field)
	}
	case Rel (False) => (xs:Seq[D]) => UnfeasibleLPRes (field)
	case _ => getResultSolver (Or (form, Rel (False)))
      }
    }

    val solver = getResultSolver (canonicalForm)

    xs => {
      val res = solver (xs)
      if (res.hasSolution)
	Some (res.optimalVector.toList)
      else
	None
    }
  }
  // Convert a flattenend conjunction to a Constraints object.
  protected def getConstraints (variables: Seq[Variable], formula: LAFormula[D]): Constraints[D] = {
    Constraints (matrixEl, variables, formula)
  }

  // Put a flattened conjunction (the given formula) in canonical form, i.e we know the
  // formula is equivalent to a formula of the form phi && Ax <= b && A'x < b',
  // where phi does not contain any variable in `variables`. The function to
  // maximize can be written c^T * x, for some vector c. Return (phi, A, b, A',
  // b', c), in that order. If A is zero, return A = None, b = None; same thing
  // for A', b' . If phi is `true`, also return None.
  protected def canonicalForm (variables: Seq[Variable], formula: LAFormula[D], maximize: LinearCombination[D]): (Option[LAFormula[D]], Option[Matrix[D]], Option[List[LinearCombination[D]]], Option[Matrix[D]], Option[List[LinearCombination[D]]],Matrix[D]) = {

    val maximizeV = maximize.toVector (variables, matrixEl)
    val (phi, nonStrictMat, nonStrictBound, strictMat, strictBound) = getConstraints (variables, formula).toOldCanonicalForm

    (phi, nonStrictMat, nonStrictBound, strictMat, strictBound, maximizeV)
  }														     
  def synthetizeMixedLP_FR (matrix: Matrix[D], maximize: Matrix[D], bound:
			    Seq[LinearCombination[D]], nNonStrict: Int, initialRoof: Seq[Int]):  (LAFormula[D], SimpleExpr) = {
    val roofMatrix = matrix.getLines (initialRoof)
    val inverseRoofMatrix = roofMatrix.inverse
    val code = CallSolver (solver.init (matrix, maximize,
                                        matrix.zero (matrix.nLines, 1)),
                           initialRoof, roofMatrix, inverseRoofMatrix,
                           false, nNonStrict, bound.map (lc => lc.toSimpleExpr))
    (Unknown (), code)
  }
  // Synthetize code to solve the maximization problem under constraint Ax <=/< b,
  // where the first `nNonStrict` lines of the matrix are non-strict inequalities,
  // and the rest are strict inequalities.
  def synthetizeMixedLP_FR (matrix: Matrix[D], maximize: Matrix[D], bound:
			    Seq[LinearCombination[D]], nNonStrict: Int):  (LAFormula[D], SimpleExpr) = {

    val solverInst = solver.init (matrix, maximize, matrix.zero (matrix.nLines, 1))
    // Find an initial roof. The bound is also not needed for this step.
    solverInst.findRoof match {
      case Right (_) => {
        // Linear program is either unfeasible or unbounded
        assert (!maximize.isZero)
        synthetizeMixedLP_maybeUnbounded (matrix, bound, nNonStrict)
      }
      case Left (initialRoof) => {
        // println ("DEBUG: initial roof will be " + initialRoof)

        synthetizeMixedLP_FR (matrix, maximize, bound, nNonStrict, initialRoof)
      }
    }
  }

  // We know that the linear program is either unbounded or unfeasible:
  // synthetize code to find out which. Basically call a simplex solver with c =
  // 0, and if the problem is feasible return unbounded, and unfeasible if the
  // problem is not feasible.
  def synthetizeMixedLP_maybeUnbounded (matrix: Matrix[D], bound:
                                        Seq[LinearCombination[D]],
                                        nNonStrict: Int): (LAFormula[D], SimpleExpr) = {
    val (pre0, code0) = synthetizeMixedLP (matrix, matrixEl.zero (matrix.nCols, 1), bound, nNonStrict)

    val pre = And (pre0, Unknown ())
    
    val resName = uniqueID ("mixedlp_maybeUnbounded_res")
    
    val fullCode = {
      If (IsFeasible (resName),
          UnboundedRes,
          resName)
    }
    (pre, Block (Val (resName, code0, TResult), fullCode))
  }
  // Synthetized a linear program with mixed strict and non-strict
  // inequalities. The program is given in matrix form, where the first
  // `nNonStrict` lines represent non-strict inequalities, and the next ones
  // represent strict inequalities. Pre-compute as much as possible.
  def synthetizeMixedLP (matrix: Matrix[D], maximize: Matrix[D], bound:
			 Seq[LinearCombination[D]], nNonStrict: Int): (LAFormula[D], SimpleExpr) = {
    val solv = solver.init (matrix, maximize, matrix.zero (matrix.nLines, 1))
    solv.transformToFullRank match {
      case Left ((transformMatrix, newSolver)) => {
	val (pre, code0) = synthetizeMixedLP_FR (newSolver.matrix,
						 newSolver.maximize, bound, nNonStrict)
	val resName = uniqueID ("mixedLPres")
        
	val resTransform = MultiplySol (resName, transformMatrix)
        
	(pre, Block (Val (resName, code0, TResult), resTransform))
      }
      case Right (res:LPResult[d]) => {
        assert (!maximize.isZero)
        synthetizeMixedLP_maybeUnbounded (matrix, bound, nNonStrict)
      }
    }
  }

  def tryToSolve (constraints: Constraints[D], maximize: Matrix[D],
                  transformMatrix: Matrix[D], maybeUnbounded: Boolean): Option[LPResult[D]] = {
    val (ineqMatrix, nNonStrict, lcBound) = constraints.ineqMatrixWithBound
    // println ("DEBUG: ineqMatrix:\n" + ineqMatrix)
    // println ("DEBUG: nNonStrict: " + nNonStrict)
    // println ("DEBUG: lcBound:\n" + lcBound)
    // println ("DEBUG: boundMatrix:\n" + constraints.boundMatrix)
    // println ("DEBUG: constraint matrix:\n" + constraints.constrMatrix)
    tryToSolve (ineqMatrix, nNonStrict, lcBound, maximize, transformMatrix, maybeUnbounded)
  }

  // Tries to fully solve the parametrized linear problem. Return the result if
  // successful, or None if this fails. This tries e.g to check if the
  // constraints without parameters are feasible. If `maybeUnbounded` is true,
  // this means that if the problem is feasible, then it is
  // unbounded.
  def tryToSolve (matrix: Matrix[D], nNonStrict: Int, bound: Seq[LinearCombination[D]],
                  maximize: Matrix[D], transformMatrix: Matrix[D],
                  maybeUnbounded: Boolean): Option[LPResult[D]] = {
    if (bound.forall (lc => lc.isConstant)){
      // No parameters at all in the formula: it can be synthetized directly
      // with the simplex method.
      val boundV = matrixEl.init (bound.map (lc => List (lc.getConstantCoeff (field))))
      val solv = solver.init (matrix, maximize, boundV)
      val res0 = solv.simplexWithStrict (nNonStrict)
      val res = {
        if (maybeUnbounded){
          if (res0.isFeasible){
            LPRes (field, None, None, None, true)
          }
          else {
            res0
          }
        }
        else {
          res0.multiplySol (transformMatrix)
        }
      }
      Some (res)
    }
    else {
      // Try to solve the system with the parameters as variables, to see if
      // there is a solution in that case.
      val parameters:Seq[Variable] = bound.flatMap (lc => lc.allVariables).distinct
      val parBounds = bound.map (lc => lc.toVector(parameters, matrixEl).transpose.negate)
      assert (!bound.isEmpty)
      val boundMatrix = parBounds.tail.foldLeft (parBounds.head) ((cur, lc) => cur.appendBottom (lc))
      val newMatrix = matrix.appendRight (boundMatrix)
      val newBound = matrix.init (newMatrix.nLines, 1, bound.map (lc => lc.getConstantCoeff (field)))

      val solv = solver.init (newMatrix, maximize.zero (maximize.nLines +  
							parameters.size, 1), newBound)
      val res = solv.fullSimplexWithStrict (nNonStrict)
      if (!res.isFeasible)
        Some (res)
      else
        None
    }
  }

  // Note that the pre-condition is false iff the linear program is not
  // feasible. It is true iff it has an optimal solution. Otherwise it is
  // Unknown
  def synthetizeConj (variables: Seq[Variable], formula: LAFormula[D], maximize: LinearCombination[D]) : (LAFormula[D], SimpleExpr) = {
    val nVariables = variables.length
    val (withoutVar, nonStrictMat, nonStrictV, strictMat, strictV, objV) =
      canonicalForm (variables, formula, maximize)
    if (nonStrictMat.isEmpty && strictMat.isEmpty){
      val pre = if (withoutVar.isEmpty) Unknown ():LAFormula[D] else withoutVar.get
      // Linear program is unbounded (if there is something to maximize)
      val code = {
        if (objV.isZero)
          MaximizedRes (variables.map (v => FieldEl (field.zero)), FieldEl (field.zero))
        else
          UnboundedRes
      }
      (pre, code)
    }
    else {
      val (fullMatrix, fullBound) = nonStrictMat match {
	case Some (m1) => strictMat match {
	  case Some (m2) => (m1.appendBottom (m2), nonStrictV.get ::: strictV.get)
	  case None => (m1, nonStrictV.get)
	}
	case None => (strictMat.get, strictV.get)
      }
      val nNonStrict = if (nonStrictMat.isEmpty) 0 else nonStrictMat.get.nLines
      val (pre0, code) = synthetizeMixedLP (fullMatrix, objV, fullBound, nNonStrict)
      val pre = if (withoutVar.isEmpty) pre0 else And (withoutVar.get, pre0)
      (pre, code)
    }
  }
  
  def synthetizeConj (variables: Seq[Variable], formula: LAFormula[D]) : (LAFormula[D], SimpleExpr) =
    synthetizeConj (variables, formula, LinearCombination (field.zero))
}  

object RSimplexSynthesis extends SimplexSynthesis[Rational] (Rational.r,
							     Rational.rmat,
							     SimplexImpl[Rational] (Rational.r, Rational.rmat))
