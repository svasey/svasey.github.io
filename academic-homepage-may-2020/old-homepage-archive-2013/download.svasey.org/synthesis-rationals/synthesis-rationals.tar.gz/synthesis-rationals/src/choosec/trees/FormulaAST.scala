package choosec
package trees

// Abstract syntax tree for a first-order formula

object Formulas {
  import numbers._
  import ScalaCode.Type
  import code.SimpleAST.SimpleExpr
  import code.SimpleAST
  import code.SimpleAST.FieldEl
  
  trait FormulaAST extends AST with ScalaExpressible {
    // Return all the variables in the formula. If `quantified` is true, include
    // quantified variables.
    def variables (quantified: Boolean): Set[Variable]
    def allVariables: Set[Variable] = variables (true)
    def unquantifiedVariables: Set[Variable] = variables (false)
    // Return true if the given variable is free in the formula
    def containsVariable (variable: Variable): Boolean =
      unquantifiedVariables.contains (variable)
    // Rename all (free and bound) variables named `from` to `to`
    def renameVariables (from: String, to: String): FormulaAST
    // Rename variables whose name is a key in the map to the corresponding value
    def renameVariables (map: Map[String, String]): FormulaAST = {
      map.toList.foldLeft (this) ((form, kv)  =>
	form.renameVariables (kv._1, kv._2))
    }
    // Replace the free occurences of the given variable with the given term
    def replaceVariable (variable: Variable, term: Term): FormulaAST
    def toSimpleExpr: SimpleExpr
  }
  trait Term extends FormulaAST {
    def variables (quantified: Boolean): Set[Variable] = this.variables
    def variables: Set[Variable]
    def renameVariables (from: String, to: String): Term
    def replaceVariable (variable: Variable, term: Term): Term
  }
  trait Relation extends ScalaExpressible {
    // Return all the variables in the arguments of the relation 
    def variables: Set[Variable]
    def containsVariable (variable: Variable): Boolean =
      variables.contains (variable)
    def renameVariables (from: String, to: String): Relation
    def replaceVariable (variable: Variable, term: Term): Relation
    def toSimpleExpr: SimpleExpr
  }
  trait Function extends Term with ScalaExpressible {
    def renameVariables (from: String, to: String): Function
    def replaceVariable (variable: Variable, term: Term): Function
    def toSimpleExpr: SimpleExpr
  }

  // Formula whose function symbols are of type F and whose relations of type R
  trait Formula[F <: Function, R <: Relation] extends FormulaAST {
    def renameVariables (from: String, to: String): Formula[F,R]
    def replaceVariable (variable: Variable, term: Term): Formula[F,R]
  }
  trait LogicalOperator[F <: Function,R <: Relation] extends Formula[F,R] {
    def renameVariables (from: String, to: String): LogicalOperator[F,R]
    def replaceVariable (variable: Variable, term: Term): LogicalOperator[F,R]

    def toSimpleExpr (constr: (SimpleExpr, SimpleExpr) => SimpleExpr,
		      constr2: Set[Formula[F,R]] => Formula[F,R],
		      formulas: Set[Formula[F,R]], neutral: SimpleExpr): SimpleExpr = {
      if (formulas.isEmpty) neutral
      else if (formulas.tail.isEmpty) formulas.head.toSimpleExpr
      else constr (formulas.head.toSimpleExpr, constr2 (formulas.tail).toSimpleExpr)
    }
  }

  case class Or[F <: Function, R <: Relation] (formulas: Set[Formula[F,R]]) extends LogicalOperator[F,R] {
    override def toString: String = "(" + formulas.mkString (" || ") + ")"
    def variables (quantified: Boolean): Set[Variable] =
      formulas.flatMap (f => f.variables (quantified))
    def renameVariables (from: String, to: String): Or[F,R] =
      Or (formulas.map (f => f.renameVariables (from, to)))
    def replaceVariable (variable: Variable, term: Term): Or[F,R] =
      Or (formulas.map (f => f.replaceVariable (variable, term)))
    def toScalaCode = ScalaCode.Or (formulas.map (f => f.toScalaCode))
    def toSimpleExpr = toSimpleExpr ((e1, e2) => SimpleAST.Or (e1, e2),
				     s => Or (s),
                                     formulas, SimpleAST.False)
      
    def getType: Type = Type ("Or")
  }

  object Or {
    def apply[F <: Function, R <: Relation] (lhs: Formula[F,R], rhs: Formula[F,R]): Formula[F,R] =
      Or (Set (lhs) + rhs)
  }
  
  case class And[F <: Function, R <: Relation] (formulas: Set[Formula[F,R]]) extends LogicalOperator[F,R] {
    override def toString: String = "(" + formulas.mkString (" && ") + ")"
    def variables (quantified: Boolean): Set[Variable] =
      formulas.flatMap (f => f.variables (quantified))
    def renameVariables (from: String, to: String): And[F,R] =
      And (formulas.map (f => f.renameVariables (from,to)))
    def replaceVariable (variable: Variable, term: Term): And[F,R] =
      And (formulas.map (f => f.replaceVariable (variable, term)))
    def toScalaCode = ScalaCode.And (formulas.map (f => f.toScalaCode))
    def getType: Type = Type ("And")
    def toSimpleExpr = toSimpleExpr ((e1, e2) => SimpleAST.And (e1, e2),
				     s => And (s),
                                     formulas, SimpleAST.True)
  }

  object And {
    def apply[F <: Function, R <: Relation] (lhs: Formula[F,R], rhs: Formula[F,R]): Formula[F,R] =
      And (Set (lhs) + rhs)
  }

  case class Not[F <: Function, R <: Relation] (form: Formula[F,R]) extends LogicalOperator[F,R] {
    override def toString: String = "!" + form.toString
    def variables (quantified: Boolean): Set[Variable] = form.variables (quantified)
    def renameVariables (from: String, to: String): Not[F,R] =
      Not (form.renameVariables (from, to))
    def replaceVariable (variable: Variable, term: Term): Not[F,R] =
      Not (form.replaceVariable (variable, term))
    def toScalaCode = ScalaCode.Not (form.toScalaCode)
    def getType: Type = Type ("Not")
    def toSimpleExpr = SimpleAST.Not (form.toSimpleExpr)
  }

  trait QuantifierType {
    def dual: QuantifierType
  }
  case object Existential extends QuantifierType {
    override def toString: String = "exists"
    def dual: QuantifierType = Universal
  }
  case object Universal extends QuantifierType {
    override def toString: String = "forall"
    def dual: QuantifierType = Existential
  }

  // Represent an unknown boolean, either true or false
  case class Unknown[F <: Function,R <: Relation] () extends Formula[F,R] {
    override def toString: String = "?unknown?"
    def variables (quantified: Boolean): Set[Variable] = Set ()
    def renameVariables (from: String, to: String): Unknown[F,R] = this
    def replaceVariable (variable: Variable, term: Term): Unknown[F,R] = this
    // There is no real translation, so we assume actions have been taken before
    // converting this  to scala code if need be.
    def toScalaCode = ScalaCode.True
    def toSimpleExpr = SimpleAST.True
    def getType: Type = Type ("Unknown")
  }
  
  case class Quantifier[F <: Function, R <: Relation] (variable: Variable, typ: QuantifierType, form: Formula[F,R]) extends Formula[F,R] {
    override def toString: String =
      typ.toString + "[" + variable + "] (" + form.toString + ")"
    def variables (quantified: Boolean): Set[Variable] = {
      val vars = form.variables (quantified)
      if (!quantified) vars - variable else vars
    }
    def renameVariables (from: String, to: String): Quantifier[F,R] =
      Quantifier (variable.renameVariables (from, to),
                  typ, form.renameVariables (from, to))
    def replaceVariable (v: Variable, term: Term): Quantifier[F,R] =
      Quantifier (v, typ, form.replaceVariable (v, term))
    def toScalaCode = form.toScalaCode
    def toSimpleExpr = form.toSimpleExpr
    def getType: Type = Type ("Quantifier")
  }
  // Relation
  case class Rel[F <: Function, R <: Relation] (rel: R) extends Formula[F,R] {
    override def toString: String = rel.toString
    def variables (quantified: Boolean): Set[Variable] = rel.variables
    def renameVariables (from: String, to: String): Rel[F,R] = Rel (rel.renameVariables (from, to).asInstanceOf[R])
    def replaceVariable (v: Variable, term: Term): Rel[F,R] =
      Rel (rel.replaceVariable (v, term).asInstanceOf[R])
    def toScalaCode = rel.toScalaCode
    def toSimpleExpr = rel.toSimpleExpr
    def getType: Type = Type ("Rel")
  }

  // I make the difference between a variable as a term, or a variable as an
  // object appearing e.g next to quantifiers. That is why this class does not extend Term.
  case class Variable (name: String) extends FormulaAST {
    override def toString: String = name
    def variables (quantified: Boolean): Set[Variable] = Set (this)
    def renameVariables (from: String, to: String): Variable =
      if (name == from) Variable (to) else this
    def replaceVariable (v: Variable, term: Term): Variable =
      this
    def toScalaCode = ScalaCode.Identifier (name)
    def toSimpleExpr = SimpleAST.Identifier (name)
    def getType: Type = Type ("Variable")
  }

  // Function symbol
  case class Func[F <: Function, R <: Relation] (func: F) extends Term {
    override def toString: String = func.toString
    def variables: Set[Variable] = func.variables
    def renameVariables (from: String, to: String): Func[F,R] = Func (func.renameVariables (from, to).asInstanceOf[F])
    def replaceVariable (v: Variable, term: Term): Func[F,R] =
      Func (func.replaceVariable (v, term).asInstanceOf[F])
    def toScalaCode = func.toScalaCode
    def toSimpleExpr = func.toSimpleExpr
    def getType: Type = Type ("Func")
  }
  
  trait ArithmeticRelation extends Relation {
    def replaceVariable (v: Variable, term: Term): ArithmeticRelation
  }
  
  case class Equals (lhs: Term, rhs: Term) extends ArithmeticRelation {
    override def toString: String = "(" + lhs.toString + " == " + rhs.toString + ")"
    def variables: Set[Variable] = lhs.variables ++ rhs.variables
    def renameVariables (from: String, to: String): Equals =
      Equals (lhs.renameVariables (from,to), rhs.renameVariables (from, to))
    def replaceVariable (v: Variable, term: Term): Equals =
      Equals (lhs.replaceVariable (v, term), rhs.replaceVariable (v, term))
    def toScalaCode = ScalaCode.Equals (lhs.toScalaCode, rhs.toScalaCode)
    def toSimpleExpr = SimpleAST.Eq (lhs.toSimpleExpr, rhs.toSimpleExpr)
    def getType: Type = Type ("Equals")
  }
  case class Lt (lhs: Term, rhs: Term) extends ArithmeticRelation {
    override def toString: String = "(" + lhs.toString + " < " + rhs.toString + ")"
    def variables: Set[Variable] = lhs.variables ++ rhs.variables
    def renameVariables (from: String, to: String): Lt =
      Lt (lhs.renameVariables (from,to), rhs.renameVariables (from, to))
    def replaceVariable (v: Variable, term: Term): Lt =
      Lt (lhs.replaceVariable (v, term), rhs.replaceVariable (v, term))
    def toScalaCode = ScalaCode.Lt (lhs.toScalaCode, rhs.toScalaCode)
    def toSimpleExpr = SimpleAST.Lt (lhs.toSimpleExpr, rhs.toSimpleExpr)
    def getType: Type = Type ("Lt")
  }
  case class LtEqual (lhs: Term, rhs: Term) extends ArithmeticRelation {
    override def toString: String = "(" + lhs.toString + " <= " + rhs.toString + ")"
    def variables: Set[Variable] = lhs.variables ++ rhs.variables
    def renameVariables (from: String, to: String): LtEqual =
      LtEqual (lhs.renameVariables (from,to), rhs.renameVariables (from, to))
    def replaceVariable (v: Variable, term: Term): LtEqual =
      LtEqual (lhs.replaceVariable (v, term), rhs.replaceVariable (v, term))
    def toScalaCode = ScalaCode.LtEq (lhs.toScalaCode, rhs.toScalaCode)
    def toSimpleExpr = SimpleAST.LtEq (lhs.toSimpleExpr, rhs.toSimpleExpr)
    def getType: Type = Type ("LtEq")
  }

  case object True extends ArithmeticRelation {
    override def toString: String = "true"
    def variables: Set[Variable] = Set ()
    def renameVariables (from: String, to: String) = this
    def replaceVariable (v: Variable, term: Term) = this
    def toScalaCode = ScalaCode.True
    def toSimpleExpr = SimpleAST.True
    def getType: Type = Type ("True")
  }
  case object False extends ArithmeticRelation {
    override def toString: String = "false"
    def variables: Set[Variable] = Set ()
    def renameVariables (from: String, to: String) = this
    def replaceVariable (v: Variable, term: Term) = this
    def toScalaCode = ScalaCode.False
    def toSimpleExpr = SimpleAST.False
    def getType: Type = Type ("False")
  }

  trait LAFunction[D <: ExpressibleOrderedField[D]] extends Function
  // The map maps each variable to its coefficient, or None to the constant term.
  case class LinearCombination[D <: ExpressibleOrderedField[D]] (coeff: Map[Option[Variable],D]) extends LAFunction[D] {
    override def toString: String = {
      val filtered = coeff.filter (pair => !pair._2.isZero)
      if (filtered.isEmpty)
        "0"
      else {
        filtered.toList.map (varOptCoeff => varOptCoeff match {
          case (None, c) => c.toString
          case (Some (v), c) => {
            if (c.isOne)
              v.name
            else
              c.toString ++ " * " ++ v.name
          }
        }).mkString (" + ")
      }
    }
    override def equals (arg0: Any): Boolean = arg0 match {
      case LinearCombination (_) => {
        val lc = arg0.asInstanceOf[LinearCombination[D]]
        coeff.filter (kv => !kv._2.isZero).equals (lc.coeff.filter (kv => !kv._2.isZero))
      }
      case _ => false
    }
    override def hashCode: Int = {
      coeff.filter (kv => !kv._2.isZero).hashCode
      // map (x => x match {
      //   case (Some (v), c) => c.hashCode + v.hashCode
      //   case (None, c) => c.hashCode
      // }).sum
    }

    def isConstant: Boolean = {
      coeff.forall (kv => kv._1.isEmpty || kv._2.isZero)
    }

    def isZero: Boolean = {
      coeff.forall (kv => kv._2.isZero)
    }

    // Return the coefficient of the given variable
    def getCoeff (field: D, v: Variable): D = {
      if (coeff.contains (Some (v)))
        coeff (Some (v))
      else
        field.zero
    }

    // Get the constant coefficient
    def getConstantCoeff (field: D): D = {
      if (coeff.contains (None))
        coeff (None)
      else
        field.zero
    }

    // Return a column vector with the coefficient of the given variables. 
    def toVector (variables: Seq[Variable], matrix: Matrix[D]): Matrix[D] = {
      require (!variables.isEmpty)
      matrix.init (IndexedSeq (variables.map (v => this.getCoeff (matrix.field, v)))).transpose
    }

    def variables: Set[Variable] =
      coeff.keys.filter (x => !x.isEmpty && !coeff (x).isZero).map (x => x.get).toSet
    
    def renameVariables (from: String, to: String): LinearCombination[D] = {
      val key = Some (Variable (from))
      if (coeff.contains (key)){
	val c = coeff (key)
	if (!c.isZero)
	  replaceVariable (Variable (from), LinearCombination (Variable (to), c.one))
	else
	  this
      }
      else {
	this
      }
    }
    def replaceVariable (v: Variable, term: Term): LinearCombination[D] = {
      val key = Some (v)
      if (coeff.contains (key)){
	val c = coeff (key)
	if (!c.isZero){
	  val lc = term.asInstanceOf[LinearCombination[D]]
	  LinearCombination (coeff - key).add (lc.scale (c))
	}
	else
	  this
      }
      else {
	this
      }
    }

    // Set the coefficient of the given variable to zero
    def removeVariable (v: Variable): LinearCombination[D] = {
      LinearCombination (coeff - Some (v))
    }

    // Do nothing if the linear combination is non-empty, but add a zero-element
    // if it is empty 
    def normalize (field: D): LinearCombination[D] = {
      if (coeff.isEmpty)
        LinearCombination (Map[Option[Variable],D] ((None, field.zero)))
      else
        this
    }

    def toSimpleExpr = {
      assert (!coeff.isEmpty)
      val field = coeff.head._2
      val filtered = coeff.filter (kv => !kv._2.isZero)
      if (filtered.isEmpty)
        FieldEl (field.zero)
      else {
        val head = filtered.head
        val lhs = {
          head match {
            case (Some (v), c) => {
              if (c.isOne)
                v.toSimpleExpr
              else 
                SimpleAST.Times (FieldEl (c), v.toSimpleExpr)
            }
            case (None, c) => FieldEl (c)
          }
        }
        if (!filtered.tail.isEmpty){
          val rhs = LinearCombination (filtered.tail).toSimpleExpr
          SimpleAST.Plus (lhs, rhs)
        }
        else
          lhs
      }
    }
    
    def toScalaCode = {
      // FIXME: this is tricky at best
      assert (!coeff.isEmpty)

      val field = coeff.head._2
      val filtered = coeff.filter (kv => !kv._2.isZero)
      if (filtered.isEmpty)
	field.zero.toScalaCode
      else {
	val lhs = {
	  filtered.head match {
	    case (Some (v), c) => {
              if (c.isOne)
                v.toScalaCode
              else if (c == field.one.negate)
                ScalaCode.DotExpr (v.toScalaCode,
                                   ScalaCode.Identifier ("negate"), List ())
              else
                ScalaCode.Times (c.toScalaCode, v.toScalaCode)
            }
	    case (None, c) => c.toScalaCode
	  }
	}
	if (filtered.tail.size > 0){
	  val rhs = LinearCombination (filtered.tail).toScalaCode
	  ScalaCode.Plus (lhs, rhs)
	}
	else {
	  lhs
	}
      }
    }
    def getType: Type = Type ("LinearCombination")

    def add (lc: LinearCombination[D]): LinearCombination[D] = {
      val keys = coeff.keys ++ lc.coeff.keys
      val newCoeff:Iterable[(Option[Variable],D)] = keys.map (k => {
	if (coeff.contains (k) && lc.coeff.contains (k))
	  (k,  coeff (k) + lc.coeff (k))
	else if (coeff.contains (k))
	  (k, coeff (k))
	else if (lc.coeff.contains (k))
	  (k, lc.coeff (k))
	else {
	  error ("Key should exist in at least one of the coefficient maps")
	}
      })
      LinearCombination (newCoeff.toMap)
    }

    def subtract (lc: LinearCombination[D]): LinearCombination[D] =
      add (LinearCombination (lc.coeff.mapValues (y => y.negate)))
    
    def add (constant: D): LinearCombination[D] = add (LinearCombination (constant))
    def negate: LinearCombination[D] = {
      LinearCombination (coeff.mapValues (y => y.negate))
    }

    def scale (x: D): LinearCombination[D] = {
      LinearCombination (coeff.mapValues (y => x * y))
    }
    // Multiply `this` by `x`, and return a linear combination if the result is
    // one, None otherwise.
    def times (x: LinearCombination[D]): Option[LinearCombination[D]] = {
      if (x.isConstant){
	if (x.isZero)
	  Some (x)
	else
	  Some (this.scale (x.coeff (None)))
      }
      else if (this.isConstant)
	x.times (this)
      else
	// We might still obtain a linear combination if some terms cancel out,
	// but this does not interest us here
	None
    }
  
    def dividedBy (x: D): LinearCombination[D] = this.scale (x.inverse)
      

    // Solve `rhs == this` for x. If all values are solutions, return None.
    def solveEquality (x: Variable, rhs: LinearCombination[D]): Option[LinearCombination[D]] = {
      val key = Some (x)
      val diff = this.subtract (rhs)
      if (!diff.coeff.contains (key) || diff.coeff(key).isZero)
	None
      else {
	val c = diff.coeff (key)
	Some (LinearCombination (diff.coeff - key).scale (c.negate.inverse))
      }
    }

    // Evaluate the linear combination using the given mapping
    def evaluate (values: Map[Variable, D]): D = {
      require (!values.isEmpty && coeff.keys.forall (el => el.isEmpty ||
						     coeff (el).isZero ||
						     values.contains (el.get)))
      val field = values.head._2
      val terms = values.keys.map (v => getCoeff (field, v) * values (v))
      
      getConstantCoeff (field) + terms.foldLeft (field.zero) ((c, r) => c + r)
    }
  }

  object LinearCombination {
    def apply[D <: ExpressibleOrderedField[D]] (constant: D): LinearCombination[D] = {
      LinearCombination (List ((None, constant)).toMap:Map[Option[Variable],D])
    }
    def apply[D <: ExpressibleOrderedField[D]] (variable: Variable, x: D): LinearCombination[D] = {
      LinearCombination (List ((Some (variable), x)).toMap:Map[Option[Variable],D])
    }
    def apply[D <: ExpressibleOrderedField[D]] (coeff: List[(LinearCombination[D],D)]):
      LinearCombination[D] = {
	coeff match {
	  case Nil => LinearCombination (Map ():Map[Option[Variable],D])
	  case (lc, x)::tail => lc.scale (x). add (LinearCombination (tail))
	}
      }


    // Initialize from a vector (line or column, it does not matter) of
    // coefficient `c`, a vector of variables `x`, and a constant term T. The resulting linear
    // combination should represent <c,x> + T.
    def apply[D <: ExpressibleOrderedField[D]] (variables: Seq[Variable], vect:
						Matrix[D], constantTerm: D): LinearCombination[D] = {
      LinearCombination (variables.map (v => Some (v)).zip (vect.toList).toMap[Option[Variable],D]).add (constantTerm)
    }

    def apply[D <: ExpressibleOrderedField[D]] (variables: Seq[Variable], vect: Matrix[D]): LinearCombination[D] = {
      LinearCombination (variables, vect, vect.field.zero)
    }

    def sum[D <: ExpressibleOrderedField[D]] (exprs: Seq[LinearCombination[D]]): LinearCombination[D] = {
      if (exprs.isEmpty)
        LinearCombination (Map[Option[Variable],D] ())
      else 
        exprs.head.add (sum (exprs.tail))
    }
  }
  
  type LAFormula[D <: ExpressibleOrderedField[D]] = Formula[LAFunction[D], ArithmeticRelation]
  type RLAFormula = LAFormula[Rational]
}
