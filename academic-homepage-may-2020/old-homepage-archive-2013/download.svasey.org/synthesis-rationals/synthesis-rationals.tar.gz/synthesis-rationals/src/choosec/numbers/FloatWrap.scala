package choosec
package numbers

import trees.ScalaCode._
  
case class FloatWrap (r: Double) extends ExpressibleOrderedField[FloatWrap]
{
  def +(that: FloatWrap) = FloatWrap (this.r + that.r)
  def *(that: FloatWrap) = FloatWrap (this.r * that.r)
  def one = FloatWrap (1.0)
  def zero = FloatWrap (0.0)
  def == (that: FloatWrap) = this.r == that.r
  override def equals (any: Any): Boolean = {
    if (any.isInstanceOf[FloatWrap]){
      any.asInstanceOf[FloatWrap] == this
    }
    else {
      false
    }
  }
  override def hashCode: Int = r.hashCode
  override def toString: String = r.toString
  def negate = FloatWrap (- r)
  def inverse = {
    require (!isZero)
    FloatWrap (1.0 / r)
  }
  def signum = r.compare (0.0)
  def isExact = false
  override def compare (that: FloatWrap) = r.compare (that.r)
  def fromString (str: String) = {
    FloatWrap (java.lang.Double.parseDouble (str))
  }
  // FIXME: do something if n is too large
  override def fromInt (n: BigInt) = FloatWrap (n.toDouble)

  // Note that due to numerical imprecision, this function is not guaranteed to
  // behave according to specifications...
  override def upTo (to: FloatWrap): FloatWrap = {
    if (this == to) this
    else if (this > to) to.upTo (this)
    else FloatWrap (java.lang.Math.nextUp (this.r))
  }

  def toDouble: Double = r
  def fromDouble_approx (x: Double, n: BigInt): FloatWrap = FloatWrap (x)
  
  def getType: Type = Type ("FloatWrap")
  def toScalaCode: Expr = {
    Apply (Identifier ("FloatWrap"), List (DoubleLit (r)))
  }
}

object FloatWrap {
  val r = FloatWrap (0.0)
  val rmat = BaseMatrix[FloatWrap] (r, List (List (r.zero)))
  
  def zero: FloatWrap = r.zero
  def one: FloatWrap = r.one

  def rationalToFloatWrap (r: Rational): FloatWrap =
    r.toFloatWrap
}
