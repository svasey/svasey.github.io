package choosec
package simplex

import numbers._
import code.SimpleAST.{SimpleExpr,Identifier,MaximizedRes,UnfeasibleRes,If}
import trees.Formulas._
import trees.FormulaTransforms._

import scala.collection.immutable.Queue  
import scala.annotation.tailrec

// Core code for solving of multiparmetric LP
object MultiparametricLP {

  // Set described by the equation {x | Ax <= b}
  trait Polyhedra[D <: ExpressibleOrderedField[D]] {
    def matrix: Matrix[D]
    def bound: Matrix[D]

    override def equals (that: Any): Boolean =
      that.isInstanceOf[Polyhedra[_]] && that.asInstanceOf[Polyhedra[D]].matrix == matrix && that.asInstanceOf[Polyhedra[D]].bound == bound

    override def hashCode: Int = (matrix, bound).hashCode
    
    def nConstraints: Int = matrix.nLines
    def nVariables: Int = matrix.nCols

    // Return true iff v is in the polyedra
    def contains (v: Matrix[D]): Boolean = {
      require (matrix.nCols == v.nLines && v.nCols == 1)
      val product = matrix * v
      List.range (1, matrix.nLines + 1).forall (i => product.get (i, 1) <= bound.get (i, 1))
    }

    // Synthetize code that checks whether the given parameters are in the
    // polyhedra, and a formula that is true iff the polyhedra contains the
    // parameters.
    def synthetize (parameters: Seq[Identifier]): (LAFormula[D], SimpleExpr) = {
      require (parameters.length == matrix.nCols)
      val formulaVariables = parameters.map (p => Variable (p.name))
      val toCheck = List.range (1, matrix.nLines + 1).map ({
        i => Rel (LtEqual (LinearCombination (formulaVariables, matrix.getLine (i)), LinearCombination (bound.get (i, 1)))):LAFormula[D]
      })


      val pre = LAsimplify (And (toCheck.toSet))
      (pre, pre.toSimpleExpr)
    }
  }
  
  class PolyhedraImpl[D <: ExpressibleOrderedField[D]] (mat: Matrix[D], b: Matrix[D]) extends Polyhedra[D] {
    require (mat.nLines == b.nLines && b.nCols == 1)
    def matrix = mat
    def bound = b

    override def toString: String = {
      "Constraint matrix:\n" + mat.toString + "\nbound:\n" + b.toString
    }
  }
  
  // Describes all the critical regions of the space, and the optimizers going
  // with them.
  trait CriticalRegionMap[D <: ExpressibleOrderedField[D]] {
    // The maximizing vector
    val maximize: Matrix[D]
  
    // Initialize an empty map, i.e one containing no regions, hence no
    // optimizer, using the given objective.
    def initEmpty (objective: Matrix[D]): CriticalRegionMap[D]
    // Add a critical region defined by the given polyhedra, a matrix D, a
    // vector w s.t the optimizer is given by x = Dp + w, where p is the
    // parameter vector.
    def addRegion (polyhedra: Polyhedra[D], optimizerMat: Matrix[D],
		   optimizerShift: Matrix[D]): CriticalRegionMap[D]

    // Mostly for performance measurement
    def nRegions: Int
  
    // Same as findSolutions, but return only the optimizer
    def findOptimizer (parameters: Matrix[D]): Option[Matrix[D]]

    // Synthetize code that assumes the given parameters are defined in the
    // environment, and returns the corresponding LP result. Also return a
    // pre-condition that is true iff the problem is feasible. If `assumePre` is
    // true, we suppose the pre-condition is valid inside the code we generate
    def synthetize (parameters: Seq[Identifier], assumePre: Boolean): (LAFormula[D], SimpleExpr)
    def synthetize (parameters: Seq[Identifier]): (LAFormula[D], SimpleExpr) =
      synthetize (parameters, true)
    // Given a vector of parameters, return its optimizer (solution to the LP)
    // and optimal value, or None if the LP is no feasible.
    def findSolutions (parameters: Matrix[D]): Option[(Matrix[D], D)] = findOptimizer (parameters) match {
      case Some (x) => Some ((x, x.innerProduct (maximize)))
      case None => None
    }
  }

  case class CriticalRegion[D <: ExpressibleOrderedField[D]] (polyhedra: Polyhedra[D],
							      optimizerMat: Matrix[D],
							      optimizerShift: Matrix[D]){
    // println ("DEBUG: polyhedra: " + polyhedra)
    // println ("DEBUG: optimizerMat:\n" + optimizerMat)
    // println ("DEBUG: optimizerShift:\n" + optimizerShift)
    require (optimizerMat.nLines == optimizerShift.nLines)

    // Two regions are the same iff they have the same polyhedra
    override def hashCode: Int = polyhedra.hashCode
    override def equals (obj: Any): Boolean =
      obj.isInstanceOf[CriticalRegion[_]] && obj.asInstanceOf[CriticalRegion[D]].polyhedra.equals (polyhedra)
  
    def nVariables: Int = polyhedra.nVariables
    def nConstraints: Int = polyhedra.nConstraints
    def contains (v: Matrix[D]): Boolean = polyhedra.contains (v)
    // Return the linear combination representing the value of the optimizer at the ith component
    def optimizerLC (parameters: Seq[Variable], line: Int): LinearCombination[D] = {
      // println ("DEBUG: optimizerMat:\n" + optimizerMat)
      // println ("DEBUG: optimizerShift:\n" + optimizerShift)
      // println ("DEBUG: optimizerLC: parameters: " + parameters)
      // println ("DEBUG: line: " + line)
      require (parameters.length == optimizerMat.nCols && 1 <= line && line <= optimizerShift.nLines)
      LinearCombination (parameters, optimizerMat.getLine (line), optimizerShift.get (line, 1))
    }
  }

  // Simple implementation, using sequential search to find the optimizer 
  class SimpleCRMap[D <: ExpressibleOrderedField[D]] (val maximize: Matrix[D], val regions: Set[CriticalRegion[D]]) extends CriticalRegionMap[D] {
    require (maximize.nCols == 1)

    override def toString: String = {
      "Regions: " + regions.toString
    }
    def initEmpty (objective: Matrix[D]) = SimpleCRMap (objective)
    def nRegions: Int = regions.size
    def addRegion (polyhedra: Polyhedra[D], optimizerMat: Matrix[D],
		   optimizerShift: Matrix[D]): SimpleCRMap[D] = 
      SimpleCRMap (maximize, regions + CriticalRegion (polyhedra, optimizerMat, optimizerShift))

    def findOptimizer (parameters: Matrix[D]): Option[Matrix[D]] = {
      regions.find (r => r.contains (parameters)) match {
	case Some (CriticalRegion (_, optimizerMat, optimizerShift)) => {
	  Some (optimizerMat * parameters + optimizerShift)
	}
	case None => None
      }
    }
		     
    def synthetize (parameters: Seq[Identifier], assumePre: Boolean): (LAFormula[D], SimpleExpr) = {
      val formulaVariables = parameters.map (id => Variable (id.name))
      def synth (remaining: Set[CriticalRegion[D]]): (LAFormula[D], SimpleExpr) = {
	if (remaining.isEmpty)
	  (Rel (False), UnfeasibleRes)
	else {
	  val region = remaining.head
	  val (inRegionPre, inRegionCode) = region.polyhedra.synthetize (parameters)
	  val optimizerLC =
	    List.range (1, maximize.nLines + 1).map (i => region.optimizerLC (formulaVariables, i))
	  val weightedOptimizer = optimizerLC.zipWithIndex.map (_ match {
	    case (lc, i) => lc.scale (maximize.get (i + 1, 1))
	  })
	  val maximum = LinearCombination.sum (weightedOptimizer)
	  val computeOptimizer = optimizerLC.map (lc => lc.toSimpleExpr)
	  val regionRes = MaximizedRes (computeOptimizer, maximum.toSimpleExpr)
	  if (assumePre && remaining.tail.isEmpty)
	    (inRegionPre, regionRes)
	  else {
            val (pre0, code0) = synth (remaining.tail)
	    val code = If (inRegionCode, regionRes, code0)
	    val pre = Or (inRegionPre, pre0)
            (pre, code)
	  }
	}
      }
      val (pre, code) = synth (regions)
      (LAsimplify (pre), code)
    }
  }

  object SimpleCRMap {
    def apply[D <: ExpressibleOrderedField[D]] (maximize: Matrix[D], regions: Set[CriticalRegion[D]]): SimpleCRMap[D] =
      new SimpleCRMap (maximize, regions)
    def apply[D <: ExpressibleOrderedField[D]] (maximize: Matrix[D]): SimpleCRMap[D] =
      SimpleCRMap (maximize, Set ())
  }

  trait MultiparametricSolver[D <: ExpressibleOrderedField[D]] {
    val simplexSolver: SimplexSolver[D]
    val crMap: CriticalRegionMap[D]

    // Solve a problem of the form max c^T x, under the constraints Ax <= w +
    // Fp, where w is a constant vector, p is a vector of parameters, and F is
    // the parameter matrix. Return the corresponding critical region
    // partitionning of space. It is assumed the matrix A has full column rank,
    // and that the system is bounded (it may not be feasible).    
    def solve (matrix: Matrix[D], maximize: Matrix[D], boundShift: Matrix[D],
               parameterMat: Matrix[D]): CriticalRegionMap[D] = {
      // If the maximize vector is zero, we will get suboptimal performance:
      // choose something to maximize.
      val newMaximize = {
        if (maximize.isZero){
          val nonZ = List.range (1, matrix.nLines + 1).find (i => !matrix.getLine (i).isZero)
          require (!nonZ.isEmpty)
          matrix.getLine (nonZ.get).transpose
        }
        else
          maximize
      }
      solve0 (matrix, newMaximize, boundShift,
              parameterMat)
    }

    def solve0 (matrix: Matrix[D], maximize: Matrix[D], boundShift: Matrix[D],
	        parameterMat: Matrix[D]): CriticalRegionMap[D]
      
  }

  class MPSolver[D <: ExpressibleOrderedField[D]] (val simplexSolver: SimplexSolver[D],
						   val crMap: CriticalRegionMap[D]) extends MultiparametricSolver[D]{
    val field = simplexSolver.field

    def solve0 (matrix: Matrix[D], maximize: Matrix[D], boundShift: Matrix[D],
	       parameterMat: Matrix[D]): CriticalRegionMap[D] = {
      require (matrix.nCols == maximize.nLines && maximize.nCols == 1 && boundShift.nLines == matrix.nLines && boundShift.nCols == 1 && parameterMat.nLines == matrix.nLines && matrix.isFullRank && matrix.nLines >= matrix.nCols)


      case class Basis (basis: Seq[Int], basisMatrix: Matrix[D],
			complementBasisMatrix: Matrix[D],
			inverseBasisMatrix: Matrix[D],
                        paramBasisMatrix: Matrix[D],
                        paramComplementMatrix: Matrix[D],
                        shiftBasisVect: Matrix[D],
                        shiftComplementVect: Matrix[D]){
        require (basis.length == basisMatrix.nLines &&
                 complementBasisMatrix.nLines == matrix.nLines - basisMatrix.nLines &&
                 inverseBasisMatrix.nLines == basisMatrix.nLines && inverseBasisMatrix.nCols == inverseBasisMatrix.nLines && paramBasisMatrix.nLines == basisMatrix.nLines &&
               paramComplementMatrix.nLines == matrix.nLines - paramBasisMatrix.nLines &&
               shiftBasisVect.nLines == basisMatrix.nLines &&
               shiftComplementVect.nLines == matrix.nLines - basisMatrix.nLines &&
               shiftBasisVect.nCols == 1 && shiftComplementVect.nCols == 1)
  
	// Overriden for efficiency reasons
	override def hashCode: Int = basis.hashCode
	override def equals (obj: Any): Boolean = 
	  obj.isInstanceOf[Basis] && obj.asInstanceOf[Basis].basis == basis
      }

      // Update the given basis and its inverse matrix. Return the new basis, if
      // it exists, or None if the resulting set is not a basis. It is assumed
      // the number of lines in the matrix is larger than the number of
      // variables (its number of columns)
      def updateBasisTry (oldBasis: Seq[Int], entering: Int, leaving: Int,
			  inverseBasisMatrix: Matrix[D]): Option[Basis] = {
	require (matrix.nLines > matrix.nCols)
        // println ("DEBUG: updating basis: old basis:" + oldBasis)
        // println ("DEBUG: entering:" + entering)
        // println ("DEBUG: leaving:" + leaving)
        // println ("DEBUG: old inverse basis matrix:\n" + inverseBasisMatrix)
	val newBasis = oldBasis.map (el => if (el == leaving) entering else el)
	val newBasisMatrix = matrix.getLines (newBasis)
	val newInverseMat = SimplexImpl.updateInverseBasisMatrixTry (newBasis, newBasisMatrix, entering,
								     inverseBasisMatrix)
	if (newInverseMat.isEmpty)
	  None
	else {
          val newBasisSet = newBasis.toSet
          // println ("DEBUG: full matrix:\n" + matrix)
          // println ("DEBUG: old basis matrix:\n" + matrix.getLines (oldBasis))
          // println ("DEBUG: new basis matrix:\n" + newBasisMatrix)
	  val newComplement = matrix.removeLines (newBasisSet)
          val newParamBasisMatrix = parameterMat.getLines (newBasis)
          val newParamComplementMatrix = parameterMat.removeLines (newBasisSet)
          val newShiftBasisVect = boundShift.getLines (newBasis)
          val newShiftComplementVect = boundShift.removeLines (newBasisSet)

	
	  Some (Basis (newBasis, newBasisMatrix, newComplement, newInverseMat.get,
		       newParamBasisMatrix, newParamComplementMatrix, newShiftBasisVect,
		       newShiftComplementVect))
	}
      }

      def isRoof (inverseBasisMatrix: Matrix[D]): Boolean = {
	List.range (1, maximize.nLines + 1).forall (i => inverseBasisMatrix.getCol (i).innerProduct (maximize) >= field.zero)
      }

      // Test if the given basis can possibly be optimal for some parameter
      // value. Return the polyhedra in which parameters must lie so that the
      // basis is optimal, if it is non-empty, or None
      // otherwise. `complementBasisMatrix` is the matrix A without the line of
      // the basis (it is assumed the complement exists, i.e there are more
      // lines in A than columns).
      def basisPolyhedra (basis: Basis): Option[Polyhedra[D]] = {
	def isEmpty (poly: Polyhedra[D]): Boolean = {
	  val solver =
            simplexSolver.init (poly.matrix,
                                maximize.zero (poly.matrix.nCols, 1), poly.bound)
	  !solver.fullSimplex.isFeasible
	}

	if (isRoof (basis.inverseBasisMatrix)){
          
	  val prod = basis.complementBasisMatrix * basis.inverseBasisMatrix
          val leftMat = prod * basis.paramBasisMatrix
	  val constrMatrix = leftMat + basis.paramComplementMatrix.negate
          val rightMat = prod * basis.shiftBasisVect.negate
	  val bound = basis.shiftComplementVect + rightMat

          // println ("DEBUG: matrix:\n" + matrix)
          // println ("DEBUG: basis matrix:\n" + basis.basisMatrix)
          // println ("DEBUG: complement basis matrix:\n" + basis.complementBasisMatrix)
          // println ("DEBUG: paramMatrix:\n" + parameterMat)
          // println ("DEBUG: basis parameter matrix:\n" + basis.paramBasisMatrix)
          // println ("DEBUG: complement parameter matrix:\n" + basis.paramComplementMatrix)
          // println ("DEBUG: constraint matrix:\n" + constrMatrix)
          // println ("DEBUG: bound:\n" + bound)
          // println ("DEBUG: maximize:\n" + maximize)

	  val poly = new PolyhedraImpl (constrMatrix, bound)
	  if (!isEmpty (poly))
	    Some (poly)
	  else
	    None
	}
	else
	  None
      }

      // Try to add the given basis to the region, and return the new region if this
      // succeeds, None otherwise (i.e the basis cannot be optimal for the parameter space)
      def addBasisTry (regions: CriticalRegionMap[D], basis: Basis): Option[CriticalRegionMap[D]] = {
	basisPolyhedra (basis) match {
	  case Some (poly) => {
	    val optimizerMat = basis.inverseBasisMatrix * basis.paramBasisMatrix
	    val optimizerShift = basis.inverseBasisMatrix * basis.shiftBasisVect
	    Some (regions.addRegion (poly, optimizerMat, optimizerShift))
	  }
	  case None => None
	}
      }



      @tailrec
      def bfs (visited: Set[Set[Int]], queue: Queue[Basis], regions: CriticalRegionMap[D]): CriticalRegionMap[D] = {
        println ("DEBUG: " + visited.size + " basis have been visited [ m = " +
		 matrix.nLines + ", n = " + matrix.nCols + "]")
        println ("DEBUG: " + queue.length + " basis are queued")
        println ("DEBUG: " + regions.nRegions + " regions have been found so far")
	if (queue.isEmpty)
	  regions
	else {
	  val basis = queue.head
	  addBasisTry (regions, basis) match {
	    case Some (newRegions) => {
	      // Add the new neighboring basis to the queue
	      val basisSet = basis.basis.toSet

	      val enterCandidates = List.range (1, matrix.nLines + 1).filter (i => !basisSet.contains (i))
	      val leaveCandidates = basis.basis

	      def newQueue (enterCand: Seq[Int], leaveCand: Seq[Int], curQueue: Queue[Basis], curVisited: Set[Set[Int]]): (Queue[Basis] , Set[Set[Int]]) = {
		if (enterCand.isEmpty)
		  (curQueue, curVisited)
		else {
		  val entering = enterCand.head
		  if (leaveCand.isEmpty)
		    newQueue (enterCand.tail, leaveCandidates, curQueue, curVisited)
		  else {
		    val leaving = leaveCand.head
		    val newBasis = basis.basis.map (el => if (el == leaving) entering else el)
		    val newBasisSet = newBasis.toSet
		    if (curVisited.contains (newBasisSet)){
		      newQueue (enterCand, leaveCand.tail, curQueue, curVisited)
		    }
		    else {
		      val newBasis2 = updateBasisTry (basis.basis, entering, leaving,
						      basis.inverseBasisMatrix)
		      if (newBasis2.isEmpty)
			newQueue (enterCand, leaveCand.tail, curQueue,
				  curVisited + newBasisSet)
		      else
			newQueue (enterCand, leaveCand.tail, curQueue.enqueue (newBasis2.get),
				  curVisited + newBasisSet)
		      
		    }
		  }
		}
	      }
	      
	      val (nextQueue, nextVisited) = newQueue (enterCandidates, leaveCandidates, queue.tail, visited)
	      bfs (nextVisited, nextQueue, newRegions)
	    }
	    case None => bfs (visited + basis.basis.toSet, queue.tail, regions)
	  }
	}
      }

      // Obtain an initial basis to start the algorithm with. Return None if
      // there are no such basis, i.e the problem is unfeasible.
      def getInitialBasis: Option[Basis] = {
        require (matrix.nLines > matrix.nCols)
        
	val constrMatrix = matrix.appendRight (parameterMat.negate)
	val newMaximize = maximize.zero (constrMatrix.nCols, 1)
	val solver = simplexSolver.init (constrMatrix, newMaximize, boundShift)
        // println ("DEBUG: running simplex with constraint matrix:\n" + constrMatrix)
        // println ("DEBUG: running simplex with maximize:\n" + newMaximize)
        // println ("DEBUG: running simplex with bound:\n" + boundShift)
	val res = solver.fullSimplex
        if (res.hasOptimalRoof){
          val optimalSol = res.optimalVector
	  val basis = {
            val paramVal = optimalSol.getLines (matrix.nCols + 1,
                                                optimalSol.nLines)
            val bound = boundShift + parameterMat * paramVal
            val solver2 = simplexSolver.init (matrix, maximize, bound)
            val res2 = solver2.simplex
            assert (res2.hasOptimalRoof)
            res2.optimalRoof
          }
          // println ("DEBUG: found basis: " + basis)
          // println ("DEBUG: matrix:\n" + matrix)
          val basisMatrix = matrix.getLines (basis)
	  val inverseBasisMatrix = basisMatrix.inverse
          
	  Some (updateBasisTry (basis, basis.head, basis.head, inverseBasisMatrix).get)
        }
        else
          None
      }

      println ("DEBUG: solving multiparametric LP")
      println ("DEBUG: Sparsity ratio of A is " + matrix.sparseRatio)
      println ("DEBUG: column rank of F is " + parameterMat.columnRank)
      if (matrix.nLines == matrix.nCols){
	val basis = List.range (1, matrix.nLines + 1)
	val inverse = matrix.inverse
        if (isRoof (inverse)){
	  val poly = new PolyhedraImpl (matrix.zero (1, parameterMat.nCols),
				        matrix.zero (1))
	  crMap.initEmpty (maximize).addRegion (poly, inverse * parameterMat, inverse * boundShift)
        }
        else
          crMap.initEmpty (maximize)
      }
      else {
	getInitialBasis match {
          case Some (initial) => {
	    val res = bfs (Set (initial.basis.toSet), Queue (initial),
			   crMap.initEmpty (maximize))
	    println ("DEBUG: multiparametric LP solver split the parameter " +
		     "space into " + res.nRegions + " regions")
                     
	    res
          }
          case None => {
            crMap.initEmpty (maximize)
          }
        }
      }
    }
  }

  object MPSolver {
    def apply[D <: ExpressibleOrderedField[D]] (simplexSolver: SimplexSolver[D], crMap: CriticalRegionMap[D]): MPSolver[D] = {
      new MPSolver (simplexSolver, crMap)
    }

    // Use the default implementation for critical region map (i.e the simple
    // linear one)
    def apply[D <: ExpressibleOrderedField[D]] (simplexSolver: SimplexSolver[D]): MPSolver[D] = {
      MPSolver (simplexSolver, SimpleCRMap (simplexSolver.maximize))
    }
  }
  
  
}
