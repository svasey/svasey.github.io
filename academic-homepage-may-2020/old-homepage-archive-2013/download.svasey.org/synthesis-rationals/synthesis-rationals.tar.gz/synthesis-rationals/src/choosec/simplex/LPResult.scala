package choosec
package simplex

import numbers._
import trees.ScalaCode._
import trees.ScalaExpressible
import code.SimpleAST.SimpleExpr
import code.SimpleAST.UnboundedRes
import code.SimpleAST.MaximizedRes
import code.SimpleAST.BoundedRes
import code.SimpleAST.UnfeasibleRes
import code.SimpleAST.FieldEl

// Describes the kind of results a linear program can have
trait LPResult[D <: ExpressibleOrderedField[D]] extends ScalaExpressible with Ordered[LPResult[D]] {
  val field: D

  // True if the objective function has a least upper bound for the set of
  // points in the linear program. Thus if the linear program is unfeasible,
  // this is false.
  def isBounded: Boolean
  // True iff there is a point satisfying the constraints of the linear program.
  def isFeasible: Boolean
  // True iff the linear program is bounded and has an optimal solution. This is
  // implied by feasible and bounded in the case of only non-strict
  // inequalities, but if strict inequalities are allowed, a linear program can
  // be bounded, feasible and still not have an optimal solution, e.g maximize x
  // with constraints x < 1 has no solutions.
  def hasSolution: Boolean
  // True if the linear program has an optimal solution and we are certain that
  // it comes from an optimal roof. This is always true for programs with
  // non-strict inequalities, but not necessarily for those with strict ones,
  // e.g maximize x with constraints x <= 1, y < 1 . Note that if it is false,
  // the optimal solution may still come from an optimal roof.
  def hasOptimalRoof: Boolean
  // If the program is bounded and feasible, return the least upper bound for
  // the linear program.
  def leastUpperBound: D

  // Convert to a result using the field E, using the given conversion method
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E): LPResult[E]
  
  
  // Set the bound of the result, if it has one
  def setBound (bound: D): LPResult[D]

  // If the result has a solution, set the bound to `maximize * sol`, otherwise,
  // leave the result unchanged.
  def setBound (maximize: Matrix[D]): LPResult[D] = {
    if (hasSolution)
      setBound (maximize.innerProduct (optimalVector))
    else
      this
  }
  
  // Return the bound as some abstract object
  def abstractBound: WithInfinitesimals[D] = {
    if (!isFeasible){
      MINUS_INFINITY ()
    }
    else if (!isBounded){
      PLUS_INFINITY ()
    }
    else if (!hasSolution){
      Element (leastUpperBound, Smaller)
    }
    else {
      Element (leastUpperBound, Same)
    }
  }
  // If the program has an optimal roof, return an optimal roof
  def optimalRoof: Seq[Int]
  // Return the optimal solution
  def optimalVector: Matrix[D]
  // If there is a solution, transform it via the given function. Otherwise if
  // there is no solution, return the result unchanged.
  def transformSol (transf: Matrix[D] => Matrix[D]): LPResult[D]

  override def toString: String = {
    if (isFeasible){
      if (isBounded){
	if (hasSolution){
	  val first = "Optimal solution:\n" ++ optimalVector.toString ++ "\n"
	  val second = "Value at optimal solution:\n" ++ leastUpperBound.toString ++ "\n"
	  val third =
	    if (hasOptimalRoof) "Optimal roof: " ++ optimalRoof.toString
	    else "No optimal roof known"
	  first ++ second ++ third
	}
	else {
	  "Problem is bounded by least upper bound " ++  leastUpperBound.toString ++
	  " and feasible but has no optimal solution"
	}
      }
      else {
	"Problem is feasible but unbounded"
      }
    }
    else {
      "Problem is unfeasible"
    }
  }

  // Change the solution
  def setSol (sol: Matrix[D]): LPResult[D] = 
    transformSol (el => sol)

  // Left-multiply the solution with the given matrix, padding the solution with
  // trailing zeroes if necessary. If there is no solution, return the result
  // unchanged.
  def multiplySol (matrix: Matrix[D]): LPResult[D] = {
    transformSol (el => {
      require (el.nLines <= matrix.nCols)
      val padded = {
	if (el.nLines == matrix.nCols)
	  el
	else
	  el.appendBottom (matrix.zero (matrix.nCols - el.nLines, 1))
      }
      matrix * padded
    })
  }
  // Change the solution so that it has only its first n components.
  def projectSol (n: Int): LPResult[D] = {
    transformSol (el => {
      require (el.nLines >= n)
      el.getLines (List.range (1, n + 1))
    })
  }

  def compare (that: LPResult[D]): Int = this.abstractBound.compare (that.abstractBound)

  // Given the linear problems `this` and `that`, return the one that yields the
  // best maximum.
  def max (that: LPResult[D]): LPResult[D] = {
    // println ("DEBUG: max between " + this.abstractBound + " and " + that.abstractBound)
    // println ("DEBUG: " + (if (this < that) that.abstractBound else this.abstractBound))
    if (this < that) that else this
  }

  def getType: Type = Type ("LPResult[" + field.getType + "]")
  def toSimpleExpr: SimpleExpr = {
    if (isFeasible){
      if (isBounded){
        if (hasSolution){
          MaximizedRes (optimalVector.toList.map (c => FieldEl (c)),
                        FieldEl (leastUpperBound))
        }
        else {
          BoundedRes (FieldEl (leastUpperBound))
        }
      }
      else {
        UnboundedRes
      }
    }
    else {
      UnfeasibleRes
    }          
  }
}

trait LPRes2[D <: ExpressibleOrderedField[D]] extends LPResult[D]
{
  def toScalaCode (fieldExpr: Expr): Expr
  def toScalaCode: Expr = {
    toScalaCode (field.toScalaCode)
  }
}

case class MaximizedLPRes[D <: ExpressibleOrderedField[D]] (val field: D, bound: D,
                                                            roof: Seq[Int],
                                                            sol: Matrix[D]) extends LPRes2[D] {
  def isBounded = true
  def isFeasible = true
  def hasSolution = true
  def hasOptimalRoof = !roof.isEmpty
  def leastUpperBound = bound
  def optimalRoof = {
    require (hasOptimalRoof)
    roof
  }
  def optimalVector = sol
  def transformSol (transf: Matrix[D] => Matrix[D]): LPResult[D] = {
    val newSol = transf (sol)
    MaximizedLPRes (field, bound, roof, newSol)
  }
  def setBound (newBound: D) = MaximizedLPRes (field, newBound, roof, sol)
  def toScalaCode (fieldExpr: Expr, boundExpr: Expr, roofExpr: Expr, solExpr: Expr): Expr = {
    Apply (Identifier ("MaximizedLPRes"), List (fieldExpr, boundExpr, roofExpr, solExpr))
  }
  def toScalaCode (fieldExpr: Expr) = {
    toScalaCode (fieldExpr, bound.toScalaCode, intSeqCode ("List", roof.toList),
                 sol.toScalaCode)
  }
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E) = {
    MaximizedLPRes (conv (field), conv (bound), roof, sol.convert (conv))
  }
}

object MaximizedLPRes {
  def apply[D <: ExpressibleOrderedField[D]] (bound: D, roof: Seq[Int], sol: Matrix[D]): MaximizedLPRes[D] = {
    MaximizedLPRes (bound, bound, roof, sol)
  }
  def apply[D <: ExpressibleOrderedField[D]] (bound: D, sol: Matrix[D]): MaximizedLPRes[D] = {
    MaximizedLPRes (bound, List (), sol)
  }
}

case class BoundedLPRes[D <: ExpressibleOrderedField[D]] (val field:D, bound: D) extends LPRes2[D] {
  def isBounded = true
  def isFeasible = true
  def hasSolution = false
  def hasOptimalRoof = false
  def leastUpperBound = bound
  def optimalRoof = error ("No optimal roof")
  def optimalVector = error ("No solution")
  def transformSol (transf: Matrix[D] => Matrix[D]) = this
  def setBound (newBound: D) = BoundedLPRes (field, newBound)
  def toScalaCode (fieldExpr: Expr, boundExpr: Expr): Expr = {
    Apply (Identifier ("BoundedLPRes"), List (fieldExpr, boundExpr))
  }
  def toScalaCode (fieldExpr: Expr): Expr = {
    toScalaCode (fieldExpr, bound.toScalaCode)
  }
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E) = {
    BoundedLPRes (conv (field), conv (bound))
  }
}

object BoundedLPRes {
  def apply[D <: ExpressibleOrderedField[D]] (bound: D): BoundedLPRes[D] = {
    BoundedLPRes (bound, bound)
  }
}

case class UnboundedLPRes[D <: ExpressibleOrderedField[D]] (val field:D) extends LPRes2[D] {
  def isBounded = false
  def isFeasible = true
  def hasSolution = false
  def hasOptimalRoof = false
  def leastUpperBound = error ("No least upper bound")
  def optimalRoof = error ("No optimal roof")
  def optimalVector = error ("No solution")
  def transformSol (transf: Matrix[D] => Matrix[D]) = this
  def setBound (newBound: D) = this
  def toScalaCode (fieldExpr: Expr): Expr = 
    Apply (Identifier ("UnboundedLPRes"), List (fieldExpr))
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E) = {
    UnboundedLPRes (conv (field))
  }
}

case class UnfeasibleLPRes[D <: ExpressibleOrderedField[D]] (val field:D) extends LPRes2[D] {
  def isBounded = false
  def isFeasible = false
  def hasSolution = false
  def hasOptimalRoof = false
  def leastUpperBound = error ("No least upper bound")
  def optimalRoof = error ("No optimal roof")
  def optimalVector = error ("No solution")
  def transformSol (transf: Matrix[D] => Matrix[D]) = this
  def setBound (newBound: D) = this
  def toScalaCode (fieldExpr: Expr): Expr = 
    Apply (Identifier ("UnfeasibleLPRes"), List (fieldExpr))
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E) = {
    UnfeasibleLPRes (conv (field))
  }
}



case class LPRes[D <: ExpressibleOrderedField[D]] (fieldEl: D, bound: Option[D],
						   optRoof: Option[Seq[Int]],
						   optVect: Option[Matrix[D]],
						   feasible: Boolean) extends LPResult[D]
{
  val field: D = fieldEl
  def isBounded: Boolean = !bound.isEmpty
  def isFeasible: Boolean = feasible
  def hasSolution: Boolean = !optVect.isEmpty
  def hasOptimalRoof: Boolean = !optRoof.isEmpty
  def leastUpperBound: D = {
    require (isBounded)
    bound.get
  }
  def optimalRoof: Seq[Int] = {
    require (hasOptimalRoof)
    optRoof.get
  }
  def optimalVector: Matrix[D] = {
    require (hasSolution)
    optVect.get
  }
  def transformSol (transf: Matrix[D] => Matrix[D]): LPResult[D] = {
    if (this.hasSolution){
      val oldSol = this.optimalVector
      val newSol = transf (oldSol)
      LPRes (field, this.bound, this.optRoof, Some (newSol), true)
    }
    else {
      this
    }
  }

  def setBound (newBound: D): LPRes[D] = {
    if (this.isBounded){
      LPRes (fieldEl, Some (newBound), optRoof, optVect, feasible)
    }
    else {
      this
    }
  }

  def toScalaCode: Expr = {
    Apply (getType.name, List (field.toScalaCode, optionCode (bound),
			       optionCode (optRoof, (r:Seq[Int]) => intSeqCode ("List",
                                                                                r.toList)),
			       optionCode (optVect), 
			       boolCode (feasible)))
  }
  def convert[E <: ExpressibleOrderedField[E]] (conv: D => E) = {
    LPRes (conv (fieldEl), if (!bound.isEmpty) Some (conv (bound.get)) else
      None, optRoof, if (!optVect.isEmpty) Some (optVect.get.convert (conv))
		     else None, feasible)
  }
}
