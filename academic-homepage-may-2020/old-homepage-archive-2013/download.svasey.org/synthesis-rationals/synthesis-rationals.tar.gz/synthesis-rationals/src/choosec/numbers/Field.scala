package choosec
package numbers

import trees.ScalaExpressible
import scala.annotation.tailrec

// Object satisfying the algebraic axioms of a field.
// The type parametrization is ugly, but it more or less works...
trait Field[T <: Field[T]]		
{
  // One might want to override `equals` and `hashCode` if this is something
  // else than componentwise equality
  def == (that: T): Boolean
  def zero: T
  def one: T
  def + (that: T): T
  def * (that: T): T
  def negate: T
  def inverse: T
  // Return true if every operation is done in an exact way (e.g pure
  // rationals), false otherwise (e.g Double)
  def isExact: Boolean
  def - (that: T): T = this + (that.negate)
  def / (that: T): T = this * (that.inverse)
  def isOne: Boolean = this == this.one
  def isZero: Boolean = this == this.zero

  // "Convert" an integer to an element of the field using the natural
  // homomorphism. This is very inefficient, so subclasses might want to
  // override that method.
  def fromInt (n: BigInt): T = {
    if (n == 0)
      zero
    else if (n < 0)
      fromInt (n + 1) - one
    else
      fromInt (n - 1) + one
  }

  // Very short string describing the number
  def shortString: String = {
    if (isOne) "one"
    else if (isZero) "zero"
    else if (this == one.negate) "mOne"
    else "r"
  }
  
  // Read from a string
  def fromString (str: String): T
}

// Field with an total order relation < such that x < y implies x + a < y + a,
// and 0 < a, 0 < b implies 0 < ab
trait OrderedField[T <: OrderedField[T]] extends Field[T] with Ordered[T]
{
  // Return -1 if this < 0, 0 if this = 0, 1 if this > 0
  def signum: Int
  // Return -1 if this < that, 0 if this = that, 1 if this > that
  def compare (that: T): Int = (this - that).signum

  // Let x0 := min(this,that), y0 := max(this,that). Return a number x s.t
  // x0 < x < y0, or x0 == x == y0, i.e strictly between x0 and y0, unless that
  // is not possible.
  def upTo (that: T): T = {
    (this + that) / (fromInt (2))
  }

  // For some type-related reason, we cannot return `this`...
  def abs: T = if (this.signum >= 0) this.negate.negate else this.negate

  // Return some double approximation to the element of the field
  def toDouble: Double

  // Return the exact value of `x` as an element of the field
  def fromDouble (x: Double):T = {
    require (!x.isInfinite && !x.isNaN)

    // A faster way is to directly parse the long representation, but I have
    // other things to do...
    val hexString = java.lang.Double.toHexString (x)
    val (sign, magn) = {
      if (hexString.head == '-') (-1, hexString.tail)
      else (1, hexString)
    }
    val (signif0, exp0) = magn.span (c => c != 'p')
    assert (exp0.head == 'p' && signif0.head == '0' && signif0.tail.head == 'x')
    val signifStr = signif0.drop (2)
    val nDigits = signifStr.length - 2

    val exp = BigInt (exp0.tail) - (nDigits * 4)
    val signif = BigInt (signifStr.head + signifStr.tail.tail, 16)

    val magnRes = {
      if (exp.signum < 0)
        fromInt (signif) / (fromInt (BigInt (1) << -exp.toInt))
      else
        fromInt (signif << exp.toInt)
    }
    if (sign > 0)
      magnRes
    else
      magnRes.negate
  }

  // Return an approximation of x as an element of the field, where n is some
  // context-dependent indication of the precision (strictly positive), to be
  // ignored if not necessary.
  def fromDouble_approx (x: Double, n: BigInt): T
}

trait ExpressibleField[T <: ExpressibleField[T]] extends Field[T] with ScalaExpressible

trait ExpressibleOrderedField[T <: ExpressibleOrderedField[T]] extends ExpressibleField[T] with OrderedField[T]


