package choosec

// Original source: http://lara.epfl.ch/web2010/cc10:top
 
import parser.Parser
import numbers._
import synthesis._
import trees.Formulas._
import trees.ScalaCode.Expr
import code.SimpleAST.SimpleExpr
import code.SimpleAST.ErrorRes
import code.SimpleAST.MaximizedRes
import code.SimpleCodeToScala._
import code.SimpleAST
 
import scala.io.Source

// Use the convert method to convert from field D to E: code outputted will use
// field E, while synthesis computations will be done using field
// D. `synthInput` contains the variables, the formula and the objective
// function to maximize. If not given, this will be parsed from the input file.
class LASynthetizer[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]](val fileName: String, val method: LASynthesisMethod[D], val convert: D => E, val synthInput:Option[(Seq[Variable], LAFormula[D], Option[LinearCombination[D]])]) extends Reporter[D,E] with Parser[D,E] {

  val source: Source = {
    if (!fileName.isEmpty) Source.fromFile(fileName).withPositioning(true)
    // Dummy source we are not supposed to use
    else Source.fromChar ('a')
  }

  // Simply return an element of the field
  def field: D = method.field
  def outField: E = convert (field)
  
  def tokens: Unit = {

    import parser.Tokens._

    // Lexing
    var t: Token = Token(BAD)
       do {
       t = nextToken
       print(t.info + "(" + t.posString + ") ")
    } while(t.info != EOF)
    terminateIfErrors

  }

  def parse:  Unit = {
    // Parsing
    val (variables, formula, maximize) = parseSource
    terminateIfErrors
    println ("Variables: " + variables)
    println ("Maximize: " + maximize)
    println ("With constraints: " + formula)
  }

  def setSynthInput (variables: Seq[Variable], formula: LAFormula[D], maximize: Option[LinearCombination[D]]): LASynthetizer[D,E] = {
    LASynthetizer (method, convert, variables, formula, maximize)
  }

  // Return variables, formula, maximize, pre-condition, synthetized code, and the set of parameters . 
  def synthetize: (Seq[Variable], LAFormula[D], Option[LinearCombination[D]], LAFormula[D], SimpleExpr, Set[Variable]) = {
    
    val (variables, formula, maximize) = {
      if (synthInput.isEmpty)
	parseSource
      else
	synthInput.get
    }
    terminateIfErrors
    println ("Variables: " + variables)
    println ("Maximize: " + maximize)
    println ("With constraints: " + formula)
    println ()
    val (pre, code) = method.synthetize (variables, formula, maximize)
    val parameters = formula.unquantifiedVariables -- variables

    (variables, formula, maximize, pre, code, parameters)
  }

  def synthetizeToFile (scalaHeaders: String, outputDir: String,
                        objectName: String): Unit = {
    synthetizeToFile (scalaHeaders, outputDir, objectName, "", "foo")
  }
                                               
  def synthetizeToFile (scalaHeaders: String, outputDir: String,
                        objectName: String, packageName: String,
                        methodName: String): Unit = {
    val filename = objectName + ".scala"
    synthetizeToFile (scalaHeaders, outputDir, objectName, packageName,
		      methodName, filename)
  }
    
  // Print the synthetized code inside a main file that demonstrates it, and
  // inside a method named `methodName` that takes the parameters in
  // alphabetical order as argument, and return the result as a list. Use E as
  // the field in the generated code, using the given conversion method.
  def synthetizeToFile (scalaHeaders: String, outputDir: String,
                        objectName: String, packageName: String,
                        methodName: String, filename: String): Unit = {
    
    import trees.ScalaCode._

    val (variables, formula, maximize, pre, code, parameters) = synthetize
    println ("DEBUG: parameters: " + parameters)
    println ("Pre-condition: " + pre)

    // Check the pre-condition
    val codeWithPre = {
      SimpleAST.If (pre.toSimpleExpr,
                    code,
                    ErrorRes ("Pre-condition not satisfied"))
    }

    val (scalaCode, scalaDecl) = toScala (method.simplexSolver,
                                          parameters.map (v => SimpleAST.Identifier (v.name)), codeWithPre, convert)
    
      
    println ("DEBUG: Code follows")
    println (Block (scalaDecl :+ scalaCode))
    val outputFile = outputDir + "/" + filename
    val out = new java.io.FileWriter (outputFile)
    val nl = System.getProperty ("line.separator")
    if (!packageName.isEmpty)
      out.write ("package " + packageName ++ nl ++ nl)
    
    out.write (scalaHeaders ++ nl ++ nl)
    out.write ("/*" ++ nl)
    out.write ("Variables: " + variables.toString ++ nl)
    out.write ("Original constraints: " + formula.toString ++ nl)
    out.write ("Maximize: " + maximize.toString ++ nl)
    out.write ("Parameters: " + parameters.toString ++ nl)
    out.write ("Pre-condition: " + pre.toString ++ nl)
    out.write ("*/" ++ nl ++ nl)
    out.write ("object " ++ objectName ++ " {" ++ nl)

    out.write (scalaDecl.map (d => d.toString).mkString (nl))
    out.write (nl ++ nl)
    
    val parNames = parameters.map (v => v.name).toList.sorted
    val parStr = parNames.map (el => el ++ " : " ++ outField.getType.toString).mkString (", ")

    out.write ("def " ++ methodName ++ " (" ++ parStr ++ ") : " ++
               "List[" ++ outField.getType.toString ++ "] = " ++ nl)
    out.write (scalaCode.toString ++ nl ++ nl)
    out.write ("def main (args: Array[String])" ++ nl)

    // Read parameters in alphabetical order
    val parVals = {
      parNames.map (name => {
        Val (Identifier (name), DotExpr (outField.zero.toScalaCode,
					 Identifier ("fromString"),
					 List (Apply (Identifier ("Console.readLine"),
						      List (StringLit ("Please enter " +
								       name + " : "))))))
      })
    }

    val setComparisonFailure =
      Assign (Identifier ("smartfloats.tools.AffineForm.printComparisonFailure"),
	      True)
    val resList = uniqueIdentifier ("resList")
    val timeStart = uniqueIdentifier ("tstart")
    val timeEnd = uniqueIdentifier ("tend")
    val timeStartVal = Val (timeStart, Apply (Identifier ("System.currentTimeMillis"),
                       List ()))
    val timeEndVal = Val (timeEnd, Apply (Identifier ("System.currentTimeMillis"),
                       List ()))

    val printTime = Apply (Identifier ("println"),
                           List (Plus (StringLit ("Total time: " ),
                                       Plus (Minus (timeEnd, timeStart),
                                             StringLit (" ms")))))

    val resVal = Val (resList, Apply (Identifier (methodName),
                                      parNames.map (v => Identifier (v))),
                                      Some (Type ("List[" ++ outField.getType.toString  ++ "]")))
    
    val printResult = Block (parVals ++ List (setComparisonFailure, timeStartVal, resVal,
                                              timeEndVal, printTime,
                                              Apply (Identifier ("println"), List (resList))))
    
    out.write (printResult.toString ++ nl)
    out.write ("}" ++ nl)
    out.close
  }
}

object LASynthetizer {
  def apply[D <: ExpressibleOrderedField[D]] (fileName: String, method: LASynthesisMethod[D]): LASynthetizer[D,D] = {
    LASynthetizer (fileName, method, (el:D) => el)
  }
  def apply[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]] (fileName: String, method: LASynthesisMethod[D], convert: D => E): LASynthetizer[D,E] = {
    new LASynthetizer (fileName, method, convert, None)
  }
  def apply[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]] (method: LASynthesisMethod[D], convert: D => E, variables: Seq[Variable], formula: LAFormula[D], maximize: Option[LinearCombination[D]]): LASynthetizer[D,E] = {
    new LASynthetizer ("", method, convert, Some ((variables, formula, maximize)))
  }
}

