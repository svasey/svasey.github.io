package choosec
package synthesis

// Thrown in the synthetized code when there is no solution
class NoSolutionException (msg: String) extends Exception (msg) {
}
