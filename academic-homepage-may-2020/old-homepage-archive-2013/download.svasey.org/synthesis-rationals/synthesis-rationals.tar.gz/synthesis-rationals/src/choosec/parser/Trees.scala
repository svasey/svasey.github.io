package choosec
package parser
 
object Trees {
  import trees.Formulas.QuantifierType
  sealed trait Tree extends Positional

  case class RChoose (variables: List[Identifier], maximize: Option[ExprTree],
                      formula: ExprTree) extends Tree

  // Any expression including identifiers and the like. Much later on, it will
  // be determined whether this corresponds to an arithmetic expression /
  // formula, etc...
  sealed trait ExprTree extends Tree

  case class Identifier (value: String) extends ExprTree
  case class IntLit (num: BigInt) extends ExprTree
  case class Plus (lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case class Minus (lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case class Times (lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case class Divides (lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case class Quantifier (quantType: QuantifierType, variable: Identifier, expr: ExprTree) extends ExprTree
  case class And (lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case class Or(lhs: ExprTree, rhs: ExprTree) extends ExprTree 
  case class Not (expr: ExprTree) extends ExprTree
  case class Equals (lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case class LessThan(lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case class LessThanEq(lhs: ExprTree, rhs: ExprTree) extends ExprTree
  case object True extends ExprTree
  case object False extends ExprTree
}
