package choosec
package code

import SimpleAST._
import SimpleSymbols._
import SimpleType._

import scala.annotation.tailrec

import numbers._

object Optimization {

  // def setPossibleResults (expr: SimpleExpr): SimpleExpr = {
  //   def union (exprs: Seq[SimpleExpr]): Set[Result] =
  //     exprs.foldLeft (Set[Result] ()) ((s, e) => s ++ e.getPossibleRes)

  //   expr match {
  //     case If (cond, then, els) => 
  //       expr.setPossibleRes (then.getPossibleRes ++ els.getPossibleRes)
  //     case Max (exprs) =>
  // 	expr.setPossibleRes (union (exprs))
  //     case Min (exprs) =>
  // 	expr.setPossibleRes (union (exprs))
  //     case r @ CallSolver (_, _, _, _, _, _, _) => expr.setPossibleRes (r)
  //     case r @ MaximizedRes (_, _) => expr.setPossibleRes (r)
  //     case r @ BoundedRes (_) => expr.setPossibleRes (r)
  //     case r @ ErrorRes (_) => expr.setPossibleRes (r)
  //     case r @ UnboundedRes => expr.setPossibleRes (r)
  //     case r @ UnfeasibleRes => expr.setPossibleRes (r)
  //     case SetBound (res, _) => expr.setPossibleRes (res.getPossibleRes)
  //     case MultiplySol (res, _) => expr.setPossibleRes (res.getPossibleRes)
  //     case Block (vals, ret) => expr.setPossibleRes (ret.getPossibleRes)
  //     case _ => expr
  //   }
  // }

  // Ugly hack to have some global overview of the possible results an
  // identifier can take.
  private var global_possibleResults: Map[Symbol, Set[Result]] = Map ()

  def updateIDRes (vals: Seq[Val], possibleRes: Map[Symbol, Set[Result]]): Map[Symbol, Set[Result]] = {
    if (vals.isEmpty)
      possibleRes
    else {
      val poss = getPossibleResults (vals.head.expr, possibleRes)
      updateIDRes (vals.tail, possibleRes + ((vals.head.id.getSymbol, poss)))
    }
  }
  def getPossibleResults (expr: SimpleExpr, possibleRes: Map[Symbol, Set[Result]]): Set[Result] = {
    def rec (exp: SimpleExpr, idres: Map[Symbol, Set[Result]]): Set[Result] = {
      def union (exprs: Seq[SimpleExpr]): Set[Result] =
	exprs.foldLeft (Set[Result] ()) ((s, e) => s ++ rec (e, idres))

      exp match {
	case If (_, then, els) => rec (then, idres) ++ rec (els, idres)
	case Max (exprs) => union (exprs)
	case Min (exprs) => union (exprs)
	case r: Result => Set (r)
	case SetBound (res, _) => rec (res, idres)
	case MultiplySol (res, _) => rec (res, idres)
	case id @ Identifier (_) => {
	  if (id.getType != TResult) Set () // Avoid e.g external variables
	  else {
	    assert (idres.contains (id.getSymbol), "idres does " +
		    "not contain " + id + " with symbol " + id.getSymbol + " idres: " + idres)
	    
	    idres (id.getSymbol)
	  }
	}
	case Block (vals, ret) => {
	  val newPoss = updateIDRes (vals, idres)
	  rec (ret, newPoss)
	}
	case _ => Set ()
      }
    }
    rec (expr, possibleRes)
  }

  // Return true if we can directly return the results as lists, and not as
  // LPResult objects. This happens intuitively if we are not composing the
  // results or manipulating them in some way.
  def useListOutput (expr: SimpleExpr): Boolean = {
    // Identifiers that are in the set can be returned and list output can be used. 
    def rec (exp: SimpleExpr, useList: Set[Symbol]): Boolean = exp match {
      case If (_, then, els) => rec (then, useList) && rec (els, useList)
      case CallSolver (_, _, _, _, _, _, _) => false
      case Max (exprs) => exprs.head.getType != TResult
      case Min (exprs) => exprs.head.getType != TResult
      case Block (vals, ret) => {
	if (vals.isEmpty)
	  rec (ret, useList)
	else {
	  val v = vals.head
	  val poss = getPossibleResults (v.expr, global_possibleResults)
	  global_possibleResults = global_possibleResults + ((v.id.getSymbol,
							      poss))
	  val newUseList = {
	    if (poss.forall (_ match {
	      case MaximizedRes (_, _) | ErrorRes (_) => true
	      case _ => false
	    }))
	      useList + v.id.getSymbol
	    else
	      useList
	  }
	  rec (Block (vals.tail, ret), newUseList)
	}
      }
      case id @ Identifier (_) => useList.contains (id.getSymbol)
      case Plus (_, _) | Minus (_, _) | Times (_, _) | UpTo (_, _) | Lt (_, _) 
	| LtEq (_, _) | Eq (_, _) | And (_, _) | Or (_, _) | Not (_) | True | False
	| ErrorRes (_) | MaximizedRes (_, _) | BoundedRes (_) | UnboundedRes | UnfeasibleRes
	| IsFeasible (_) | HasSolution (_) | GetSolution (_, _) | SetBound (_, _)
	| MultiplySol (_,_) | GetBound (_) | FieldEl (_) => true
    }
    rec (expr, Set ())
  }

  // Do some simple transformation so that the expression is ready to be outputed 
  def transformForListOutput (expr: SimpleExpr, constEl: SimpleExpr): SimpleExpr = expr match {
    case If (cond, then, els) => If (cond, transformForListOutput (then, constEl),
				     transformForListOutput (els, constEl)).copyType (expr)
    case MaximizedRes (sol, bound) => MaximizedRes (sol, constEl).copyType (expr)
    case BoundedRes (_) => ErrorRes ("Problem is feasible and bounded but has no maximum").copyType (expr)
    case UnboundedRes => ErrorRes ("Problem is feasible but unbounded").copyType (expr)
    case UnfeasibleRes => ErrorRes ("Problem is unfeasible").copyType (expr)
    case SetBound (res, _) => transformForListOutput (res, constEl)
    case Block (vals, ret) => 
      Block (vals, transformForListOutput (ret, constEl)).copyType (expr)
    case _ => expr
  }
  
  def getAllID (exprs: Traversable[SimpleExpr]): Set[Identifier] =
    exprs.foldLeft (Set[Identifier] ()) ((s, e) => s ++ getAllID (e))
  
  def getAllID (e: SimpleExpr*): Set[Identifier] =
    getAllID (e)
  
  // Return the set of all identifiers used in the given expression
  def getAllID (expr: SimpleExpr): Set[Identifier] = expr match {
    case If (cond, then, els) => getAllID (cond, then, els)
    case Plus (lhs, rhs) => getAllID (lhs, rhs)
    case Minus (lhs, rhs) => getAllID (lhs, rhs)
    case Times (lhs, rhs) => getAllID (lhs, rhs)
    // case DividedBy (lhs, rhs) => getAllID (lhs, rhs)
    case Max (exprs) => getAllID (exprs)
    case Min (exprs) => getAllID (exprs)
    case UpTo (from, to) => getAllID (from, to)
    case Lt (lhs, rhs) => getAllID (lhs, rhs)
    case LtEq (lhs, rhs) => getAllID (lhs, rhs)
    case Eq (lhs, rhs) => getAllID (lhs, rhs)
    case And (lhs, rhs) => getAllID (lhs, rhs)
    case Or (lhs, rhs) => getAllID (lhs, rhs)
    case Not (e) => getAllID (e)
    case CallSolver (_, _, _, _, _, _, bound) => getAllID (bound)
    case MaximizedRes (sol, bound) => getAllID (sol) ++ getAllID (bound)
    case BoundedRes (bound)=> getAllID (bound)
    case IsFeasible (res) => getAllID (res)
    case HasSolution (res) => getAllID (res)
    case GetSolution (res, _) => getAllID (res)
    case SetBound (res, _) => getAllID (res)
    case MultiplySol (res, _) => getAllID (res)
    case GetBound (res) => getAllID (res)
    case id @ Identifier (_) => Set (id)
    case Block (vals, ret) => getAllID (vals.map (v => v.expr)) ++ getAllID (ret)
    case True | False | ErrorRes (_) | UnboundedRes | UnfeasibleRes |
      FieldEl (_) => Set ()
  }

  def getAllSymbols (expr: SimpleExpr): Set[Symbol] =
    getAllID (expr).map (id => id.getSymbol)

  // Simplify boolean formula and remove dead branches, e.g expression of the
  // form if(false) ...
  // Also set the possible results it can return (if it returns a result).
  def removeDeadBranches (expr: SimpleExpr): SimpleExpr = {
    runTransform (removeDeadBranches0, expr)
  }

  def removeDeadBranches0 (expr: SimpleExpr): SimpleExpr = expr match {
    case If (cond, then, els) => {
      if (cond == True) then
      else if (cond == False) els
      else If (cond, then, els)
    }
    
    case Block (vals, ret) => {
      // Remove useless vals
      val usedSymbols = getAllSymbols (ret)
      val valSymbols = vals.map ((v:Val) => (v, getAllSymbols (v.expr))).toMap
      // println ("DEBUG: used identifiers for block: " + Block (vals, ret))
      // println ("DEBUG: val: " + newVals.map (v => getAllID (v.expr)))
      // println ("DEBUG: used: " + getAllID (ret))
      // Remove unused Val declaration from the list
      def removeUnused (decls: Seq[Val]): Seq[Val] = {
        if (decls.isEmpty){
          decls
        }
        else {
          val head = decls.head
          val headSymbol = head.id.getSymbol
          val tail = removeUnused (decls.tail)
          if (usedSymbols.contains (headSymbol) ||
              tail.exists ((v:Val) => valSymbols (v).contains (headSymbol)))
            head +: tail
          else
            tail
        }
      }
      
      Block (removeUnused (vals), ret)
    }
    case e @ _ => e
  }

  // Compute symbolic expressions, e.g if 2*x + x appears in an expression,
  // replace it with 3 * x .
  def doSymbolicComputations[D <: ExpressibleOrderedField[D]] (field: D) (expr: SimpleExpr): SimpleExpr = {
    import trees.Formulas.LinearCombination
    import trees.Formulas.LAFormula
    import trees.FormulaTransforms._
    import trees.Formulas

    def binToLComb (lhs: SimpleExpr, rhs: SimpleExpr, combine: (LinearCombination[D], LinearCombination[D]) => Option[LinearCombination[D]]): Option[LinearCombination[D]] = {
      lazy val lcLhs = toLComb (lhs)
      lazy val lcRhs = toLComb (rhs)

      if (lcLhs.isEmpty || lcRhs.isEmpty)
	None
      else
	combine (lcLhs.get, lcRhs.get)
    }
  
    def toLComb (e: SimpleExpr): Option[LinearCombination[D]] = {
      require (e.getType == TField)
      e match {
	case Plus (lhs, rhs) => 
	  binToLComb (lhs, rhs, (a, b) => Some (a.add (b)))
	case Minus (lhs, rhs) =>
	  binToLComb (lhs, rhs, (a,b) => Some (a.subtract (b)))
	case Times (lhs, rhs) => 
	  binToLComb (lhs, rhs, (a,b) => a.times (b))
	case FieldEl (value) =>
	  Some (LinearCombination[D] (value.asInstanceOf[D]))
	case Identifier (name) =>
	  Some (LinearCombination[D] (Formulas.Variable (name), field.one))
	// UpTo may be replaced by (lhs + rhs) / 2, but this may create other
	// problems with e.g unexact fields, and that may also make e.g rational
	// numbers grow large.
	case UpTo (lhs, rhs) =>
	  binToLComb (lhs, rhs, (a, b) => if (a.equals (b)) Some (a) else None)
	case If (_, _, _) | Max (_) | Min (_) | GetSolution (_, _) |
	  GetBound (_) | Block (_, _) => None
	case _ => error ("Wrong type for expression " + e + " (should NOT be TField)")
      }
    }
    
    def binLCToLFormula (lhs: SimpleExpr, rhs: SimpleExpr, combine: (LinearCombination[D], LinearCombination[D]) => Option[LAFormula[D]]): Option[LAFormula[D]] = {
      lazy val newLhs = toLComb (lhs)
      lazy val newRhs = toLComb (rhs)
      if (newLhs.isEmpty || newRhs.isEmpty)
	None
      else
	combine (newLhs.get, newRhs.get)
    }
    def binLFormula (lhs: SimpleExpr, rhs: SimpleExpr, combine: (LAFormula[D], LAFormula[D]) => Option[LAFormula[D]]): Option[LAFormula[D]] = {
      lazy val newLhs = toLFormula (lhs)
      lazy val newRhs = toLFormula (rhs)
      if (newLhs.isEmpty || newRhs.isEmpty)
	None
      else
	combine (newLhs.get, newRhs.get)
    }
    def toLFormula (e: SimpleExpr): Option[LAFormula[D]] = {
      require (e.getType == TBool)
      e match {
	case Lt (lhs, rhs) =>
	  binLCToLFormula (lhs, rhs, (a,b) => Some (Formulas.Rel (Formulas.Lt (a, b))))
	case LtEq (lhs, rhs) =>
	  binLCToLFormula (lhs, rhs, (a,b) => Some (Formulas.Rel (Formulas.LtEqual (a, b))))
	case Eq (lhs, rhs) =>
	  binLCToLFormula (lhs, rhs, (a,b) => Some (Formulas.Rel (Formulas.Equals (a, b))))
	case And (lhs, rhs) =>
	  binLFormula (lhs, rhs, (a,b) => Some (Formulas.And (a, b)))
	case Or (lhs, rhs) =>
	  binLFormula (lhs, rhs, (a,b) => Some (Formulas.Or (a, b)))
	case Not (r) => {
	  val newR = toLFormula (r)
	  if (newR.isEmpty)
	    None
	  else
	    Some (Formulas.Not (newR.get))
	}
	case True => Some (Formulas.Rel (Formulas.True))
	case False => Some (Formulas.Rel (Formulas.False))
	case If (_, _, _) | IsFeasible (_) | HasSolution (_) | Identifier (_) |
	  Block (_, _) => None
	case _ => error ("Wrong type for expression " + e + " (should NOT be TBool)")
      }
    }
    
    expr.getType match {
      case TResult => expr.recTransform (doSymbolicComputations (field))
      case TBool => toLFormula (expr) match {
	case Some (form) => {
	  val simplified = LAsimplify (form).toSimpleExpr
	  // val simplified = form.toSimpleExpr
	  val allSyms = getAllSymbols (expr)
	  val scope = allSyms.map (sym => (sym.name, sym)).toMap
	  attachSymbols (scope, simplified)
	  typecheck (simplified, TBool)
	  simplified
	}
	case None => expr.recTransform (doSymbolicComputations (field))
      }
      case TField => toLComb (expr) match {
	// The symbolic computations have already been done when constructing
	// the linear combination object
	case Some (lc) => {
	  val simplified = lc.toSimpleExpr
	  val allSyms = getAllSymbols (expr)
	  val scope = allSyms.map (sym => (sym.name, sym)).toMap
	  attachSymbols (scope, simplified)
	  typecheck (simplified, TField)
	  simplified
	}
	case None => expr.recTransform (doSymbolicComputations (field))
      }
      case _ => error ("Unexpected expression type: " + expr.getType)
    }
  }
  // Simply compute constant expressions, but do not propagate them
  def constantFolding[D <: ExpressibleOrderedField[D]] (expr: SimpleExpr): SimpleExpr = {
    def arithPlus (lhs: SimpleExpr, rhs: SimpleExpr): Option[SimpleExpr] = {
      lhs match {
	case FieldEl (v) => if (v.asInstanceOf[D].isZero) Some (rhs) else None
	case _ => {
	  rhs match {
	    case FieldEl (v) => if (v.asInstanceOf[D].isZero) Some (lhs) else None
	    case _ => None
	  }
	}
      }
    }
    def minMax (isMaximum: Boolean, exprs:Seq[SimpleExpr]): SimpleExpr = {
      assert (!exprs.isEmpty)
      if (exprs.tail.isEmpty)
	exprs.head
      else if (exprs.head.getType == TField){
	val (constants, nonConstants) = exprs.partition (e => e match { case FieldEl (_) => true;
								       case _ => false })
	if (constants.isEmpty)
	  if (isMaximum) Max (exprs) else Min (exprs)
	else if (isMaximum){
	  val newMax = constants.map (e => e.asInstanceOf[FieldEl[D]].value).max
	  if (nonConstants.isEmpty)
	    FieldEl (newMax).setType (TField)
	  else
	    Max (FieldEl (newMax).setType (TField) +: nonConstants)
	}
	else {
	  val newMin = constants.map (e => e.asInstanceOf[FieldEl[D]].value).min
	  if (nonConstants.isEmpty)
	    FieldEl (newMin).setType (TField)
	  else
	    Min (FieldEl (newMin).setType (TField) +: nonConstants)
	}
      }
      else {
	assert (exprs.head.getType == TResult)
	assert (isMaximum)
	
	if (exprs.exists (e => e == UnboundedRes))
	  UnboundedRes
	else {
	  val newExprs = exprs.filter (e => e != UnfeasibleRes)
	  if (newExprs.isEmpty) UnfeasibleRes
	  else if (newExprs.tail.isEmpty) newExprs.head
	  // FIXME: one can do better
	  else Max (newExprs)
	}
      }
    }



    def postTransf (exp: SimpleExpr): SimpleExpr = exp match {
      case Plus (lhs @ FieldEl (v1), rhs @ FieldEl (v2)) => 
	FieldEl (v1.asInstanceOf[D] + v2.asInstanceOf[D])
      case Plus (lhs, rhs) =>
	arithPlus (lhs, rhs).getOrElse (exp)
      case Minus (lhs @ FieldEl (v1), rhs @ FieldEl (v2)) =>
	FieldEl (v1.asInstanceOf[D] - v2.asInstanceOf[D])
      case Minus (lhs, rhs) =>
	arithPlus (lhs, rhs).getOrElse (exp)
      case Times (lhs @ FieldEl (v1), rhs @ FieldEl (v2)) =>
	FieldEl (v1.asInstanceOf[D] * v2.asInstanceOf[D])
      case Times (lhs, rhs) => lhs match {
	case FieldEl (v) => {
	  if (v.asInstanceOf[D].isZero) lhs
	  else if (v.asInstanceOf[D].isOne) rhs
	  else exp
	}
	case _ => rhs match {
	  case FieldEl (v) => postTransf (Times (rhs, lhs))
	  case _ => exp
	}
      }
      case Max (exprs) => minMax (true, exprs)
      case Min (exprs) => minMax (false, exprs)
      case UpTo (lhs @ FieldEl (v1), rhs @ FieldEl (v2)) =>
	FieldEl (v1.asInstanceOf[D].upTo (v2.asInstanceOf[D]))
      case Lt (lhs @ FieldEl (v1), rhs @ FieldEl (v2)) =>
	fromBoolean (v1.asInstanceOf[D] < v2.asInstanceOf[D])
      case LtEq (lhs @ FieldEl (v1), rhs @ FieldEl (v2)) =>
	fromBoolean (v1.asInstanceOf[D] <= v2.asInstanceOf[D])
      case Eq (lhs @ FieldEl (v1), rhs @ FieldEl (v2)) =>
	fromBoolean (v1.asInstanceOf[D] == v2.asInstanceOf[D])
      case And (lhs, rhs) => {
	if (lhs == False || rhs == False) False
	else if (lhs == True) rhs
	else if (rhs == True) lhs
	else exp
      }
      case Or (lhs, rhs) => {
	if (lhs == True || rhs == True) True
	else if (lhs == False) rhs
	else if (rhs == False) lhs
	else exp
      }
      case Not (e) => {
	if (e == True) False
	else if (e == False) True
	else exp
      }

      case IsFeasible (res) => {
	val possibleRes = getPossibleResults (res, global_possibleResults)
	assert (!possibleRes.isEmpty)
	if (possibleRes.forall (_ match {
	  case UnfeasibleRes | ErrorRes (_) => true
	  case _ => false
	})){
	  False
	}
	else if (possibleRes.forall (_ match {
	  case MaximizedRes (_, _) | BoundedRes (_) | ErrorRes (_) |
	  UnboundedRes => true
	  case _ => false
	})){
	  True
	}
	else {
	  IsFeasible (res)
	}
      }
      
      case HasSolution (res) => {
	val possibleRes = getPossibleResults (res, global_possibleResults)
	assert (!possibleRes.isEmpty)
	if (possibleRes.forall (_ match {
	  case MaximizedRes (_, _) | ErrorRes (_) => true
	  case _ => false
	})){
	  True
	}
	else if (possibleRes.forall (_ match {
	  case BoundedRes (_) | ErrorRes (_) | UnboundedRes | UnfeasibleRes => true
	  case _ => false
	})){
	  False
	}
	else {
	  HasSolution (res)
	}
      }
      
      case GetSolution (res, id) => {
	res match {
	  case MaximizedRes (sol, _) => sol.apply (id - 1)
	  case _ => exp
	}
      }
      case GetBound (res) => {
	res match {
	  case MaximizedRes (_, bound) => bound
	  case BoundedRes (bound) => bound
	  case _ => exp
	}
      }
      case SetBound (res, maximize) => {
	if (maximize.isIdentity)
	  res
	else
	  exp
      }
      case _ => exp
    }
    def preTransf (exp: SimpleExpr): SimpleExpr = exp match {
      case bl @ Block (vals, ret) => {
	global_possibleResults = updateIDRes (vals, global_possibleResults)
	exp
      }
      case _ => exp
    }
    
    runTransform (preTransf, postTransf, expr)
  }

  // Just propagate the constants but do not fold the expressions
  def propagate (expr: SimpleExpr): SimpleExpr = {
    def propag (exp: SimpleExpr): SimpleExpr = exp match {
      case Block (vals, ret) => {
	val toPropagate = vals.filter (v => {
	  v.expr match {
	    case FieldEl (_) | Identifier (_) | True | False | MaximizedRes (_, _) | BoundedRes (_) |
	      ErrorRes (_) | UnboundedRes | UnfeasibleRes => true
	    case _ => false
	  }
	})
	def propagateVal (v: Val, decls: Seq[Val]): Seq[Val] = {
	  decls.map (d => Val (d.id, replaceIdentifier (v.id, v.expr, d.expr),
			       d.typ, d.useLazy))
	}
	val newVals = toPropagate.foldLeft (vals) ((decls, v) => propagateVal
						   (v, decls))
	val newRet = toPropagate.foldLeft (ret) ((r, v) =>
	  replaceIdentifier (v.id, v.expr, r))

	// If the node to be returned is a single identifier, also propagate its
	// expression. 
	val newRet2 = {
	  newRet match {
	    case id @ Identifier (_) => {
	      newVals.find (el => el.id.getSymbol == id.getSymbol) match {
		case Some (v) => v.expr
		case None => newRet
	      }
	    }
	    case _ => newRet
	  }
	}

	Block (newVals, newRet2)
	
      }
      case _ => exp
    }
    runTransform (propag, expr)
  }
  
  def constantPropagation (expr: SimpleExpr): SimpleExpr = {


    def foldPropag (exp: SimpleExpr): SimpleExpr = {
      propagate (fixpoint (constantFolding, exp))
    }

    fixpoint (foldPropag, expr)
  }

  // Run f until a fixed-point is reached, or until `maxTime` milliseconds have
  // elapsed. By default, the method is run for an unlimited amount of time.
  @tailrec
  def fixpoint[A] (f: A => A, start: A, maxTime: Long = -1, startTime: Long = -1): A = {
    val t0 = {
      if (maxTime != -1 && startTime == -1)
	System.currentTimeMillis
      else
	startTime
    }
    val t2 = System.currentTimeMillis
    if (maxTime != -1 && t2 - t0 > maxTime)
      start
    else {
      val next = f (start)
      if (next == start) start else fixpoint (f, next, maxTime, t0)
    }
  }
}
