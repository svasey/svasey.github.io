package choosec
package numbers

// Simple program to test the upTo function for rationals
  
object UpToTest {
  def ceil (n: BigInt, m: BigInt): BigInt = {
    val (d, mod) = n /% m
    if (mod == 0)
      d
    else
      d + 1
  }
  
  def test (low: Rational, up: Rational): Unit = {
    require (Rational.zero <= low && low < up)
    val lowerBound = (low.denum + up.denum) / (up.num * low.denum - low.num *
                                               up.denum)
    val upperBound = ceil (low.denum * up.denum + low.denum + up.denum,
                           up.num * low.denum - low.num * up.denum)
    val lowerP = ceil (low.num * lowerBound + 1, low.denum)
    val upperP = ceil (low.num * upperBound + 1, low.denum)

    val res = low.upTo (up)
    println ("Lower bound: " + lowerP + "/" + lowerBound)
    println ("Result: " + res)
    println ("Upper bound: " + upperP + "/" + upperBound)
  }

  def search (limit: BigInt): Unit = {
    def testList (xs: List[Rational]): Unit = {
      require (!xs.isEmpty)
      xs.tail.foreach (x => {
        if (x < xs.head)
          test (x, xs.head)
        else
          test (xs.head, x)
      })
    }
    def constructNext (xs: List[Rational]): List[Rational] = {
      require (!xs.isEmpty)
      def next (num: BigInt): Rational = {
        if (num >= xs.head.denum)
          Rational (1, xs.head.denum + 1)
        else if (num.gcd (xs.head.denum) == 1)
          Rational (num, xs.head.denum)
        else 
          next (num + 1)
      }
      next (xs.head.num + 1) :: xs
    }
    def iter (xs: List[Rational]): Unit = {
      if (xs.head.denum > limit)
        return
      else {
        testList (xs)
        iter (constructNext (xs))
      }
    }
    iter (List (Rational.one))
  }
}
