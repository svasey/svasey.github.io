package choosec
package synthesis

import simplex._
import simplex.MultiparametricLP._
import numbers._
import trees.Constraint._
import trees.Formulas._
import code.SimpleAST
import code.SimpleAST.SimpleExpr
import code.SimpleAST.uniqueID
import code.SimpleAST.Val
import code.SimpleAST.Block
import code.SimpleAST.If
import code.SimpleAST.UnfeasibleRes
import code.SimpleAST.HasSolution
import code.SimpleAST.BoundedRes
import code.SimpleAST.FieldEl
import code.SimpleAST.GetBound
import code.SimpleAST.MaximizedRes
import code.SimpleAST.GetSolution
import code.SimpleType._


class MultiparametricSynthesis[D <: ExpressibleOrderedField[D]] (mpSolver: MultiparametricSolver[D]) extends MixedSynthesis[D] (mpSolver.simplexSolver.field, mpSolver.simplexSolver.matrix, mpSolver.simplexSolver)
{
  override def FMOrSimplex (problem: FRProblem[D]): (LAFormula[D], SimpleExpr) = problem match {
    case FRProblem (constr, _, maximize, _, _, _, allVariables) => {
      // println ("DEBUG: problem:\n" + problem)

      if (constr.constrMatrix.isZero){
	// We are in the very special zero-matrix case: delegate it to above
	super.FMOrSimplex (problem)
      }
      else {
	// We suppose we have already done Gaussian elimination beforehand, and
	// that there are still parameters to be eliminated.	
	require (constr.nEq == 0 && constr.boundMatrix.nCols >= 2)
	val constrMatrix = constr.constrMatrix
	val nStrict = constr.constrMatrix.nLines - constr.nNonStrict
	val boundShift = constr.boundMatrix.getCol (1)
	val parameterMatrix = constr.boundMatrix.getCols (2, constr.boundMatrix.nCols)
	val parameters = constr.parameters.map (v => SimpleAST.Identifier (v.name))
	
	  
	lazy val pair = {
          mpSolver.solve (constrMatrix, maximize, boundShift, parameterMatrix).synthetize (parameters)
	}
	lazy val relaxedPre = pair._1
	lazy val relaxedCode = pair._2

	if (nStrict == 0)
	  (relaxedPre, relaxedCode)
	else {
	  val solv = solver.init (constrMatrix, maximize, boundShift)
	  val feasibleSolver = solv.strictIneqFeasibleSolver (constr.nNonStrict)
	  val newBoundShift = {
	    val toAppend = feasibleSolver.bound.getLines (boundShift.nLines + 1,
							  feasibleSolver.bound.nLines)
	    boundShift.appendBottom (toAppend)
	  }
	  val newParameterMatrix = {
	    val toAppend =
	      newBoundShift.zero (newBoundShift.nLines - parameterMatrix.nLines,
				  parameterMatrix.nCols)
	    parameterMatrix.appendBottom (toAppend)
	  }
	  lazy val feasibleSolverCR = mpSolver.solve (feasibleSolver.matrix,
						 feasibleSolver.maximize,
						 newBoundShift, newParameterMatrix)
	  lazy val pair2 = feasibleSolverCR.synthetize (parameters)
	  lazy val feasiblePre = pair2._1
	  lazy val feasibleCode = pair2._2

	  def synthFeasible: SimpleExpr = {
	    val feasRes = uniqueID ("feasRes")
	    val feasVal = Val (feasRes, feasibleCode, TResult)
	    val code = {
	      // We can assume the pre-condition is true, so the problem will be
	      // feasible and bounded.
	      If (SimpleAST.Lt (FieldEl (field.zero), GetBound (feasRes)),
		  MaximizedRes (List.tabulate (constrMatrix.nCols) (n => GetSolution (feasRes, n + 1)),
				FieldEl (field.zero)),
		  UnfeasibleRes)
	    }

	    Block (feasVal, code)
	  }
	  if (maximize.isZero){
	    val pre = And (feasiblePre, Unknown ())
	    (pre, synthFeasible)
	  }
	  else {
	    val lubParam = uniqueID ("lub")
	    val newParameters = parameters :+ lubParam
	    val newBoundShift2 = newBoundShift.appendBottom (boundShift.zero (1))
	    val newParameterMatrix2 = {
	      val appendRight = boundShift.zero (newParameterMatrix.nLines, 1)
	      val appendBottom = boundShift.zero (1, newParameterMatrix.nCols).appendRight (boundShift.identity (1).negate)
	      newParameterMatrix.appendRight (appendRight).appendBottom (appendBottom)
	    }
	    
	    val maxSolver = solv.strictIneqMaximizeSolver (constr.nNonStrict,
							   field.zero, feasibleSolver)
	    val maxSolverCR = mpSolver.solve (maxSolver.matrix, maxSolver.maximize,
					      newBoundShift2, newParameterMatrix2)
	    val (_, maxCode) = maxSolverCR.synthetize (newParameters)
	    // maxPre should say exactly the same thing as relaxedPre
	    val pre = And (Unknown (), relaxedPre)
	    val relaxedRes = uniqueID ("relaxedRes")
	    val relaxedVal = Val (relaxedRes, relaxedCode, TResult)
	    val lubVal = Val (lubParam, GetBound (relaxedRes), TField)
	    val maxRes = uniqueID ("maxRes")
	    val maxVal = Val (maxRes, maxCode, TResult)

	    val checkFeas = {
	      val feasRes = uniqueID ("feasRes")
	      val feasVal = Val (feasRes, synthFeasible, TResult)
	      Block (feasVal,
		     If (HasSolution (feasRes),
			 BoundedRes (lubParam),
			 UnfeasibleRes))
	    }
  
	    val code = {
	      If (SimpleAST.Lt (FieldEl (field.zero), GetBound (maxRes)),
		  MaximizedRes (List.tabulate (constrMatrix.nCols) (n => GetSolution (maxRes, n + 1)),
				lubParam),
		  checkFeas)
	    }
	    (pre, Block (List (relaxedVal, lubVal, maxVal), code))
	  }
	}
      }
    }
  }
}
