package choosec
package trees

import Formulas._
import FormulaTransforms._
import numbers._
import simplex._
import code.SimpleAST.SimpleExpr
import code.SimpleAST.Block
import code.SimpleAST.Val
import code.SimpleAST.uniqueID

object Constraint {
  // Represent a conjunction, of the form `phi && Ax <= b && Bx < d && Cx == e
  // where `phi` does not contain any of the variables in `x`.  `constrMatrix`
  // begins with `nEq` lines representing equalities, then follow `nNonStrict`
  // lines representing non-strict inequalities, and the rest is strict
  // inequalities. `boundMatrix` gives a linear combination of the parameters
  // making up the bound. The linear combination is obtained by taking the
  // product of the bound matrix with the vector [1 a1 a2 ... ak]^T, where the
  // matrix has k + 1 columns and m lines, and {a1, ..., ak} are the parameters,
  // i.e the first column contains the constant term.
  case class Constraints[D <: ExpressibleOrderedField[D]]
  (withoutVariables:LAFormula[D], constrMatrix: Matrix[D], nEq: Int,
   nNonStrict: Int, boundMatrix: Matrix[D], variables: Seq[Variable],
   parameters: List[Variable])
  {
    override def toString: String = {
      "Variables: " + variables.toString + "\n" +
      "Parameters: " + parameters.toString + "\n" + 
      "Pre-condition: " + withoutVariables.toString + "\n" + 
      "Constraint matrix:\n" + constrMatrix.toString + "\n" + 
      "Number of equalities: " + nEq + "\n" + 
      "Number of non-strict inequalities: " + nNonStrict + "\n" + 
      "Bound matrix:\n" + boundMatrix
    }

    // The constraint is equivalent to a formula of the form phi && Ax <= b && A'x
    // < b', where phi does not contain any variable in `variables`. Return (phi,
    // A, b, A', b'), in that order. If A is zero, return A = None, b = None;
    // same thing for A', b' . If phi is `true`, also return None.
    def toOldCanonicalForm:(Option[LAFormula[D]], Option[Matrix[D]], Option[List[LinearCombination[D]]],
			    Option[Matrix[D]], Option[List[LinearCombination[D]]]) = {
      val phi = if (withoutVariables == Rel (True)) None else Some (withoutVariables)
      // Bound as a linear combination of the parameters
      val (ineqMatrix, newNNonStrict, ineqBound) = ineqMatrixWithBound
      if (ineqMatrix.isZero){
	(phi, None, None, None, None)
      }
      else {
	val (strictMatrix, strictBound) = {
	  if (newNNonStrict == ineqMatrix.nLines){
	    (None, None)
	  }
	  else {
	    (Some (ineqMatrix.getLines (newNNonStrict + 1, ineqMatrix.nLines)),
	     Some (ineqBound.drop (newNNonStrict)))
	  }
	}
	val (nonStrictMatrix, nonStrictBound) = {
          if (newNNonStrict == 0){
            (None, None)
          }
          else {
            (Some (ineqMatrix.getLines (1, newNNonStrict)),
             Some (ineqBound.take (newNNonStrict)))
          }
        }

	(phi, nonStrictMatrix, nonStrictBound, strictMatrix, strictBound)
      }
    }

    def hasStrictInequalities: Boolean = 
      nEq + nNonStrict < constrMatrix.nLines

    // Return a matrix equivalent to the constraint matrix but that represents
    // only non-strict and strict inequalities (no equalities). Return the
    // number of non-strict inequalities in the matrix (the first lines). Also
    // return the bound that goes with it as a linear combination.
    def ineqMatrixWithBound: (Matrix[D], Int, List[LinearCombination[D]]) = {
      // println ("DEBUG: constrMatrix2:\n" + constrMatrix)
      if (nEq == 0){
        (constrMatrix, nNonStrict, this.boundAsLC)
      }
      else {
        val eqMat = constrMatrix.getLines (1, nEq)
        val lcBound = this.boundAsLC
        val eqBound = lcBound.take (nEq)
        val ineqBound = eqBound.map (el => el.negate) ++ eqBound ++ lcBound.drop (nEq)
        val ineqMat = constrMatrix.appendTop (eqMat.negate)
        (ineqMat, nNonStrict + 2 * nEq, ineqBound)
      }

    }

    // Return a matrix equivalent to the constraint matrix but that represents
    // only non-strict and strict inequalities (no equalities). Return the
    // number of non-strict inequalities in the matrix (the first lines)
    def ineqMatrix: (Matrix[D], Int) = {
      val (mat, n, _) = ineqMatrixWithBound
      (mat, n)

    }

    // Return the bound vector as a linear combination of the parameters
    def boundAsLC: List[LinearCombination[D]] = {
      List.range (1, boundMatrix.nLines + 1).map (id => {
	lineToLinearCombinationWithConstant (parameters, boundMatrix, id)
      })
    }

    // Return the same constraint with the matrix changed. 
    def setMatrix (newMatrix: Matrix[D]): Constraints[D] = {
      new Constraints (withoutVariables, newMatrix, nEq, nNonStrict, boundMatrix,
                       variables, parameters)
    }

    def setBound (newBound: Matrix[D]): Constraints[D] = {
      new Constraints (withoutVariables, constrMatrix, nEq, nNonStrict,
                       newBound, variables, parameters)
    }

    // Strip the matrix from the equality lines
    def removeEq: Constraints[D] = {
      val (newMatrix, newNNonStrict) = {
	if (nEq == constrMatrix.nLines){
	  (constrMatrix.zero (1, variables.length), 1)
	}
	else {
	  (constrMatrix.removeLines (1, nEq), nNonStrict)
	}
      }
      val newBound = {
	if (nEq == boundMatrix.nLines){
	  boundMatrix.zero (1, parameters.length)
	}
	else {
	  boundMatrix.removeLines (1, nEq)
	}
      }
      new Constraints (withoutVariables, newMatrix, 0, newNNonStrict, newBound,
                       variables, parameters)                 
    }
    // Remove some variables from the constraints, and use the given new
    // constraint matrix.
    def removeVariables (toRemove: Set[Variable],
                         newConstr: Matrix[D]): Constraints[D] = {
      require ((toRemove.size == variables.size) || (variables.size - toRemove.size == newConstr.nCols))
      Constraints (withoutVariables, newConstr,
                   nEq, nNonStrict, boundMatrix, variables.filter (v =>
                     !toRemove.contains (v)), parameters)
    }

    // Set a new pre-condition
    def setPre (pre: LAFormula[D]): Constraints[D] = {
      new Constraints (pre, constrMatrix, nEq, nNonStrict, boundMatrix,
                       variables, parameters)
    }

    // Remove the zero lines in the constraint matrix, moving them to
    // the pre-condition
    def cleanupZeroLines: Constraints[D] = {
      // println ("DEBUG: cleanupZeroLines; constraint: " + this)
      val pre0 = {
        List.range (1, constrMatrix.nLines + 1).map (id => {
          val line = constrMatrix.getLine (id)
          if (!line.isZero)
            Rel (True):LAFormula[D]
          else {
            val rhs = lineToLinearCombinationWithConstant (parameters,
                                                           boundMatrix, id)
            val lhs = LinearCombination (line.field.zero)
            if (id <= nEq)
              Rel (Equals (lhs, rhs)):LAFormula[D]
            else if (id <= nEq + nNonStrict)
              Rel (LtEqual (lhs, rhs)):LAFormula[D]
            else
              Rel (Lt (lhs, rhs)):LAFormula[D]
          }
        })
      }
      val newPre = And (Set(withoutVariables) ++ pre0.toSet)
      val nVariables = constrMatrix.nCols
      val nParameters = boundMatrix.nCols
      val (newConstrMat, newBoundMat, newNEq, newNNonStrict) = {
        if (constrMatrix.isZero)
          (constrMatrix.zero (1, nVariables), boundMatrix.zero (1, nParameters), 1, 0)
        else {
          val toRemove = List.range (1, constrMatrix.nLines).filter (id =>
            constrMatrix.getLine (id).isZero).toSet
	  // println ("DEBUG: toRemove: " + toRemove)
          val newNEq = nEq - toRemove.count (id => id <= nEq)
          val newNNonStrict = nNonStrict - toRemove.count (id => id > nEq &&
                                                           id <= nEq + nNonStrict)
          (constrMatrix.removeLines (toRemove),
           boundMatrix.removeLines (toRemove), newNEq, newNNonStrict)
        }
      }
      Constraints (newPre, newConstrMat, newNEq, newNNonStrict, newBoundMat,
                   variables, parameters)
    }

    // Return true iff the dimensions of the matrices are consistent 
    def checkDimensions: Boolean = {
      // println ("DEBUG: checking constraint dimension")
      val nVariables = constrMatrix.nCols
      val nConstr = constrMatrix.nLines
      // -1 is for the constant term
      val nParameters = boundMatrix.nCols - 1

      // println ("DEBUG: constrMatrix:\n" + constrMatrix)
      // println ("DEBUG: boundMatrix:\n" + boundMatrix)
      // println ("DEBUG: nEq: " + nEq)
      // println ("DEBUG: nNonStrict: " + nNonStrict)
      // println ("DEBUG: variables: " + variables)
      // println ("DEBUG: parameters: " + parameters)
      
      ((nVariables == variables.length) || (nVariables == 1 && variables.isEmpty)) && nParameters == parameters.length &&
      (nEq + nNonStrict) <= nConstr && nConstr == boundMatrix.nLines
    }

    def getNVariables: Int = constrMatrix.nCols
  }

  object Constraints {
    def apply[D <: ExpressibleOrderedField[D]] (matrixEl: Matrix[D], variables: Seq[Variable], formula: LAFormula[D]): Constraints[D] = {
      val field = matrixEl.field
      val variableSet = variables.toSet
      val nVariables = variableSet.size
      val conj:Set[LAFormula[D]] = {
        formula match {
	  case And (f) => f
	  case r @ Rel (_) => Set (r)
	  case _ => error ("Formula should be a flattened conjunction")
        }
      }

      // Progressively collect the coefficients. curRels contains the relation
      // remaining to consider in the conjunction, curPhi is the current formula
      // without variables in `variables`, curNonStrict is a list of pairs, where
      // the first element of the pair contains the coefficient of the variables
      // in `variables` of a non-strict inequality, and the second element
      // contains the "constant" coefficient, i.e a linear combination of
      // parameters not in `variables`. `curStrict` is the same thing but for
      // strict inequalities.
      def collect (curRels: Set[LAFormula[D]], curPhi: List[LAFormula[D]], curNonStrict:
		   List[(List[D], LinearCombination[D])], curStrict:
		   List[(List[D], LinearCombination[D])], curEq: List[(List[D], LinearCombination[D])]): (List[LAFormula[D]], List[(List[D], LinearCombination[D])], List[(List[D], LinearCombination[D])], List[(List[D], LinearCombination[D])]) =
                     {
                       // Given the left-hand side and the right hand side of some equality or inequality
                       // (strict or non-strict), return a pair containing the list of
                       // coefficient of variables in `variables` (when they are moved to the
                       // left hand side), and the remaining parameters as a linear combination
                       // (when they are moved to the right hand side). Return None if the
                       // coefficients in the list are all zero.
                       def toLine (lhs: Term, rhs: Term): Option[(List[D], LinearCombination[D])] = {
	                 // Put everything on the left hand side
	                 val leftLC = rearrangeRelation (Equals (lhs, rhs)) match {
	                   case Equals (l, _) => l.asInstanceOf[LinearCombination[D]]
	                   case _ => error ("Rearranging a relation should produce the same relation")
	                 }
	                 val (allZero, line) = variables.foldRight (true, List[D]()) ((v, pair) => pair match {
	                   case (allZ, curL) => {
	                     val c = leftLC.getCoeff(field, v)
	                     (allZ && c.isZero, c :: curL)
	                   }
	                 })
	                 if (allZero){
	                   None
	                 }
	                 else {
	                   val rightLC = LinearCombination (leftLC.coeff.filterKeys (k => k match {
	                     case Some (v) => !variableSet.contains (v)
	                     case None => true
	                   })).scale (field.one.negate)
	                   Some ((line, rightLC))
	                 }
                       }
                       
                       if (curRels.isEmpty){
	                 (curPhi, curNonStrict, curStrict, curEq)
                       }
                       else {
	                 val first = curRels.head
	                 val next = curRels.tail
	                 first match {
	                   case Rel (rel) => rel match {
	                     case Equals (lhs, rhs) => toLine (lhs, rhs) match {
	                       case Some (pair) => collect (next, curPhi, curNonStrict, curStrict, pair::curEq)
	                       case None => collect (next, first::curPhi, curNonStrict, curStrict, curEq)
	                     }
	                     case Lt (lhs, rhs) => toLine (lhs, rhs) match {
	                       case Some (pair) => collect (next, curPhi, curNonStrict, pair::curStrict, curEq)
	                       case None => collect (next, first::curPhi, curNonStrict, curStrict, curEq)
	                     }
	                     case LtEqual (lhs, rhs) => toLine (lhs, rhs) match {
	                       case Some (pair) => collect (next, curPhi, pair::curNonStrict, curStrict, curEq)
	                       case None => collect (next, first::curPhi, curNonStrict, curStrict, curEq)
	                     }
	                     case True => collect (next, curPhi, curNonStrict, curStrict, curEq)
	                     case False => collect (next, (Rel(False):LAFormula[D])::curPhi, curNonStrict, curStrict, curEq)
	                   }
	                   case _ => error ("Expected relation inside formula in canonical form")
	                 }
                       }
                     }

      // Helper function to convert a line list in the format returned by collect
      // to a matrix and a vector.
      def getMatV (lineList: List[(List[D], LinearCombination[D])]): (Option[Matrix[D]], Option[List[LinearCombination[D]]]) = lineList match {
        case Nil => (None, None)
          case _ => {
	    val (lines, v) = lineList.unzip
	    (Some (matrixEl.init (lines)), Some (v.map (x => x.normalize (field))))
          }
      }
      
      
      val (phiConj, nonStrictConj, strictConj, eqConj) = collect (conj, Nil, Nil, Nil, Nil)
      val phi = if (phiConj.isEmpty) Rel (True):LAFormula[D] else And (phiConj.toSet)
      val (nonStrictMat, nonStrictV) = getMatV (nonStrictConj)
      val (strictMat, strictV) = getMatV (strictConj)
      val (eqMat, eqV) = getMatV (eqConj)
      val nEq = if (eqMat.isEmpty) 0 else eqMat.get.nLines
      val nNonStrict = if (nonStrictMat.isEmpty) 0 else nonStrictMat.get.nLines
      val parameters = formula.unquantifiedVariables.filter (v => !variableSet.contains (v)).toList
      val constrMatrix = {
        def toIndexedSeq (m: Option[Matrix[D]]): IndexedSeq[IndexedSeq[D]] = m match {
	  case Some (mat) => mat.getElems
	  case None => IndexedSeq ()
        }
        val constrSeq = toIndexedSeq (eqMat) ++ toIndexedSeq (nonStrictMat) ++ toIndexedSeq (strictMat)
        if (constrSeq.isEmpty)
	  matrixEl.zero (nVariables)
        else
	  matrixEl.init (constrSeq)
      }
      val bound = {
        val boundList = eqV.getOrElse (Nil) ++ nonStrictV.getOrElse (Nil) ++ strictV.getOrElse (Nil)
        if (boundList.isEmpty)
	  List (LinearCombination (field.zero))
        else
	  boundList
      }
      val boundMatrix = matrixEl.init (bound.map (b => {
        if (parameters.isEmpty) List (b.getConstantCoeff (field))
        else b.getConstantCoeff (field) :: b.toVector (parameters, matrixEl).toList
      }))

      // Rename variables to avoid any kind of name conflict
      val newVariables = variables.map (v => {
        Variable (uniqueID (v.name + "_").name)
      })

      // println ("DEBUG: converting to constraint")
      // println ("DEBUG: formula: " + formula)
      // println ("DEBUG: phi: " + phi)
      // println ("DEBUG: constrMatrix:\n" + constrMatrix)
      // println ("DEBUG: nEq:" + nEq)
      // println ("DEBUG: nNonStrict:" + nNonStrict)
      // println ("DEBUG: boundMatrix:\n" + boundMatrix)
      // println ("DEBUG: variable: " + newVariables)
      // println ("DEBUG: parameters: " + parameters)
  
      Constraints (phi, constrMatrix, nEq, nNonStrict, boundMatrix, newVariables, parameters)
    }
  }
  
  // Represent a conjunction that has been transformed so that the constraint
  // matrix has full column rank. `transformMatrix` is the matrix by which to
  // multiply a solution to get back the a solution for the original problem. If
  // `maybeUnbounded` is true, and the problem is feasible, then it is unbounded
  // (note that in that case the `maximize` vector is not meaningful and could
  // be anything, even zero).  `codeStack` is the current code that has been
  // synthetized for this problem. If the result is known
  // for sure (for example if the constraint does not depend on any parameters),
  // then `result` contains it (already multiplied by the transform matrix),
  // otherwise it is None. `allVariables` contains the original list of
  // variables to solve for (e.g before gaussian elimination). This is only used
  // for a more understandable output.
  case class FRProblem[D <: ExpressibleOrderedField[D]]
  (constr: Constraints[D], codeStack: (Seq[Val], Option[SimpleExpr]), maximize: Matrix[D],
   transformMatrix: Matrix[D], maybeUnbounded: Boolean,
   result: Option[LPResult[D]], allVariables: Seq[Variable])
  {
    override def toString: String = {
      constr + "\n\n" + "Current Code: " + (if (codeStack._2.isEmpty) "None" else
	getCode.toString ()) + "\n\n" +
      "maximize (transposed): " + maximize.transpose.toString + "\n" +
      "Transform matrix:\n" + transformMatrix.toString + "\n" +
      "Maybe unbounded ? :" + maybeUnbounded + "\n" +
      "Result: " + result + "\n" +
      "All variables: " + allVariables
    }
  
    def setMaybeUnbounded: FRProblem[D] = {
      FRProblem (constr, codeStack, maximize, transformMatrix, true, result, allVariables)
    }

    def isSolved: Boolean = !result.isEmpty
    def changeConstraints (transform: Constraints[D] => Constraints[D]):FRProblem[D] = {
      FRProblem (transform (constr), codeStack, maximize, transformMatrix,
                 maybeUnbounded, result, allVariables)
    }
    def removeEq: FRProblem[D] =
      changeConstraints (c => c.removeEq)

    def setMatrix (constrMatrix: Matrix[D]): FRProblem[D] =
      changeConstraints (c => c.setMatrix (constrMatrix))
    def setBound (newBound: Matrix[D]): FRProblem[D] =
      changeConstraints (c => c.setBound (newBound))
    def removeVariables (toRemove: Set[Variable], newConstr: Matrix[D]): FRProblem[D] =
      changeConstraints (c => c.removeVariables (toRemove, newConstr))

    def setPre (pre: LAFormula[D]): FRProblem[D] =
      changeConstraints (_.setPre (pre))

    def cleanupZeroLines: FRProblem[D] =
      changeConstraints (_.cleanupZeroLines)

    def hasStrictInequalities: Boolean =
      constr.hasStrictInequalities
  
    def pushCodeVal (top: List[Val]): FRProblem[D] = {
      FRProblem (constr, (top ++ codeStack._1, codeStack._2), maximize, transformMatrix,
                 maybeUnbounded, result, allVariables)
    }
    // Change the objective vector
    def setMaximize (newMax: Matrix[D]): FRProblem[D] = {
      FRProblem (constr, codeStack, newMax, transformMatrix, maybeUnbounded,
                 result, allVariables)
    }

    // Return true if the dimensions of the matrices are consistent, false
    // otherwise. Do not compare the constraint matrix and the transform matrix
    def checkDimensions: Boolean = {
      val nVariables = maximize.nLines

      // println ("DEBUG: checking dimensions")
      // println ("DEBUG: maximize:\n" + maximize)
      // println ("DEBUG: transform matrix:\n" + transformMatrix)
      // println ("DEBUG: constraint: " + constr)
      // println ("DEBUG: constr check: " + constr.checkDimensions)
      // println ("DEBUG: nVariables: " + nVariables)
      // println ("DEBUG: constrMatrix.nCols: " + constr.constrMatrix.nCols)
      // println ("DEBUG: nVariables check: " + (nVariables == constr.constrMatrix.nCols))
      constr.checkDimensions && (nVariables == constr.constrMatrix.nCols) &&
      transformMatrix.nCols == transformMatrix.nLines && maximize.nCols == 1 && {
        result match {
          case Some (res) =>
            !res.hasSolution || (res.hasSolution &&
                                 res.optimalVector.nCols == 1 &&
                                 res.optimalVector.nLines == nVariables)
          case None => true
        }
      }
    }
    
    def getCode: SimpleExpr = {
      require (!codeStack._2.isEmpty)
      Block (codeStack._1, codeStack._2.get)
    }

    def getNVariables: Int = constr.getNVariables
  }

  object FRProblem {
    def apply[D <: ExpressibleOrderedField[D]] (solver: SimplexSolver[D], variables:
						Seq[Variable], formula: LAFormula[D], goal: LinearCombination[D]): FRProblem[D] = {
      val matrixEl = solver.matrix
      val field = matrixEl.field
      val constraints = Constraints (matrixEl, variables, formula)
      val maximizeV = goal.toVector (variables, matrixEl)
      val nVariables = variables.length

      if (constraints.constrMatrix.isZero){
        val unbounded = !maximizeV.isZero
        val res = {
          if (unbounded)
            LPRes (field, None, None, None, true)
          else
            LPRes (field, Some (field.zero), None,
                   Some (matrixEl.zero (nVariables, 1)), true)
        }
        FRProblem (constraints, (List (), Some (res.toSimpleExpr)), maximizeV,
                   matrixEl.identity (nVariables),
                   unbounded, Some (res), variables)
      }
      else {
        def toProblem (maximize: Matrix[D]): FRProblem[D] = {
          val solv = solver.init (constraints.constrMatrix, maximize,
                                  matrixEl.zero (constraints.constrMatrix.nLines, 1))
          solv.transformToFullRank match {
            case Left ((transformMatrix, ns)) => {
	      val toRemove = constraints.variables.drop (ns.matrix.nCols).toSet
              val newConstraints = constraints.removeVariables (toRemove,ns.matrix)
              val ineqMatrix = newConstraints.ineqMatrix._1
              val newSolver = solver.init (ineqMatrix, ns.maximize, matrixEl.zero (ineqMatrix.nLines))
              newSolver.findRoof match {
                // No roof found: problem either unbounded or unfeasible
                case Right (_) => {
                  assert (!ns.maximize.isZero)
                  FRProblem (newConstraints, (List (), None), ns.maximize,
                             transformMatrix, true, None, variables)
                }
                // Roof found: problem bounded
                case Left (_) => {
                  FRProblem (newConstraints, (List (), None), ns.maximize,
                             transformMatrix, false, None, variables)
                }
              }
            }
            // Problem is possibly unbounded
            case Right (_) => {
              assert (!maximize.isZero)
              toProblem (maximizeV.zero).setMaybeUnbounded
            }
          }
        }
        toProblem (maximizeV)
      }
    }
  }


  // Convert a line of the matrix to a linear combination with the given
  // variables. Assume the first column of the line is the constant coefficient.
  def lineToLinearCombinationWithConstant[D <: ExpressibleOrderedField[D]] (variables: Seq[Variable],
	   matrix: Matrix[D], id: Int): LinearCombination[D] = {
    val line = matrix.getLine (id)
    val const = line.get (1,1)
    if (line.nCols == 1) LinearCombination (const)
    else LinearCombination (variables, line.getCols (List.range (2, line.nCols + 1)),
			    const)
  }
  
  // Same as `lineToLinearCombinationWithConstant`, but assuming the first
  // column is the coefficient for the first variable, etc... 
  def lineToLinearCombination[D <: ExpressibleOrderedField[D]] (variables: Seq[Variable],
								matrix: Matrix[D], id: Int): LinearCombination[D] = {
    LinearCombination (variables, matrix.getLine (id))
  }
}
