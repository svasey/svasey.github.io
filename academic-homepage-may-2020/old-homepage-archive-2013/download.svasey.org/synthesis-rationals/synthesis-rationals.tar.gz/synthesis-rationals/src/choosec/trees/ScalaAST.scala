package choosec
package trees

import numbers._
import ScalaPrinter._
import scala.collection.mutable.HashMap

object ScalaCode {
  var uidMap: HashMap[String,BigInt] = HashMap ()
  // Return a unique identifier whowse name begins with `prefix`
  def uniqueIdentifier (prefix: String): Identifier = {
    val uid:BigInt = if (uidMap.contains (prefix)) uidMap (prefix) else 1
    val uidStr = if (uid == 1) "" else uid.toString
    val ret = Identifier (prefix + uidStr + "__")
    uidMap.put (prefix, uid + 1)
    ret
  }
  
  // Abstract syntax tree for (a small subset of) scala 
  trait ScalaAST extends AST

  trait Expr extends ScalaAST with ScalaExpressible {
    def toScalaCode: Expr = this
    def getType: Type = Type ("Any")
    override def toString: String = prettyPrint (this)
  }

  // Simply describe a type by its representing string
  case class Type (name: Identifier) extends ScalaAST {
    override def toString: String = name.toString
  }
  object Type {
    def apply (name: String): Type = {
      Type (Identifier (name))
    }
  }
  
  // Return code that tests whether the given identifier is empty
  def emptyCode (id: Identifier): Expr =
    DotExpr (id, Identifier ("isEmpty"), List ())

  def getCode (id: Identifier): Expr =
    DotExpr (id, Identifier ("get"), List ())

  def someCode (expr: Expr): Expr = 
    Apply (Identifier ("Some"), List (expr))
  def optionCode[T <: ScalaExpressible] (opt: Option[T]): Expr = opt match {
    case Some (obj) => someCode (obj.toScalaCode)
    case None => NoneSym
  }
  def optionCode[T] (opt: Option[T], toCode: T => Expr): Expr = opt match {
    case Some (obj) => someCode (toCode (obj))
    case None => NoneSym
  }

  // To use when the problem has no solution
  def noSolutionError (msg: String): Expr = {
    noSolutionError (StringLit (msg))
  }

  def noSolutionError (msg: Expr): Expr = {
    Apply (Identifier ("throw"), List (New (Identifier ("NoSolutionException"), List (msg))))
  }

  // To use when there is a real error
  def errorCode (msg: String): Expr = {
    errorCode (StringLit (msg))
  }

  def errorCode (msg: Expr): Expr = {
    Apply (Identifier ("scala.Predef.error"),
	   List (msg))
  }

  def seqCode[T] (name: String, toCode: T => Expr, xs: Seq[T]): Expr = Apply (Identifier (name), xs.toList.map (toCode))

  def seqCode[T <: ScalaExpressible] (name: String, xs: Seq[T]): Expr =
    seqCode (name, (el:T) => el.toScalaCode, xs)

  def intSeqCode (name: String, xs: Seq[Int]): Expr =
    seqCode (name, (el:Int) => IntLit (el),xs)

  def intSetCode (intSet: Set[Int]) = intSeqCode ("Set", intSet.toList)

  def matrixFromListCode[D <: ExpressibleOrderedField[D]] (matrix: Matrix[D], list: Expr): Expr = {
    DotExpr (matrix.zero (1).toScalaCode, Identifier ("init"),
	     List (IntLit (matrix.nCols), IntLit (1),
                   list))
  }

  // Convert a big integer to scala code
  def bigIntCode (n: BigInt): Expr = {
    if (n <= Int.MaxValue && n >= Int.MinValue)
      IntLit (n.toInt)
    else
      // Apply (Identifier ("BigInt"), List (StringLit (n.toString)))
      Apply (Identifier ("BigInt"), List (Apply (Identifier ("Array"),
                                                 n.toByteArray.map (b => {
                                                   ByteLit (b)
                                                 }).toList)))
  }
  
  def boolCode (t: Boolean): Expr = {
    if (t) True
    else False
  }
  
  case object True extends Expr 
  case object False extends Expr
  // The skip statement, i.e the empty expression
  case object Skip extends Expr 

  case class Or (exprs: Set[Expr]) extends Expr
  object Or {
    def apply (lhs: Expr, rhs: Expr): Expr =
      Or (Set (lhs) + rhs)
  }

  case class And (exprs: Set[Expr]) extends Expr
  object And {
    def apply (lhs: Expr, rhs: Expr): Expr =
      And (Set (lhs) + rhs)
  }

  case class Assign (lhs: Identifier, rhs: Expr) extends Expr
  
  case class Not (expr: Expr) extends Expr 
  case class Identifier (name: String) extends Expr {
    override def toString: String = name
  }
  case class Equals (lhs: Expr, rhs: Expr) extends Expr
  case class Lt (lhs: Expr, rhs: Expr) extends Expr
  case class LtEq (lhs: Expr, rhs: Expr) extends Expr
  case class Plus (lhs: Expr, rhs: Expr) extends Expr
  case class Times (lhs: Expr, rhs: Expr) extends Expr
  case class Minus (lhs: Expr, rhs: Expr) extends Expr
  case class DividedBy (lhs: Expr, rhs: Expr) extends Expr

  // FIXME: to be removed
  case class Min (xs: Seq[Expr]) extends Expr {
    require (!xs.isEmpty)
  }
  case class Max (xs: Seq[Expr]) extends Expr {
    require (!xs.isEmpty)
  }
  
  case class New (id: Identifier, args: Seq[Expr]) extends Expr
  // Expression of the form $func (...)
  case class Apply (id: Identifier, args: Seq[Expr]) extends Expr
  case class StringLit (value: String) extends Expr
  case class IntLit (value: Int) extends Expr

  case class DoubleLit (value: Double) extends Expr

  case class ByteLit (value: Byte) extends Expr

  // Expression of the form { $stat ; $x } 
  case class Block (first: Expr, rest: Seq[Expr]) extends Expr {
    def stats: Seq[Expr] = first +: rest
  }

  object Block {
    def apply (xs: Seq[Expr]): Block = {
      require (!xs.isEmpty)
      Block (xs.head, xs.tail)
    }
  }
  
  case class If (ifExpr: Expr, ifPart: Expr, elsePart: Option[Expr]) extends Expr
  case class DotExpr (receiver: Expr, method: Identifier, args: Seq[Expr]) extends Expr      
  // Expression of the form `val x = e`
  case class Val (id: Identifier, expr: Expr, t: Option[Type],
                  isLazy: Boolean) extends Expr

  object Val {
    def apply (id: Identifier, expr: Expr): Val =
      Val (id, expr, None)
    def apply (id: Identifier, expr: Expr, typ: Option[Type]): Val =
      Val (id, expr, typ, false)
  }
  
  case object NoneSym extends Expr

  // Make sure there are no nested blocks
  def flattenBlock (block: Block): Block = {
    Block (block.stats.flatMap (_ match {
      case b: Block => flattenBlock (b).stats
      case e @ _ => Seq (e)
    }))
  }
}


trait ScalaExpressible {
  // Return code that evaluates to a scala representation of the object
  def toScalaCode: ScalaCode.Expr
  def getType: ScalaCode.Type
}
