package choosec
package numbers

import trees.ScalaCode._
import trees.ScalaExpressible

import scala.annotation.tailrec

import smartfloats._

// Arbitrary precision implementation of the rational numbers.
class Rational (n: BigInt, d: BigInt) extends ExpressibleOrderedField[Rational]
{
  require (d != 0)
  private val g: BigInt = n.abs.gcd (d.abs)
  val num: BigInt = {
    if (d < 0)  -n / g  else n / g
  }
  // Make sure there is only one fraction representing 0
  val denum: BigInt = if (n == 0) BigInt (1) else d.abs / g

  override def toString: String = num + (if (denum != 1) "/" + denum else "")
  override def equals (any: Any): Boolean = {
    if (any.isInstanceOf[Rational]){
      any.asInstanceOf[Rational] == this
    }
    else {
      false
    }
  }
  override def hashCode: Int = (num, denum).hashCode

  def == (that: Rational): Boolean = {
    // Since the fractions are already reduced this is equivalent to checking
    // equality componentwise 
    (this.num == that.num) && (this.denum == that.denum)
  }

  def zero: Rational = new Rational (0,1)
  def one: Rational = new Rational (1,1)
  def + (that: Rational): Rational = {
    val d = this.denum.gcd (that.denum)
    new Rational (this.num * (that.denum / d) + that.num * (this.denum / d),
		  (this.denum / d) * that.denum)
  }
  def * (that: Rational): Rational =
    new Rational (this.num * that.num, this.denum * that.denum)

  def negate: Rational = new Rational (-num,denum)
  def inverse: Rational = {
    require (num != 0)
    new Rational (denum,num)
  }

  override def fromInt (n: BigInt): Rational = new Rational (n, 1)

  // Quick and dirty parsing without any kind of sanity check.
  def fromString (str: String): Rational = {
    val (num, denum) = str.span (c => c != '/')
    if (denum.isEmpty)
      fromInt (BigInt (num))
    else
      new Rational (BigInt (num), BigInt (denum.tail))
  }

  // FIXME: this may not be the best approximation...
  def toDouble: Double = {
    val (quotient, rem) = num /% denum
    quotient.toDouble + (rem.toDouble / denum.toDouble)
  }

  def fromDouble_approx (x: Double, n: BigInt): Rational =
    this.fromDouble (x).bestApprox (n)
  
  def toFloatWrap: FloatWrap = {
    new FloatWrap (toDouble)
  }

  // FIXME: we loose some error...
  def toSmartFloatWrap: SmartFloatWrap = {
    val (quotient, rem) = num /% denum
    val el = SmartFloat (quotient.toDouble) + (SmartFloat (rem.toDouble) / SmartFloat (denum.toDouble))
    new SmartFloatWrap (el)
  }

  // Overriden so that we can try to find a rational of small encoding size
  // between `this` and `that`. This should return a rational with smallest
  // denominator (and also smallest encoding size)
  override def upTo (that: Rational): Rational = {
    if (this == that)
      this
    else {
      // Low-level algorithm: assume 0 <= p1/q1 < p2/q2, and return r s.t
      // p1/q1 < r < p2/q2
      def between (p1: BigInt, q1: BigInt, p2: BigInt, q2: BigInt): Rational = {
        require (p1 >= 0 && q1 > 0 && p2 > 0 && q2 >= 0 && (p2*q1 - p1*q2) > 0)

        // Return ceil (a/ b)
        def ceilDiv (a: BigInt, b: BigInt): BigInt = {
          val (r,m) = a /% b
          if (m == 0) r else r + 1
        }
        
        val delta = p2 * q1 - p1 * q2
        var qHigh = ((q1 * q2 + q1 + q2) / delta) + 1
        var qLow = (q1 + q2) / delta
        var pLow = ceilDiv (p1 * qLow + 1, q1)
        var pHigh = (p2 * qLow - 1) / q2

        if (pLow <= pHigh)
          return Rational (pLow, qLow)
        
        assert (qLow < qHigh)
        while (qLow < qHigh){
          assert (ceilDiv (p1 * qHigh + 1, q1) <= (p2 * qHigh - 1) / q2)
          val qMid = (qHigh + qLow) / 2
          val pLow2 = ceilDiv (p1 * qMid + 1, q1)
          val pHigh2 = (p2 * qMid - 1) / q2

          if (pLow2 <= pHigh2)
            qHigh = qMid
          else {
            pLow = pLow2
            pHigh = pHigh2
            qLow = qMid + 1
          }
        }
        return Rational (ceilDiv (p1 * qHigh + 1, q1), qHigh)
      }
      val (r1, r2) = if (this < that) (this,that) else (that, this)
        
      assert (r1 < r2)
      val (sr1, sr2) = (r1.signum, r2.signum)
      val res = {
        if (sr1 < 0 && sr2 > 0)
          zero
        else if (sr1 < 0 && sr2 <= 0)
          between (-r2.num, r2.denum, -r1.num, r1.denum).negate
        else {
          assert (sr1 >= 0 && sr2 > 0)
          between (r1.num, r1.denum, r2.num, r2.denum)
        }
      }
      assert (r1 < res && res < r2)
      res
    }
  }

  // Return the best approximation with denominator at most n
  def bestApprox (n: BigInt): Rational = {
    require (n >= 1)

    val nRat = fromInt (n)
    
    // Compute the lower and upper convergents of `this`, and return the one of
    // the two which is the best approximation. This is an implementation of the
    // algorithm in "Theory of Linear and Integer Programming", by Schrijver.

    def approx (x: Rational): Rational = {
      require (x >= 0 && x.denum > n)

      @tailrec
      def iter (p0: Rational, q0: Rational, p1: Rational,
                q1: Rational): Rational = {
        // println ("DEBUG: p0: " + p0)
        // println ("DEBUG: q0: " + q0)
        // println ("DEBUG: p1: " + p1)
        // println ("DEBUG: q1: " + q1)
        require (p0.isInteger && q0.isInteger && p1.isInteger && q1.isInteger &&
                 q0 <= nRat && q1 <= nRat)
        val t = fromInt (((p0 - x*q0) / (x*q1 - p1)).floor)
        val q2 = q0 + t*q1
        if (q2 > nRat){
          // Compute the semiconvergent
          val k = fromInt (((nRat - q0) / q1).floor)
          val first = (p0 + k*p1) / (q0 + k*q1)
          val second = p1 / q1
          
          val firstDiff = (x - first).abs
          val secondDiff = (x - second).abs
          val cmp = firstDiff.compare (secondDiff)
          if (cmp < 0)
            first
          else if (cmp > 0)
            second
          else {
            assert (cmp == 0)
            // Return the approximation with the smallest denominator
            if (first.denum < second.denum)
              first
            else
              second
          }
        }
        else {
          val p2 = p0 + t*p1
          iter (p1, q1, p2, q2)
        }
      }
      iter (zero, one, one, zero)
    }

    if (this.denum <= n)
      this
    else {
      if (this.signum >= 0)
        approx (this)
      else
        approx (this.negate).negate
    }
  }
  
  // Return the lowest integer greater than `this`
  def ceil: BigInt = 
    - (this.negate.floor)
  
  // Return the largest integer less than `this`
  def floor: BigInt = {
    val (ret, rem) = num /% denum
    if (signum < 0 && rem != 0)
      ret - 1
    else
      ret
  }
  
  def signum = num.signum
  def isExact = true

  def isInteger: Boolean = denum == 1

  def toScalaCode: Expr = {
    val numExpr = bigIntCode (num)
    val denumExpr = bigIntCode (denum)
    Apply (Identifier ("Rational"), List (numExpr, denumExpr))
  }
  def getType: Type = Type ("Rational")
}

object Rational {
  // Hack to be able to call zero and one without having instantiated any
  // rational object.
  val r = new Rational (1,1)
  val rmat = BaseMatrix[Rational] (r, List (List (r.zero)))
  
  def zero: Rational = r.zero
  def one: Rational = r.one
  implicit def fromBigInt (n: BigInt): Rational = r.fromInt (n)
  def fromString (str: String): Rational = r.fromString (str)
  implicit def fromInt (n: Int): Rational = fromBigInt (BigInt (n))

  def apply (n: BigInt, d: BigInt): Rational =
    new Rational (n,d)
  def apply (n: BigInt): Rational =
    fromBigInt (n)
  def apply (n: Int): Rational =
    fromInt (n)


  def fromDouble (x: Double): Rational =
    r.fromDouble (x)
  
  def fromDouble_approx (x: Double, n: BigInt): Rational =
    r.fromDouble_approx (x, n)
}
