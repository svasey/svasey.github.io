package choosec
package parser

// Original source: http://lara.epfl.ch/web2010/cc10:top

import choosec.LASynthetizer
import numbers._

import scala.io.Source

trait Lexer[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]] {
  // This indicates to the Scala compiler that this trait will be composed with
  // a Compiler. This implies that the methods from the Reporter class will be
  // available at run-time, as well as the reference to the Source object.
  self: LASynthetizer[D,E] =>

  import Tokens._

  // This contains the last character from the stream that hasn't been processed
  // yet. This is used by some methods that have to read ahead of the character
  // stream to know when the current token ends
  var lastChar: Option[Char] = None
  
  // True if c is a letter, lower or upper case
  def isLetter (c: Char): Boolean = {
    ('A' <= c &&  c <= 'Z') || ('a' <= c && c <= 'z')
  }

  // True if c is a decimal digit
  def isDigit (c: Char): Boolean = {
    '0' <= c && c <= '9'
  }

  // True if c is a valid character in the middle of an identifier
  def isIDLetter (c: Char): Boolean = {
    isLetter (c) || (c == '_') || isDigit (c)
  }

  // True if c is a new line
  def isNewline (c: Char): Boolean = {
    (c == '\n') || (c == '\r')
  }

  // True if c is a whitespace character, 
  def isSpace (c: Char): Boolean = {
    c <= ' '
  }

  // Return true if there is a next character to be read, either in the source
  // or in lastChar.
  def hasNextChar: Boolean = {
    lastChar match {
      case Some (char) => true
      case None => source.hasNext
    }
  }

  // Return the next character to be read. It is an error if there is no next
  // character.
  def getNextChar: Char = {
    assert (hasNextChar)
    lastChar match {
      case Some (char) => {
	lastChar = None
	char
      }
      case None => source.next
    }
  }

  // Read the source until stop(c) is true, and return the string that was read
  // up to (but not including) c. Set lastChar if necessary.
  def readUntil (stop: Char => Boolean): String = {
    // This is written in imperative style in order to be more efficient.
    var s = new StringBuffer
    while (hasNextChar){
      val c = getNextChar
      if (stop (c)){
	lastChar = Some (c)
	return s.toString
      }
      else {
	s.append (c)
      }
    }
    s.toString
  }

  // Drop all characters from the source until the stop function returns
  // true, or end of file is encountered. Return the character for which the
  // stop function returned true, or None if EOF happened before.
  def dropUntil (stop: Char => Boolean): Option[Char] = {
    if (hasNextChar){
      val c = getNextChar
      if (stop (c)){
	Some (c)
      }
      else {
	dropUntil (stop)
      }
    }
    else {
      None
    }
  }

  // Skip all spaces and comments, and return the next meaningful character. If
  // end of file was encountered, return None. Set lastChar if some look ahead
  // was needed, e.g for differentiating a division sign from a comment.
  def skipSpaceAndComments: Option[Char] = {
    // Read until a comment opened with /* is closed. It is a fatal error if EOF
    // is reached before.
    def readUntilClosing: Unit = {
      dropUntil (x => (x == '*'))
      // Read a sequence of '*'
      val last = dropUntil (x => (x != '*'))
      last match {
	case Some ('/') => return
	case Some (_) => readUntilClosing
	case None =>
 	  fatalError ("Comment beginning with /* was never closed",
		      source.pos + 1)
      }
    }

    val c = dropUntil (x => (!isSpace (x)))
    c match {
      case None => None
      case Some('/') => {
	if (hasNextChar){
	  getNextChar match {
	    case '/' => {
	      dropUntil (x => isNewline (x))
	      // This works, because we do not need to register the new line
	      // character that has just been read
	      skipSpaceAndComments
	    }
	    case '*' => {
	      readUntilClosing
	      skipSpaceAndComments
	    }
	    case char => {
	      lastChar = Some (char)
	      Some ('/')
	    }
	  }
	}
	else {
	  Some ('/')
	}
      }
      case _ => c
    }
  }
  
  // Return a token, setting its position along the way. The length argument
  // must contain the number of characters to read back before getting to the
  // beginning of the token
  def retToken (token: Token, length: Int): Token =
    token.setPos ((source.pos - length) + 1)

  // Read one or two equal signs, and return the appropriate token. Set lastChar
  // if needed.
  def parseEqualSign: Token = {
    if (! hasNextChar){
      error ("Expected '=' before end of file", source.pos + 1)
      retToken (Token (BAD), 1)
    }
    else {
      val c = getNextChar
      if (c == '='){
	retToken (Token (EQUALS), 2)
      }
      else {
        error ("Expected '=', got '" + c + "'", source.pos)
        lastChar = Some (c)
        retToken (Token (BAD), 2)
      }
    }
  }

  // Read either < or <=, and return the appropriate token. Set lastChar
  // if needed.
  def parseLessThanSign: Token = {
    if (! hasNextChar){
      retToken (Token (LESSTHAN), 1)
    }
    else {
      val c = getNextChar
      if (c == '='){
	retToken (Token (LESSTHANEQ), 2)
      }
      else {
	lastChar = Some (c)
	retToken (Token (LESSTHAN), 2)
      }
    }
  }

  // Parse a logic connector: || or && . Assume the first character is a valid
  // one. 
  def parseLogicConnector: Token = {
    val c = getNextChar
    if (hasNextChar){
      val next = getNextChar
      if (next == c){
	next match {
	  case '&' => retToken (Token (AND), 2)
	  case '|' => retToken (Token (OR), 2)
	  case _ => {
	    // Should not happen
	    scala.Predef.error ("Bug in the compiler, while lexing. " ++
				"Please report it.")
	  }
	}
      }
      else {
	error ("Expected '" + c + "', got '" + next + "'", source.pos)
	lastChar = Some (next)
	retToken (Token (BAD), 2)
      }
    }
    else {
      error ("Expected '" + c + "' before end of file", source.pos + 1)
      retToken (Token (BAD), 1)
    }
  }

  // Read an identifier. Assume the first character in the stream is a valid
  // first character for an identifier.
  def getIdentifier: Token = {
    val id = readUntil (x => (!isIDLetter (x)))
    // Number of characters that have been read after the beginning of the
    // identifier: length of the identifier plus one more character, unless an
    // eof occured.
    val length = if (hasNextChar) (id.length + 1) else id.length
    
    // Check for keywords
    id match {
      case "true" => retToken (Token (TRUE), length)
      case "false" => retToken (Token (FALSE), length)
      case "RChoose" => retToken (Token (RCHOOSE), length)
      case "forall" => retToken (Token (FORALL), length)
      case "exists" => retToken (Token (EXISTS), length)
      case _ =>
	retToken (Token (ID (id)), length)
    }
  }
  
  // Read an integer. Assume the first character in the stream is a valid first
  // character for an integer.
  def getInteger: Token = {
    val numberAsString = readUntil (x => !isDigit (x))
    val num = scala.math.BigInt(numberAsString)
    val length =
      if (hasNextChar)
	(numberAsString.length + 1)
      else
	numberAsString.length
      
    if ((numberAsString.charAt (0) == '0') && (numberAsString.length > 1)){
      val ret = retToken (Token (BAD), length)
      error ("Integer litteral begins with a zero", ret.pos)
      ret
    }
    else {
      retToken (Token (NUM (num)), length)
    }
  }
  
  /** Works like an iterator, and returns the next token from the input stream. */
  def nextToken: Token = {
    val c = skipSpaceAndComments
    c match {
      // Play it safe: the position of EOF is set as the position of the last
      // character of the files so that errors can be reported without any
      // trouble because of a position "outside" the file.
      case None => retToken (Token (EOF), 1)
      case Some ('(') => retToken (Token (LPAREN), 1)
      case Some (')') => retToken (Token (RPAREN), 1)
      case Some ('{') => retToken (Token (LBRACE), 1)
      case Some ('}') => retToken (Token (RBRACE), 1)
      case Some ('[') => retToken (Token (LSQUARE), 1)
      case Some (']') => retToken (Token (RSQUARE), 1)
      case Some ('+') => retToken (Token (PLUS), 1)
      case Some ('-') => retToken (Token (MINUS), 1)
      case Some ('*') => retToken (Token (TIMES), 1)
      case Some ('/') => retToken (Token (DIVIDES), if (hasNextChar) 2 else 1)
      case Some ('<') => parseLessThanSign
      case Some (',') => retToken (Token (COMMA), 1)
      case Some ('!') => retToken (Token (NOT), 1)
      case Some ('=') => parseEqualSign 
      case Some ('&') => {
	lastChar = Some ('&')
	parseLogicConnector
      }
      case Some ('|') => {
	lastChar = Some ('|')
	parseLogicConnector
      }
      case Some (char) => {
	if (isLetter (char)){
	  lastChar = Some (char)
	  getIdentifier
	}
	else if (isDigit (char)){
	  lastChar = Some (char)
	  getInteger
	}
	else {
	  error ("Unexpected character: '" + char + "'", source.pos)
	  retToken (Token (BAD), 1)
	}
	
      }
    }
  }
}
