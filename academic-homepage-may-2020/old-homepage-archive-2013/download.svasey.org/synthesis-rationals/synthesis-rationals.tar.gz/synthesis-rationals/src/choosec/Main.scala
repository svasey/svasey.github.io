package choosec

import synthesis.RFourierMotzkinSynthesis._
import synthesis._
import trees.Formulas._
import trees.FormulaTransforms._
import numbers.Rational._
import numbers.Rational
import numbers._
import simplex._
import simplex.MultiparametricLP._

// Implements various tests
object Main {
  def formulaTest = {
    import numbers.Rational._
    import trees.Formulas._
    import trees.FormulaTransforms._

    val x = LinearCombination (Variable ("x"), one)
    val y = LinearCombination (Variable ("y"), one)
    val u = LinearCombination (Variable ("u"), one)
    val v = LinearCombination (Variable ("v"), one)
    val xEqualsY:RLAFormula = Rel (Equals (x, y))
    val uEqualsV:RLAFormula = Rel (Equals (u, v))
    val notUEqualsV = Not (uEqualsV)
    val xGtEqualY:RLAFormula = Rel (LtEqual (y, x))
    val maximize:RLAFormula =
      And (Rel (LtEqual (LinearCombination (List ((x, one), (y, one))),
			 LinearCombination (one))),
           Quantifier (Variable ("u"), Universal,
                       Quantifier (Variable ("v"), Universal,
                                   implies (Rel (LtEqual (LinearCombination (List ((u, one), (v, one))),
                                                          LinearCombination (one))),
                                            Rel (LtEqual (LinearCombination
							  (List ((u, one), (v, one))),
							  LinearCombination
							  (List ((x, one), (y, one)))))))))
    val tricky:RLAFormula =
      And (Rel (LtEqual (x, LinearCombination (one))),
           Quantifier (Variable ("x"), Universal,
                       Rel (Equals (x, LinearCombination (zero)))))
                                            
    println ("Original: " + notUEqualsV)
    println ("Simplified: " + canonicalDNF (removeLeq (removeNegations (notUEqualsV))))
    
    println ("Maximization (original): " + maximize)
    println ("Maximization (simplified): " + canonicalDNF (negationNormalForm (maximize)))
    println ("Tricky (original): " + tricky)
    println ("Tricky (simplified): " + canonicalDNF (negationNormalForm (tricky)))
  }

  def synthesisTest = {
    val x = LinearCombination (Variable ("x"), one)
    val y = LinearCombination (Variable ("y"), one)
    val z = LinearCombination (Variable ("z"), one)

    val xysum = LinearCombination (List ((x, one), (y, one)))
    val sum = xysum.add (z)
    
    val form1 = Rel[LAFunction[Rational],ArithmeticRelation] (Equals (sum, LinearCombination (new Rational (42, 1))))
    val form2 =
      Rel[LAFunction[Rational],ArithmeticRelation] (Equals (xysum, LinearCombination (one)))
    val form3 =
      Rel (Lt (x, LinearCombination (zero))):LAFormula[Rational]

    // Get x,y,z s.t x + y + z == 42 && x + y == 1 && x < 0
    // One possible solution is x = -1, y = 2, z = 41
    val form = And (List (form1, form2, form3).toSet )
    println ("Formula: " + form)
    val (pre, code) =
      synthetize (List (Variable ("x"),
			Variable ("y"),
			Variable ("z")), form)
    
    println ("Pre-condition: " + canonicalDNF (pre))
    println ("Code: " + code)

    // Get x s.t 0 < x < 1
    val rel1 = Rel (Lt (x, LinearCombination (one))):LAFormula[Rational]
    val rel2 = Rel (Lt (LinearCombination (zero), x)):LAFormula[Rational]
    val f2 = And (rel1, rel2)
    println ("Formula: " + f2)
    val (pre2, code2) = synthetize (List (Variable ("x")), f2)
    println ("Pre-condition: " + canonicalDNF (pre2))
    println ("Code: " + code2)

    // Maximize x with constraint x < 1 (no solutions)
    val f3 = Rel (Lt (x, LinearCombination (one))):LAFormula[Rational]
    println ("Formula: " + f3 + " [maximize x]")
    val (pre3, code3) = synthetize (List (Variable ("x")), f3, Some (x))
    println ("Pre-condition: " + canonicalDNF (pre3))
    println ("Code: " + code3)

    // Maximize 2 * x with constraint x <= 1
    val f4 = Rel (LtEqual (x, LinearCombination (one))):LAFormula[Rational]
    println ("Formula: " + f4 + " [maximize 2 * x]")
    val (pre4, code4) = synthetize (List (Variable ("x")), f4,
                                    Some (x.scale (fromInt (2))))
    println ("Pre-condition: " + canonicalDNF (pre4))
    println ("Code: " + code4)

    // Maximize x without constraint (no solutions)
    val f5 = Rel (True):LAFormula[Rational]
    println ("Formula: " + f5 + " [maximize x]")
    val (pre5, code5) = synthetize (List (Variable ("x")), f5, Some (x))
    println ("Pre-condition: " + canonicalDNF (pre5))
    println ("Code: " + code5)

    // Get x s.t (y < x < 0) || (0 < x < y)
    // Such an x exists iff y != 0.
    val f6 =
      Or (And (Rel (Lt (x, LinearCombination (zero))):RLAFormula,
               Rel (Lt (y, x)):RLAFormula),
          And (Rel (Lt (LinearCombination (zero), x)):RLAFormula,
               Rel (Lt (x, y)):RLAFormula))
             
    println ("Formula: " + f6)
    val (pre6, code6) = synthetize (List (Variable ("x")), f6)
    println ("Pre-condition: " + canonicalDNF (pre6))
    println ("Code: " + code6)

  }

  def synthetizerDemo[D <: ExpressibleOrderedField[D]] (method: LASynthesisMethod[D], inFile: String, outDir:  String, objectName: String): Unit = {
    synthetizerDemo[D,D] (method, inFile, outDir, objectName, (d:D) => d)
  }  
  
  def synthetizerDemo[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]] (method: LASynthesisMethod[D], inFile: String, outDir:  String, objectName: String, convert: D => E): Unit = {
    val synth = LASynthetizer (inFile, method, convert)
    val scalaHeaders = "import choosec.numbers._\nimport choosec.simplex._\nimport smartfloats._\nimport choosec.synthesis.NoSolutionException"
    synth.synthetizeToFile (scalaHeaders, outDir, objectName)
  }

  // Parse part of the command line: return the synthesis method, and two
  // booleans `useSmartFloat` and `useFloat`, which are true if we want to use
  // smart floats and floats respectively
  def parsecl (args: Array[String]): (LASynthesisMethod[Rational], Boolean, Boolean) = {
    // Some quick and dirty command line parsing. 
    val useSmartFloat = args.contains ("--smartfloat")
    val useFloat = args.contains ("--float")
    val MIXED_FM = "--mixedfm"
    val PURE_FM = "--purefm"
    val PURE_SIMPLEX = "--simplex"
    val MULTIPARAMETRIC = "--multiparametric"

    val matrix = Rational.rmat
    val field = matrix.field
    val solver = SimplexImpl (field, matrix)
    val mpsolver = MPSolver (solver)
    val method = {
      if (args.contains (PURE_FM))
	new FourierMotzkinSynthesis (field)
      else if (args.contains (MIXED_FM))
	new MixedFMSynthesis (field, matrix, solver)
      else if (args.contains (PURE_SIMPLEX))
	new PureSimplexSynthesis (field, matrix, solver)
      else if (args.contains (MULTIPARAMETRIC))
        new MultiparametricSynthesis (mpsolver)
      else
	new MixedSynthesis (field, matrix, solver)
    }

    (method, useSmartFloat, useFloat)
  }

  def main (args: Array[String]){
    // Some quick and dirty command line parsing.
    val (method, useSmartFloat, useFloat) = parsecl (args)

    val newArgs = args.filter (el => !el.startsWith ("--"))
    val (in: String, outDir: String, objectName: String) = {
      if (newArgs.length > 0){
        if (newArgs.length <= 1)
          (newArgs (0), "/tmp", "LATest")
        else {
          val path = newArgs (1)
          if (!path.contains ('/')){
            (newArgs (0), ".", path.takeWhile (c => c != '.'))
          }
          else {
            val split = path.reverse.span (c => c != '/')

            (newArgs (0), split._2.reverse, split._1.reverse.takeWhile (c => c != '.'))
          }
        }
      }
      else {
        println ("Error: please supply some input file")
        System.exit (1)
        ("","")
      }
    }
    
    if (useSmartFloat){
      synthetizerDemo (method, in, outDir, objectName, SmartFloatWrap.rationalToSmartFloatWrap)
    }
    else if (useFloat){
      synthetizerDemo (method, in, outDir, objectName, FloatWrap.rationalToFloatWrap)
    }
    else {
      synthetizerDemo (method, in, outDir, objectName)
    }
  }
}
