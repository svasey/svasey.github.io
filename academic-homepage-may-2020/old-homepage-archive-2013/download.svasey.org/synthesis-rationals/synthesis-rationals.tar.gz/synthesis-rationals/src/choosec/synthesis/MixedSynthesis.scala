package choosec
package synthesis

import trees.Formulas._
import trees.FormulaTransforms._
import trees.Constraint._
import code.SimpleAST
import code.SimpleAST.SimpleExpr
import code.SimpleAST.ErrorRes
import code.SimpleAST.UnboundedRes
import code.SimpleAST.UnfeasibleRes
import code.SimpleAST.MaximizedRes
import code.SimpleAST.uniqueID
import code.SimpleAST.HasSolution
import code.SimpleAST.IsFeasible
import code.SimpleAST.Block
import code.SimpleAST.Max
import code.SimpleAST.Val
import code.SimpleAST.If
import code.SimpleAST.GetSolution
import code.SimpleAST.Identifier
import code.SimpleType._
import numbers._
import simplex._


// Synthesis method that uses both Fourier Motzkin and the simplex method,
// choosing which is more convenient for each case
class MixedSynthesis[D <: ExpressibleOrderedField[D]] (fieldElem: D, matrixElem: Matrix[D], solverEl: SimplexSolver[D]) extends SimplexSynthesis[D] (fieldElem, matrixElem, solverEl) {

  val fmSynth = new FourierMotzkinSynthesis (field)

  // The returned pre-condition is true only if the problem is feasible and
  // bounded. However in general it is only a necessary condition for the
  // existence of a solution, no a sufficient one.
  override def synthetize (variables: Seq[Variable], formula: LAFormula[D],
                           goal: LinearCombination[D]): (LAFormula[D], SimpleExpr) = {
    val canonForm = canonicalDNF (eliminateQuantifiers (formula))
    println ("DEBUG: canonical form: " + canonForm)
    require (!hasUnknown (canonForm))

    // Put each conjunction in canonical form
    val problems = {
      canonForm match {
        case Or (forms) => forms.map (f => toFRProblem (variables, f, goal))
        case f @ _ => Set (toFRProblem (variables, f, goal))
      }
    }

    val (unboundedProb, boundedProb) = problems.partition (p => p.maybeUnbounded)
    // println ("DEBUG: unboundedProb: " + unboundedProb)
    // println ("DEBUG: boundedProb: " + boundedProb)
    
    if (boundedProb.isEmpty){
      // Avoid any synthesis: we already know the result
      (Rel (False), ErrorRes  ("Unbounded or unfeasible problem"))
    }
    else {
      // First synthetize the potentially unbounded conjunctions. In order for a
      // solution to exist, they must all be unfeasible.
      val (unboundedPre, unboundedCode) = synthetizeUnbounded (unboundedProb)
      // println ("DEBUG: unboundedPre: " + unboundedPre)
      // println ("DEBUG: unboundedCode: " + unboundedCode)

      if (unboundedPre != Rel (False)){
        val (boundedPre, boundedCode) = synthetizeBounded (boundedProb)
        // println ("DEBUG: boundedPre: " + boundedPre)
        // println ("DEBUG: boundedCode: " + boundedCode)

	val pre = simplify (And (boundedPre, unboundedPre))
	val code = {
	  // We still need to check that the thing is unbounded
	  if (hasUnknown (unboundedPre)){
	    val condName = uniqueID ("unboundedCond")
	    val condVal = Val (condName, unboundedCode, TBool, true)
	    Block (condVal, If (condName, boundedCode, UnboundedRes))
	  }
	  else {
	    boundedCode
	  }
	}
	(pre, code)
      }
      else {
        (Rel (False), UnboundedRes)
      }
    }

  }

  // Synthetize the part of the code dealing with potentially unbounded
  // problems. This should output a formula that is true iff all the problems
  // are unfeasible. The synthetized code should return a boolean that is true
  // if and only if all the problems are unfeasible (this includes the case
  // where `unboundedProb` is empty). The code may NOT assume the pre-condition
  // is true.
  def synthetizeUnbounded (unboundedProb: Set[FRProblem[D]]): (LAFormula[D], SimpleExpr) = {

    val synthetized = unboundedProb.map (prb => synthetizeFRProb (prb))
    // println ("DEBUG: synthetized:" + synthetized)
    if (synthetized.isEmpty){
      (Rel (True), SimpleAST.True)
    }
    else {
      val pre = simplify (And (synthetized.map (el => Not (el.constr.withoutVariables))))

      val code = {
        if (!hasUnknown (pre)){
          pre.toSimpleExpr
        }
        else {
          val toSynth = synthetized.filter (el => {
            simplify (el.constr.withoutVariables) != Rel (False)
          })
          assert (!toSynth.isEmpty)
          def genCode (cur: Set[FRProblem[D]]): SimpleExpr = {
            if (cur.isEmpty)
              SimpleAST.True
            else {
              val head = cur.head
              val tail = cur.tail
              val resName = uniqueID ("unboundedRes")
              val resVal = head.getCode
              val test = {
                If (SimpleAST.And (head.constr.withoutVariables.toSimpleExpr, IsFeasible (resName)),
                    SimpleAST.False,
                    genCode (tail))
              }
              Block (Val (resName, resVal, TResult), test)
            }
          }
          genCode (toSynth)
        }
      }
      (pre, code)
    }
  }

  // Try to sort the sequence of synthetized problem in order to minimize the
  // average computation time when we try to find a feasible problem, starting
  // with the first one.
  def sortSynthetized (toSort: Seq[(FRProblem[D], Identifier)]): Seq[(FRProblem[D], Identifier)] = {
    // FIXME: This can be improved
    def lt (pair1: (FRProblem[D], Identifier),
            pair2: (FRProblem[D], Identifier)): Boolean = {
      if (hasUnknown (pair2._1.constr.withoutVariables))
        true
      else if (hasUnknown (pair1._1.constr.withoutVariables))
        false
      else
        pair1._2.name < pair2._2.name
    }
    toSort.sortWith (lt)
  }

  // Synthetize the part of the code dealing with bounded problems. The outputed
  // formula should be true only if one problem has a feasible solution (so this
  // is only a necessary, not a sufficient, condition for existence of a maximal
  // solution). If the set of problem is empty, there is no solution.
  def synthetizeBounded (boundedProb: Set[FRProblem[D]]): (LAFormula[D], SimpleExpr) = {
    // require (!boundedProb.isEmpty)
    val zeroGoal = !boundedProb.isEmpty && boundedProb.head.maximize.isZero
    val synthetized = boundedProb.map (prb => synthetizeFRProb (prb)).filter (prb => prb.constr.withoutVariables != Rel (False) || prb.isSolved).toSeq
    // No solution
    if (synthetized.isEmpty){
      (Rel (False), ErrorRes ("No solution"))
    }
    // If everything has been solved, we can return the result right away
    else if (synthetized.forall (prb => prb.isSolved)){
      val finalProb = synthetized.foldLeft (synthetized.head) ((a, b) => {
	if (a.result.get < b.result.get) b else a
      })
      val finalRes = finalProb.result.get
      val pre = if (finalRes.hasSolution) finalProb.constr.withoutVariables else Rel (False):LAFormula[D]

      (pre, finalRes.toSimpleExpr)
    }
    else {
      val pre0 = simplify (Or (synthetized.map (el => el.constr.withoutVariables).toSet))
      val pre = {
	if (!zeroGoal && boundedProb.exists (prb => prb.hasStrictInequalities)){
	  // We don't really know what to expect, because of strict inequalities
          
          simplify (And (pre0, Unknown ()))
	}
	else pre0
      }
      val code = {
	if (pre == Rel (False)){
	  ErrorRes ("No solution")
	}
	else {
	  assert (!synthetized.isEmpty)
          def getCode (prb: FRProblem[D]): SimpleExpr = {
            // No need to check the pre-condition, as it is assumed to hold
            // beforehand.
            // FIXME: The general condition is `pre0 implies prbPre`. Write code
            // to approximate this quickly.
            // If the goal is zero, we use a slightly different approach (i.e we
            // check the condition beforehand), so we
            // do not have to check the pre-condition

            val prbPre = simplify (prb.constr.withoutVariables)
            // println ("DEBUG: getting code for problem:")
            // println (prb)
            if (zeroGoal || (prbPre == pre0)){
              prb.getCode
            }
            else {
              If (prbPre.toSimpleExpr, prb.getCode, UnfeasibleRes)
            }
          }
          val allNames = synthetized.map (prb => uniqueID ("result"))
          
          val useLazy = if (zeroGoal && !synthetized.tail.isEmpty) true else false
          
          val resVals = synthetized.zip (allNames).map (prbName => {
            Val (prbName._2, getCode (prbName._1), TResult, useLazy)
          }).toSeq

          val finalComputation = {
            val compute = {
              if (zeroGoal){
                val newSynthetized = sortSynthetized (synthetized.zip (allNames))
                def recGen (cur: Seq[(LAFormula[D],Identifier)]): SimpleExpr = {
                  require (!cur.isEmpty)
                  val (headPre, headID) = (simplify (cur.head._1), cur.head._2)
                  val tail = cur.tail

                  if (tail.isEmpty)
                    headID
                  else {
                    val ifCond = {
                      if (hasUnknown (headPre))
                        SimpleAST.And (headPre.toSimpleExpr,
                                       HasSolution (headID))
                      else
                        headPre.toSimpleExpr
                    }

                    If (ifCond, headID, recGen (tail))
                  }
                }
                recGen (newSynthetized.map (prbName => {
                  (prbName._1.constr.withoutVariables, prbName._2)
                }))
                                          
              }
              else {
                Max (allNames)
              }
            }
          
            compute
          }
          
          Block (resVals, finalComputation)
	}
      }
      
      (pre, code)
    }
  }

  def eliminateEqualities (problem: FRProblem[D]): FRProblem[D] = {
    if (problem.constr.nEq == 0){
      problem
    }
    else problem.constr match {
      case Constraints (pre, constrMatrix, nEq, nNonStrict, boundMatrix,
            variables, parameters) => {
        val (nVariables, nParameters) = (constrMatrix.nCols, boundMatrix.nCols)
        val fullEqMatrix = constrMatrix.getLines (1, nEq).appendRight (boundMatrix.getLines (1, nEq))
        val (_, rrMat, pivots) = fullEqMatrix.rowReduceWithPivots
        val varMatrix = rrMat.getCols (1, nVariables)
        val paramMatrix = rrMat.getCols (nVariables + 1, rrMat.nCols)
        val fullMatrix = {
          if (nEq == constrMatrix.nLines) rrMat
          else rrMat.appendBottom (constrMatrix.appendRight (boundMatrix).getLines (nEq + 1, constrMatrix.nLines))
        }.appendBottom (problem.maximize.transpose.appendRight (matrixEl.zero (1, boundMatrix.nCols)))
	val (varPivots, paramPivots) = pivots.partition (_ <= nVariables)
        val toRemove = variables.zipWithIndex.filter (vId => (varPivots.contains
                                                              (vId._2 + 1))).map (x => x._1).toSet
        val newPre = {
          if (paramPivots.isEmpty) Rel (True):LAFormula[D]
          else {
            val minPivot = paramPivots.min
            // Find the line of the pivot
            val firstLine = rrMat.nonZeroLine (minPivot).get
            And (List.range (firstLine, rrMat.nLines + 1).map (id => {
              assert (varMatrix.getLine (id).isZero)
              val lc = lineToLinearCombinationWithConstant (parameters,
                                                            paramMatrix, id)
              Rel (Equals (lc, LinearCombination (field.zero))):LAFormula[D]
            }).toSet)
          }
        }
        def genVal (column: Int): Val = {
          val pivotLine = rrMat.nonZeroLine (column).get
          val v = variables (column - 1)
          val asLC = {
            val varLC = lineToLinearCombination (variables, varMatrix, pivotLine).removeVariable (v).negate
            val paramLC = lineToLinearCombinationWithConstant (parameters,
                                                               paramMatrix, pivotLine)
            varLC.add (paramLC)
          }
          Val (Identifier (v.name), asLC.toSimpleExpr, TField)
        }
        val valList = varPivots.map (col => genVal (col)).toList
        val newFullMat = varPivots.foldLeft (fullMatrix) ((cur, col) => {
          cur.elimColumn (col)
        }).removeCols (varPivots)
        val newNVariables = nVariables - varPivots.size
        assert (newFullMat.nCols == newNVariables + nParameters)
        val newNonEq = {
          if (nEq == newFullMat.nLines - 1){
            newFullMat.zero (1, newFullMat.nCols)
          }
          else {
            newFullMat.getLines (nEq + 1, newFullMat.nLines - 1)
            // newFullMat.getLines (nEq + 1, newFullMat.nLines)
          }
        }
        val newConstr = {
          if (newNVariables == 0){
            newFullMat.zero (newNonEq.nLines, 1)
          }
	  else {
            newNonEq.getCols (1, newNVariables)
	  }
        }
        val newBound = newNonEq.getCols (newNVariables + 1, newNonEq.nCols)
        val newMaximize = {
	  if (newNVariables == 0){
	    newFullMat.zero (1,1)
	  }
	  else {
	    newFullMat.getLine (newFullMat.nLines).getCols (1, newNVariables).transpose
	  }
	}

	// println ("DEBUG: eliminating equalities from\n" + problem)
	// println ("DEBUG: toRemove: " + toRemove)
	// println ("DEBUG: newPre: " + newPre)

        val newProblem = problem.removeEq.setBound (newBound).removeVariables (toRemove, newConstr).pushCodeVal (valList).setPre (And (problem.constr.withoutVariables, newPre)).setMaximize (newMaximize)

	// println ("DEBUG: new problem:\n" + newProblem)

        assert (newProblem.checkDimensions)
        newProblem
      }
    }
  }

  // Use Fourier-Motzkin elimination to reduce the problem's size as much as
  // possible. If the variable list ends-up being zero in the return value,
  // this means that all constraints have been eliminated, and the only part of
  // the constraint that matters is the `withoutVariables` member.
  def partialFourierMotzkin (problem: FRProblem[D]): FRProblem[D] = {
    // Eliminate equalities
    val nextProblem = eliminateEqualities (problem)

    // FIXME: TODO
    // 
    // Eliminate some inequalities so that this does not add too many new ones
    // 
    
    // Remove zero lines
    nextProblem.cleanupZeroLines
  }

  // Synthetize code for the given problem. The code should return an
  // LPResult object. The pre-condition (in the `withoutVariables` member of the
  // returned object) should be true if and only if the problem has a
  // solution (if `problem.maybeUnbounded` is true, we take the maximize vector
  // to be zero, so that the pre-condition is true if and only if the problem is
  // feasible.)
  def synthetizeFRProb (problem: FRProblem[D]): FRProblem[D] = {
      if (problem.isSolved)
        problem
      else problem match {
        case FRProblem (constr, _, maximize, transformMatrix, maybeUnbounded, _,
                      allVariables) => {
          assert (constr.constrMatrix.isFullRank)
	  // println ("DEBUG: synthetizing problem " + problem)
          val maximizeV = if (maybeUnbounded) maximize.zero else maximize
          tryToSolve (constr, maximizeV, transformMatrix, maybeUnbounded) match {
            case Some (res) => {
              val hasSol = (maybeUnbounded && res.isFeasible) || res.hasSolution
              val pre:LAFormula[D] = if (hasSol) constr.withoutVariables else Rel (False)
              FRProblem (constr.setPre (pre), (List (), Some (res.toSimpleExpr)),
                         maximizeV, transformMatrix,
                         maybeUnbounded, Some (res), allVariables)
            }
            case None => {
              val newProblem = partialFourierMotzkin (problem.setMaximize (maximizeV))
              val (pre0, code0) = FMOrSimplex (newProblem)
	      // println ("DEBUG: pre0: " + pre0)
              // Simply generate code to transform back the result
              val resName = uniqueID ("synthProbRes")
              val resVal = Val (resName, code0, TResult)
              val code = {
                if (maybeUnbounded){
                  val test = {
                    If (IsFeasible (resName),
                        UnboundedRes,
                        resName)
                  }
                  (List (resVal), Some (test))
                }
                else {
                  val expandResult:Seq[Val] = {
                    newProblem.constr.variables.zipWithIndex.map (vId => {
                      Val (Identifier (vId._1.name),
                           GetSolution (resName, vId._2 + 1), TField)
                    })
                  }
                  val reconstruct:(Seq[Val], SimpleExpr) = {
                    val maximizeLC = LinearCombination (problem.constr.variables, problem.maximize)
                    val newBoundCode = maximizeLC.toSimpleExpr

                    val solName = uniqueID ("solV")
                    val newVariables = problem.allVariables.map (v => {
                      uniqueID (v.name + "_new")
                    })
                    val truncTransform = transformMatrix.getCols (1, problem.getNVariables)
                    assert (truncTransform.nLines == newVariables.length &&
                            truncTransform.nCols == problem.getNVariables)
                    val newVariablesBlock = newVariables.zipWithIndex.map (_ match {
                      case (newV, id) => {
                        val expr = LinearCombination (problem.constr.variables,
                                                      truncTransform.getLine (id + 1))
                        Val (newV, expr.toSimpleExpr, TField)
                      }
                    })

                    val res0 = MaximizedRes (newVariables, newBoundCode)
                    (newVariablesBlock, res0)
                  }
                  val finalBlock = Block (expandResult ++
                                          newProblem.codeStack._1 ++
                                          reconstruct._1, reconstruct._2)
                  val test = If (HasSolution (resName), finalBlock, resName)

                  (List (resVal), Some (test))
                }
              }

              val pre = And (pre0, newProblem.constr.withoutVariables)
	      // println ("DEBUG: final pre: " + pre)
              FRProblem (newProblem.constr.setPre (pre), code,
                         maximizeV, transformMatrix, maybeUnbounded, None, allVariables)
            }
          }
        }
      }
  }
  
  // Try to guess when it is suitable to use the Fourier-Motzkin method, and
  // when it is not. Return true if it is, false otherwise.
  def canUseFM (matrix: Matrix[D], bound: List[LinearCombination[D]],
                maximize: Matrix[D], nNonStrict: Int): Boolean = {
    // FIXME: This can be improved...
    val MAX_M = 8
    val MAX_N = 4
    matrix.nLines <= MAX_M && matrix.nCols <= MAX_N
  }
  
  // If possible, use Fourier-Motzkin to synthetize the given problem. If this
  // is not possible (i.e too costly), return None.
  def tryFourierMotzkin (matrix: Matrix[D], bound: List[LinearCombination[D]], maximize: Matrix[D], nNonStrict: Int): Option[(LAFormula[D], SimpleExpr)] = {
    if (matrix.isZero || canUseFM (matrix, bound, maximize, nNonStrict)){
      Some (fmSynth.synthetize (matrix, bound, maximize, nNonStrict))
    }
    else
      None
  }

  // Synthetize using either the simplex or the Fourier-Motzkin method.
  def FMOrSimplex (problem: FRProblem[D]): (LAFormula[D], SimpleExpr) = problem match {
    case FRProblem (constr, _, maximize, _, _, _, _) => {
      // FIXME: Better fourier-motzkin elimination not dependent on LinearCombination
      val (matrix, nNonStrict, bound) = constr.ineqMatrixWithBound
      tryFourierMotzkin (matrix, bound, maximize, nNonStrict) match {
        case Some (synthRes) => synthRes
        case None => {
          // Use the simplex method
	  require (!matrix.isZero)
          synthetizeMixedLP_FR (matrix, maximize, bound, nNonStrict)
        }
      }
    }
  }

  protected def toFRProblem (variables: Seq[Variable], formula: LAFormula[D],
                             goal: LinearCombination[D]): FRProblem[D] = {
    FRProblem (solver, variables, formula, goal)
  }
}

object RMixedSynthesis extends MixedSynthesis[Rational] (Rational.r, Rational.rmat, SimplexImpl[Rational] (Rational.r, Rational.rmat))

object FloatMixedSynthesis extends MixedSynthesis[SmartFloatWrap] (SmartFloatWrap.r, SmartFloatWrap.rmat, SimplexImpl[SmartFloatWrap] (SmartFloatWrap.r, SmartFloatWrap.rmat))
