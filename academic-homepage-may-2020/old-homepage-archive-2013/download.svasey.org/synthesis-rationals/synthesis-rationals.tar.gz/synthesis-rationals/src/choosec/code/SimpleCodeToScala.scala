package choosec
package code

import trees.ScalaCode
import trees.ScalaCode.uniqueIdentifier
import trees.ScalaCode.intSeqCode
import trees.ScalaCode.DotExpr
import trees.ScalaCode.Apply
import trees.ScalaCode.IntLit
import trees.ScalaCode.errorCode
import trees.ScalaCode.noSolutionError
import trees.ScalaCode.seqCode
import SimpleAST._
import SimpleType._
import SimpleSymbols._
import Optimization._
import numbers._
import simplex._
  
// Convert simple code to scala
object SimpleCodeToScala {
  type SVal = ScalaCode.Val
  type SIdentifier = ScalaCode.Identifier
  
  class ConstantToID[D <: ExpressibleOrderedField[D]] (val fieldMap: Map[D, SVal], val matrixMap: Map[Matrix[D], SVal], val otherMap: Map[Any, SVal], resultMap: Map[Result, SVal], val dummySolver: Option[SVal]) {
    // Add an element to a map, but do not change the map if the key is already
    // in the map.
    private def mapAdd[A,B] (map: Map[A,B], key: A, value: B): Map[A,B] = {
      if (map.contains (key))
        map
      else
        map + ((key, value))
    }
  
    
    def addFieldEl (el: D, v: SVal): ConstantToID[D] = {
      ConstantToID (mapAdd (fieldMap, el, v), matrixMap, otherMap, resultMap, dummySolver)
    }
    def addMatrixEl (el: Matrix[D], v: SVal): ConstantToID[D] = {
      ConstantToID (fieldMap, mapAdd (matrixMap, el, v), otherMap, resultMap, dummySolver)
    }
    def addOtherEl (el: Any, v: SVal): ConstantToID[D] = {
      ConstantToID (fieldMap, matrixMap, mapAdd (otherMap, el, v), resultMap, dummySolver)
    }
    def addResultEl (el: Result, v: SVal): ConstantToID[D] = {
      ConstantToID (fieldMap, matrixMap, otherMap, mapAdd (resultMap,el, v), dummySolver)
    }
    def addDummySolver (v: SVal): ConstantToID[D] = {
      if (hasDummySolver)
        this
      else
        ConstantToID (fieldMap, matrixMap, otherMap, resultMap, Some (v))
    }

    def containsFieldEl (el: D): Boolean = fieldMap.contains (el)
    def getFieldID (el: D): SIdentifier = {
      require (fieldMap.contains (el))
      fieldMap (el).id
    }
    def containsResult (el: Result): Boolean = resultMap.contains (el)
    def getResultID (el: Result): SIdentifier = {
      require (resultMap.contains (el))
      resultMap (el).id
    }

    def containsOtherEl (el: Any): Boolean = otherMap.contains (el)
    def getOtherID (el: Any): SIdentifier = {
      require (otherMap.contains (el))
      otherMap (el).id
    }

    def containsMatrix (el: Matrix[D]): Boolean = matrixMap.contains (el)
    def getMatrixID (el: Matrix[D]): SIdentifier = {
      require (matrixMap.contains (el))
      matrixMap (el).id
    }

    def hasDummySolver: Boolean = !dummySolver.isEmpty
    def getDummySolverID: SIdentifier = {
      require (hasDummySolver)
      dummySolver.get.id
    }

    def getCode: Seq[SVal] = {
      val first = fieldMap.values.toSeq ++ matrixMap.values.toSeq ++ otherMap.values.toSeq ++ resultMap.values.toSeq
      if (dummySolver.isEmpty)
        first
      else
        first ++ Seq (dummySolver.get)
    }
  }
  object ConstantToID {
    def apply[D <: ExpressibleOrderedField[D]] (fieldMap: Map[D, SVal], matrixMap: Map[Matrix[D], SVal], otherMap: Map[Any, SVal], resultMap: Map[Result, SVal], dummySolver:Option[SVal]) = {
      new ConstantToID[D] (fieldMap, matrixMap, otherMap, resultMap, dummySolver)
    }
  }

  // Flatten block definitions, so that if a block returns a block, the two will
  // get put together in a single block (variables are not renamed, we assume
  // they share different names)
  def flattenBlocks (expr: SimpleExpr): SimpleExpr = {
    // Note: flattened is in reverse order
    def flattenVals (flattened: Seq[Val], current: Seq[Val]): Seq[Val] = {
      if (current.isEmpty)
	flattened
      else {
	val head = current.head
	current.head.expr match {
	  case Block (decls, ret) => {
	    require (!flattened.exists (v => decls.exists (v2 => v.id == v2.id)))
	    val newDecls = {
	      if (head.useLazy)
		decls.map (d => Val (d.id, d.expr, d.typ, true))
	      else
		decls
	    }
	      
	    flattenVals (Val (head.id, ret, head.typ, head.useLazy) +: (newDecls.reverse ++ flattened), current.tail)
	  }
	  case _ => flattenVals (head +: flattened, current.tail)
	}
      }
    }
    
    def flatten (b: SimpleExpr): SimpleExpr = b match {
      case Block (vals, ret) => {
	if (vals.isEmpty){
	  ret
	}
	else {
	  val newVals = flattenVals (List (), vals).reverse
	  ret match {
            case bl : Block => {
              val newBlock = flattenBlocks (bl).asInstanceOf[Block]
              require (newVals.forall (v => !newBlock.vals.exists (v2 => v2.id == v.id)))
              Block (newVals ++ newBlock.vals, newBlock.ret)
            }
            case _ => Block (newVals, ret)
	  }
	}
      }
      case _ => b
    }

    runTransform (flatten, expr)
  }
  def convertFieldEl[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]] (expr: SimpleExpr, conv: D => E): SimpleExpr = {
    def transf (e: SimpleExpr): SimpleExpr = e match {
      case CallSolver (solver, initialRoof, roofMatrix, inverseRoofMatrix, canBeUnbounded,
		       nNonStrict, bound) => {
	CallSolver (solver.asInstanceOf[SimplexSolver[D]].convert[E] (conv), initialRoof, roofMatrix.asInstanceOf[Matrix[D]].convert[E] (conv),
		    inverseRoofMatrix.asInstanceOf[Matrix[D]].convert[E] (conv), canBeUnbounded, nNonStrict, bound)
      }
      case SetBound (res, maximize) =>
	SetBound (res, maximize.asInstanceOf[Matrix[D]].convert[E] (conv))
      case MultiplySol (res, matrix) =>
	MultiplySol (res, matrix.asInstanceOf[Matrix[D]].convert[E] (conv))
      case FieldEl (el) => {
	FieldEl[E] (conv (el.asInstanceOf[D]))
      }
      case _ => e
    }
    runTransform (transf, expr)
  }

  // `constEl` is some simple expression to be used where we don't care about
  // the value of an expression.
  def optimize[D <: ExpressibleOrderedField[D]] (expr: SimpleExpr, constEl: SimpleExpr, field: D): (SimpleExpr, Boolean) = {
    require (constEl.isTyped)
    val MAX_TIME = 8192
    println ("DEBUG: Optimizing the synthetized code (will run for at most "
	     + MAX_TIME / 1000.0 + " secs)")
    def iter (exp: SimpleExpr): SimpleExpr = doSymbolicComputations (field) (constantPropagation (flattenBlocks (removeDeadBranches (exp))))
    val newExpr = fixpoint (iter, expr, MAX_TIME)
    // Check whether the results can be outputed as list or not
    if (useListOutput (newExpr)){
      (fixpoint (iter, transformForListOutput (newExpr, constEl), MAX_TIME), true)
    }
    else
      (newExpr, false)
  }
  
  def preProcess[D <: ExpressibleOrderedField[D], E <:  ExpressibleOrderedField[E]] (externalVariables: Traversable[Identifier], expr: SimpleExpr, field: D, conv: D => E): (SimpleExpr, Boolean) = {
    typecheck (attachSymbols (externalVariables, expr), TResult)
    val (newExpr, listOutput) = optimize (expr, FieldEl (field).setType (TField), field)
    // Convert field elements
    // expr
    (convertFieldEl (newExpr, conv), listOutput)
  }

  // Try to save space by initiating a val for each constant appearing in the
  // program. 
  def collectConstants[D <: ExpressibleOrderedField[D]] (field: D, expr: SimpleExpr): ConstantToID[D] = {

    def recCollect (exprs: Traversable[SimpleExpr], cur: ConstantToID[D]): ConstantToID[D] = {

      if (exprs.isEmpty){
        cur
      }
      else {
        val next = collect (exprs.head, cur)
        recCollect (exprs.tail, next)
      }
    }

    def addFieldEl (r: D, cur: ConstantToID[D]): ConstantToID[D] = {
      if (cur.containsFieldEl (r))
        cur
      else {
        val id = uniqueIdentifier (r.shortString)
        val newCode = ScalaCode.Val (id,  r.toScalaCode, Some (r.getType))
        cur.addFieldEl (r, newCode)
      }
    }

    def addResult (res: Result, cur: ConstantToID[D]): ConstantToID[D] = {
      val next = addFieldEl (field.asInstanceOf[D], cur)
      val fieldID = next.getFieldID (field.asInstanceOf[D])

      
      val (idStr, resEl) = {
        res match {
          case UnboundedRes => ("res_unbounded", UnboundedLPRes (field))
          case UnfeasibleRes => ("res_unfeasible", UnfeasibleLPRes (field))
          case _ => error ("Unexpected result type")
        }
      }
      val id = uniqueIdentifier (idStr)
      
      next.addResultEl (res, ScalaCode.Val (id, resEl.toScalaCode (fieldID),
                                            Some (resEl.getType)))
    }

    def addMatrix (mat: Matrix[D], cur: ConstantToID[D]): ConstantToID[D] = {

      val next = mat.toList.foldLeft (cur) ((c, r) => addFieldEl (r, c))

      val matrixCode = mat.toScalaCode (el => next.getFieldID (el))
      val id = uniqueIdentifier (mat.shortString)

      next.addMatrixEl (mat, ScalaCode.Val (id, matrixCode, Some (mat.getType)))
    }

    def collect (e: SimpleExpr, cur: ConstantToID[D]): ConstantToID[D] = e match {
      case If (cond, then, els) => recCollect (Seq (cond, then, els),
                                               cur)
      case Plus (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)
      case Minus (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)
      case Times (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)
      // case DividedBy (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)
      case Max (exprs) => recCollect (exprs, cur)
      case Min (exprs) => recCollect (exprs, cur)
      case UpTo (from, to) => recCollect (Seq (from, to), cur)
      case Lt (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)
      case LtEq (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)
      case Eq (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)      
      case And (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)      
      case Or (lhs, rhs) => recCollect (Seq (lhs, rhs), cur)      
      case Not (expr) => collect (expr, cur)
      case MaximizedRes (sol, bound) => recCollect (bound +: sol, cur)
      case BoundedRes (bound) => collect (bound, cur)
      case IsFeasible (res) => collect (res, cur)
      case HasSolution (res) => collect (res, cur)
      case GetSolution (res, _) => collect (res, cur)
      case SetBound (res, maximize) => {
        val next = collect (res, cur)
        addMatrix (maximize.asInstanceOf[Matrix[D]], next)
      }
      case MultiplySol (res, matrix) => {
        val next = collect (res, cur)
        addMatrix (matrix.asInstanceOf[Matrix[D]], next)
      }
      case GetBound (res) => collect (res, cur)
      case Block (vals, ret) => recCollect (ret +: vals.map (x => x.expr), cur)
      case el @ FieldEl (value) => addFieldEl (value.asInstanceOf[D], cur)
      case el @ UnboundedRes => addResult (el, cur)
      case el @ UnfeasibleRes => addResult (el, cur)
      case CallSolver (solver, initialRoof, roofMatrix,
                       inverseRoofMatrix, canBeUnbounded,
                       nNonStrict, bound) => {
        val next = recCollect (bound, cur)

        val next2 = addMatrix (roofMatrix.asInstanceOf[Matrix[D]], addMatrix (inverseRoofMatrix.asInstanceOf[Matrix[D]], next))

        // Since we anyway have to initialize the bounds before launching the
        // solver, we just initialize the matrices
        val next3 = addMatrix (solver.matrix.asInstanceOf[Matrix[D]], addMatrix (solver.maximize.asInstanceOf[Matrix[D]], next2))

        // And the initial roof
        val id = uniqueIdentifier ("roof")
        val code = intSeqCode ("List", initialRoof)
        val next4 = next3.addOtherEl (initialRoof, ScalaCode.Val (id, code, Some (ScalaCode.Type ("Seq[Int]"))))

        // And a dummy solver
        val mat = solver.matrix.asInstanceOf[Matrix[D]].zero (1)
        val next5 = addMatrix (mat, next4)
        val matID = next5.getMatrixID (mat)
        val solverID = uniqueIdentifier ("dummySolver")
        next5.addDummySolver (ScalaCode.Val (solverID, solver.toScalaCodeDummy (matID), Some (solver.getType)))
      }
      case True | False | Identifier (_) | ErrorRes (_) => cur
    }
    collect (expr, ConstantToID (Map (), Map (), Map (), Map (), None))
  }



  def getOptimalCode (expr: ScalaCode.Expr): ScalaCode.Expr = {
    DotExpr (DotExpr (expr,
		      ScalaCode.Identifier ("optimalVector"), List ()),
	     ScalaCode.Identifier ("toList"), List ())
  }

  def toScala[D <: ExpressibleOrderedField[D]]  (solver: SimplexSolver[D],
    externalVariables: Traversable[Identifier], expr: SimpleExpr): (ScalaCode.Expr, Seq[ScalaCode.Expr]) = {
    toScala[D,D] (solver, externalVariables, expr, (d:D) => d)
  }  
  // Convert the given expression to scala code that uses element of the field E
  // instead of D, using the given conversion function. Also return the list of
  // global declarations to be used.
  def toScala[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]]
    (inSolver: SimplexSolver[D], externalVariables: Traversable[Identifier],
    expr: SimpleExpr, convert: D => E): (ScalaCode.Expr, Seq[ScalaCode.Expr]) = {

    val solver = inSolver.convert (convert)
    val field = solver.field
    val matrix = solver.matrix
    val (newExpr, useList) = preProcess[D,E] (externalVariables, expr,
					      inSolver.field.asInstanceOf[D], convert)
    val constants = collectConstants (field, newExpr)
    val constantCode = constants.getCode

    def minMax (name: String, exprs: Seq[SimpleExpr]): ScalaCode.Expr = {
      assert (!exprs.isEmpty)
      if (exprs.tail.isEmpty)
        recToScala (exprs.head)
      else {
	val typeStr = {
	  if (exprs.head.getType == TResult) "LPResult[" + field.getType + "]"
	  else if (exprs.head.getType == TField) field.getType
	  else {assert (false); ""}
	}
        DotExpr (seqCode ("List[" + typeStr + "]", exprs.map (el => recToScala (el))),
                 ScalaCode.Identifier (name), List())
      }
    }

    // toList is true iff the results must be outputed as a list.
    def recToScala (expr: SimpleExpr, toList: Boolean = false): ScalaCode.Expr = expr match {
      case If (cond, then, els) => {
        ScalaCode.If (recToScala (cond), recToScala (then, toList),
                      Some (recToScala (els, toList)))
      }
      case Plus (lhs, rhs) => ScalaCode.Plus (recToScala (lhs), recToScala (rhs))
      case Minus (lhs, rhs) => ScalaCode.Minus (recToScala (lhs), recToScala (rhs)) 
      case Times (lhs, rhs) => ScalaCode.Times (recToScala (lhs), recToScala (rhs))
      // case DividedBy (lhs, rhs) => ScalaCode.DividedBy (recToScala (lhs), recToScala (rhs))

      case Max (exprs) => minMax ("max", exprs)
      case Min (exprs) => minMax ("min", exprs)
      case UpTo (from, to) => DotExpr (recToScala (from), ScalaCode.Identifier ("upTo"),
                                       List (recToScala (to)))
      case Lt (lhs, rhs) => ScalaCode.Lt (recToScala (lhs), recToScala (rhs))
      case LtEq (lhs, rhs) => ScalaCode.LtEq (recToScala (lhs), recToScala (rhs))
      case Eq (lhs, rhs) => ScalaCode.Equals (recToScala (lhs), recToScala (rhs))

      case And (lhs, rhs) => ScalaCode.And (recToScala (lhs), recToScala (rhs))
      case Or (lhs, rhs) => ScalaCode.Or (recToScala (lhs), recToScala (rhs))
      case Not (e) => ScalaCode.Not (recToScala (e))
      case True => ScalaCode.True
      case False => ScalaCode.False
      case MaximizedRes (sol, bound) => {
	if (toList){
	  seqCode ("List", sol.map (el => recToScala (el)))
	}
	else {
          val solCode = matrix.toScalaCodeCol (sol.map (el => recToScala (el)))
          val boundCode = recToScala (bound)
          Apply (ScalaCode.Identifier ("MaximizedLPRes"), List (boundCode,
								solCode))
	}
      }
      case BoundedRes (bound) => {
	assert (!toList, "BoundedRes should have been transformed to error")
        val boundCode = recToScala (bound)
        Apply (ScalaCode.Identifier ("BoundedLPRes"), List (boundCode))
      }
      case ErrorRes (msg) => {
        noSolutionError (msg)
      }
      case el @ UnboundedRes => assert (!toList);  constants.getResultID (el)
      case el @ UnfeasibleRes => assert (!toList); constants.getResultID (el)
      case IsFeasible (res) =>
        DotExpr (recToScala (res), ScalaCode.Identifier ("isFeasible"), List ())
      case HasSolution (res) =>
        DotExpr (recToScala (res), ScalaCode.Identifier ("hasSolution"), List ())
      case GetSolution (res, id) => {
        val getSol = DotExpr (recToScala (res), ScalaCode.Identifier ("optimalVector"), List ())
        DotExpr (getSol, ScalaCode.Identifier ("get"), List (IntLit (id), IntLit (1)))
      }
      case SetBound (res, maximize) => {
	assert (!toList, "SetBound should have been eliminated")
        val maximizeID = constants.getMatrixID (maximize.asInstanceOf[Matrix[E]])
        DotExpr (recToScala (res), ScalaCode.Identifier ("setBound"),
                 List (maximizeID))
      }
      case MultiplySol (res, matrix) => {
        val matrixID = constants.getMatrixID (matrix.asInstanceOf[Matrix[E]])
	val multCode = DotExpr (recToScala (res), ScalaCode.Identifier ("multiplySol"),
				   List (matrixID))
	if (toList){
	  DotExpr (DotExpr (multCode,
			    ScalaCode.Identifier ("optimalVector"), List ()),
		   ScalaCode.Identifier ("toList"), List ())
	}
	else
	  multCode
      }
      case GetBound (res) =>
        DotExpr (recToScala (res), ScalaCode.Identifier ("leastUpperBound"), List ())
      case FieldEl (value) => constants.getFieldID (value.asInstanceOf[E])
      case id @ Identifier (name) => {
	assert (!toList)
	ScalaCode.Identifier (name)
      }

      case CallSolver (solver, initialRoof, roofMatrix, inverseRoofMatrix, _,
                       nNonStrict, bound) => {
	assert (!toList)
        val initialRoofID = constants.getOtherID (initialRoof)
        val roofMatrixID = constants.getMatrixID (roofMatrix.asInstanceOf[Matrix[E]])
        val inverseRoofMatrixID = constants.getMatrixID (inverseRoofMatrix.asInstanceOf[Matrix[E]])
        val boundCode = matrix.toScalaCodeCol (bound.map (el => recToScala (el)))
        val n = IntLit (nNonStrict)
        val matrixCode = constants.getMatrixID (solver.matrix.asInstanceOf[Matrix[E]])
        val maximizeCode = constants.getMatrixID (solver.maximize.asInstanceOf[Matrix[E]])
        val dummySolver = constants.getDummySolverID
        val solverCode = DotExpr (dummySolver, ScalaCode.Identifier ("init"),
                                  List (matrixCode, maximizeCode, boundCode))
        DotExpr (solverCode, ScalaCode.Identifier ("simplexWithStrict"),
                 List (initialRoofID, roofMatrixID, inverseRoofMatrixID, n))
      }
      case Block (vals, ret) => {
        val retCode = recToScala (ret, toList)
        val scalaVal = vals.map (el => {
          ScalaCode.Val (ScalaCode.Identifier (el.id.name), recToScala (el.expr),
                         Some (toScalaType (field, el.typ)), el.useLazy)
        })
        ScalaCode.Block (scalaVal :+ retCode)                                 
      }
    }
    

    val code = {
      if (useList){
	List (recToScala (newExpr, true))
      }
      else {
	val resCode = recToScala (newExpr)
	val resID = uniqueIdentifier ("finalRes")
	val resVal = ScalaCode.Val (resID, resCode, Some (toScalaType (field, TResult)))
	// Check if we are sure the problem has a solution
	val hasSolution = getPossibleResults (newExpr, Map ()).forall (r => r match {
	  case MaximizedRes (_, _) | ErrorRes (_) => true
	  case _ => false
	})
	val resToList =  DotExpr (DotExpr (resID, ScalaCode.Identifier ("optimalVector"), List ()),
				  ScalaCode.Identifier ("toList"), List ())
	
	val test = {
	  ScalaCode.If (DotExpr (resID, ScalaCode.Identifier ("hasSolution"), List ()), 
			resToList,
			Some (noSolutionError (DotExpr (resID, ScalaCode.Identifier ("toString"), List ()))))
	}
	if (hasSolution) List (resVal, resToList) else List (resVal, test)
      }
    }
    (ScalaCode.Block (code), constantCode)
  }
}
