package choosec
package code

import SimpleAST._
import trees.ScalaCode
import numbers._

object SimpleType {
  def toScalaType[D <: ExpressibleOrderedField[D]] (field: D, typ: Type): ScalaCode.Type = typ match {
    case TUntyped | TError => ScalaCode.Type ("Any")
    case TResult => ScalaCode.Type ("LPResult[" ++ field.getType.toString ++ "]")
    case TBool => ScalaCode.Type ("Boolean")
    case TField => field.getType
  }
  
  trait Type 

  case object TUntyped extends Type 
  case object TError extends Type 

  case object TResult extends Type 
  case object TBool extends Type
  case object TField extends Type

  trait Typed {
    self =>

    private var _typ: Type = TUntyped
    private var _possibleRes: Set[Result] = Set ()

    def setType (tpe: Type): self.type = {
      _typ = tpe; this
    }
    def isTyped: Boolean = this.getType != TUntyped && this.getType != TError
    def getType: Type = _typ
    def copyType (e: Typed): self.type = {
      this.setType (e.getType)
    }
    // def setPossibleRes (res: Result): self.type = {
    //   setPossibleRes (Set (res))
    // }
    // def setPossibleRes (res: Set[Result]): self.type = {
    //   // println ("DEBUG: setting possible result of " + this + " to " + res)
    //   _possibleRes = res
    //   this
    // }
    // def getPossibleRes: Set[Result] = _possibleRes
    // def hasPossibleRes: Boolean = !_possibleRes.isEmpty
  }

  // Typecheck an expression (that has already all its symbols attached). Attach
  // all the necessary types, and return the type of the expression. `exp`
  // contains the types the user expects
  def typecheck (e: SimpleExpr, exp: Type*): Type =
    typecheck2 (e, exp)

  def typecheck2 (e: SimpleExpr, exp: Seq[Type]): Type = {
    def typecheck0 (expr: SimpleExpr): Type = {
      def tcArith (lhs: SimpleExpr, rhs: SimpleExpr): Type = {
        typecheck (lhs, TField)
        typecheck (rhs, TField)
        TField
      }
      def tcArithRel (lhs: SimpleExpr, rhs: SimpleExpr): Type = {
        typecheck (lhs, TField)
        typecheck (rhs, TField)
        TBool
      }
      def tcBoolRel (lhs: SimpleExpr, rhs: SimpleExpr): Type = {
        typecheck (lhs, TBool)
        typecheck (rhs, TBool)
        TBool
      }
      def tcMinMax (exprs: Seq[SimpleExpr]): Type = {
        val types = exprs.map (e => typecheck (e, TField, TResult))
        if (types.forall (t => t == TResult))
          TResult
        else if (types.forall (t => t == TField))
          TField
        else {
          assert (false, "Min or max of elements of different type")
          TError
        }
      }
      
      expr match {
        case If (cond, then, els) => {
          typecheck (cond, TBool)
          val t = typecheck2 (then, exp)
          typecheck (els, t)
        }
        case Plus (lhs, rhs) => tcArith (lhs, rhs)
        case Minus (lhs, rhs) => tcArith (lhs, rhs)
        case Times (lhs, rhs) => tcArith (lhs, rhs)
        // case DividedBy (lhs, rhs) => tcArith (lhs, rhs)
        case Lt (lhs, rhs) => tcArithRel (lhs, rhs)
        case LtEq (lhs, rhs) => tcArithRel (lhs, rhs)
        case Eq (lhs, rhs) => tcArithRel (lhs, rhs)
        case And (lhs, rhs) => tcBoolRel (lhs, rhs)
        case Or (lhs, rhs) => tcBoolRel (lhs, rhs)
        case Not (e) => typecheck (e, TBool); TBool
        case Max (exprs) => tcMinMax (exprs)
        case Min (exprs) => tcMinMax (exprs)
        case UpTo (from, to) => tcArith (from, to)
        case MaximizedRes (sol, bound) => {
          sol.foreach (s => typecheck (s, TField))
          typecheck (bound, TField)
          TResult
        }
        case BoundedRes (bound) => typecheck (bound, TField); TResult
        case IsFeasible (res) => typecheck (res, TResult); TBool
        case HasSolution (res) => typecheck (res, TResult); TBool
        case GetSolution (res, _) => typecheck (res, TResult); TField
        case SetBound (res, _) => typecheck (res, TResult)
        case MultiplySol (res, _) => typecheck (res, TResult);
        case GetBound (res) => typecheck (res, TResult); TField
        case id @ Identifier (name) => id.getType
        case CallSolver (_, _, _, _, _, _, bound) => {
          bound.foreach (b => typecheck (b, TField))
          TResult
        }
        case Block (vals, ret) => {
          vals.foreach (v => typecheck (v.expr, v.typ))
          typecheck2 (ret, exp)
        }
        case True | False => TBool
        case UnboundedRes | UnfeasibleRes | ErrorRes (_) => TResult
        case FieldEl (_) => TField
      }
    }
    val t = typecheck0 (e)
    e.setType (t)
    assert (exp.contains (t), "Unexpected type: " + t + "; expected " + exp +
            "\n" + "Expression: " + e)
    t
  }
}
