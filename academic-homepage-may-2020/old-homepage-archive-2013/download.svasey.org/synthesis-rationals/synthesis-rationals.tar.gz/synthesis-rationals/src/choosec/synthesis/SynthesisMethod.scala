package choosec
package synthesis

import trees.Formulas._
import trees.FormulaTransforms._
import code.SimpleAST.SimpleExpr
import code.SimpleAST.MaximizedRes
import code.SimpleAST.Identifier
import code.SimpleAST.Val
import code.SimpleAST.GetSolution
import code.SimpleAST.uniqueID
import code.SimpleAST.Block
import code.SimpleAST
import code.SimpleType._
import simplex._
import numbers._
  
trait SynthesisMethod[F <: Function, R <: Relation] {
  // Synthetize code for the given formula. The returned formula must be a
  // formula without the given variables that is true if and only if the
  // original formula is satisfiable.
  // 
  // This implements conversion to DNF and only needs a synthesis method for
  // conjunctions. It is of course possible to override that method if something
  // more efficient is needed.
  def synthetize (variables: Seq[Variable],
        	  formula: Formula[F,R]): (Formula[F,R], SimpleExpr) = {

    def recSynth (form: Formula[F,R]): (Formula[F,R], SimpleExpr) = {
      form match {
        case f @ Or (_) => {
	  // FIXME: maybe try to somehow sort the formulas beforehand ? 
	  val (lhs, rhs) = recSplit (f)
          val (preL, computeL) = recSynth (lhs)
          val simplifiedL = simplify (preL)
          // Try to get rid of useless branches
          if (simplifiedL == Rel (True)){
            (preL, computeL)
          }
          else {
            val (preR, computeR) = recSynth (rhs)
            if (simplifiedL == Rel (False)){
              (preR, computeR)
            }
            else {
              val pre = Or (preL, preR)
              val code = SimpleAST.If (simplifiedL.toSimpleExpr,
                                       computeL, computeR)
	        (pre, code)
            }
          }
        }
        case Quantifier (_, _, _) =>
	  synthetize (variables, eliminateQuantifiers (form))
        case _ => {
          // println ("DEBUG: synthetizing conjunction: " + form)
          synthetizeConj (variables, form)
        }
      }
    }
    val canonicalForm = canonicalDNF (formula)
    // println ("DEBUG: synthetizing canonical form: " + canonicalForm)
    require (!hasUnknown (canonicalForm))

    recSynth (canonicalForm)
  }
  

  // Given a formula in prenex form, return an equivalent quantifier-free
  // formula [not necessarily in canonical form]
  def eliminateQuantifiers (formula: Formula[F,R]): Formula[F,R] = formula match {
    case Quantifier (variable, typ, form) => typ match {
      case Existential => synthetize (List (variable), form)._1
      case Universal => Not (synthetize (List (variable), Not (form))._1)
    }
    case _ => formula
  }

  // Try to reduce the formula to one of smaller size
  def simplify (formula: Formula[F,R]): Formula[F,R] = {
    formula
  }

  // Convert the formula to disjunctive normal form, doing any) theory-specific
  // transformation needed so that the synthetizeConj algorithm can work without any trouble.
  def canonicalDNF (formula: Formula[F,R]): Formula[F,R] = {
    simplify (disjunctiveNormalForm (prenexForm (negationNormalForm (formula))))
  }

  // Do synthesis for several variables based on a procedure synt that does
  // synthesis for a single variable.
  def synthetizeMultiVariables (variables: Seq[Variable],
				formula: Formula[F,R],
				synt: ((Variable, Formula[F,R]) => (Formula[F,R], SimpleExpr))):
  (Formula[F,R], SimpleExpr) = {
    // Generate code of the form val x_1 = ... ; val x_2 = ...  for each variable in vars.
    def synthetizeMultiVariables0 (vars: Seq[Variable], form: Formula[F,R]): (Formula[F,R], Seq[Val]) = {
      if (vars.isEmpty){
        (form, Seq ())
      }
      else {
        val head = vars.head
        val tail = vars.tail
        val (preHead, computeHead) = synt (head, form)
        val (preTail, tailList) = synthetizeMultiVariables0 (tail, preHead)
        (preTail, tailList :+ Val (Identifier (head.name), computeHead, TField))
      }
    }
    
    require (!variables.isEmpty)
    val (pre, valList) = synthetizeMultiVariables0 (variables, formula)
    // The bound does not matter here
    val bound = valList.head.id
    (pre, Block (valList, MaximizedRes (valList.reverse.map (v => v.id), bound)))
  }

  // Do synthesis for a formula which is a conjunction, in canonical form (c.f `canonicalDNF`)
  def synthetizeConj (variables: Seq[Variable], formula: Formula[F,R]): (Formula[F,R], SimpleExpr)
}

trait LASynthesisMethod[D <: ExpressibleOrderedField[D]] extends SynthesisMethod[LAFunction[D], ArithmeticRelation] {
  // Element of the field, used to e.g get the zero element.
  val field: D

  // Return the simplex solver used to solve the constraints. If no solver is
  // used, simply initialize a dummy solver
  def simplexSolver: SimplexSolver[D] = {
    SimplexImpl (BaseMatrix.colV (field))
  }
  // Return code that sets `size` variables to zero. Useful when we have found
  // that no solutions exist
  // def zeroList (size: Int): Expr = {
  //   Apply (Identifier ("List"), List.fill (size) { field.zero.toScalaCode })
  // }
  
  override def simplify (formula: LAFormula[D]): LAFormula[D] = {
    LAsimplify (formula)
  }

  override def canonicalDNF (formula: LAFormula[D]): LAFormula[D] = {
    // simplify (disjunctiveNormalForm (removeLeq (findEq (simplify (disjunctiveNormalForm (prenexForm (removeNegations (negationNormalForm (formula)))))))))
    // Do not remove <= relations, since they make trouble when converting them
    // to DNF. We can basically handle them like <.
    simplify (findEq (simplify (disjunctiveNormalForm (prenexForm (removeNegations (negationNormalForm (formula)))))))
  }
  // Give an optional function of the variables to be maximized. The default
  // implementation simply transforms the formula to an equivalent one with the
  // maximizing goal added.
  def synthetize (variables: Seq[Variable], formula: LAFormula[D], 
		  maximize: Option[LinearCombination[D]]): (LAFormula[D], SimpleExpr) = maximize match {
    case Some (func) => {
      val optVars = func.unquantifiedVariables.intersect (variables.toSet)
      if (optVars.isEmpty) {
	synthetize (variables, formula)
      }
      else {
	val prefix = uniquePrefix (formula)
	val replaceMap = variables.zipWithIndex.map (varIndex => (varIndex._1.name, prefix +
								  varIndex._2.toString)).toMap
	val newVariables = replaceMap.values.map (v => Variable (v))
	val replacedFormula:LAFormula[D] =
	  formula.renameVariables (replaceMap).asInstanceOf[LAFormula[D]]
	val replacedFunc:Term =
	  func.renameVariables (replaceMap).asInstanceOf[Term]
	val newFormula =
	  And (formula, quantify (Universal, newVariables,
				  implies (replacedFormula,
					   Rel[LAFunction[D],ArithmeticRelation]
					     (LtEqual (replacedFunc, func)))))
	println ("DEBUG: old formula: " + formula)
        println ("DEBUG: to maximize: " + func)
	println ("DEBUG: new formula: " + newFormula)
	synthetize (variables, newFormula)
      }
      
    }
    case None => synthetize (variables, formula)
  }
}

