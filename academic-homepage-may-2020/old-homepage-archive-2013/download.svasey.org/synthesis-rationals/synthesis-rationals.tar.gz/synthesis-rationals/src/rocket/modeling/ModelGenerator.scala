package rocket
package modeling

import choosec.numbers._
import choosec.synthesis._
import choosec.LASynthetizer
import choosec.trees.Formulas._

import java.io.File

// Synthetize and compile code to control the rocket . Only synthetize and
// compile if this is really necessary.
// This only generates one-dimensional model (for now).
object ModelGenerator {
  val largestDenominator = 1000
  
  val outputDir = "tmp/synthetized"
  val classOutputDir = outputDir + "/root"
  val packageName = "rocket.synthetized"
  val scalaHeaders = "import choosec.numbers._\nimport choosec.simplex._\nimport smartfloats._\nimport choosec.synthesis.NoSolutionException"

  // `nSamples` is the number of samples of time we will take in our model: To
  // be more precise, this is the number of time units until landing.
  // `nDisj` is the number of disjunctions we can use in the model. In general,
  // time to solve the constraints increase linearly in the number of disjunctions
  class Synthetizer[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]]
    (nSamples: Int, nDisj: Int, method: LASynthesisMethod[D], convert: D => E)
  {
    require (nSamples >= 2 && nDisj >= 1 && nDisj <= nSamples)
    val field = method.field
    // Return a filename prefix corresponding to the given parameters
    def namePrefix: String = 
      List ("model", nSamples.toString, nDisj.toString).mkString ("_")

    val minimizeFuelName = "minimizeFuel"
    val minimizeSpeedName = "minimizeSpeed"

    // Time before impact
    val initialAccelParameter = LinearCombination (Variable ("A0"), field.one)
    val initialSpeedParameter = LinearCombination (Variable ("V0"), field.one)
    val initialPositionParameter = LinearCombination (Variable ("X0"), field.one)
    val boosterAccelParameter = LinearCombination (Variable ("B"), field.one)
    val gravParameter = LinearCombination (Variable ("G"), field.one)
    val fuelParameter = LinearCombination (Variable ("F0"), field.one)

    def fuelVariableName (i: Int): String = {
      require (i >= 1 && i < nSamples)
      "b" + i.toString
    }
    // Return the variable representing the amount of fuel used at time i, i >=1
    def fuelVariable (i: Int): LinearCombination[D] = {
      require (i >= 1 && i < nSamples)
      LinearCombination (Variable (fuelVariableName (i)), field.one)
    }
    def allFuelVariables: List[Variable] =
      List.range (1, nSamples).map (i => Variable (fuelVariableName (i)))

    // Return the total amount of fuel
    def totalFuel: LinearCombination[D] = 
      LinearCombination.sum (List.range (1, nSamples).map (fuelVariable))
  
    // Return an expression representing the acceleration at time i
    def accelAt (i: Int): LinearCombination[D] = {
      require (i >= 0 && i < nSamples)
      if (i == 0)
	initialAccelParameter
      else 
	gravParameter.negate.add (fuelVariable (i))
    }

    // This is simply the equation v_{t + 1} = v_t + a_t, that has
    // been unrolled for efficiency
    def speedAt (i: Int): LinearCombination[D] = {
      require (i >= 0 && i <= nSamples)
      initialSpeedParameter.add (LinearCombination.sum (List.range (0, i).map (j => accelAt (j))))
    }      

    // This is simply the equation x_{t + 1} = v_t + x_t, that has been unrolled
    // for efficiency
    def positionAt (i: Int): LinearCombination[D] = {
      require (i >= 0 && i <= nSamples)
      // x0 + i*v0
      val init = initialPositionParameter.add (initialSpeedParameter.scale (field.fromInt (i)))

      val toSum = List.range (0, i).map (j => accelAt (j).scale (field.fromInt (i - j)))

      // sum from 0 to i - 1 of (i - j)*a_j
      val next = LinearCombination.sum (toSum)
      init.add (next)
    }

    // Generate the constraints concerning the fuel use variables. If
    // `restrictTotal` is true, restrict the total amount of fuel to be less
    // than the fuel parameter
    def fuelUseConstraints (restrictTotal: Boolean): LAFormula[D] = {
      // Generate the constraints for one variable
      def gen (i: Int): LAFormula[D] = {
        require (i >= 1 && i < nSamples)
        val lhs = Rel (LtEqual (LinearCombination (field.zero), fuelVariable (i))):LAFormula[D]

        val rhs = Rel (LtEqual (fuelVariable (i), boosterAccelParameter)):LAFormula[D]
        And (lhs, rhs)
      }
      val first = And (List.range (1, nSamples).map (gen).toSet)
      val second = {
	if (restrictTotal)
	  Rel (LtEqual (totalFuel, fuelParameter))
	else
	  Rel (True)
      }:LAFormula[D]
      And (first, second)
    }

    // Generate the constraints for speed and positions: the final positions and
    // speed are zero . If `minimizeSpeed` is true, do not impose that the final
    // speed is zero, and do not create disjunctions.
    def speedPosConstraints (minimizeSpeed: Boolean): LAFormula[D] = {
      // Generate the constraint for stopping at time n
      def speedPosConstr (n: Int): LAFormula[D] = {
	val lastPos = Rel (Equals (LinearCombination (field.zero), positionAt (n))):LAFormula[D]
	val lastSpeed = {
	  if (minimizeSpeed)
	    Rel (LtEqual (speedAt (n), LinearCombination (field.zero)))
	  else
	    Rel (Equals (LinearCombination (field.zero), speedAt (n)))
	}:LAFormula[D]

        val rest = And (List.range (1, n).map (id => {
          Rel (LtEqual (LinearCombination (field.zero), positionAt (id))):LAFormula[D]
        }).toSet)
	And (Set (lastPos, lastSpeed, rest))
      }

      if (minimizeSpeed)
	speedPosConstr (nSamples)
      else
	Or (List.range (nSamples - nDisj + 1, nSamples + 1).map (speedPosConstr).toSet)
    }
  
    // Return all constraints
    def combinedConstraints (minimizeSpeed: Boolean): LAFormula[D] = 
      And (Set (fuelUseConstraints (minimizeSpeed), speedPosConstraints (minimizeSpeed)))
    
    def synthetize (variables: Seq[Variable], formula: LAFormula[D],
                    maximize: LinearCombination[D], methodName: String): Unit = {
      val synthetizer = LASynthetizer (method, convert, variables, formula,
                                       Some (maximize))
      // Capitalize the method name
      val objectName = methodName.head.toUpper + methodName.tail
      val filename = namePrefix + "_" + methodName + ".scala"
      println ("DEBUG: synthetizing to file")
      synthetizer.synthetizeToFile (scalaHeaders, outputDir, objectName,
                                    packageName, methodName, filename)      
      println ("DEBUG: done")
    }

    // Recursively remove a directory
    def removeDirectory (path: String): Unit = {
      val dir = new File (path)
      require (dir.isDirectory || !dir.exists)
      def rec (file: File): Unit = {
	if (file.isDirectory){
	  file.listFiles.foreach (p => rec (p))
	}
	println ("DEBUG: Deleting " + file)
	// file.delete
      }

      if (dir.exists)
	rec (dir)
    }
  
    // Synthetize and compile everything (if not already done).
    def synthetizeAll: Unit = {
      val path = outputDir + "/" + namePrefix
      if (! new File (path).exists){
        synthetizeMinimizeFuel
	// synthetizeMinimizeSpeed
        compile
      }
      else {
	println ("Everything has already been synthetized")
      }

      // Update the symbolic link to point to the new code
      new File (classOutputDir).delete
      val proc = Runtime.getRuntime ().exec (Array ("ln", "-s", namePrefix, classOutputDir))
      proc.waitFor
      assert (proc.exitValue == 0)
    }
    

    // Synthetize the code that estimates the amount of fuel to spend in each
    // time interval. The synthetized code takes as parameters, in this order,
    // the initial acceleration, the maximal booster acceleration (B), the
    // gravitational acceleration, the initial speed, and the initial position.
    // It returns a list of numbers between 0 and B, the ith of which represent
    // the booster acceleration to use between time i and i + 1.
    def synthetizeMinimizeFuel: Unit = {
      val formula = combinedConstraints (false)
      val variables = allFuelVariables
      val maximize = totalFuel.negate
      synthetize (variables, formula, maximize, minimizeFuelName)
    }

    // This takes the same arguments, with a fuel argument between the booster
    // acceleration and the gravity acceleration, and returns the same things as
    // the fuel minimizer, but tries to minimize the speed on impact, respecting
    // the constraints on fuel.
    def synthetizeMinimizeSpeed: Unit = {
      val formula = combinedConstraints (true)
      val variables = allFuelVariables
      val maximize = speedAt (nSamples)
      synthetize (variables, formula, maximize, minimizeSpeedName)
    }

    def getSolverForMinimizingFuel: Seq[D] => Option[Seq[D]] = {
      val formula = combinedConstraints (false)
      val variables = allFuelVariables
      val maximize = totalFuel.negate

      val solver = method.simplexSolver
      val simplexMethod = new SimplexSynthesis[D] (solver.field, solver.matrix, solver)
      
      simplexMethod.getSolverForConstraints (variables, formula, maximize)
    }
  
    // Compile all the files that have been synthetized
    def compile: Unit = {
      val bindir = "bin/scala_2.8.1/classes/:lib/smartfloat_2.8.1-0.0.jar"

      // val allNames = List (minimizeFuelName, minimizeSpeedName)
      val allNames = List (minimizeFuelName)
      
      val files = allNames.map (el => namePrefix + "_" + el + ".scala")

      val realOutputdir = outputDir + "/" + namePrefix
      new File (realOutputdir).mkdir
      
      def gencmd (filename: String): Array[String] = {
        val opts = Array ("-optimise")
        // val opts = Array[String] ()
        Array ("scalac") ++ opts ++ Array ("-d", realOutputdir, "-cp", bindir, outputDir + "/" + filename)
      }

      val allCmd = files.map (f => gencmd (f))

      println ("Calling scala compiler...")
      allCmd.foreach (cmd => {
	println (cmd.mkString (" "))
        val proc = Runtime.getRuntime ().exec (cmd)
	val stdout = proc.getInputStream
	val stderr = proc.getErrorStream

	proc.waitFor
	print (io.Source.fromInputStream (stdout).getLines.mkString ("\n"))
	print (io.Source.fromInputStream (stderr).getLines.mkString ("\n"))
	
	if (proc.exitValue != 0)
	  error ("Scala compiler exited with non-zero return status " +
		 proc.exitValue)
      })
    }
  }

  object Synthetizer {
    def apply[D <: ExpressibleOrderedField[D]]
      (nSamples: Int, nDisj: Int, method: LASynthesisMethod[D]): Synthetizer[D,D] =
    {
      def convert (el: D): D = el
      Synthetizer (nSamples, nDisj, method, convert)
    }
    def apply[D <: ExpressibleOrderedField[D], E <: ExpressibleOrderedField[E]]
      (nSamples: Int, nDisj: Int, method: LASynthesisMethod[D], convert:D => E): Synthetizer[D,E] =
    {
      new Synthetizer (nSamples, nDisj, method, convert)
    }
  }

  // Takes several arguments: options on synthesis, as asccepted by
  // choosec.Main, and the following:
  // * The number of samples to use
  // * The number of disjunction to use (will be one if not specified)
  def main (args: Array[String]){
    import java.lang.Double.parseDouble
    import Rational.fromDouble_approx

    // Some quick and dirty command line parsing
    val (method, useSmartFloat, useFloat) = choosec.Main.parsecl (args)
    val newArgs = args.filter (el => !el.startsWith ("--"))
    val (nSamples, nDisj) = {
      if (newArgs.length < 1){
	println ("Error: please supply the number of samples to take")
	System.exit (1)
	(0,0)
      }
      else {
	val d = {
	  if (newArgs.length > 1) BigInt (newArgs (1)).toInt
	  else 1
	}
		
	(BigInt (newArgs (0)).toInt, d)
      }
    }:(Int, Int)

    def launch[E <: ExpressibleOrderedField[E]] (convert: Rational => E): Unit = {
      Synthetizer[Rational,E] (nSamples, nDisj, method, convert).synthetizeAll
    }

    if (useSmartFloat)
      launch (SmartFloatWrap.rationalToSmartFloatWrap)
    else if (useFloat)
      launch (FloatWrap.rationalToFloatWrap)
    else
      launch (el => el)
  }
}
