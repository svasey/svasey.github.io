package rocket
package simulation

import Simulation._
import FuelScheduler._
import rocket.gui.SimulationGUI.RocketSimulatorGUI
  
object RocketSimulation {

  trait MovingObjectSimulator extends TimedSimulator {
    var position: PhysVector
    var velocity: PhysVector
    var acceleration: PhysVector

    def dim: Int = position.dim
    def updateVariables: Unit
    // Return true iff the object has gotten somewhere, i.e the simulation is over
    def reachedTarget: Boolean
  
    def runTimedStep: Boolean = {
      position = position + velocity * simulatedTimeStep
      velocity = velocity + acceleration * simulatedTimeStep
      
      updateVariables
      reachedTarget
    }
  }

  // This abstracts my simple model of a rocket in a gravitationnal field.
  // `boosterAcceleration` is the full acceleration the rocket booster can
  // have, in m/s^2 . It is assumed that the booster obtains this acceleration
  // instantly.
  trait AbstrRocketSimulator extends MovingObjectSimulator {
    val boosterAcceleration: Double
    // Gravitational acceleration
    var grav: PhysVector
    // Amount of fuel left, in seconds
    var fuel: Double
    // Give the fraction of `boosterAcceleration` we will use from the boosters
    // in this time interval. The magnitude must be one if we use full power, 0
    // if we use no power.
    var boosterDirection: PhysVector

    def updateGrav: Unit
    def updateBoosterDirection: Unit
    // Some deviation from the original acceleration due to e.g measurement errors.
    def accelerationDeviation: PhysVector
    // Additionnal amount of fuel we lost due to e.g measurement errors.
    def fuelDeviation: Double
    
    def updateVariables: Unit = {
      assert (fuel > 0 || (boosterDirection.norm == 0))
      acceleration = grav + boosterDirection * boosterAcceleration + accelerationDeviation
      fuel -= boosterDirection.norm * simulatedTimeStep + fuelDeviation
      updateGrav
      if (fuel > 0)
	updateBoosterDirection
      else
	boosterDirection = PhysVector.zero (dim)
    }
  }
  trait LandRocketSimulator extends AbstrRocketSimulator {
    def reachedTarget = 
      (dim == 1 && position.x <= 0) || (dim > 1 && position.y <= 0)
  }
  
  trait NoBoosterRocketSimulator extends AbstrRocketSimulator {
    def updateBoosterDirection: Unit = {}
    val boosterAcceleration = 0.0
    var fuel = 0.0
  }

  // Waste all the fuel trying to stabilize the rocket, i.e compensate exactly
  // the gravitational field.
  trait StabilizingRocketSimulator extends AbstrRocketSimulator {
    def updateBoosterDirection: Unit = {
      require (fuel > 0)
      boosterDirection = {
	if (boosterAcceleration <= grav.norm)
	  -grav.normalized
	else
	  -grav / boosterAcceleration
      }
    }
  }

  // Linearly increase its booster output until it is at full power, then
  // decrease it, and so on.
  trait OscillatingRocketSimulator extends AbstrRocketSimulator {
    var increasing: Boolean = true
    // Increment per second
    val secDelta: Double
    def updateBoosterDirection: Unit = {
      val delta = simulatedTimeStep * secDelta
      val newDirection = {
	if (increasing)
	  boosterDirection + (-grav.normalized) * delta
	else
	  boosterDirection - (-grav.normalized) * delta
      }
      if (increasing && newDirection.norm >= 1)
	increasing = false
      else if (!increasing && newDirection.norm < 0.01)
	increasing = true
      else 
	boosterDirection = newDirection 
    }
  }

  trait NoPerturbationRocketSimulator extends AbstrRocketSimulator {
    def updateGrav = {}
    def accelerationDeviation = PhysVector.zero (dim)
    def fuelDeviation = 0.0
  }



  trait ConsoleOutputRocketSimulator extends AbstrRocketSimulator {
    override def outputInfo: Unit = {
      println ("Position: " + position + " speed: " + velocity.norm + " fuel: " + fuel +
	       " real time: " + elapsedReal + " simulated time: " + elapsedSimulated)
    }
  }

  // Rocket with no boosters simulated at real time with no perturbation,
  // simulation stops when it crashes .
  class FreeFall (g: Double, initPos: Double, initVel: Double,
				timeStep: Double) extends LandRocketSimulator with NoBoosterRocketSimulator with NoPerturbationRocketSimulator with RealTimeSimulator with RocketSimulatorGUI {
    val simulatedTimeStep = timeStep
    var position = PhysVector (initPos)
    var velocity = PhysVector (initVel)
    var acceleration = PhysVector.zero (1)
    var grav = PhysVector (-g)
    var boosterDirection = PhysVector.zero (1)
  }

  // Tries to compensate the gravity field, and eventually fall down for lack of fuel
  class DelayedFreeFall (boostAccel: Double, g: Double, initPos: Double, initVel: Double,
			 initFuel: Double,
			 timeStep: Double) extends LandRocketSimulator with StabilizingRocketSimulator with NoPerturbationRocketSimulator with RealTimeSimulator with RocketSimulatorGUI {
    val simulatedTimeStep = timeStep
    val boosterAcceleration = boostAccel
    var position = PhysVector (initPos)
    var velocity = PhysVector (initVel)
    var acceleration = PhysVector.zero (1)
    var grav = PhysVector (-g)
    var fuel = initFuel
    var boosterDirection = PhysVector.zero (1)
  }

  // Oscillate before falling out of fuel
  class Oscillator (boostAccel: Double, g: Double, initPos: Double, initVel: Double,
			 initFuel: Double,
			 timeStep: Double) extends LandRocketSimulator with OscillatingRocketSimulator with NoPerturbationRocketSimulator with RealTimeSimulator with RocketSimulatorGUI {
    val secDelta = 0.25
    val simulatedTimeStep = timeStep
    val boosterAcceleration = boostAccel
    var position = PhysVector (initPos)
    var velocity = PhysVector (initVel)
    var acceleration = PhysVector.zero (1)
    var grav = PhysVector (-g)
    var fuel = initFuel
    var boosterDirection = PhysVector.zero (1)
  }

  class Lander (nSamp: Int, boostAccel: Double, g: Double, initPos: Double, initFuel: Double, timeStep: Double, initVel: Double, realTimeSec: Double, initAccel: Double) extends LandRocketSimulator with ConcurrentFuelSchedulerSimulator with  NoPerturbationRocketSimulator with RocketSimulatorGUI {
    var boosterDirection = PhysVector.zero (1)
    var fuel = initFuel
    var grav = PhysVector (-g)
    var acceleration = PhysVector (initAccel)
    var position = PhysVector (initPos)
    var velocity = PhysVector (initVel)
    val simulatedTimeStep = timeStep
    val boosterAcceleration = boostAccel
    val realTimeSecond = realTimeSec
    // scheduler = Basic1DScheduler.inst
    // scheduler = SimplexScheduler.inst (nSamp, 1)
    scheduler = SynthetizedScheduler.inst (nSamp)
  }

  object Lander {
    def apply (nSamp: Int, boostAccel: Double, g: Double, initPos: Double, initFuel: Double,
	       timeStep: Double, initVel: Double = 0.0, realTimeSec: Double = 1.0, initAccel: Double = 0.0): Lander = {
      new Lander (nSamp, boostAccel, g, initPos, initFuel, timeStep, initVel, realTimeSec, initAccel)
    }
  }
}
