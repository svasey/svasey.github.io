package rocket
package simulation

import Simulation._
import RocketSimulation._
import choosec.numbers._
import choosec.synthesis.NoSolutionException

import scala.concurrent._

object FuelScheduler {
  trait Schedule {
    // I assume this will always be called with an increasingly large time
    // value.
    def getScheduled (time: Double): PhysVector
    // Overwrite this schedule with a new schedule, except perhaps for the first
    // scheduled entries.
    def overwrite (newSchedule: Schedule): Schedule
    // Remove all items with starting time strictly lower than time, except the last one.
    def updateTime (time: Double): Schedule
  }

  // The left element of the pair indicates the starting time in which the given
  // acceleration must be used.
  class IntervalSchedule (val schedule: Seq[(Double, PhysVector)]) extends Schedule {
    // FIXME: this can be done more efficiently
    def getScheduled (time: Double): PhysVector = {
      require (!schedule.isEmpty)
      def rec (xs: Seq[(Double, PhysVector)]): PhysVector = {
        if (xs.tail.isEmpty || xs.tail.head._1 > time)
          xs.head._2
        else
	  rec (xs.tail)
      }
      rec (schedule)
    }

    def overwrite (newSchedule: Schedule): IntervalSchedule = {
      // FIXME: this "type conversion" can probably be done more elegantly
      assert (newSchedule.isInstanceOf[IntervalSchedule])
      val ns = newSchedule.asInstanceOf[IntervalSchedule]
      // Append ys to the first elements of ys such that the list remains sorted
      // (w.r to the first component) 
      def merge (xs: Seq[(Double, PhysVector)], ys: Seq[(Double, PhysVector)]): Seq[(Double, PhysVector)] = {
	if (!xs.isEmpty && (xs.head._1 < ys.head._1))
	  xs.head +: merge (xs.tail, ys)
	else
	  ys
      }
      new IntervalSchedule (merge (this.schedule, ns.schedule))
    }

    def updateTime (time: Double): IntervalSchedule = {
      def rm (xs: Seq[(Double,PhysVector)]): Seq[(Double, PhysVector)] = {
	if (!xs.isEmpty && !xs.tail.isEmpty && xs.head._1 <= time && xs.tail.head._1 <= time)
	  rm (xs.tail)
	else
	  xs
      }
      new IntervalSchedule (rm (schedule))
    }

    override def toString: String = {
      schedule.toString
    }
    
  }
  trait FuelSchedulerSimulator extends AbstrRocketSimulator {
    var schedule: Schedule
    def updateSchedule: Unit
    def updateBoosterDirection: Unit = {
      updateSchedule
      // Try to be smart: if the speed is too small: stop the boosters instead
      // of following the schedule
      if (speedIsTooSmall)
	boosterDirection = PhysVector.zero (1)
      else 
	boosterDirection = schedule.getScheduled (elapsedSimulated)
    }
    def speedIsTooSmall: Boolean = {
      val criticalSpeed = -1.0
      dim == 1 && velocity.x >= criticalSpeed
    }
  }
  trait ConcurrentFuelSchedulerSimulator extends FuelSchedulerSimulator {
    protected var isComputing: Lock = new Lock ()
    override var schedule: Schedule = null
    protected var newSchedule: Schedule = schedule

    var scheduler: Scheduler = null
    
    def initScheduler: Scheduler = {
      scheduler = scheduler.init (position, velocity, acceleration, grav,
				  boosterAcceleration, fuel, elapsedSimulated)
      scheduler
    }
    def defaultSchedule: Schedule =
      initScheduler.defaultSchedule
    
    // Start a thread that will modify `newSchedule` with a new
    // schedule. Release the `isComputing` lock when done.
    def runSchedulerThread: Unit = {
      val pos = position
      val vel = velocity
      val accel = acceleration
      val g = grav
      val boosterAccel = boosterAcceleration
      val currentFuel = fuel

      class Sched extends Runnable {
        override def run (): Unit = {
          newSchedule =  initScheduler.getNewSchedule 
          isComputing.release
        }
      }

      new Thread (new Sched ()).start
    }
    def updateSchedule: Unit = {
      if (isComputing.available){
	// This happens at the first iteration
	if (newSchedule != null){
          schedule = schedule.overwrite (newSchedule).updateTime (elapsedSimulated)
	  // println ("DEBUG: new schedule: " + schedule)
	}
	else {
	  schedule = defaultSchedule
	}
        isComputing.acquire
        runSchedulerThread
      }
    }

    def getPerformance: PerformanceMeasurer = scheduler.getPerformance
  }

  trait Scheduler {
    // Create a new instance of the scheduler
    def init (position: PhysVector, velocity: PhysVector, acceleration: PhysVector,
	      gravity: PhysVector, boosterAcceleration: Double, fuel: Double,
	      currentTime: Double): Scheduler
    // Return a default schedule; this must be computed quickly
    def defaultSchedule: Schedule
    // Compute a new schedule, this can be slower to compute
    def getNewSchedule: Schedule = defaultSchedule
    // Return some performance indicator. To be ignored if not relevant.
    def getPerformance: PerformanceMeasurer = new PerfMeasurer (0, 0.0, 0.0)
  }

  // Simple scheduler in one dimension.
  class Basic1DScheduler (val x0: Double, val v0: Double, val a0: Double, val g: Double,
			  val b0: Double, val f0: Double, val t0: Double) extends Scheduler {
    // Used for numerical comparisons
    val EPS = 1e-16
  
    def init (pos: PhysVector, vel: PhysVector, accel: PhysVector,
	      grav: PhysVector, boosterAccel: Double, f: Double,
	      t0: Double): Basic1DScheduler = {
      require (pos.dim == 1 && vel.dim == 1 && accel.dim == 1 && grav.dim == 1)
      new Basic1DScheduler (pos.x, vel.x, accel.x, grav.x, boosterAccel, f, t0)
    }

    // Return the smallest non-negative solution of the equation bx + c = 0, or
    // None if no such solution exists
    def solveLinear (b: Double, c: Double): Option[Double] = {
      if (scala.math.abs (b) < EPS){
	if (c == 0)
	  // This is the smallest non-negative value, by definition
	  Some (0)
	else
	  None
      }
      else {
	val r = (-c) / b
	if (r < 0 )
	  None
	else
	  Some (r)
      }
    }
  
    // Return the smallest non-negative solution of the equation ax^2 + bx + c =
    // 0, or None if no such solution exists
    def solveQuadratic (a: Double, b: Double, c: Double): Option[Double] = {
      // println ("DEBUG: solveQuadratic: " + a  + ", " + b + ", " + c)
      if (scala.math.abs (a) < EPS)
	solveLinear (b, c)
      else {
	val delta = b*b - 4*a*c

	if (delta < 0){
	  None
	}
	else {
	  val sqr = scala.math.sqrt (delta)
	  val sol1 = (-b + sqr) / (2*a)
	  val sol2 = (-b - sqr) / (2*a)
	  
	  if (sol1 >= 0 && sol2 >= 0)
	    Some (scala.math.min (sol1, sol2))
	  else if (sol1 >= 0)
	    Some (sol1)
	  else if (sol2 >= 0)
	    Some (sol2)
	  else
	    None
	}
      }
    }

    // If we want to switch on the booster at one point at full power and leave
    // them on afterward, return the time at which to do it for a soft landing,
    // and the landing time. If it is not possible to land softly, return None.
    def criticalTimes: Option[(Double, Double)] = {
      solveQuadratic (((g*g) / (2 * b0)) + (g / 2),
		      ((g * v0) / b0) + v0,
		      ((v0 * v0) / (2 * b0)) + x0) match
      {
	case Some (t) => Some (((v0 + (b0 + g) * t) / b0, t))
	case None => None
      }
    }
    
    // Return a schedule that goes into free fall and then brake at maximum
    // power at just the right time.
    def defaultSchedule: Schedule = {
      criticalTimes match {
	case Some ((tc, _)) => {
	  val schedList = List ((0.0, PhysVector.zero (1)),
				((tc + t0), PhysVector (1.0)))
	  new IntervalSchedule (schedList)
	}
	case None => {
	  if (v0 > 0)
	    // We want to go down: stop everything
	    new IntervalSchedule (List ((0.0, PhysVector.zero (1))))
	  else
	    // Begin braking now, even though it may not be possible to avoid crashing
	    new IntervalSchedule (List ((0.0, PhysVector (1.0))))
	}
      }
    }
  }
  
  object Basic1DScheduler {
    // A dummy instance
    val inst = new Basic1DScheduler (0,0,0,0,0,0,0)
  }

  object SynthetizedScheduler {
    def inst (nSamples: Int): SynthetizedScheduler = 
      new SynthetizedScheduler (0,0,0,0,0,0,0,nSamples, -1, new PerfMeasurer (0,
									      0.0,
									      0.0))
  }

  trait PerformanceMeasurer {
    def update (timems: Long): PerformanceMeasurer
  }

  // Average and max time are in seconds
  case class PerfMeasurer (n: Long,
                           avgTime: Double, maxTime: Double) extends  PerformanceMeasurer {
    def update (timems: Long): PerfMeasurer = {
      if (n == 0){
        PerfMeasurer (1, timems / 1000.0, timems / 1000.0)
      }
      else {
        val newAvg = (n.toDouble / (n + 1)) * avgTime + timems / (1000.0 * (n + 1))    
        val newMax = {
          if ((timems / 1000.0) > maxTime) timems / 1000.0
          else maxTime
        }
        PerfMeasurer (n + 1, newAvg, newMax)
      }
    }
    override def toString: String = {
      "Number of times a solver was called: " + n + "\n" +
      "Average solving time: " + avgTime + " [s]\n" +
      "Max solving time: " + maxTime + " [s]"
    }
  }
  
  class SynthetizedScheduler (x0: Double, v0: Double, a0: Double,
			      g: Double, b0: Double, f0: Double,
			      t0: Double, val nSamples: Int, impactT: Double,
			      perfMeas: PerformanceMeasurer) extends Basic1DScheduler (x0, v0, a0, g, b0, f0, t0) {

    import rocket.synthetized.MinimizeFuel.minimizeFuel
    // import rocket.synthetized.MinimizeSpeed.minimizeSpeed
    import rocket.modeling.ModelGenerator

    // Field to use
    type D = Rational
    val field: D = Rational.r
    
    var impactTime: Double = impactT
    var perfMeasurer: PerformanceMeasurer = perfMeas
    
    override def init (position: PhysVector, velocity: PhysVector, acceleration: PhysVector,
		       gravity: PhysVector, boosterAcceleration: Double, fuel: Double,
		       currentTime: Double): SynthetizedScheduler = {
      val basic:Basic1DScheduler = super.init (position, velocity, acceleration, gravity, boosterAcceleration, fuel, currentTime)
      new SynthetizedScheduler (basic.x0, basic.v0, basic.a0, basic.g, basic.b0, basic.f0, basic.t0,
				nSamples, impactTime, perfMeasurer)
    }
    
    def approx (x: Double): D = {
      field.fromDouble_approx (x, ModelGenerator.largestDenominator)
      // field.fromDouble (x)
    }

    def callFuelMinimizer0 (convertedA0: D, convertedB0: D, convertedG0: D,
			    convertedV0: D, convertedX0: D): Seq[D] = {
      minimizeFuel (convertedA0, convertedB0, convertedG0, convertedV0,
		    convertedX0)
    }
    def callFuelMinimizer (convertedA0: D, convertedB0: D, convertedG0: D,
			   convertedV0: D, convertedX0: D): Seq[D] = {
      val t0 = System.currentTimeMillis
      val res = callFuelMinimizer0 (convertedA0, convertedB0, convertedG0,
				    convertedV0, convertedX0)
      val t2 = System.currentTimeMillis
      perfMeasurer = perfMeasurer.update (t2 - t0)
      res
    }

    override def getPerformance: PerformanceMeasurer = perfMeasurer

    // Using the synthetized code, get the fuel to use, as a sequence of
    // `nSamples` - 1 numbers, the ith of which represent the amount of fuel to
    // use (as a number between 0 and 1) in the interval [t0 + (i/N)*T, t0 + ((i
    // + 1)/N)*T], where T is the number of seconds remaining before impact, t0
    // is the current time, and N = `nSamples`. Also return the time before
    // impact T. Return None if the synthetized code returned errors (i.e the
    // problem is unfeasible).
    def getFuelUse: Option[(Seq[D],Double)] = {
      val increaseCoeff = 1.2
      val maxNTries = 10
      
      def rec (timeBeforeImpact: Option[Double], nTry: Int): Option[(Seq[D], Double)] = {
	if (nTry > maxNTries)
	  None
	else timeBeforeImpact match {
	  case None => None
	  case Some (tBef) => {
	    // println ("DEBUG: tentative time before impact: " + tBef)
	    // println ("DEBUG: current time: " + t0)
	    val t = approx (tBef)
	    // Unit conversions
	    val dt = t / field.fromInt (nSamples)
	    val dt_2 = dt * dt

       	    val convertedB0 = approx (b0) * dt_2
       	    val convertedG0 = approx (-g) * dt_2 // The model takes a positive grav. acceleration
       	    val convertedX0 = approx (x0)

	    val convertedA0_1 = approx (a0) * dt_2
	    // This works better: the model has a tendency to overestimate the initial acceleration...
	    val convertedA0_2 = convertedG0.negate

	    val convertedV0_1 = approx (v0) * dt
	    // It seems the model gives too much value to the initial speed, so we change it slightly..
	    val convertedV0_2 = convertedV0_1 + convertedA0_2


	    val (convertedA0, convertedV0) = {
	      // Model pre-condition not satisfied: do not overestimate
	      if (convertedA0_2 + convertedV0_2 < convertedX0.negate)
		(convertedA0_1, convertedV0_1)
	      else
		(convertedA0_1, convertedV0_1)
	    }

	    def normalize (xs: Seq[D]): Seq[D] = 
	      xs.map (x => if (convertedB0 == field.zero) field.zero else x / convertedB0)

	    // First tentative schedule
	    val tentative = {
	      try {
      		Some ((normalize (callFuelMinimizer (convertedA0, convertedB0, convertedG0,
      						     convertedV0, convertedX0)), tBef))
	      }
	      catch {
		case _: NoSolutionException => {
		  // This can mean several things: either we are too fast and
		  // will crash anyway, or our time on impact is badly
		  // estimated (probably too low).
		  // To know which one, we look at what happens if
		  // we use the full power of our boosters:
		  solveQuadratic ((b0 + g) / 2, v0, x0) match {
		    case Some (_) => {
		      println ("WARNING: going down too fast !")
		      None
		    }
		    case None => {
		      // Recompute a new time before impact
		      if (nTry == 1){
			impactTime = -1
			rec (estimateTimeBeforeImpact, nTry + 1)
		      }
		      // Increase the impact time
		      else {
			rec (Some (tBef * increaseCoeff), nTry + 1)		       
		      }
		    }
		  }
		}
	      }
	    }:Option[(Seq[D], Double)]

	    // FIXME: we should consider whether we have enough fuel to match
	    // the tentative schedule.
	    tentative
	  }
	}
      }
      val criticalSpeed = -1.0
      if (v0 >= criticalSpeed)
	None
      else
	rec (estimateTimeBeforeImpact, 1)
    }

    // Estimate the time before impact. Return None if we cannot produce a
    // reliable estimate (e.g the rocket is going up, or there is no
    // gravitational acceleration). If a value is returned, then it must be
    // strictly positive, such that it is approximated to a positive number
    // using `approx`.
    def estimateTimeBeforeImpact: Option[Double] = {
      
      def newEstimate: Option[Double] = {
       	criticalTimes match {
       	  case Some ((_, t)) => Some (t)
       	  // This means we will fall down anyway: solve the equation when we use
	  // full power all along.
	  case None => solveQuadratic ((g + b0) / 2, v0, x0)
        }
      }
      
      // def newEstimate: Option[Double] = 
      // 	solveQuadratic (g / 2, v0, x0)

      if (impactTime <= 0 || t0 >= impactTime){
	newEstimate match {
       	  case Some (est) => {
       	    if (est > 0 && approx (est) > 0){
       	      Some (est)
       	    }
       	    else 
       	      None
	  }
	  case None => None
	}
      }
      else
	Some (impactTime - t0)
    }

    override def getNewSchedule: Schedule = {
      getFuelUse match {
      	case Some ((fuelUse, timeBeforeImpact)) => {
	  impactTime = t0 + timeBeforeImpact
      	  assert (fuelUse.size == nSamples - 1 && fuelUse.forall (el => field.zero <= el &&
      								  el <= field.one),
      		  "Fuel use: " + fuelUse.toString)

	  // Some simple heuristic to improve results
	  val safetyCoeff = 0.0 / nSamples		// To be determined empirically
	  val criticalHeight = 50.0
	  val timeCorrection = {
	    if (x0 <= criticalHeight)
	      0
	    else
	      timeBeforeImpact * safetyCoeff
	  }

	  // println ("DEBUG: time before impact: " + timeBeforeImpact)
	  
      	  val schedList = fuelUse.zipWithIndex.map (_ match {
      	    case (el: D, i: Int) => {
      	      val startTime:Double =
		scala.math.max (t0 + (i + 1) * (timeBeforeImpact / nSamples) - timeCorrection, t0)
      	      (startTime, PhysVector (el.toDouble))
      	    }
      	  })
      	  new IntervalSchedule (schedList)
      	}
	case None => {
      	  println ("WARNING: using default schedule")
	  defaultSchedule
	}
      }
    }
  }

  class SimplexScheduler (x0: Double, v0: Double, a0: Double,
			  g: Double, b0: Double, f0: Double,
			  t0: Double, nSamples: Int, impactT: Double,
			  perfMeas: PerformanceMeasurer, val nDisj: Int) extends SynthetizedScheduler (x0,v0,a0,g,b0,f0,t0,nSamples,impactT, perfMeas) {
    import rocket.modeling.ModelGenerator.Synthetizer
    import choosec.synthesis.FourierMotzkinSynthesis
    
    override def init (position: PhysVector, velocity: PhysVector, acceleration: PhysVector,
		       gravity: PhysVector, boosterAcceleration: Double, fuel: Double,
		       currentTime: Double): SynthetizedScheduler = {
      val basic:SynthetizedScheduler = super.init (position, velocity, acceleration, gravity, boosterAcceleration, fuel, currentTime)
      val s = new SimplexScheduler (basic.x0, basic.v0, basic.a0, basic.g, basic.b0, basic.f0, basic.t0,
				       basic.nSamples, basic.impactTime, basic.perfMeasurer, nDisj)
      s.solvingFunc = this.solvingFunc
      s
    }

    var solvingFunc:Seq[D] => Option[Seq[D]] = null

    override def callFuelMinimizer0 (convertedA0: D, convertedB0: D, convertedG0: D,
				     convertedV0: D, convertedX0: D): Seq[D] = {
      if (solvingFunc == null)
	solvingFunc = Synthetizer (nSamples, nDisj,  new FourierMotzkinSynthesis (field)).getSolverForMinimizingFuel
      
      solvingFunc (List (convertedA0, convertedB0, convertedG0, convertedV0,
			 convertedX0)) match {
	case Some (res) => res
	case None => throw new NoSolutionException ("Unfeasible")
      }
    }
  }

  object SimplexScheduler {
    def inst (nSamples: Int, nDisj: Int): SimplexScheduler = 
      new SimplexScheduler (0,0,0,0,0,0,0,nSamples, -1,
			    new PerfMeasurer (0, 0.0, 0.0), nDisj)
  }
}
