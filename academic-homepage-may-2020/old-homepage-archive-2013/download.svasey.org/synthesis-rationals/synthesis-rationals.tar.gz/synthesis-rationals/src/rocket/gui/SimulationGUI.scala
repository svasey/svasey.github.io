package rocket
package gui

import simulation.RocketSimulation._
import simulation.PhysVector
  
// This is a quick-and-dirty GUI made only to show the rocket. There is probably
// not much hope of doing something more with it.

object SimulationGUI {
  import javax.swing._
  import java.awt.Dimension
  import java.awt.Toolkit
  import java.awt.Rectangle
  import java.awt.Graphics
  import java.awt.Graphics2D
  import java.awt.Color
  import javax.imageio._
  import java.io._
  import java.awt.font._
  
  

  
  trait RocketSimulatorGUI extends AbstrRocketSimulator {
    // Height of the rocket, in meters
    val rocketHeight = 5.0

    class MainFrame extends JFrame {

      class MainPanel extends JPanel {
	class Rocket {
	  var img: java.awt.image.BufferedImage = null
	  val imgPath = "data/rocket.png"
	  def init: Unit = {
	    img = ImageIO.read (new File (imgPath))
	  }
	  // Set position and draw it. The position is taken to be that of the bottom
	  // middle part of the image, with respect to the top-left *floor* corner.
	  def update (gc: Graphics): Unit = {
	    val x = getXPos
	    val y = getYPos
	    val pixelHeight = rocketHeight * pixelPerMeter
	    val scaling = pixelHeight / img.getHeight
	    val imgWidth = scaling * img.getWidth
	    val imgHeight = scaling * img.getHeight

	    // The resulting GUI x and y
	    val newX = x - imgWidth / 2.0
	    val newY = defaultHeight - floorHeight - (y + imgHeight)

	    gc.drawImage (img, newX.toInt, newY.toInt, imgWidth.toInt,
			  imgHeight.toInt, null)
	    // Add the fuel somehow...
	    gc.setColor (Color.orange)

	    val fuelWidth = imgWidth / 4.0
	    val fuelScale = 5 * fuelWidth
	    val fuelHeight = boosterDirection.norm * fuelScale
	    // I had to play a little bit with the image to make the parameters right
	    gc.fillOval ((newX -fuelWidth / 2.0 + imgWidth / 2.0).toInt, (newY + imgHeight -
							    5).toInt, fuelWidth.toInt,
			 fuelHeight.toInt)
	  }
	}

	var rocket = new Rocket
	val floorHeight = 50
	var initialFuel:Double = 0
	def init: Unit = {
	  initialFuel = fuel
	  rocket.init
	}
	
	override def paintComponent (gc: Graphics){
	  super.paintComponent (gc)

	  gc.setColor (Color.red)
	  // Draw floor
	  gc.fillRect (0,defaultHeight - floorHeight, defaultWidth, floorHeight)
	  // Draw rocket
	  rocket.update (gc)
	  // Bar size (in pixel)
	  val barWidth = 200
	  val barHeight = 30
	  val fuelBarX = defaultWidth - barWidth
	  val fuelBarY = 0
	  gc.setColor (Color.green)
	  gc.drawRect (fuelBarX, 0, barWidth, barHeight)
	  val newWidth = {
	    if (initialFuel == 0) 0
	    else (barWidth * (fuel / initialFuel)).toInt
	  }
	  gc.fillRect (fuelBarX, fuelBarY, newWidth, barHeight)

	  val horAlign = 150
	  val vertAlign = 30
	  // Write fuel information
	  gc.drawString ("Fuel left: " + "%.2f".format (fuel) + " [s]",
			 defaultWidth - horAlign, barHeight + vertAlign)
	  // Write speed information
	  val speed = if (dim == 1) velocity.x else velocity.norm
	  gc.drawString ("Speed: " + "%.2f".format (speed) + " [m/s]",
			 defaultWidth - horAlign, barHeight + 2*vertAlign)
	  
	  // Write height
	  val height = if (dim == 1) position.x else position.y
	  gc.drawString ("Height: " + "%.2f".format (height) + " [m]",
			 defaultWidth - horAlign, barHeight + 3*vertAlign)
	  // Write gravitational acceleration 
	  val g = if (dim == 1) grav.x else grav.y
	  gc.drawString ("Gravity: " + "%.2f".format (g) + " [m/s^2]",
			 defaultWidth - horAlign, barHeight + 4*vertAlign)
	  val boosterUse = boosterDirection.norm
	  gc.drawString ("Booster use: " + "%.2f".format (boosterUse),
			 defaultWidth - horAlign, barHeight + 5*vertAlign)
	  // Write booster acceleration 
	  val boosterPower = if (dim == 1) boosterDirection.x else boosterDirection.norm
	  gc.drawString ("Booster: " + "%.2f".format (boosterPower * boosterAcceleration) + " [m/s^2]",
			 defaultWidth - horAlign, barHeight + 6*vertAlign)
	  // Write time
	  gc.drawString ("Time: " + "%.2f".format (elapsedSimulated) + " [s]",
			 defaultWidth - horAlign, barHeight + 7*vertAlign)
	  // Write acceleration
	  val accel = if (dim == 1) acceleration.x else acceleration.norm
	  gc.drawString ("Accel: " + "%.2f".format (accel) + " [m/s^2]",
			 defaultWidth - horAlign, barHeight + 8*vertAlign)
	}
	
      }

      // Set window size compatible with small screens (the lower limit is a
      // 800x600 screen, to which we have to remove about 50px for the task
      // bar). It is harder to set those sizes relative to the screen size, so
      // this hasn't been done here.
      val defaultWidth = 800
      val defaultHeight = 550

      // Put the frame on the middle of the screen
      val rel_x = 0.5
      val rel_y = 0.5
      
      def setRelativeLocation (middleRelX: Double,
			       middleRelY: Double): Unit = 
				 {
				   assert ((middleRelX >= 0) && (middleRelX <= 1) &&
					   (middleRelY >= 0) && (middleRelY <= 1));
				   
				   val toolkit = Toolkit.getDefaultToolkit ();
				   val screenDimensions = toolkit.getScreenSize ();
				   
				   val width: Int = this.getWidth ();
				   val height: Int = this.getHeight ();
				   
				   val x: Int = ((middleRelX * screenDimensions.width) - (0.5 * width)).toInt;
				   val y: Int = ((middleRelY * screenDimensions.height) - (0.5 * height)).toInt;
				   
				   this.setLocation (x,y);
				 }

      var panel = new MainPanel

      // Return how many pixels a meter should be. We will try to optimize this
      // to make the rocket fit in the screen 
      def pixelPerMeter: Double = {
	// We still want the rocket to be visible
	val min = 1/rocketHeight
	// We do not want the rocket to take more than a fraction of the screen
	val max = (defaultHeight / rocketHeight) / 8

	val curPos = scala.math.max (0, if (dim == 1) position.x else position.y)
	val cand = 0.8 * (defaultHeight / curPos)
	// But we do not want to change the scale often, so we will only settle
	// for the lower power of 2.
	val exp = scala.math.floor (scala.math.log (cand) / scala.math.log (2))
	val res = scala.math.pow (2, exp)
	val finalRes = {
	  if (res <= min)
	    min
	  else if (res >= max)
	    max
	  else
	    res
	}
	// println ("DEBUG: curPos is " + curPos)
	// println ("DEBUG: scale is " + finalRes + " pixel per meter")
	finalRes
      }

      // Get the x and y positions in pixel, with respect to the lower left
      // corner of the floor.
      def getXPos: Double = {
	if (dim == 1)
	  defaultWidth / 2
	else
	  position.x
      }

      def getYPos: Double = {
	val r = {
	  if (dim == 1)
	    position.x
	  else
	    position.y
	}
	r * pixelPerMeter
      }
  
      def init (): Unit = {
	setTitle ("RocketLander")
	setSize (defaultWidth, defaultHeight);
	this.setRelativeLocation (rel_x, rel_y)
	JFrame.setDefaultLookAndFeelDecorated (true)

	setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE)
	panel.setBackground (Color.black)
	panel.init
	add (panel)
	panel.setVisible (true)
	setVisible (true)
      }



      // Update the GUI
      def update: Unit = {
	// setText (pos.toString)
	// label.setVisible (true)
	repaint ()
	panel.setVisible (true)
      }
    }


    var main: MainFrame = new MainFrame ()
    override def outputInfo: Unit = {
      if (nSteps == 0)
	main.init
      main.update
    }
  }
  
}
