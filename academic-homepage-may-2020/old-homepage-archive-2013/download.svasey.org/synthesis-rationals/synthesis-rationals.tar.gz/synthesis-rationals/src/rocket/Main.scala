package rocket

import simulation.RocketSimulation._
import java.lang.Double.parseDouble

object Main {
  def main (args: Array[String]){
    // Some quick command line parsing
    val newArgs = args.filter (el => !el.startsWith ("--"))
    val (boostAccel, g, initFuel, x0, v0, nSamples, realTimeSec, step, initialAccel) = {
      if (newArgs.length < 8){
	println ("Error: please supply the needed 7 arguments")
	System.exit (1)
	(0,0,0,0,0,0,0,0,0)
      }
      else {
	val a = {
	  if (newArgs.length > 8) parseDouble (newArgs (8))
	  else 0.0
	}
	
	(parseDouble (newArgs (0)),parseDouble (newArgs (1)),parseDouble
	 (newArgs (2)),parseDouble (newArgs (3)),parseDouble (newArgs (4)),
	 BigInt (newArgs (5)).toInt, parseDouble (newArgs (6)), parseDouble (newArgs (7)), a)
      }
    }:(Double, Double, Double, Double, Double, Int, Double, Double, Double)


    // val sim = new DelayedFreeFall (boostAccel, g, x0, v0, initFuel, step)
    // val sim = new Oscillator (boostAccel, g, x0, v0, initFuel, step)
    val sim = Lander (nSamples, boostAccel, g, x0, initFuel, step, v0, realTimeSec, initialAccel)

    val t0 = System.currentTimeMillis
    sim.run
    val t2 = System.currentTimeMillis
    val t = (t2 - t0) / 1000.0
    println ("Simulation is over. Final simulated time: " + "%.2f".format(sim.elapsedSimulated)
	     + " s , Speed of impact: " + "%.2f".format (sim.velocity.norm) + " m/s , " +
	     "Remaining fuel: " + "%.2f".format (sim.fuel))
    println ("Total real time: " + t + " sec, Performance: " +
	     sim.getPerformance)
  }
}
