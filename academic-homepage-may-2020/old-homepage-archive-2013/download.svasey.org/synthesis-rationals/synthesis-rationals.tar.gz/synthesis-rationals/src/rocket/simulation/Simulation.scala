package rocket
package simulation

// Base abstract classes for simulation
object Simulation {

  trait Simulator {
    // Number of steps that have currently been executed
    var nSteps: BigInt = 0
    
    // Run a simulation. Return the number of steps it took.
    def run: BigInt = {
      outputInfo
      var over = false
      while (!over){
	over = runStep
	outputInfo
	nSteps = nSteps + 1
      }
      nSteps
    }

    // Output some information on the simulation's progress
    def outputInfo: Unit = {}
  
    // Run one step. Return true iff the simulation is over after that step
    def runStep: Boolean
  }

  // Simulator with some notion of time, trying to mix it with the real world's time
  trait TimedSimulator extends Simulator {
    // Time one step takes in the simulated word, in seconds
    val simulatedTimeStep: Double

    // Time one simulated second must take in the real world. This is used to
    // try to maintain the invariant: nSteps * simulatedTimeStep * realTimeSecond == elapsedTime
    val realTimeSecond: Double

    // Starting time, in nano seconds. This must be set only once
    var startTime: Long = -1

    // Get the current simulated time, in seconds
    def elapsedSimulated: Double = nSteps.toDouble * simulatedTimeStep
    // Get the elapsed real time, in seconds
    def elapsedReal: Double = (System.nanoTime - startTime) * 1e-9
    
    def syncTime: Unit = {
      if (realTimeSecond != 0){
	val expectedElapsed = elapsedSimulated * realTimeSecond * 1e9
	val elapsed = System.nanoTime - startTime
	if (elapsed < expectedElapsed){
	  val diff = expectedElapsed - elapsed
	  val sleepMillis: Long = (diff * 1e-6).toLong
	  val sleepNanos: Int = (diff - (sleepMillis * 1e6)).toInt
	  Thread.sleep (sleepMillis, sleepNanos)
	}
	else {
	  val diff = (elapsed - expectedElapsed) * (1e-6)
	  if (diff > 200)
	    println ("WARNING: Simulation is too slow: delay is " + diff + " ms ")
	}
      }
    }

    def runTimedStep: Boolean
    
    def runStep: Boolean = {
      if (nSteps == 0)
	startTime = System.nanoTime;
      
      val ret = runTimedStep
      syncTime
      ret
    }
  }
  
  trait RealTimeSimulator extends TimedSimulator {
    val realTimeSecond = 1.0
  }
}
  
