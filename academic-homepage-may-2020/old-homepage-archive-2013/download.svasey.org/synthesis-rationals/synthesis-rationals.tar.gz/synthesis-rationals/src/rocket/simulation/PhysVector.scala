package rocket
package simulation

// Vector
class PhysVector (val components: Vector[Double]) {
  def x: Double = get (0)
  def y: Double = get (1)
  def z: Double = get (2)
  def get (index: Int): Double = {
    require (index >= 0 && index < components.size)
    components (index)
  }
  def dim: Int = components.length
  def +(that: PhysVector): PhysVector = {
    require (this.dim == that.dim, "Vectors " + this + " and " + that +
	     " with components " + this.components + " " + that.components +" must have the same dimensions")
    val res = new PhysVector (Vector.range (0, this.dim).map (i => components(i) + that.components (i)))
    assert (res.dim == this.dim)
    res
  }
  def -(that: PhysVector): PhysVector = {
    this + (-that)
  }
  def unary_- : PhysVector = this * (-1.0)
  def *(scal: Double): PhysVector = {
    
    val res = new PhysVector (components.map (_ * scal))
    assert (this.dim == res.dim)
    res
  }
  def /(scal: Double): PhysVector = {
    val res = new PhysVector (components.map (_ / scal))
    assert (this.dim == res.dim)
    res
  }
  def norm: Double =
    scala.math.sqrt (components.foldLeft (0.0) ((cur, el) => cur + el * el))
  override def toString: String = {
    if (dim == 1) x.toString
    else "(" ++ components.mkString (",") ++ ")"
  }
  def isZero: Boolean = norm == 0.0
  def normalized: PhysVector = if (isZero) this else this / (this.norm)
}

object PhysVector {
  def apply (comp: Double*): PhysVector = {
    require (!comp.isEmpty)
    new PhysVector (Vector () ++ comp)
  }
  def zero (dim: Int): PhysVector = {
    require (dim >= 1)
    new PhysVector (Vector.fill (dim) ({0}))
  }
  // The unit vector at the given position
  def unit (dim: Int, pos: Int): PhysVector = {
    require (dim >= 1 && pos < dim)
    new PhysVector (Vector.tabulate (dim) (id => if (id == pos) 1.0 else 0.0))
  }
}

