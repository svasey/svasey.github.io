#!/bin/bash

### Package a release tarball. The first argument is the version number, the
### second is the project source directory. There should be nothing to commit to
### the git repository, otherwise the script will complain

# Copyright (C) 2008 Sebastien Vasey

# This file is part of list2pkg

# list2pkg is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
   
# list2pkg is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
   
# You should have received a copy of the GNU General Public License
# along with list2pkg; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA 02110-1301, USA.  

set -o errexit

usage ()
{
    echo "usage: $0 version project_root_directory" 1>&2
}

VERSION="$1"
PROJECT_ROOT="$2"
DOCUMENTATION="${PROJECT_ROOT}/doc"
TMP_DIR="/var/tmp"

if [ $# -ne 2 ]; then
    usage
    exit 1
fi

# We make sure the documentation compiles first.
${PROJECT_ROOT}/helpers/build-doc.sh $PROJECT_ROOT

(cd $PROJECT_ROOT && git status | grep "^nothing to commit" > /dev/null)

if [ $? -ne 0 ]; then
    echo "There should be nothing to commit in the git directory" 1>&2
    exit 1
fi

(cd $PROJECT_ROOT && git tag "v${VERSION}")

# Do everything in a temporary directory in order not to pollute the original
# source directory.

TMP_ROOT="$(mktemp -d ${TMP_DIR}/list2pkg.XXXXXXXXX)"
TMP_PROJROOT="${TMP_ROOT}/list2pkg-${VERSION}"

cp -arv "$PROJECT_ROOT" "$TMP_PROJROOT"

# Compile the documentation so that the files have the proper version
${PROJECT_ROOT}/helpers/build-doc.sh $PROJECT_ROOT

#  Copy the documentation
cp -av ${DOCUMENTATION} ${TMP_PROJROOT}

for f in $(cat ${TMP_PROJROOT}/.gitignore) ; do
    if echo $f | grep -E 'doc/html' || echo $f | grep -E 'doc/man' ; then
	true
    else
	(cd $TMP_PROJROOT && rm -rfv $f)
    fi
done

echo $VERSION > "${TMP_PROJROOT}/VERSION"

DEST="${PWD}"

cd "$TMP_ROOT" && tar --create --gzip --file \
    "${DEST}/list2pkg-${VERSION}.tar.gz" "list2pkg-${VERSION}"

rm -rfv ${TMP_ROOT}

exit 0


