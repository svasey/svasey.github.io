### Author: Sebastien Vasey (http://svasey.org/)

"""
Some special type of files that use the pickle module. These are usually used
when python programs using those classes need to communicate: these are NOT
intended to be user-readable, nor readable by other programs that do not use
these classes.
"""

from os.path import exists, basename, dirname
from pickle import dump, load

from svlib.globallock.GlobalLock import GlobalLock
from svlib.file.func import fileHash
from svlib.atomicfile.AtomicFile import AtomicFile

class PickleFile:
    """File that can be pickled (base abstract class)"""

    def __init__ (self, filePath):
        self.filePath = filePath

    def readContent (self):
        """Return the content of the file"""

        with open (self.filePath, 'r') as fileStream:
            return load (fileStream)
    
    def writeContent (self, content):
        """Overwrite the content of the file"""
        
        with open (self.filePath, 'w') as fileStream:
            return dump (content, fileStream)

class AtomicPickleFile (PickleFile):
    """File that can be updated in an atomic way (use AtomicFile) """

    def writeContent (self, content):
        with AtomicFile (self.filePath, 'w') as fileStream:
            return dump (content, fileStream)


class GlobalCounter (AtomicPickleFile):
    """
    Implements a global counter: only one process at a time can change it.
    """
    
    counterLock = None

    def __init__ (self, counterPath, firstValue = 1, reset = False):
        """
        The counter is stored at counterPath. If it does not exist, initialize
        it at the given first value. Otherwise, if reset is False do nothing. If
        reset is True, reset it to the given first value.
        """

        AtomicPickleFile.__init__ (self, counterPath)

        self.counterLock = GlobalLock (basename (counterPath),
                                       lockDir = dirname (counterPath))
        self.counterLock.lock ()
        if (not exists (counterPath)) or reset:
            self.writeContent (firstValue)
        self.counterLock.unlock ()

    def doOperation (self, operation):
        """
        Do a given operation on the counter, defined by a function operation
        taking one argument: the current value of the counter. Write back the
        result of operation on the counter and return the previous value.
        """

        self.counterLock.lock ()
        previousValue = self.readContent ()
        nextValue = operation (previousValue)
        self.writeContent (nextValue)
        self.counterLock.unlock ()

        return previousValue

    def increment (self, toAdd = 1):
        """
        Increment the counter by toAdd (1 by default) and return the value
        BEFORE incrementation
        """
        return self.doOperation (lambda x: x + toAdd)
        
        
class FileChangeDB (AtomicPickleFile):
    """
    Database which we can query to know whether a given file has changed
    since we last updated the database. The datastructure in the file is just a
    dictionary that contains a pathString -> hash mapping. SHA512 is used.
    """

    def readContent (self):
        """
        Small extension to the original readContent: if the file does not
        exist, we return an empty dictionary: this means the database has not
        been created yet and hence all files are new
        """

        if not exists (self.filePath):
            return dict ()
        else:
            return AtomicPickleFile.readContent (self)
    
    def fileHash (self, filePath):
        """Return a hash string for the file in filePath"""

        return fileHash (filePath)
            

    def fileInDatabase (self, filePath):
        """
        Return true if the given file is registered in the database
        """

        dictionary = self.readContent ()
        
        return filePath in dictionary
    
    def fileHasChanged (self, filePath):
        """
        Return true when the given file is known as having changed, or is not in
        the database
        """

        dictionary = self.readContent ()

        if filePath not in dictionary:
            return True

        hash = self.fileHash (filePath)
        
        return hash != dictionary[filePath]

    def updateDatabase (self, fileList, removeOld = True):
        """
        Update the database and write it to the file system. Update the hashes
        of the files in fileList or add them if there were not in before. If
        removeOld is true, we will remove all the old entries, so only files in
        fileList will remain. If it is false, entry for files not in fileList
        might remain.
        """

        dictionary = self.readContent ()

        if removeOld:
            dictionary.clear ()

        for file in fileList:
            dictionary[file] = self.fileHash (file)

        self.writeContent (dictionary)

