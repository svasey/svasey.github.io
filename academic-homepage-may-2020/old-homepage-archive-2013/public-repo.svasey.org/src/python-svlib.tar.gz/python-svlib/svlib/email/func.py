"""
Utility functions to send/receive emails quickly
"""

### Author: Sebastien Vasey (http://svasey.org/)

from subprocess import Popen, PIPE
from svlib.servicerunner.Runner import UnexpectedStatusError

def sendMail ( subjectField, content, fromField = 'root@localhost',
               toField = 'root@localhost'):
    """
    Send a simple email to a given recipient
    """
    
    fullContent = 'From: ' + fromField + '\n' + 'To: ' + toField + '\n' + \
        'Subject: ' + subjectField + '\n' + content
    cmd = ['sendmail', '-t']
    process = Popen (cmd, stdin = PIPE)
    process.communicate (fullContent)
    if process.returncode != 0:
        raise UnexpectedStatusError (cmd, process.returncode, 0)
    
