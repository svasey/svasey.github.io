### Author: Sebastien Vasey (http://svasey.org/)

"""

NOTE: Most of this module is CRAP. DO NOT USE IT. The only functions you can use
are callCmd and callCmdGetOutput

Classes to represent services that are running

We must be able to kill those services, see whether they are still running, and
get their return status
"""

import os
import sys
from os import makedirs, link, fork, listdir, remove, execvp, waitpid, dup2
from os.path import exists, join, basename, isdir, realpath
from subprocess import call, Popen, PIPE
from time import time, sleep
from pickle import dump, load
from threading import Thread, current_thread
from tempfile import mkdtemp
from shutil import rmtree
from glob import glob
from signal import signal, SIGTERM
import errno

from svlib.globallock.GlobalLock import GlobalLock, LockingFailedError, \
    NotLockedError
from svlib.atomicfile.AtomicFile import AtomicFile, HLAtomicFile
from svlib.timestampfile.TimestampFile import TimestampFile
from svlib.forked.Forked import Forked, safeKill, safeFork
from svlib.random.Random import tempfilepath
from svlib.random.Random import randomString
from svlib.fs.func import removeThing


class UnexpectedStatusError (Exception):
    """Exception thrown when the return status was not the one expected"""

    def __init__ (self, command, returnStatus, expectedStatus):
        self.command = command
        self.returnStatus = returnStatus
        self.expectedStatus = expectedStatus

    def __str__ (self):
        return "Command " + str(self.command) + \
            " returned unexpected return status " + \
            str(self.returnStatus) + " (expected " + \
            str(self.expectedStatus) + ")"

def lowLevelCallCmd (cmd, expectedReturnStatus, nostdout, nostderr,
                     usePipes = False):
    """
    Function called by both callCmd and callCmdGetOutput to do most of their
    work. If usePipes is True, the stdout and stderr argument to Popen will be
    subprocess.PIPE (unless of course nostdout or nostderr is specified).

    Return a tuple (ret, stdout, stderr), unless the expected return status is
    not good in which case an UnexpectedStatusError is thrown.
    """

    with open (os.devnull, 'w') as nullWriteFile:
        stdoutFile = None
        stderrFile = None
        if usePipes:
            stdoutFile = PIPE
            stderrFile = PIPE
        if nostdout:
            stdoutFile = nullWriteFile
        if nostderr:
            stderrFile = nullWriteFile

        process = None
        def cleanup(signum, frame):
            # print "DEBUG: cleaning up"
            if process:
                process.terminate ()
        # If SIGTERM is received, forward it to the child process
        signal (SIGTERM, cleanup)
        process = Popen (args = cmd, stdout = stdoutFile, stderr = stderrFile)
        outData = ''
        errData = ''
        ret = None
        try:
            if usePipes:
                (outData, errData) = process.communicate ()
            else:
                process.wait ()
        except OSError as err:
            # If it isn't an interrupted call, raise
            if err.errno != errno.EINTR:
                raise
        ret = process.returncode
        if (not expectedReturnStatus is None) \
                and (ret != expectedReturnStatus):
            raise UnexpectedStatusError (cmd, ret, expectedReturnStatus)
        
        return (ret, outData, errData)
    
def callCmd (cmd, expectedReturnStatus = 0, nostdout = False,
             nostderr = False):
    """
    Convenience function to call a command (blocking). If the return status is
    different than expectedReturnStatus (0 by default), we raise an
    UnexpectedStatusError. If expectedReturnStatus is None, the feature is
    disabled and the return status is returned whichever it is. If nostdout or
    nostderr are True, redirect stdout or stderr to /dev/null . `cmd` should be
    given as a list of arguments.
    """

    return (lowLevelCallCmd (cmd, expectedReturnStatus, nostdout, nostderr,
                             usePipes = False))[0]
    
def callCmdGetOutput (cmd, expectedReturnStatus = 0, nostdout = False,
                      nostderr = False):
    """
    Convenience function to call a command (blocking). If the return status is
    different than expectedReturnStatus (0 by default), we raise an
    UnexpectedStatusError. If expectedReturnStatus is None, the return status is
    returned whichever it is. Furtheremore, the standard output content and the
    standard error content are also returned (the output of the function is the
    tuple (retcode, stdout, stderr). Do NOT use if a large output is produced by
    your command. If nostdout or nostderr is True, redirect the stream to
    /dev/null instead, and return an empty string as stdout/stderr.
    """

    return lowLevelCallCmd (cmd, expectedReturnStatus, nostdout, nostderr,
                            usePipes = True)

# Test the module
if __name__ == '__main__':
    print 'Calling command: true'

    ret = callCmd (['true'])

    print 'Return code is', ret
    print 'Calling command: false'

    try:
        ret = callCmd (['false'])
    except UnexpectedStatusError as err:
        print err

    print 'Calling command false, with no expected status'
    ret = callCmd (['false'], expectedReturnStatus = None)
    print 'Return code is', ret
    print 'Calling command false with expected status 1'
    ret = callCmd (['false'], expectedReturnStatus = 1)
    print 'Return code is', ret

    print 'Calling command echo "hi"'
    callCmd (['echo', 'hi'])

    print 'Calling command echo "hi" without stdout'
    callCmd (['echo', 'hi'], nostdout = True)

    print 'Getting output of echo "hi"'
    (ret, outData, errData) = callCmdGetOutput (['echo', 'hi'])
    print 'Output is', outData



class RunnerException (Exception):
    pass

class ServiceRunningError (RunnerException):
    pass

class NoRunnerFileError (RunnerException):
    pass

# Define a few helper methods
def isEmpty (file):
    with open (file, "r") as stream:
        if stream.readline ():
            return False
    return True

def createDirs (dir):
    """Helper function to create a directory hierarchy"""
    try:
        makedirs (dir)
    except OSError as err:
        if not exists (dir):
            raise

class Runner:
    """Represent a running service"""

    # Global name the runner is known as. This must be agreed upon
    # beforehand. If this is not given in the constructor, a unique, guaranteed
    # not to be shared by other instances name is given
    serviceName = None
    
    # Where every file used (return status, lock file) is.
    serviceDir = None

    # Where the return status is stored. This is not created until we
    # effectively manage to run something.
    returnAtomicStream = None

    # Lock of the return file. When this gets unlocked, then any process can
    # remove our return file
    returnLock = None

    # Locked when we are starting the service
    startLock = None

    # Locked when the service is running
    runLock = None

    # Forked object running in the background when the service is running. We
    # must be careful to wait() for it when it has finished, otherwise lots of
    # zombies will be left over.
    runnerProcess = None


    def getUnusedName (self, runDir):
        """
        Return a service name that is not yet used. To do that, we return a
        name containing the current timestamp and a 12 character random string
        (be paranoid :-))
        """

        return 'anonymous.' + str (time ()) + randomString (length = 12)
    
    # /tmp prefix is used by default so that non-root program can also use that
    # class.
    def __init__ (self, serviceName = None, runDir = join (os.sep, "tmp")):
        """If serviceName is not given, we create an 'anonymous' runner, that
        will have a unique name different than all the other ones"""

        if serviceName is None:
            self.serviceName = self.getUnusedName (runDir)
        else:
            self.serviceName = serviceName
        self.serviceDir = join (runDir, "servicerunner." + self.serviceName)
        createDirs (self.serviceDir)
        self.startLock = GlobalLock ("start", lockDir = self.serviceDir)
        self.runLock = GlobalLock ("run", lockDir = self.serviceDir)

    def launchFunction (self, toCall, args = (), kwargs = {}):
        """Run the given function. Do not block. Any exception thrown by the
        function is caught and written as return status. If something is still
        running, raise a ServiceRunningError"""

        # Do a little cleaning up, just so that the service directory does not
        # clutter up with useless files
        self.cleanupRunFiles ()
        
        try:
            self.startLock.lock (block = False)
        except LockingFailedError as err:
            raise ServiceRunningError ()
        if self.runLock.isLocked ():
            self.startLock.unlock ()
            raise ServiceRunningError ()
        
        # If the service is not starting and not running, it is safe to
        # start it. Since we acquired the start lock, no race condition is
        # possible

        # We create the return file and its lock
        atomicFilePath = tempfilepath (prefix = 'return.', suffix = '.ret',
                                       dir = self.serviceDir)
        self.returnLock = GlobalLock (atomicFilePath, lockDir = self.serviceDir)
        self.returnLock.lock ()
        self.returnAtomicStream = AtomicFile (atomicFilePath, 'w+')
        # Make the return file an empty file
        self.returnAtomicStream.commit ()

        # Finally, we fork the function runner
        self.runnerProcess = Forked (self.functionRunner,
                                     (toCall, args, kwargs))

        # We wait until the runLock is locked for sure before releasing our
        # start lock.
        while (not self.runLock.isLocked ()) and \
                self.runnerProcess.isRunning ():
            sleep (0.1)

        self.startLock.unlock ()

    def functionRunner (self, toCall, args = (), kwargs = {}):
        """'Run the given function in a separate process"""

        # First, acquire the run lock
        self.runLock.lock ()
        ret = None
        try:
            # Fork the given function
            self.funcProcess = Forked (toCall, args, kwargs)
            # Get return value, waiting for procObj to return
            ret = self.funcProcess.getReturnValue ()
        except Exception as err:
            ret = err
            
        self.returnAtomicStream.seek (0)
        dump (ret, self.returnAtomicStream)
        self.returnAtomicStream.commit ()
        self.runLock.unlock ()

    def cleanupRunFiles (self):
        """Cleanup all the file we can in serviceDir"""
        listing = listdir (self.serviceDir)
        toremove = []
        for name in listing:
            # Make this a full path
            entry = join (self.serviceDir, name)

            # Do not remove any lock file, except those associated with an
            # unused return file (will be deleted at the same time as the return
            # file is deleted.
            if (not name.endswith (".lock")) and (not isdir (entry)) and \
                    (not name.endswith (".update")):
                if name.endswith (".ret"):
                    # Remove the return file only if the lock file is not
                    # locked
                    lock = GlobalLock (name, lockDir = self.serviceDir)
                    if not lock.isLocked ():
                        # First remove the other files, then the .ret file,
                        # since if something fails in between the removals, the
                        # ret file will still be checked by cleanuprunFiles
                        toremove.extend (glob (entry + "?*"))
                        toremove.append (entry)
                else:
                    toremove.append (entry)
        for el in toremove:
            try:
                if isdir (el):
                    rmtree (el)
                else:
                    remove (el)
            # Ignore it if file does not exist anymore (probably a race
            # condition)
            except OSError as err:
                    if err.errno != errno.ENOENT:
                        raise

    def isRunning (self):
        """Return true if ANY instance of the service is currently running,
        false otherwise."""
        return (self.startLock.isLocked () or self.runLock.isLocked ())

    def ourInstanceIsRunning (self):
        """Return true if an instance started with this object is currently
        running (useful to know if we can get the return status)"""

        # We assume it is running if the return status is not empty, this would
        # mean something has been written to it, and since it is atomic, the
        # full return status must have been written.
        if self.returnAtomicStream is None:
            return False

        # Rewind to the beginning of the file
        self.returnAtomicStream.seek (0)

        ret = True
        if self.returnAtomicStream.readline ():
            ret = False

        self.returnAtomicStream.seek (0)

        return ret

    
    def collectedReturnStatus (self):
        """Return true if we have already collected this instance's running
        status, and everything has already been cleaned-up"""
        return self.returnAtomicStream is None

    def hasReturnStatus (self):
        """Return true if this instance's return status can be collected using
        getReturnStatus"""
        return (not self.ourInstanceIsRunning ()) and \
            (not self.collectedReturnStatus ())

    def getReturnStatus (self, block = True):
        """Read the return status of this instance. If block is true, wait until
        we have it. If it is false, raise a servicerunning error if this
        instance is still running."""

        if self.ourInstanceIsRunning ():
            if  not block:
                raise ServiceRunningError ()
            while self.ourInstanceIsRunning ():
                sleep (0.1)
        
        # Our instance is not running, and will not run again while we are
        # checking the return status
        self.returnAtomicStream.seek (0)
        ret = load (self.returnAtomicStream)

        # Now that we have the return status, we can clean up everything
        self.returnAtomicStream.close ()
        self.returnAtomicStream = None
        self.returnLock.unlock ()
        self.cleanupRunFiles ()

        # Do not forget to wait for the runner function
        self.runnerProcess.wait ()

        return ret

    def kill (self, timeout = 1):
        """Send sigterm to the process. If this does not work after timeout
        seconds, send sigkill. Return the exit status. Raise a RunnerException
        if we have not started the service yet"""
        if self.runnerProcess is None:
           raise RunnerException ("We have never started an instance " +
                                  "of service: cannot kill it")

        ret = self.runnerProcess.kill (timeout)
        try:
            self.runLock.unlock ()
        except NotLockedError as err:
            # It doesn't matter if it is unlocked: we go on
            pass

        self.cleanupRunFiles ()
        return ret

    def execCmd (self, cmd):
        """Call execvp on cmd and return afterward"""
        pid = safeFork ()
        if (pid == 0):
            # In child
            try:
                execvp (cmd[0], cmd)
            except Exception as err:
                # It is necessary to do  this, otherwise the python process
                # returns 0 for some reason
                sys.stderr.write (str (err) + '\n') 
                sys.exit (127)
        else:
            # In parent. 
            signal (SIGTERM, lambda signum, frame: (safeKill (pid)))
            (pid, status) = waitpid (pid, 0)
            return status >> 8
    
    def launchCmd (self, cmd):
        """Start a given external command. Do not block. cmd must be given as a
        list of argument"""

        program = cmd[0]
        self.launchFunction (lambda : (self.execCmd (cmd)))



    
        


class CommandRunner (Runner):
    """Runner specialized in running external commands: capture stdout and
    stderr. This is not to be used in case the command outputs large amounts of
    data. Do NOT forget to close() it after it was run. If you just want to run
    a command and get its final output, use the convenience function
    callCmdGetOutput"""

    # The command to be run
    command = None
    # Temporary directory that will contain the two output file (stderr and
    # stdout)
    outputDir = None
    # Standard output and standard error file and their stream object
    stdoutFile = None
    stdoutStream = None
    stderrFile = None
    stderrStream = None

    # Popen object used to run the command
    processObj = None
    
    def __init__ (self, command, serviceName = None,
                  runDir = join (os.sep, "tmp"), stdoutfile = None,
                  stderrfile = None, canReadStdout = True,
                  canReadStderr = True):
        """
        Initialize: the arguments are the same as for Runner except the first
        one: a list of all the command arguments. stdoutfile and stderrfile are
        used to provide alternate files in which their output will be
        written. This can be used to e.g specify /dev/null or /dev/stdout to one
        of them if it is not needed. If canReadStdout is False, the stderr file
        will never be read and a call to getCurrentStdout will just return an
        empty string.
        """
        
        Runner.__init__ (self, serviceName, runDir)
        self.command = command
        self.outputDir = mkdtemp (dir = runDir, prefix = "svlib.commandrunner.",
                                  suffix = '.outdir')
        if stdoutfile is None:
            self.stdoutFile = join (self.outputDir, 'stdout')
        else:
            self.stdoutFile = stdoutfile
        if stderrfile is None:
            self.stderrFile = join (self.outputDir, 'stderr')
        else:
            self.stderrFile = stderrfile

        self.canReadStdout = canReadStdout
        self.canReadStderr = canReadStderr

        
    def execCmd (self, cmd):
        """Call execvp on cmd and return afterward. Redirect stdout and stderr
        to stdoutStream and stderrStream"""

        self.stdoutStream = open (self.stdoutFile, 'w')
        self.stderrStream = open (self.stderrFile, 'w')
        
        pid = safeFork ()
        if (pid == 0):
            # In child
            try: 
                stdoutNo = self.stdoutStream.fileno ()
                stderrNo = self.stderrStream.fileno ()
                dup2 (stdoutNo, 1)
                self.stdoutStream.close ()
                dup2 (stderrNo, 2)
                self.stderrStream.close ()
                execvp (cmd[0], cmd)
            except Exception as err:
                # It is necessary to do  this, otherwise the python process
                # returns 0 for some reason
                sys.stderr.write (str (err) + '\n') 
                sys.exit (127)
        else:
            # In parent
            signal (SIGTERM, lambda signum, frame: (safeKill (pid)))
            (pid, status) = waitpid (pid, 0)
            return status >> 8
            
    def launch (self):
        """Start to run the command and write its output. Do not block"""
        self.launchFunction (lambda: (self.execCmd (self.command)))

    def getCurrentOut (self, inStderr):
        """Return what the program has so far outputed in either stderr or
        stdout depending whether inStderr is True or False"""

        filename = self.stdoutFile
        if inStderr:
            filename = self.stderrFile
            if not self.canReadStderr:
                return ''
        if not self.canReadStdout:
            return ''

        # If the file does not exist yet (race condition), just return nothing
        if not exists (filename):
            return ''
        else:
            with open (filename, 'r') as fileStream:
                return fileStream.read ()
        
    def getCurrentStderr (self):
        """Get what the program has so far outputed to stderr in a string"""
        return self.getCurrentOut (True)
        
    def getCurrentStdout (self):
        """Get what the program has so far outputed to stdout in a string"""
        return self.getCurrentOut (False)

    def kill (self, timeout = 1):
        """Same behavior as kill of Runner, but returns a (returncode, stdout,
        stderr) tuple and call close() so that you do not have to do it
        yourself."""
        
        ret = Runner.kill (self, timeout)
        stdoutString = self.getCurrentStdout ()
        stderrString = self.getCurrentStderr ()

        rmtree (self.outputDir)
        return (ret, stdoutString, stderrString)
    
    def close (self):
        """To run once you are done with the object and do not want to get the
        normal or error output anymore. Otherwise, temporary files will still be
        lying around... Once you have done this, any call to getCurrentStderr or
        getCurrentStdout will result in an error. Also, this implicitely calls
        getReturnStatus if it has not been done yet, and return the
        status.  Otherwise, this returns None"""
        
        ret = None
        if not self.collectedReturnStatus ():
            ret =  self.getReturnStatus ()
        removeThing (self.outputDir)
        removeThing (self.serviceDir)
        return ret

# def callCmd (cmd, expectedReturnStatus = 0, nostdout = False,
#              nostderr = False):
#     """
#     Convenience function to call a command (create the anonymous runner etc,
#     and get its return status (blocking)). If the return status is different
#     than expectedReturnStatus (0 by default), we raise an
#     UnexpectedStatusError. If expectedReturnStatus is None, the feature is
#     disabled and the return status is returned whichever it is. If nostdout or
#     nostderr are True, redirect stdout or stderr to /dev/null .
#     """

#     stdoutfile = '/dev/stdout'
#     if nostdout:
#         stdoutfile = os.devnull
#     stderrfile = '/dev/stderr'
#     if nostderr:
#         stderrfile = os.devnull
        
#     return callCmdGetOutput (cmd, expectedReturnStatus, stdoutfile,
#                              stderrfile, canReadStdout = False,
#                              canReadStderr = False)[0]
    
# def callCmdGetOutput (cmd, expectedReturnStatus = 0, stdoutfile = None,
#                       stderrfile = None, canReadStdout = True,
#                       canReadStderr = True):
#     """
#     Convenience function to call a command (create the anonymous command
#     runner etc, and get its return status (blocking)). If the return status is
#     different than expectedReturnStatus (0 by default), we raise an
#     UnexpectedStatusError. If expectedReturnStatus is None, the return status is
#     returned whichever it is. Furtheremore, the standard output content and the
#     standard error content are also returned (the output of the function is the
#     tuple (retcode, stdout, stderr).

#     If stdoutfile or stderrfile are specified, use them instead of the temporary
#     files created to get the standard output and standard error. This can be
#     used to redirect one of them to /dev/null for example. The canReadStdout and
#     canReadStderr arguments are used in case a file like /dev/stdout is passed
#     as stdoutfile. In that case, it doesn't make sense to read stdout afterward,
#     and so canReadStdout should be set to False. In that case, an empty string
#     will be returned if getCurrentStdout is called
#     """

#     runner = CommandRunner (cmd, stdoutfile = stdoutfile,
#                             stderrfile = stderrfile,
#                             canReadStdout = canReadStdout,
#                             canReadStderr = canReadStderr)
#     runner.launch ()
#     returnStatus = runner.getReturnStatus ()
#     stdoutString = runner.getCurrentStdout ()
#     stderrString = runner.getCurrentStderr ()

#     runner.close ()
#     if (not expectedReturnStatus is None) \
#             and (returnStatus != expectedReturnStatus):
#         raise UnexpectedStatusError (cmd, returnStatus, expectedReturnStatus)

    
#     return (returnStatus, stdoutString, stderrString)

        
# Just do some small tests
# if __name__ == "__main__":
#     print "DEBUG: initialising hello"
#     testRun = Runner ("hello")
#     print "DEBUG: is hello running ? " + str (testRun.isRunning ())
#     func = lambda : 42
    
#     print "DEBUG: launching function"
#     testRun.launchFunction (func)

#     print "DEBUG: is hello running ? " + str (testRun.isRunning ())
#     print "DEBUG: is our instance running ? " + \
#         str (testRun.ourInstanceIsRunning ())
    
    
#     print "DEBUG: Getting return status"
#     print "DEBUG: return status is " + str (testRun.getReturnStatus ())

#     print "DEBUG: launching new function: sleep 2"
#     testRun.launchCmd (['sleep','2'])
#     print "DEBUG: is service running ?", str (testRun.isRunning ())
#     print "DEBUG: is our instance running ?", \
#         str (testRun.ourInstanceIsRunning ())

#     print "DEBUG: Getting return status"
#     print "DEBUG: return status is", str (testRun.getReturnStatus ())
#     print "DEBUG: launching anonymous command true"
#     callCmd (["true"])
#     print "DEBUG: launching anonymous command false"
#     try:
#         callCmd (["false"])
#     except UnexpectedStatusError as err:
#         print "DEBUG: got error " + str (err)

#     print "DEBUG: calling command and getting output"
#     (retcode, stdoutString, stderrString) = callCmdGetOutput \
#         (["echo","hello world"])

#     print "DEBUG: return status is", retcode
#     print "DEBUG: stdout is '" + stdoutString + "'"
#     print "DEBUG: stderr is '" + stderrString + "'"

#     print "DEBUG: launching killable command sleep 42"
#     runner = Runner ()
#     runner.launchCmd (['sleep', '42'])
#     print "DEBUG: kill exit status is", runner.kill ()
    

