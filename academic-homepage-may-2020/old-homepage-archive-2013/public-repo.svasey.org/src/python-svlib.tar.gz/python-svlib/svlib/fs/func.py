"""
Functions dealing with the file system
"""

### Author: Sebastien Vasey (http://svasey.org/)

from os import listdir, makedirs, mkdir, remove, rmdir, getcwd, rename, \
    symlink, readlink, chown, lchown, walk, stat, lstat, chmod
from os.path import basename, exists, isdir, islink, relpath, dirname, \
    lexists, join, samefile, realpath
from tempfile import mkdtemp
from shutil import rmtree, copy2, copystat
from pwd import getpwnam
from grp import getgrnam

from svlib.file.func import sameContent

import os

def isHidden (filePath):
    """
    Return true if the given filepath is that of a hidden file
    """

    return (basename (filePath))[0] == '.'

def ls (directory, showHidden = False):
    """
    Return all the files in the directory, minus the . and .. files. Do not
    return any hidden file unless showHidden is True.
    """

    fileList = listdir (directory)

    if showHidden:
        return fileList
    
    return filter ((lambda el: not isHidden (el)), fileList)

def lsRec (directory, followLinks = False, showHidden = False):
    """
    List all the regular files in the given directory. Follow symbolic links if
    followLinks is True. If showHidden is True, also include hidden files
    """

    currentList = []
    fileList = ls (directory, showHidden)
    for el in fileList:
        fullPath = join (directory, el)
        if followLinks and islink (fullPath):
            fullPath = realpath (fullPath)
        if not islink (fullPath):
            if isdir (fullPath):
                currentList.extend (lsRec (fullPath, followLinks, showHidden))
            else:
                currentList.append (fullPath)

    return currentList
        

def mkdirTry (dirPath, createIntermediary = True):
    """
    Create the dirPath directory, do not return an error if it already
    exists. If createIntermediary is true, create all the intermediary
    directories that do not exist in the given path
    """

    if not exists (dirPath):
        if createIntermediary:
            makedirs (dirPath)
        else:
            mkdir (dirPath)

class StupidMistakeError (Exception):
    """
    Thrown when the user tries to remove / ^^
    """

    pass
            
def removeThing (path, removeIfNotEmpty = True, ignoreNotExists = False,
                 removeRoot = False):
    """
    Remove the file at the given path. It can be a directory or a regular
    file. If removeIfNotEmpty is true and the file is a directory, the content
    of the directory will be removed too. Otherwise if the path is a directory
    an error will be raised. If the path is a symbolic link, the symbolic link
    will be removed, not what it points to. If ignoreNotExists is True, no error
    will be raised if the file to remove does not exist. This will refuse to
    remove the root directory and raise an error unless you specify removeRoot =
    True, but do so with caution :-)
    """

    if (not ignoreNotExists) or lexists (path):
        # We have to do that before the root check: it might be a symbolic link
        # that points to a non existing path, and in that case the samefile call
        # will raise an reror
        if islink (path):
            remove (path)
        elif (not removeRoot) and samefile (path, '/'):
            raise StupidMistakeError ()
        elif isdir (path):
            if removeIfNotEmpty:
                rmtree (path)
            else:
                rmdir (path)
        else:
            remove (path)
        

def relPath (fullPath, rootDir = ''):
    """
    Return the relative path of fullPath relative to rootDir. By default,
    rootDir is taken to be the current directory when the function is
    invoked. If rootDir is not a directory, return the path relative to the
    dirname of rootDir.
    """

    if rootDir == '':
        rootDir = getcwd ()
    if not isdir (rootDir):
        return relPath (fullPath, dirname (rootDir))

    return relpath (fullPath, rootDir)

def updateLink (linkPath, pointsTo, tempDir = None):
    """Update linkPath to point to pointsTo. Assumes linkPath is a symbolic
    link: this will override whatever this was.  This is done in an atomic way:
    at any moment in time, the symlink either points to the old destination or
    to the new. If it did not exist, create it. Use tempDir to specify a
    temporary directory to use to create the temporary symlink. If not given,
    the default will be used"""

    symlinkDir = ''
    if tempDir is None:
        tempDir = dirname (linkPath)
        
    symlinkDir = mkdtemp (dir = tempDir)

    tempLink = join (symlinkDir, 'temp_symlink')
    symlink (pointsTo, tempLink)
    rename (tempLink, linkPath)
    removeThing (symlinkDir)

class Error (EnvironmentError):
    pass

try:
    WindowsError
except NameError:
    WindowsError = None

def updateTree (src, dest, symlinks = False, ignore = None,
                mustNotExist = False):
    """
    Works like shutil.copytree, but without the requirement that the destination
    tree does not exist. This is almost copy-pasted code from the
    shutil.copytree function.
    """

    names = listdir (src)
    if ignore is not None:
        ignored_names = ignore (src, names)
    else:
        ignored_names = set ()

    if mustNotExist:
        makedirs (dest)
    else:
        mkdirTry (dest)
        
    errors = []

    for name in names:
        if name not in ignored_names:
            srcname = join (src, name)
            destname = join (dest, name)

            try:
                if symlinks and islink (srcname):
                    linkto = readlink (srcname)
                    updateLink (destname, linkto)
                elif isdir (srcname):
                    if not isdir (destname):
                        removeThing (destname, ignoreNotExists = True)
                    updateTree (srcname, destname, symlinks, ignore,
                                mustNotExist)
                else:
                    if isdir (destname) or islink (destname):
                        removeThing (destname)
                    copy2 (srcname, destname)
            except (IOError, os.error), why:
                errors.append ((srcname, destname, str (why)))
            # Catch the error from the recursive updateTree so that we can
            # continue with other files
            except Error, err:
                errors.extend (err.args[0])
    try:
        copystat (src, dest)
    except OSError, why:
        if WindowsError is not None and isinstance(why, WindowsError):
            # Copying file access times may fail on Windows
            pass
        else:
            errors.extend((src, dest, str(why)))
    if errors:
        raise Error, errors

def syncTree (src, dest, symlinks = False, ignore = None,
              checkSameContent = False):
    """
    Synchronize two directory trees to make sure dest has exactly the same
    content as src. If symlinks is false, copy the content of symlinks rather
    than symlinks themselves. If it is True, copy the symlinks themselves. If
    ignore is not None, this should be a function called in the same manner as
    shutils.copytree . The ignored files will only be copied from src to dest if
    they do not exist in dest. If checkSameContent is True, return True if no
    change was made to dest. This is almost copy-pasted from shutil.copytree
    """

    names = listdir (src)
    destNames = listdir (dest)
    srcSet = set (names)
    destSet = set (destNames)

    # This will stay true until we find a difference between src and dest
    wasSameContent = True

    # We will remove everything that is in dest but not in src
    toRemove = destSet - srcSet
    for el in toRemove:
        wasSameContent = False
        fullPath = join (dest, el)
        removeThing (fullPath)
        
    if ignore is not None:
        ignored_names = ignore (src, names)
    else:
        ignored_names = set ()

    errors = []
    for name in names:
        if (name not in ignored_names) or not exists (join (dest, name)):
            srcname = join (src, name)
            destname = join (dest, name)

            try:
                if symlinks and islink (srcname):
                    linkto = readlink (srcname)
                    if checkSameContent and wasSameContent:
                        if islink (destname):
                            linked = readlink (destname)
                            if linked != linkto:
                                wasSameContent = False
                        else:
                            wasSameContent = False
                    updateLink (destname, linkto)
                elif isdir (srcname):
                    if not isdir (destname):
                        removeThing (destname, ignoreNotExists = True)
                        wasSameContent = False
                    same =  syncTree (srcname, destname, symlinks, ignore,
                                      (checkSameContent and wasSameContent))
                    if not same:
                        wasSameContent = False
                else:
                    if isdir (destname) or islink (destname):
                        wasSameContent = False
                        removeThing (destname)
                    if not exists (destname):
                        wasSameContent = False
                    elif checkSameContent and wasSameContent:
                        same = sameContent (srcname, destname)
                        if not same:
                            wasSameContent = False
                    copy2 (srcname, destname)
            except (IOError, os.error), why:
                errors.append ((srcname, destname, str (why)))
            # Catch the error from the recursive syncTree so that we can
            # continue with other files
            except Error, err:
                errors.extend (err.args[0])

    try:
        copystat (src, dest)
    except OSError, why:
        if WindowsError is not None and isinstance (why, WindowsError):
            # Copying file access times may fail on Windows
            pass
        else:
            errors.extend ((src, dest, str(why)))
    if errors:
        raise Error, errors
    
    return wasSameContent


def recChown (path, uid, gid, followLinks = False):
    """
    Recursively change the ownership of path. If path is a directory,
    recursively change the ownership of its files and its subdirectories. If
    followLinks is True, follow symlinks. WARNING: does not check for infinite
    recursion in that case ! Set uid or gid to -1 if no change is wanted.

    This function is here for backward-compatibility only and is just a wrapper
    around changePerm
    """

    changePerm (path, user = uid, group = gid, recursive = True,
                followLinks = followLinks)


def recChmod (path, mode, add = 0, followLinks = False):
    """
    Recursively change the permission of path. If path is a directory,
    recursively change the ownership of its files and its subdirectories. If
    followLinks is True, follow symlinks. Note that if followLinks is False and
    I encounter a symlink, no file permission will be modified. WARNING: does
    not check for inifinite recursion in that case. The mode argument has a
    syntax similar to the mode argument of os.chmod . If add is 0, set all the
    files and directory to exactly `mode'. If `add' is > 0, add the bits in
    `mode' to the file's permissions. If `add' is < 0, remove the bits in `mode'
    from the file's permissions.

    This function is here for backward-compatibility only and is just a wrapper
    around changePerm
    """

    changePerm (path, mode, add, recursive = True,
                followLinks = followLinks)
    


def changePerm (path, mode = None, add = 0, user = None,
                group = None, recursive = False, followLinks = False):
    """
    Change the permissions and ownership of path.

     - The mode argument has a syntax similar to the mode argument of os.chmod
       If it is none, permissions are not changed.
       - If add is > 0, add the bits in `mode` to the file's permission. If it
       is < 0, remove the bits in `mode` from the file's permissions. If it is
       0, set the file's permission to exactly `mode`.
     - user can be either a username given as a string or a user id given as an
       integer. If it is None or -1, the user is not changed
     - group can be either a group name given as a string or a group id given as
       an integer. If it is None or -1, the group is not changed
     - If recursive is True and path is a directory (or a symlink and
       followLinks is True), recursively change the permissions of all the files
       in `path`. Otherwise, change only the permissions of path
     - If followLinks is True, follow symlinks (WARNING: does not check for
       infinite recursion) If it is False, and a symlink is encountered, no
       permission will be changed.
    """

    if mode is None:
        # Add no bits to the file's permission
        mode = 0
        add = 1

    uid = -1
    gid = -1
    
    if user is not None:
        uid = user
        if type (user) == type (''):
            uid = getpwnam (user).pw_uid
    if group is not None:
        gid = group
        if type (group) == type (''):
            gid = getgrnam (group).gr_gid

    def getEffectiveMode (path, mode, add):
        """
        Return the mode argument we should pass to os.chmod
        """

        if add == 0:
            return mode

        fileMode = None
        if islink (path):
            fileMode = (lstat (path)).st_mode
        else:
            fileMode = (stat (path)).st_mode
        # Remove the filetype mask
        fileMode = fileMode & int ('4777', 8)
        if add > 0:
            return mode | fileMode
        else:
            assert (add < 0)
            return fileMode & (~mode)
            
    if recursive and followLinks and islink (path):
        changePerm (readlink (path), mode, add, user, group, recursive,
                    followLinks)
    elif not islink (path):
        effectiveMode = getEffectiveMode (path, mode, add)
        chown (path, uid, gid)
        chmod (path, effectiveMode)
        if recursive and isdir (path):
            filelist = listdir (path)
            for el in filelist:
                elPath = join (path, el)
                changePerm (elPath, mode, add, user, group, recursive,
                            followLinks)
        
def cleanDirectory (path):
    """
    Remove everything that is inside the directory pointed to by path, but not
    the directory itself
    """

    filelist = listdir (path)
    for el in filelist:
        elPath = join (path, el)
        removeThing (elPath, ignoreNotExists = True)
    
def diskUsage (fileList, followLinks = True):
    """
    Get the number of bytes all the files in fileList take on disk, as reported
    by the OS. If the list is empty, return 0. If symbolic links are specified,
    follow them unless followLinks is False. If some of the files are directory,
    compute the disk usage of all the files they contain recursively
    """

    total = 0
    for el in fileList:
        size = 0
        if (not islink (el)) and isdir (el):
            size = diskUsage (listdir (el), followLinks)
            
        if followLinks:
                size = size + (stat (el)).st_size
        else:
                size = size + (lstat (el)).st_size
            
        total = total + size

    return total

