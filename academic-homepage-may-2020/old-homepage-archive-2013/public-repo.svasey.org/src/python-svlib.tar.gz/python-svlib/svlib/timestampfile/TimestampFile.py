### Author: Sebastien Vasey (http://svasey.org/)

"""
Classes to represent a file where we write a timestamp
"""

from pickle import dump, load
from time import time

from svlib.atomicfile.AtomicFile import AtomicFile

class TimestampFile:
    """File where a timestamp is written"""

    def __init__ (self, filePath, initialTimestamp = None):
        """The initialTimestamp will be written to the file. If None, nothing
        will be written (the file will be left as is)"""
        self.filePath = filePath
        if initialTimestamp is not None:
            self.writeTimestamp (initialTimestamp) 

    def writeTimestamp (self, timestamp):
        """Write the given timestamp to the file"""
        with AtomicFile (self.filePath, "w") as stream:
            dump (timestamp, stream)
        
    def refresh (self):
        """Write the current timestamp to the file"""
        self.writeTimestamp (time ())

    def readTime (self):
        """Return the timestamp in the file"""
        with open (self.filePath, "r") as stream:
            return load (stream)
        
    def hasTimeouted (self, timeoutInterval):
        """Return true if the timestamp in the file is older than
        timeoutInterval"""
        timeInFile = self.readTime ()
        return (time () - timeInFile) > timeoutInterval

    
        
    
