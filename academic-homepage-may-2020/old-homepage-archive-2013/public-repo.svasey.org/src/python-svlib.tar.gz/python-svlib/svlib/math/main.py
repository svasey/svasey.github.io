"""
Main math functions. 
"""

### Author: Sebastien Vasey (http://svasey.org/)

def isPowerOfTwo (n):
    """
    Return True if n is a power of two, False otherwise. This assumes that x i s
    a strictly positive integer.
    """

    assert (n > 0)
    return n & (n - 1) == 0

