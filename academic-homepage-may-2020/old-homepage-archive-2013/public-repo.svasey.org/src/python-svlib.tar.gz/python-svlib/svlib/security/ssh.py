### Author: Sebastien Vasey (http://svasey.org/)

"""
Contains some helper commands to use ssh instead a python script
"""

from os.path import join, exists

class NoConfigFileError (Exception):
    """
    Raised when no ssh configuration file are found for a given host
    """

    def __init__ (self, username, host):
        self.host = host
        self.username = username
        Exception.__init__ (self, 'Could not find configuration file for ' +
                            username + '@' + host)
    

def findConfigFile (user, hostname, baseDir):
    """
    Find a ssh configuration file to connect to hostname as user and return its
    path. The file is searched for in baseDir. Raise a NoConfigFileError if no
    such file was found. The file is searched in
    `baseDir/user@hostname/ssh_config`
    """

    configPath = join (baseDir, user + '@' + hostname, 'ssh_config')
    if not exists (configPath):
        raise NoConfigFileError (user, hostname)
    return configPath

def getSSHCommands (username, server, baseDir):
    """
    Return a tuple (sshCmd, scpBase) containing the ssh command to connect to
    the given server with the given username, and the file transfer command to
    do transfer files from/to it: scpBase takes as argument the source and
    destination files to transfer. Look for the ssh configuration files in
    `baseDir`
    """

    hostConfigPath = findConfigFile (username, server, baseDir)
    serverString = username + '@' + server

    # We need to be root to access the private key needed to authenticate on the
    # remote host.
    sshBase = ['sudo', 'ssh','-t', '-F', hostConfigPath]
    sshCmd = sshBase + [serverString]
    scpBase = ['sudo', 'rsync', '--progress', '--rsh=' + ' '.join (sshBase)]

    return (sshCmd, scpBase)
