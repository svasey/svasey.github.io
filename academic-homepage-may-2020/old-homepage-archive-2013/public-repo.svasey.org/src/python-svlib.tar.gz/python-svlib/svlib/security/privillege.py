### Author: Sebastien Vasey (http://svasey.org/)

"""Code to check and set privilleges, as well as add new users and groups"""

from sys import argv
from os import geteuid, execvp
from grp import getgrall, getgrgid
from pwd import getpwnam

from svlib.servicerunner.Runner import callCmd

class PrivillegeError (Exception):
    """
    Main exception class of this file
    """

    pass

def hasRootPrivillege ():
    """Return True if we are currently running with root privillege, false
    otherwise"""

    return geteuid () == 0

def runSudo (command = None, sudoPath = 'sudo',
             sudoOpts = [], checkPriv = hasRootPrivillege):
    """
    If we do not have some privillege, exec sudo with the command given as
    argument or with sys.argv if command is None.  Concretely, if the checkPriv
    function returns False, we execute $(sudo sudoOptss command). sudoPath can
    be absolute or relative to PATH.

    Command must be given as a list of arguments.

    This can be used in scripts when the script needs root privillege but
    doesn't have them. Just call that function at the very beginning of the
    program.
    """

    if command is None:
        command = argv
    if not checkPriv ():
        execvp (sudoPath, [sudoPath] + sudoOpts + command)

def addUser (userName, ignoreExists = False, homeDir = None,
             shell = '/bin/false'):
    """
    Create a user account with name userName and homeDir /home/userName by
    default. If ignoreExists is True, do nothing if the user already
    exists. Create a group the same name as the user as primary group.
    """

    if homeDir is None:
        homeDir = join ('/home', userName)
    
    ret = callCmd (['useradd', '--shell', shell, '--home', homeDir,
                    userName], expectedReturnStatus = None, nostderr = True)
    if (ret != 0):
        if not ignoreExists and (ret == 9):
            raise PrivillegeError ('User ' + userName + ' already exists')
        elif (ret != 9):
            raise PrivillegeError ('Error while creating user ' + userName +
                                   ' exit status was ' + str (ret))
    # Set a group named the same as the user as primary group
    addUserGroup (userName, groupList = [], primaryGroup = userName,
                  createGroups = True)

def getPrimaryGroupName (userName):
    """
    Get the name of the primary group of userName
    """

    return getgrgid (getpwnam (userName).pw_gid).gr_name    
    
def removeUser (userName, ignoreNotExists = False):
    """
    Remove the user named userName and its primary group. Do not remove its home
    directory. If ignoreNotExists is True, no error will be raised in case the
    group did not exist.
    """

    primaryGroup = getPrimaryGroupName (userName)
    ret = callCmd (['userdel', userName], expectedReturnStatus = None,
                   nostderr = True)
    if ret != 0:
        if (not ignoreNotExists) and (ret == 6):
            raise PrivillegeError ('User ' + userName + ' does not exist')
        elif ret != 6:
            raise PrivillegeError ('Error while removing user ' + userName +
                                   ' exit status was ' + str (ret))
    removeGroup (primaryGroup, ignoreNotExists = True)

def addUserGroup (userName, groupList, primaryGroup = None,
                  createGroups =  False):
    """
    Add userName to the groups in groupList. If primaryGroup is not None, set
    the primary group to primaryGroup. If createGroups is True,
    create the non-existing groups in groupList and primaryGroup
    """

    if createGroups:
        for el in groupList:
            addGroup (el, ignoreExists = True)
        if primaryGroup is not None:
            addGroup (primaryGroup, ignoreExists = True)

    if primaryGroup is not None:
        callCmd (['usermod', '--gid', primaryGroup, userName], nostderr = True)
    if groupList:
        callCmd (['usermod', '--append', '--groups', ','.join (groupList),
                  userName], nostderr = True)
    

def removeUserGroup (userName, groupList):
    """
    Remove the given user from the groups in groupList
    """

    allGroups = getgrall ()
    
    primaryGroup = getgrgid (getpwnam (userName).pw_gid).gr_name
    # Groups the user is member of, without the primary group and the groups in
    # groupList
    userGroups = []
    for group in allGroups:
        if (userName in group.gr_mem) and (group.gr_name not in groupList) \
                and (group.gr_name != primaryGroup):
            userGroups.append (group.gr_name)

    callCmd (['usermod', '--groups', ','.join (userGroups), userName],
             nostderr = True)

def addGroup (groupName, ignoreExists = False):
    """
    Create a group named groupName. If ignoreExists is True, do not raise any
    error if the group already exists
    """

    ret = callCmd (['groupadd', groupName], expectedReturnStatus = None,
                   nostderr = True)
    if ret != 0:
        if (not ignoreExists) and (ret == 9):
            raise PrivillegeError ('Group ' + groupName + ' already exists')
        elif ret != 9:
            raise PrivillegeError ('Error while adding group ' + groupName +
                                   ' exit status was ' + str (ret))

def removeGroup (groupName, ignoreNotExists = False):
    """
    Remove the group named groupName. If ignoreNotExists is True, no errors will
    be raised in case the group did not exist.
    """

    ret = callCmd (['groupdel' , groupName], expectedReturnStatus = None,
                   nostderr = True)
    if ret != 0:
        if (not ignoreNotExists) and (ret == 6):
            raise PrivillegeError ('Group ' + groupName + ' does not exist')
        elif ret != 6:
            raise PrivillegeError ('Error while removing group ' + groupName +
                                   ' exit status was ' + str (ret))
    
