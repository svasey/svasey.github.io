"""
Contains functions dealing with any kind of lists
"""

### Author: Sebastien Vasey (http://svasey.org/)

def flatten (lis):
    """
    Assuming lis is a list of lists, flatten it so that it becomes a single list
    at the end
    """
    
    return sum (lis, [])

def flatMap (func, lis):
    """
    Call map on lis, and then flatten the result
    """

    return flatten (map (func, lis))
