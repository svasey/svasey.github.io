"""Contains functions dealing with list of strings"""

### Author: Sebastien Vasey (http://svasey.org/)

from svlib.string.func import unsensitiveEquals

def indexNotCaseSensitive (lis, stri):
    """Return the index of the first occurence of the string in the list, raise
    a ValueError if it is not in the list. Do all comparision in a case
    insensitive way"""

    for (i, el) in enumerate(lis):
        if unsensitiveEquals (stri, el):
            return i

    raise ValueError (stri + " not in the list")
