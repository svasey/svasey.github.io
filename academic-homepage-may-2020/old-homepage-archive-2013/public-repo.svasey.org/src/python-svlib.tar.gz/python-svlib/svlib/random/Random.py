### Author: Sebastien Vasey (http://svasey.org/)

"""Contains all functions to generate things using randomness"""

from random import randint,random,choice
from string import ascii_letters
from os.path import exists, join

def randomString (length = 6, characters = ascii_letters):
    """Return a random string with the given characters, of the indicated
    length. Characters must be a string consisting of all characters you want to
    possibly be included. If the same character is included several times, then
    it will have more probability than the others to be chosen. The default is
    ascii letters (A-Z and a-z)"""

    randomString = ""
    for index in range (length):
        randomString = randomString + choice (characters)

    return randomString

def tempfilepath (suffix ='', prefix = 'tmp', dir = None):
    """Generate a random temporary file path, guaranteed not to exist after
    generated"""
    if dir is None:
        dir = ""
    randomName = randomString ()
    randomPath = join (dir, prefix + randomName + suffix)
    while exists (randomPath):
        randomName = randomString ()
        randomPath = join (dir, prefix + randomName + suffix)

    return randomPath
    

    


