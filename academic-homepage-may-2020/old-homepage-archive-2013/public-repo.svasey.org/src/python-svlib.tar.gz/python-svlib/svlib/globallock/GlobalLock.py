"""
Classes to represent a "global" lock: given a ressource name previously agreed
on and a directory, any process using that class can lock the lock file
"""

### Author: Sebastien Vasey (http://svasey.org/)

import os
from os import makedirs, remove, fork, getppid
from os.path import join, exists, isdir
from fcntl import lockf, LOCK_UN, LOCK_EX, LOCK_NB
from threading import Thread
from time import sleep
from errno import ENOENT, EACCES, EAGAIN
from shutil import rmtree
from glob import glob

class GlobalLockException (Exception):
    pass

class LockingFailedError (GlobalLockException):
    pass

class NotLockedError (GlobalLockException):
    pass


class GlobalLock:
    """Implements the Global Lock idea"""

    def __init__ (self, resourceName, lockDir = join (os.sep,
                                                      "tmp")):
        self.resourceName = resourceName
        self.lockDir = lockDir
        try:
            makedirs (lockDir)
        except OSError as err:
            if not exists (lockDir):
                raise
        self.lockFile = join (lockDir, resourceName + ".lock")
        # Create the lock file
        self.lockStream = open (self.lockFile, "w")
        self.lockNo = self.lockStream.fileno ()
        # True if we have locked the file using this object
        self.hasLock = False

    def lock (self, block = True):
        """Acquire the lock. If block is False, raise a LockingFailed
        error if this fails. If not, block until we have acquired the lock"""

        if not block:
            try:
                lockf (self.lockNo, LOCK_EX | LOCK_NB)
            except IOError as err:
                if (err.errno == EACCES) or (err.errno == EAGAIN):
                    raise LockingFailedError ()
                else:
                    raise
        else:
            lockf (self.lockNo, LOCK_EX)
            
        self.hasLock = True

    def unlock (self):
        """Unlock the lock we have acquired"""
        if not self.hasLock:
            raise NotLockedError ()
        
        lockf (self.lockNo, LOCK_UN)
        self.hasLock = False

    def isLocked (self):
        """
        Return true if the lock is locked, false otherwise. This requires
        acquiring the lock for a short period if time.
        """
        
        if self.hasLock:
            return True

        try:
            self.lock (block = False)
        except LockingFailedError:
            return True
        
        self.unlock ()
        return False


