"""
Class representing a file that cannot be globbed for interoperability reasons
(e.g a pid file or a file containg a list of word ...). More precisely, those
classes are intended to communicate with other programs that are NOT using those
classes. The files are also user-readable. However, it is NOT recommended to use
those classes when one intends a user to write to the files, as almost no
parsing verification is done. This might only be useful for very simple files,
otherwise, prefer the python ConfigParser module
"""

### Author: Sebastien Vasey (http://svasey.org/)

from os.path import exists, normpath, join, dirname, abspath

from svlib.fs.func import relPath

class NoPickleFile:
    """File that cannot be pickled for interoperability reasons (base abstract
    class)"""

    def __init__ (self, filePath):
        self.filePath = filePath

    def readContent (self):
        """Return the content of the file"""
        raise NotImplementedError ("readContent is virtual")
    
    def writeContent (self, content):
        """Overwrite the content of the file"""
        raise NotImplementedError ("writeContent is virtual")

class StringListFile (NoPickleFile):
    """
    Represent a list of strings, one string for each line of the file. The
    strings cannot contain new lines but can be empty.
    """

    def __init__ (self, filePath):
        NoPickleFile.__init__ (self, filePath)

    def readContent (self):
        """
        Return the list of strings contained in the file, or the empty list if
        the file does not contain anything or does not exist.
        """

        lis = []
        
        if not exists (self.filePath):
            return lis
        
        for line in open (self.filePath, 'r'):
            lis.append (line.rstrip ('\n'))

        return lis

    def writeContent (self, lis):
        with open (self.filePath, 'w') as fileStream:
            for line in lis:
                fileStream.write (line + '\n')

class CommentsStringListFile (StringListFile):
    """
    StringListFile with comments: line that begin with a given character (the
    comments delimiter) simply won't be returned. The default comment delimiter
    is '#'. If the commentDelimiter is None, then no comment delimiter will be
    considered (equivalent to StringListFile)
    """

    def __init__ (self, filePath, commentDelimiter = '#'):
        StringListFile.__init__ (self, filePath)
        self.commentDelimiter = commentDelimiter

    def readContent (self):
        stringList = StringListFile.readContent (self)
        if self.commentDelimiter is None:
            return stringList
        else:
            return filter (lambda el: not el.startswith (self.commentDelimiter),
                           stringList)
    
            
class SimpleStringFile (StringListFile):
    """Represents a file containing a simple short single string in ascii with
    no blank characters, followed eventually by one or more blank characters"""

    def __init__ (self, filePath):
        """The file path must be filePath"""
        StringListFile.__init__ (self, filePath)

    def readContent (self):
        stringList = StringListFile.readContent (self)
        return (' '.join (stringList)).strip ()

    def writeContent (self, content):
        """The content is written in the following format: the string is
        written, and the exactly one new line character (dependent on the
        operating system)"""
        StringListFile.writeContent (self, [content])


class IntegerFile (SimpleStringFile):
    """Represents a file containing a single integer file in ascii, followed
    eventually by one or more new line or spaces. The reading is made using
    python's built in int function"""

    def __init__ (self, filePath, radix = 10):
        """The file path must be filePath, the radix (base of the number we are
        reading) is 10 by default."""
        SimpleStringFile.__init__ (self, filePath)
        self.radix = radix
    
    def readContent (self):
        numberString = SimpleStringFile.readContent (self)
        return int (numberString, self.radix)

    def writeContent (self, content):
        """The content is written in the following format: the integer is
        written without leading 0, followed by one new line character (depends
        on the operating system"""
        SimpleStringFile.writeContent (self, str (content))
        
class BooleanFile (IntegerFile):
    """File containing only a boolean (represented by a 0 or a 1) in textual
    representation, with some spaces or newlines around"""

    def __init__ (self, filePath):
        IntegerFile.__init__ (self, filePath)

    def readContent (self):
        """Return true or false depending on what is in the file. If we read a
        0, return false, otherwise return true"""
        return (IntegerFile.readContent (self) != 0)
    
    def writeContent (self, content):
        """Write a 0 if content is False, a 1 otherwise, followed by the system
        new line character"""
        toWrite = 1
        if not content:
            toWrite = 0
        IntegerFile.writeContent (self, toWrite)

    def toggle (self):
        """Write True if the current content is False, False otherwise"""
        self.writeContent (not self.readContent ())

class KeyValueFile (StringListFile):
    """
    File containing key/value pairs. One pair per line, the key and the value
    are separated with a given separator (:::) by default
    """

    DEFAULT_SEPARATOR = ':::'

    def __init__ (self, filePath, separator = DEFAULT_SEPARATOR):
        StringListFile.__init__ (self, filePath)
        self.separator = separator
    
    def readContent (self):
        """
        Return a dictionary with the key/value pairs
        """

        lis = StringListFile.readContent (self)
        dictionary = dict ()
        
        for line in lis:
            if line.find (self.separator) != -1:
                keyVal = line.split (self.separator)
                dictionary[keyVal[0]] = keyVal[1]

        return dictionary
    
    def writeContent (self, dictionary):
        """
        Write the given dictionary to the file
        """

        lis = []
        for (key, value) in dictionary.items ():
            lis.append (key + self.separator + value)

        StringListFile.writeContent (self, lis)

class PathListFile (CommentsStringListFile):
    """
    File containing a list of path, one path per line. Path should not have the
    \n character in them. Empty lines (i.e lines that contain only spaces) are
    ignored. Relative path are interpreted with respect to the file path and
    converted to absolute
    """

    def readContent (self, relativePath = True):
        """
        Set relativePath to False if you do not want the relative paths to be
        interpreted in any way. If the file might include comments, set the
        delimiter with commentDelimiter. Any line whose content begins with
        commentDelimiter will be ignored. 
        """

        lis = CommentsStringListFile.readContent (self)
        filelist = []
        for line in lis:
            strippedLine = line.strip ()
            if (strippedLine != ''):
                path = line.rstrip ('\n')
                if relativePath and (not path.startswith ('/')):
                    path = normpath (join (dirname (self.filePath), path))

                filelist.append (path)

        return filelist

    def writeContent (self, filelist, resolveRelPath = True):
        """
        Write the files 
        If resolveRelPath is true, the relative paths in fileList will be
        converted to absolute path from the current directory before writing
        them.
        """

        lis = []
        for path in filelist:
            towrite = path
            if (not path.startswith ('/')) and resolveRelPath:
                towrite = abspath (path)
            lis.append (towrite)

        CommentsStringListFile.writeContent (self, lis)
            
    
