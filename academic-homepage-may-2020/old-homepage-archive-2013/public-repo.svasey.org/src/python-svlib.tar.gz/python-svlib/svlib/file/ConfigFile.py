"""
Implements some kinds of configuration files and easy ways to write/read
them. Configuration files are meant to be user readable AND writable. If you do
not need some of those properties, see the NoPickleFile or PickleFile classes
"""

### Author: Sebastien Vasey (http://svasey.org/)
from ConfigParser import SafeConfigParser

def readSimpleConf (filePath, sectionName = 'DEFAULT'):
    """
    Read a simple configuration file: a file in the INI syntax, as read by the
    python ConfigParser module, with only one sectionName section. Return a
    dictionary of all key/value pairs encountered, or an empty dictionary if the
    file did not exist or the section is empty.
    """

    config = SafeConfigParser ()
    config.read (filePath)
    nameValList = config.items (sectionName)
    
    return dict (nameValList)
