"""
Functions dealing with files
"""

### Author: Sebastien Vasey (http://svasey.org/)

from hashlib import sha512
from os.path import samefile, exists

# When we have to read a file in block, this will be the number of bytes in one
# block.
BLOCK_SIZE=1024

class FileError (Exception):
    """
    Main exception class for the functions in that file
    """
    pass

def concatenateFiles (fileList, outFile, separator = ''):
    """
    Concatenate the content of all the files in fileList in the order they are
    given, separating with separator and writing the result in outFile
    """

    with open (outFile, 'w') as outStream:
        for (index, el) in enumerate (fileList):
            with open (el, 'r') as outEl:
                block = outEl.read (BLOCK_SIZE)
                while block:
                    outStream.write (block)
                    block = outEl.read (BLOCK_SIZE)
            if index < (len (fileList) - 1):
                outStream.write (separator)

class LineOutOfBoundsError (FileError):
    pass
            
def getLineContent (filePath, lineNo):
    """
    Return the content of the file at line number lineNo (starts at
    1). Return the string without the final newline. raise a
    LineOutOfBoundsError if the line number is not within the file's range
    """

    counter = 1
    for line in open (filePath, 'r'):
        if counter == lineNo:
            return line.rstrip ('\n')
        counter = counter + 1

    raise LineOutOfBoundsError ("File " + filePath + " does not have a line " +
                                "number " + str (lineNo))

def stringInFile (pattern, filePath):
    """
    Return true if string appears in the content of filePath, False otherwise
    """

    patternLength = len (pattern)
    blockSize = max (BLOCK_SIZE, patternLength - 1)
    with open (filePath, 'r') as fileStream:
        block = fileStream.read (blockSize)
        last = ''
        while block:
            if ((last + block[:patternLength]).find (pattern) != -1) or \
                    (block.find (pattern) != -1):
                return True

            # The pattern could overlap two blocks
            last = block[-1 * (patternLength - 1):]
            block = fileStream.read (blockSize)

    return False

def replaceInFile (mapping, inFile, outFile):
    """
    Replace all the keys in the mapping by their value in the file content in
    inFile, writing in outFile. Note that inFile and outFile cannot be the same
    file.
    """

    assert (not exists (outFile) or not samefile (inFile, outFile))

    maxLength = 0
    for (key, value) in mapping.items ():
        if len (key) > maxLength:
            maxLength = len (key)
    
    blockSize = max (BLOCK_SIZE, maxLength - 1)
    with open (outFile, 'w' ) as outStream:
        with open (inFile, 'r') as fileStream:
            block = fileStream.read (blockSize)
            last = ''
            while block:
                toWrite = last + block
                for (key, value) in mapping.items ():
                    toWrite = toWrite.replace (key, value)
                    
                outStream.write (toWrite[:-1 * (maxLength - 1)])

                # The patterns could overlap two blocks
                last = toWrite[-1 * (maxLength - 1):]
                block = fileStream.read (blockSize)

            outStream.write (last)

def readContent (filePath):
    """
    Return the entire content of the file in filePath. You should be very
    careful with this, as this puts everything entirely in memory, and this
    function assumes you know what you are doing and does not do any check
    """

    with open (filePath, 'r') as fileStream:
        return fileStream.read ()

def createEmpty (filePath, ignoreExists = True, overwrite = False):
    """
    Create an empty file at filePath. If ignoreExists is True, do not complain
    if the file already exists. Otherwise, raise an error. If overwrite is True,
    overwrite the file's content to make it empty, otherwise do nothing. 
    """

    if exists (filePath):
        if not ignoreExists:
            raise FileError ('File ' + filePath + ' already exists')
        elif not overwrite:
            return

    writeContent ('', filePath)
    
    
def writeContent (content, filePath, append = False):
    """
    Write all the content in content to filePath. If append is true, append it
    instead
    """

    mode = 'w'
    if append:
        mode = 'a'
    with open (filePath, mode) as fileStream:
        fileStream.write (content)

def fileHash (filePath, hashObj = None):
    """
    Return a hash digest string for the content of the file in filePath, using
    the given hashObj (conforming to the interface defined in python's hashlib),
    or sha512 if not given. Of course, hashObj must not have been updated with
    other strings before, or the result returned will not be the hash of only
    the file content.
    """

    currentHash = hashObj
    if hashObj is None:
        currentHash = sha512 ()

    with open (filePath, 'r') as fileStream:
        block = fileStream.read (BLOCK_SIZE)
        while block:
            currentHash.update (block)
            block = fileStream.read (BLOCK_SIZE)

    return currentHash.hexdigest ()


def sameContent (firstFile, secondFile):
    """
    Compare the content of the two files byte per byte. Return True if they are
    equal, False otherwise.
    """

    same = True
    firstStream = open (firstFile, 'r')
    secondStream = open (secondFile, 'r')

    block = 'a'
    while same and block:
        block = firstStream.read (BLOCK_SIZE)
        same = (block == secondStream.read (BLOCK_SIZE))

    firstStream.close ()
    secondStream.close ()

    return same
    
