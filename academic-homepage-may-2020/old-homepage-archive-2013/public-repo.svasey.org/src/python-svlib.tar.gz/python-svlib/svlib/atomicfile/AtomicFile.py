"""
Contains implementation of a file that can only be modified in an atomic
way (only works on UNIX).

Also contains some utility functions to change other files in an atomic way
"""

### Author: Sebastien Vasey (http://svasey.org/)

from tempfile import NamedTemporaryFile, mkdtemp
from shutil import copyfile, rmtree
from os.path import exists, dirname, isdir, samefile, join, basename
from os import readlink, remove, listdir, rename, symlink
from glob import glob
from shutil import copy2
from time import sleep

from svlib.fs.func import updateLink, removeThing
from svlib.file.func import BLOCK_SIZE

def fileAtomicOperation (filePath, toRun):
    """
    Run some operation on a file in an atomic way: The toRun function must take
    as argument the path to the file it must modify. It can then do all it wants
    on the file in an atomic or non-atomic way. The same modification will be
    done on filePath but atomically. Note that the file at filePath does not
    have to exist. In that case, the argument to toRun will not exist as
    well. Similarly, toRun may remove the temporary file it is passed as
    argument. In that case, the file at filePath will be atomically deleted as
    well.
    """

    fileDir = dirname (filePath)
    # Cleanup temporary directories that are left due to some error
    for el in glob (join (fileDir, 'svlib.fileAtomicOperation.*.temp')):
        # Just a hack to avoid race conditions in most cases.
        sleep (1)
        removeThing (el, ignoreNotExists = True)
        
    tempDir = mkdtemp (dir = fileDir, prefix = 'svlib.fileAtomicOperation.',
                       suffix = '.temp')
    tempFile = join (tempDir, basename (filePath))
    if exists (filePath):
        copy2 (filePath, tempFile)
    toRun (tempFile)
    if exists (tempFile):
        rename (tempFile, filePath)
    else:
        remove (filePath)
    removeThing (tempDir)

def atomicFileCopy (src, atomicDest):
    """
    Copy the content of the file in src to the atomic file at atomicDest (in an
    atomic way, of course)
    """
  
    with AtomicFile (atomicDest, 'w') as destStream:
        with open (src, 'r') as srcStream:
            block = srcStream.read (BLOCK_SIZE)
            while block:
                destStream.write (block)
                block = srcStream.read (BLOCK_SIZE)
    

class AtomicFile:
    """An atomic file can be written to in an arbitrary way, affecting
    the original file only when the changes are commited. They are committed in
    a way that make it impossible for the original file to be in an intermediary
    state at any time."""

    # Prefix for the temporary directory that is created
    ATOMIC_DIR_PREFIX = '.atomicfile.'
    
    # Path to the file provided by the user
    filePath = None
    # Temporary file where the content is written
    tempFilePath = None
    # Temporary directory containing all the temporary files
    tempDirPath = None
    # File where the actual content is
    currentContentPath = None
    # Stream obtained after opening tempFilePath
    tempFile = None

    def __init__ (self, filePath, mode):
        self.filePath = filePath
        self.mode = mode
        if not (exists (self.filePath)):
            self.tempDirPath = mkdtemp \
                (prefix = self.ATOMIC_DIR_PREFIX + basename (filePath) + '.',
                 dir = dirname (filePath))
        else:
            self.currentContentPath = join (dirname (filePath),
                                            readlink (filePath))
            self.tempDirPath = dirname (self.currentContentPath)
            self.cleanupTempDir ()
            
        self.switchTempFile ()

    def remove (self):
        """Remove all the files in an atomic way"""
        remove (self.filePath)
        rmtree (self.tempDirPath)
        
    def switchTempFile (self):
        """When a change has just been commited or when initializing, we need to
        create a new temporary file where to write the new content""" 
            
        self.tempFile = NamedTemporaryFile (dir = self.tempDirPath,
                                            delete = False)
        self.tempFilePath = self.tempFile.name
        self.tempFile.close ()
        if not (self.currentContentPath is None):
            copyfile (self.currentContentPath, self.tempFilePath)
            
        self.tempFile = open (self.tempFilePath, self.mode)
        
    def cleanupTempDir (self):
        """Remove all the useless temporary files in the temporary directory"""
        for entry in listdir (self.tempDirPath):
            el = join (self.tempDirPath, entry)
            if isdir (el):
                rmtree (el)
            elif (self.currentContentPath is None) or \
                    (not (samefile (self.currentContentPath, el))):
                remove (el)
        
    def __enter__ (self):
        return self

    # Change the filePath symbolic link to point to newDest, which must be in
    # tempDir
    def switchSymlink (self, newDest):
        # It is better if the symlink is relative
        updateLink (self.filePath, join (basename (self.tempDirPath),
                                         basename (newDest)),
                    tempDir = self.tempDirPath)
    def commit (self):
        """Write the modifications back to the original file"""
        self.switchSymlink (self.tempFilePath)
        self.currentContentPath = self.tempFilePath
        self.cleanupTempDir ()
        self.switchTempFile ()

    def revert (self):
        """Revert our modification to the original state. This renders the
        object useless."""
        self.tempFile.close ()
        self.cleanupTempDir ()

    def fileObj (self):
        return self.tempFile

    
    def close (self):
        """Close all filehandles and commit the changes"""
        self.tempFile.close ()
        self.commit ()
        self.cleanupTempDir ()
            
    def __exit__ (self, type, value, traceback):
        if not (type is None):
            self.revert ()
        else:
            self.close ()
    
    # Just the usual functions from the file io standard library. Some might
    # frankly be just useless
            
    def flush (self):
        return self.tempFile.flush ()
    def isatty (self):
        return self.tempFile.isatty ()
    def next (self):
        return self.tempFile.next ()
    def read (self, size = -1):
        if size == -1:
            return self.tempFile.read ()
        else:
            return self.tempFile.read (size)
    def readline (self, size = -1):
        if size == -1:
            return self.tempFile.readline ()
        else:
            return self.tempFile.readline (size)
    def readlines (self, sizehint = -1):
        if sizehint == -1:
            return self.tempFile.readlines ()
        else:
            return self.tempFile.readlines (sizehint)
    def xreadlines (self):
        return self.tempFile.xreadlines ()
    def seek (self, offset, whence = 0):
        return self.tempFile.seek (offset, whence)
    def tell (self):
        return self.tempFile.tell ()
    def truncate (self, size = -1):
        if size == -1:
            return self.tempFile.truncate ()
        else:
            return self.tempFile.truncate (size)
    def write (self, str):
        return self.tempFile.write (str)
    def writelines (self, sequence):
        return self.tempFile.writelines (sequence)


class HLAtomicFile (AtomicFile):
    """Atomic file to which we can use hardlink if we are careful: during the
    commit, there is a brief window where the hardlink to the file content
    changes, but once the commit is done, the file content is still at the same
    inode.""" 

    def commit (self):
        """Write the modifications back to the original file"""
        self.switchSymlink (self.tempFilePath)
        if self.currentContentPath is not None:
            # Keep the same currentContentPath
            copyfile (self.tempFilePath, self.currentContentPath)
            self.switchSymlink (self.currentContentPath)
            self.cleanupTempDir ()
        else:
            self.currentContentPath = self.tempFilePath
            self.cleanupTempDir ()
            self.switchTempFile ()
        
        
        
    
