"""
NOTE: This module is CRAP. Do NOT use.

Classes represented a children that has been forked from the main process. 
"""

### Author: Sebastien Vasey (http://svasey.org/)

import sys, os
from os import fork, kill, waitpid, WNOHANG, getpid
from os.path import join
from errno import EPERM, ENOENT
from signal import signal, SIGTERM, SIGKILL, SIGHUP
from time import sleep, time
from pickle import dump, load
from shutil import rmtree
from tempfile import mkdtemp

from svlib.atomicfile.AtomicFile import AtomicFile

class ForkedException (Exception):
    pass

class ProcessRunningError (ForkedException):
    pass

class NotRunningError (ForkedException):
    pass

def safeFork ():
    """
    Do a fork, but do some cleaning up beforehand to avoid bugs. The usage is
    like os.fork
    """

    # This is necessary, otherwise the forked process inherits the buffer of
    # those two which might cause duplicate output problems
    sys.stdout.flush ()
    sys.stderr.flush ()

    return fork ()

def pidExists (pid):
    """Checks whether a given pid is currently running. Works for any pid, not
    just a child"""
    try:
        kill (pid, 0)
        return True
    except OSError as err:
        return err.errno == EPERM

def safeKill (pid, timeout = 1):
    """Send SIGTERM and SIGHUP to pid, and if after timeout it still exists,
    send SIGKILL"""

    if pidIsRunning (pid):
        kill (pid, SIGTERM)
        kill (pid, SIGHUP)
        killTime = time ()
        while (time () - killTime) <= timeout:
            try:
                return doWait (pid, block = False)
            except ProcessRunningError:
                pass
            sleep (0.1)
            
        kill (pid, SIGKILL)
        return doWait (pid, block = True)
        

def pidIsRunning (pid):
    """Return true if pid is still a running process. pid must be a child of the
    current process  for this to work"""
    try:
        doWait (pid, block = False)
    except ProcessRunningError:
        return True
    else:
        return False

def doWait (pid, block = True):
    """Wait for pid to finish and return its return status. If block is true,
    really wait until it finishes, otherwise raise a ProcessRunningError if the
    process is still running"""

    opt = 0
    if not block:
        opt = WNOHANG
        
    (pid, status) = waitpid (pid, opt)
    if pid == 0:
        raise ProcessRunningError ()
    # Return only the high byte (the exit status)
    return status >> 8

class Forked:
    def __init__ (self, function, args = (), kargs = {},
                  temporaryDir = join (os.sep, "tmp")):
        """Initialize the fork, forking and running function with args as
        regular arguments and kargs as parameter arguments."""

        self.temporaryDir = mkdtemp (dir = temporaryDir,
                                     prefix = "pyforked.",
                                     suffix = ".tmp")

        self.processRunning = True
        self.childPid = safeFork ()

        if (self.childPid == 0):
            # In child
            pid = getpid ()
            ret = None
            try:
                ret = function (*args, **kargs)
            except Exception as err:
                # Apparently, the exact exception type is not always
                # pickable. To avoid this, we have to change the type of all
                # exception return status
                ret = Exception (str (err))
            # Write the return status to a temporary file, if it still exists
            try:
                outFile = join (self.temporaryDir, str (pid) + ".ret")
                with AtomicFile (outFile, "w") as retStream:
                    dump (ret, retStream)
            except OSError as err:
                if err.errno != ENOENT:
                    raise
                

            sys.exit (0)
        else:
            # In parent: set signal handler
            signal (SIGTERM, (lambda signum, frame: (self.kill ())))

    def __del__ (self):
        # If we are the child, we don't want to have anything to do with that
        # object.
        if self.childPid != 0:
            # This might fail in some subtle cases
            try:
                rmtree (self.temporaryDir)
            except OSError as err:
                if err.errno != ENOENT:
                    raise


    def kill (self, timeout = 1):
        """Send sigterm and sighup to the process. If this does not work after
        timeout seconds, send sigkill. Return the exit stats"""

        if self.isRunning ():
            kill (self.childPid, SIGTERM)
            kill (self.childPid, SIGHUP)
            killTime = time ()
            while (time () - killTime) <= timeout:
                try:
                    return self.wait (block = False)
                except ProcessRunningError:
                    pass
                sleep (0.1)

            kill (self.childPid, SIGKILL)
            return self.wait (block = True)

    def isRunning (self):
        """Return true if the process is still running"""
        if not self.processRunning:
            return False
        try:
            self.wait (block = False)
        except ProcessRunningError:
            return True
        else:
            return False
    
    def wait (self, block = True):
        """Wait until the child finishes, and return its return status. If block
        is False, raise a ProcessRunningError if the process is still running"""

        if not self.processRunning:
            raise NotRunningError ()
        status = doWait (self.childPid, block)
        
        self.processRunning = False
        # Return only the high byte (the exit status)
        return status >> 8

    def getReturnValue (self, block = True):
        """Return the function return value. If block is True, wait until the
        function exited. Otherwise, raise a ProcessRunningError if the process
        is still running."""
        if self.processRunning:
            self.wait (block)

        retFile = join (self.temporaryDir, str (self.childPid) + ".ret")
        ret = None
        with open (retFile, "r") as retStream:
            ret = load (retStream)

        return ret

    
    
