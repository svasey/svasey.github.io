### Author: Sebastien Vasey (http://svasey.org/)

"""Some utility string functions"""

from os.path import basename, dirname, join
import os

byteMultiples = ['k', 'm', 'g', 't', 'p', 'e', 'z', 'y']

def unsensitiveCmp (first, second):
    """String case-unsensitive comparison: return a negative number if first <
    second, 0 if first == second and a positive number if first > second"""

    firstLC = first.lower ()
    secondLC = second.lower ()

    return cmp (firstLC, secondLC)

def unsensitiveEquals (first, second):
    """Just a helper function around unsensitiveCmp: return true if first and
    second are equal, false otherwise"""

    return unsensitiveCmp (first,second) == 0

def contains (str, charSet):
    """
    Return a set of the characters in charSet that are contained in str
    """

    retSet = set ()
    for char in str:
        if char in charSet:
            retSet.add (char)

    return retSet

def hasExtension (filePath, ext = None):
    """
    Return true if the given filePath has the extension ext (i.e its basename
    ends with .$ext). If no ext argument is given, then we return true if the
    file has any extension (i.e it contains a dot)
    """

    if ext is None:
        name = basename (filePath)
        return '.' in name
    else:
        return filePath.endswith ('.' + ext)

def changeExtension (filePath, newExt):
    """
    Change the extension of filePath to newExt: return the new file string. If
    the file does not have an extension (i.e its basename does not contain
    something like `.ext`), then the new extension is simply appended to the
    file's basename.
    """
    
    if not hasExtension (filePath):
        return filePath + '.' + newExt

    else:
        name = basename (filePath)
        splitStr = name.split ('.')
        
        newName = '.'.join (splitStr[:-1]) + '.' + newExt
        return join (dirname (filePath), newName)

def stripExtension (filePath, nExt = 1):
    """
    Return the given filepath without its nExt leading extensions. If it had no
    extension in the first place, return it unchanged.
    """

    assert (nExt >= 0)
    if (nExt == 0) or not hasExtension (filePath):
        return filePath
    else:
        name = basename (filePath)
        newName =  '.'.join(name.split ('.')[:-1])
        return stripExtension (join (dirname (filePath), newName), nExt - 1)

def getExtension (filePath):
    """
    Return the extension(s) of the given filepath, prefixed with a dot. For
    example if the file is README.dot.txt, return .dot.txt . If it has no
    extension (i.e no dot in the basename), return the full basename (without
    dot)
    """

    name = basename (filePath)

    splitName = name.split ('.')

    if len (splitName) == 1:
        return splitName[0]
    else:
        return '.' + ('.'.join (splitName[1:]))
    
def extractNumberFromString (numberString):
    """
    Given a string containing a number, return only the number in the given base
    """

    beginPos = -1
    for (index, value) in enumerate (numberString):
        if (beginPos == -1) and value.isdigit ():
            beginPos = index
        elif (beginPos != -1) and (not value.isdigit ()):
            return int (numberString[beginPos:index] )

    # Should never happen
    assert (False)
            
def splitNumberString (numberString):
    """
    Given a string beginning with a number, return a tuple (number, suffix)
    containing the number part and the rest
    """

    assert (numberString[0].isdigit ())
    for index, value in enumerate (numberString):
        if not value.isdigit ():
            return (int (numberString[:index]), numberString[index:])

    return (int (numberString), '')

def parseByteSizeUnit (unit):
    """
    Parse a string of between one and three characters describing an SI
    multiple, e.g KB or kib, or k. Return the multiplier it represents, i.e the
    number by which to multiply `n` `unit` to convert it to bits.
    """

    assert ((len (unit) >= 1) and (len (unit) <= 3))

    multiplePart = None
    iPart = None
    bPart = None

    if unit[0].lower() in byteMultiples:
        multiplePart = unit[0].lower ()
        if len (unit) > 1:
            if unsensitiveEquals (unit[1], 'i'):
                iPart = unit[1]
                if len (unit) > 2:
                    assert (unsensitiveEquals (unit[2], 'b'))
                    bPart = unit[2]
            else:
                assert ((unsensitiveEquals (unit[1], 'b')) and \
                            (len (unit) == 2))
                bPart = unit[1]
    else:
        assert ((len (unit) == 1) and (unsensitiveEquals (unit[0], 'b')))
        bPart = unit[0]

    multiple = 8
    if bPart == 'b':
        multiple = 1
    powersOfTen = (iPart is None)

    if multiplePart is not None:
        if powersOfTen:
            multiple = multiple * \
                10**(3 * (byteMultiples.index (multiplePart) + 1))
        else:
            multiple = multiple * \
                2**(10 * (byteMultiples.index (multiplePart) + 1))

    return multiple
    

def parseByteSize (bytes):
    """
    Parse a size in bytes, with optional multipliers (KB, Kb, KiB ...), and
    return the number of bits it represents
    """

    number, suffix = splitNumberString (bytes)
    if not suffix:
        return number * 8

    multiple = parseByteSizeUnit (suffix)

    return number * multiple
                
def sizeString (bits, unit = None):
    """
    Return a user-readable string expressing the given size using the given
    unit, or choosing a good unit if unit is None.
    """

    bytes = bits * 8
    if unit is None:
        for (index, mult) in enumerate (byteMultiples):
            if 10**(3 * (index + 1)) > bytes:
                if index == 0:
                    unit = 'B'
                else:
                    unit = byteMultiples[index - 1] + 'B'
                break
    
    multiple = parseByteSizeUnit (unit)
    n = float (bits) / float (multiple)

    
    return format (n, '.3g') + unit
