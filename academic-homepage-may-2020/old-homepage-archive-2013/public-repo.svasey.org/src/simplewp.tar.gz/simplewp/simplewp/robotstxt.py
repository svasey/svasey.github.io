### Author: Sebastien Vasey (http://svasey.org/)

"""
Contains some functions for generating a standard robots.txt_ excluding e.g
alternatives content form created by wpcompile
 
.. robots.txt: http://www.robotstxt.org/orig.html
"""


from simplewp.builder import getAllSources
from svlib.fs.func import relPath
from svlib.string.func import changeExtension

def excludeAlternative (rstDir, excludePrintable = True,
                        excludePdf = True, excludeTxt = True):
    """
    Return a list of Disallow: strings to copy as is into the robots.txt
    file. The list is intended to be written using writelines (e.g it already
    contains line separator) It will disallow all alternative contents of the
    html file. You can change any of the exclude arguments if you do not want it
    to be the case for specific files
    """

    disallowList = []
    sources = getAllSources (rstDir)
    for el in sources:
        relative = relPath (el, rstDir)
        printable = changeExtension (relative, 'chtml')
        pdf = changeExtension (relative, 'pdf')
        txt = relative
        if excludePrintable:
            disallowList.append ('/' + printable)
        if excludePdf:
            disallowList.append ('/' + pdf)
        if excludeTxt:
            disallowList.append ('/' + txt)
    
    return map (lambda el: 'Disallow: ' + el + '\n', disallowList)

        
