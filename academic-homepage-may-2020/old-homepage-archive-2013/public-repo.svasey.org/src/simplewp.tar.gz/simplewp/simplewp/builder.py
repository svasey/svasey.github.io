### Author: Sebastien Vasey (http://svasey.org/)

"""
Contains helper functions to build website and create the builders
"""

import os

from optparse import OptionParser
from ConfigParser import SafeConfigParser
from sys import argv
from os import getcwd, listdir, chdir, walk, rename, environ, \
    readlink, symlink
from os.path import basename, dirname, join, exists, isdir, normpath, abspath, \
    islink, lexists, samefile
from shutil import copy, copytree, rmtree
from tempfile import mkdtemp
from re import search
from glob import glob
from time import localtime

from svlib.fs.func import ls, mkdirTry, removeThing, relPath, isHidden, \
    updateTree
from svlib.file.func import concatenateFiles, stringInFile, replaceInFile
from svlib.file.ConfigFile import readSimpleConf
from svlib.picklefile.PickleFile import FileChangeDB
from svlib.nopicklefile.NoPickleFile import KeyValueFile
from svlib.servicerunner.Runner import callCmd
from svlib.string.func import changeExtension

INITIAL_HEADER_LEVEL=2

LATEX_STYLESHEET_PATH = join ('/', 'etc', 'simplewp', 'stylesheet.tex')
COMMON_OPTS = ['--tab-width=4', '--trim-footnote-reference-space', '--halt=3',
               '--no-toc-backlinks']

DEFAULT_PDF_CMD = ['svrst2pdf.py', '--use-latex-toc',
                   '--documentoptions=11pt,a4paper', '--use-latex-footnotes',
                   '--use-latex-citations',
                   '--hyperlink-color=0', '--literal-block-env=verbatim',
                   '--stylesheet=' + LATEX_STYLESHEET_PATH] + \
                   COMMON_OPTS

DEFAULT_HTML_CMD = ['svrst2html.py', '--link-stylesheet',
                    '--initial-header-level=' + str (INITIAL_HEADER_LEVEL),
                    '--no-doc-title', '--no-section-subtitles',
                    '--footnote-reference=superscript'] + \
                    COMMON_OPTS

# Default stylesheet for the printable html version (the one associated with the
# compiled html file). The urls are relative to the build directory
DEFAULT_PRINT_STYLESHEET_URL='css/print.css'
DEFAULT_STYLESHEET_URL='css/default.css'

def getScriptID (scriptName):
    """Get the position in which the script is to run from its name. If there is
    no explicit ID, return -1"""

    splitStr = scriptName.split ('.')
    if len (splitStr) >= 3:
        # There is an id
        return int (splitStr[1])
    else:
        return -1

def scriptNameCmp (firstName, secondName):
    """Return -1 if firstName must be run before secondName, 1 if it is the
    other way around and 0 if it does not matter"""

    return getScriptID (firstname) - getScriptID (secondName)

def preCompileList (nameList):
    """
    Return a (possibly empty) list of pre compile scripts to run in order from
    nameList.
    """

    scriptsList = filter ((lambda el: el.startswith ('precompile.')), nameList)

    return sorted (scriptsList, scriptNameCmp)

def postCompileList (nameList):
    """
    Return a (possibly empty) list of post compile scripts to run in order from
    nameList.
    """

    scriptsList = filter ((lambda el: el.startswith ('postcompile.')), nameList)

    return sorted (scriptsList, scriptNameCmp)


def runScripts (sourceDir, listFilter):
    """
    Run all the scripts in sourceDir matched by listFilter, a function taking as
    argument the basenames of the elements of a directory, and returning the
    list of scripts to run from this name. The scripts will be run in the order
    given in the list
    """

    scriptDir = join (sourceDir, 'scripts')
    buildDir = getcwd ()
    for (dirPath, dirNames, fileNames) in walk (scriptDir, followlinks = True):
        toRun = listFilter (fileNames)

        for el in toRun:
            fullPath = join (dirPath, el)
            print "DEBUG: calling script", fullPath
            callCmd ([fullPath, sourceDir, buildDir])    
    
def runPreCompile (sourceDir):
    """
    Run the precompile scripts in the scripts directory
    """

    runScripts (sourceDir, preCompileList)

def runPostCompile (sourceDir):
    """
    Run the postcompile scripts in the scripts directory
    """

    runScripts (sourceDir, postCompileList)

def copyEverything (sourceDir):
    """
    Copy everything from the tocopy directory to the current directory,
    preserving the directory hierarchy
    """

    toCopyDir = join (sourceDir, 'tocopy')
    def ignoreFunc (dirPath, items):
        def filterFunc (fullPath):
            """
            Return True if the fullPath must be excluded
            """
            return isHidden (fullPath)

        toRet =  filter ((lambda el: filterFunc (join (dirPath, el))), items)
        return toRet 
        
    updateTree (toCopyDir, getcwd (), ignore = ignoreFunc, symlinks = True)
#     toCopy = ls (toCopyDir)
#     for el in toCopy:
#         src = join (toCopyDir, el)
#         name = basename (el)
#         dest = join (getcwd (), name)
#         print "DEBUG: copying", src, "to", dest
#         if (not isdir (src)) or islink (src):
#             # Copy does not handle symbolic links correctly
#             if islink (src):
#                 pointsTo = readlink (src)
#                 removeThing (dest, ignoreNotExists = True)
#                 symlink (pointsTo, dest)
#             else:
#                 copy (src, dest)
#         else:
#             updateTree (src, dest, symlinks = True)

def builderInit ():
    """
    Initialize the builder: the script that will compile the static
    website. Parse its command line arguments, cd to the build directory, run
    the precompile scripts, copy the files in the tocopy directory, and return a
    tuple (options, source) with the options and the source directory. options
    contains the following members:

    * buildAll: True if the user wants to rebuild everything from scratch
    """


    parser = OptionParser (usage = argv[0] + " [sourcedir] [builddir]")
    parser.add_option ('-a','--buildall', action = 'store_true',
                       dest = 'buildAll', default = False,
                       help = 'Build everything from scratch')
    (option, args) = parser.parse_args ()

    if len (args) > 2:
        parser.error ("Incorrect number of arguments")

    sourceDir = getcwd ()

    if len (args) >= 1:
        sourceDir = abspath (args[0])
    buildDir = join (sourceDir, 'build')
    if len (args) >= 2:
        buildDir = abspath (args[1])

    chdir (buildDir)
    runPreCompile (sourceDir)
    copyEverything (sourceDir)
    
    return (option, sourceDir)

def getSourcesDict (rstDir, dirPath):
    """
    Return a dictionary whose keys are the source file basenames, and whose
    value are sets of files (fullPath) that should be compiled into the source
    """

    sources = dict ()

    for el in glob (join (dirPath, '*.rst')):
        name = basename (el)
        # We  will deal with the special head file later
        if name != 'head.rst':
            splitStr = name.split ('.')
            if splitStr[-2].isdigit ():
                sourceName = '.'.join (splitStr[:-2]) + '.source'
            else:
                sourceName = '.'.join (splitStr[:-1]) + '.source'
            if sourceName in sources:
                sources[sourceName].add (el)
            else:
                sources[sourceName] = set ([el])

    headPath = findHeadPath (rstDir, dirPath)
    if headPath is not None:
        for sourceName in sources.keys ():
            # Impossible to use getSourceOptions here, since we do not have the
            # source path
            options = readSimpleConf (changeExtension (join (dirPath,
                                                             sourceName),
                                                       'conf'))
            
            if 'nohead' not in options:
                sources[sourceName].add (headPath)
                
    return sources

def createSourceFiles (rstDir, dirPath, buildDir):
    """
    Compile all the .rst files in dirPath into several .sources file in
    buildDir. Each .sources file will be a web page or a pdf
    """
    
    # Maps one source name (string) to a set of rst files that will be compiled
    # into the same source. 
    sources = getSourcesDict (rstDir, dirPath)
    print "DEBUG: sources is", sources

    def rstCompare (first, second):
        """
        Compare two rst file name. Return a negative number if first must be
        concatenated before second, 0 if it does not matter and a positive
        number otherwise
        """

        if basename (first) == 'head.rst':
            return -1
        elif basename (second) == 'head.rst':
            return 1

        else :
            return (int (first.split ('.')[-2]) - int (first.split ('.')[-2]))

    sourceList = []
    for (sourceName, elSet) in sources.items ():
        elList = sorted (elSet, rstCompare)
        sourceOut = join (buildDir, sourceName)
        concatenateFiles (fileList = elList, outFile= sourceOut,
                          separator = '\n\n')
        sourceList.append (sourceOut)

    return sourceList


def rstToHtml (sourceFile, rstDir, formulaDir, language, cssPrint,
               additionalArguments = []):
    """
    Compile the source rst file to html. The output file will be the same as the
    sourceFile but without the .source extension and with the .chtml (compiled
    html) one. formulaDir is where the mathematical formula png should be
    put. language is the language the file is written in. cssPrint is the url to
    the stylesheet used. additionalArguments contains a list of additionnal
    options to pass to the DEFAULT_HTML_CMD. Return the name of the created html
    file
    """

    def addHtmlTitle (source, output):
        """
        Given an html file source, parse it to get its title and put it between
        <title> tags in output
        """

        options = getSourceOptions (source, rstDir)
        title = getFileTitle (source, options)
        replaceInFile ({'<title></title>':'<title>' + title + '</title>'},
                       source, output)

    environ['SVRST_PNGDIR'] = formulaDir
    tempFile =  changeExtension (sourceFile, 'tempchtml')
    outFile =  changeExtension (sourceFile, 'chtml')
    callCmd (DEFAULT_HTML_CMD + ['--language=' + language] + \
                 ['--stylesheet=' + cssPrint] + \
                 additionalArguments + [sourceFile, tempFile])
    addHtmlTitle (tempFile, outFile)
    removeThing (tempFile)

def rstToPdf (sourceFile, language, sourceDir,
              additionalArguments = []):
    """
    Compile the source rst file to pdf. The output file will be the same as the
    sourceFile, but without the .source extension and with the .pdf
    one. language is the language the file is written in, additionalArguments
    contains a list of additionnal options to pass to the DEFAULT_PDF_CMD
    .Return the name of the created pdf file
    """
    
    options = readSimpleConf (join (sourceDir, 'global.conf'))

    if 'root-url' in options:
        rootUrl = options['root-url']
        print "DEBUG: rootUrl is", rootUrl
        dirPart = '/' + dirname (sourceFile)
        if dirPart.startswith ('/./'):
            dirPart = dirPart[2:]
        if dirPart == '/.':
            dirPart = ''
        print "DEBUG: dirPart is", dirPart
        dirUrl = rootUrl + dirPart
        environ['FULL_DIR_URL'] = dirUrl
    
    outFile = changeExtension (sourceFile, 'pdf')
    callCmd (DEFAULT_PDF_CMD + \
                 ['--language=' + language] + \
                 additionalArguments + [sourceFile, outFile])
    
def getSourceOptions (sourceFile, rstDir):
    """
    Get the options given by the user of sourceFile as a dictionary. The option
    keys can be

    * stylesheet: specify an alternate css stylesheet for the html file
    * pdfopts: additionnal options to pass to the pdf compiler
    * htmlopts: additionnal options to pass to the html compiler
    * nopdf: if specified, this means the file should not be compiled to pdf
    * alternatepdf: if specified, this means the file should not be compiled to
      pdf, but that a replacement pdf will exist (from tocopy).
    * nohtml: if specified, this means the file should not be compiled to html
    * title: alternate title for the html file
    * print-stylesheet: css stylesheet used for the printable version
    * nohead: if specified, this means we should not happen the head.rst file to
       the source file
    * alternatecat: alternate files to concatenate with the compiled html
      file, space-separated, must obey the usual naming conventions.
    """

    filePath = changeExtension (join (rstDir, relPath (sourceFile)), 'conf')
    
    return readSimpleConf (filePath)

def getSourceLanguage (sourceFile):
    """
    Get the language sourceFile is written in as a two-letter string. If we do
    not have enough information, en is assumed
    """

    language = 'en'
    name = basename (sourceFile)
    splitStr = ((name.split ('.'))[0]).split ('_')

    if len (splitStr) >= 2:
        if len (splitStr[-1]) == 2:
            language = splitStr[-1]

    return language
    
def buildFile (sourceFile, sourceDir):
    """
    Compile a single sources (rst) file to html and pdf. Does not check if it
    has already been compiled before. Return the path to the compiled html file,
    or None if it was not compiled to html
    """

    rstDir = join (sourceDir, 'rst')

    options = getSourceOptions (sourceFile, rstDir)
    
    name = basename (sourceFile)
    language = getSourceLanguage (sourceFile)
    htmlOut = None
    if 'nohtml' not in options:
        formulaDir = join (dirname (sourceFile), name + '-formula-png')
        htmlOpts = []
        if 'htmlopts' in options:
            htmlOpts = options['htmlopts'].split (' ')
        cssPrint = relPath (DEFAULT_PRINT_STYLESHEET_URL, sourceFile)
        if 'print-stylesheet' in options:
            cssPrint = options['print-stylesheet']
        htmlOut = rstToHtml (sourceFile, rstDir, formulaDir, language, cssPrint,
                             htmlOpts)
    if ('nopdf' not in options) and ('alternatepdf' not in options):
        pdfOpts = []
        if 'pdfopts' in options:
            pdfOpts = options['pdfopts'].split (' ')
        rstToPdf (sourceFile, language, sourceDir, htmlOpts)

    return htmlOut

def getAllSources (rstDir):
    """
    Get the a list containing the full path of all the sources file in the rst
    directory. Used by the robotstxt module.
    """

    fullList = []
    for (dirPath, dirNames, fileNames) in walk (rstDir, followlinks = True):
        sourcesList = getSourcesDict (rstDir, dirPath).keys ()
        sourcesList = map (lambda el: join (dirPath, el), sourcesList)
        fullList.extend (sourcesList)

    return fullList

def findHeadPath (rstDir, dirPath):
    """
    Find the most specific head.rst file for dirPath i.e if there is an head.rst
    file in dirPath choose this one. If there isn't check if there is one one
    level below, and so on. If there is no head file in rstDir or above, return
    None
    """

    currentPath = abspath (dirPath)

    sameFile = False
    while not sameFile:
        sameFile = samefile (currentPath, rstDir)
        if exists (join (currentPath, 'head.rst')):
            return join (currentPath, 'head.rst')
        currentPath = dirname (currentPath)

    return None

def updateAllSources (sourceDir, changeDatabase, recompileAll):
    """
    Re-create and compile the source files. Return a list of all source files
    that were created and compiled. Update the change database
    """

    rstDir = join (sourceDir, 'rst')
    allSources = []
    for (dirPath, dirNames, fileNames) in walk (rstDir, followlinks = True):
        buildPath = relPath (dirPath, rstDir)
        mkdirTry (buildPath)
        sources = createSourceFiles (rstDir, dirPath, buildPath)
        print "DEBUG: sources are", sources
        for file in sources:
            allSources.append (file)
            if recompileAll or changeDatabase.fileHasChanged (file):
                htmlFile = buildFile (file, sourceDir)
                changeDatabase.updateDatabase ([file], removeOld = False)

    # We still have to remove the files that were not visited this time and are
    # still in the database 
    changeDatabase.updateDatabase (allSources, removeOld = True)
    return allSources


def isSourcesDir (sources, directory):
    """
    Return true if the given directory is part of at least one of the path
    component of sources.
    """

    for el in sources:
        if el.startswith (directory):
            return True

    return False

def isSourcesEl (sources, path, rstDir):
    """
    Return true if the given file is a source or a compiled source
    """

    elPath = normpath (path)
    
    for el in sources:
        fullPath = normpath (el)
        name = basename (el)
        options = getSourceOptions (fullPath, rstDir)

        if fullPath == elPath:
            return True

        if ('nopdf' not in options) and ('alternatepdf' not in options):
            pdfPath = changeExtension (fullPath, 'pdf')
            if elPath == pdfPath:
                return True
        if 'nohtml' not in options:
            htmlPath = changeExtension (fullPath, 'chtml')
            if elPath == htmlPath:
                return True
            
    return False
            

def inToCopy (toCopyDir, path, isDirectory):
    """Return true if the given path is in toCopy and is/is not a directory"""
    toCopyPath = join (toCopyDir, path)
    if lexists (toCopyPath):
        isDir = isdir (toCopyPath) 

        # The islink is a hack, since we cannot determine a-priori whether the
        # symlinks points to a directory or not, we just return true if it
        # exists
        return islink (toCopyPath) or (isDirectory and isDir) or \
            ((not isDirectory) and (not isDir))
    return False

def isFormulaDir (sources, path):
    """
    If the given directory is a formula directory, return its associated html
    file, otherwise return None
    """

    fullPath = normpath (path)

    for el in sources:
        formulaDir = el + '-formula-png'
        if (normpath (formulaDir) == fullPath):
            return changeExtension (el, 'chtml')

    return None
    
def cleanupFormulaDir (formulaDir, htmlFile):
    """
    Cleanup the given formula directory: remove files that are not used anymore
    by searching their basename in the htmlFile: if they do not appear, then
    they are not used
    """

    for file in ls (formulaDir):
        fullPath = join (formulaDir, file)
        name = basename (file)
        if not stringInFile (name, htmlFile):
            print "DEBUG: removing old formula file", fullPath
            removeThing (fullPath)

def cleanupBuildDir (sources, sourceDir):
    """
    Remove everything in the build directory (assumed to be the current
    directory) that is not a compiled source file or a file that has been copied
    from tocopy. Do not remove any hidden file or directory. sources is a list
    of all the sources file that were just built. sourceDir is the root
    directory of the website's source
    """

    copyDir = join (sourceDir, 'tocopy')
    rstDir = join (sourceDir, 'rst')
    buildDir = getcwd ()
    for (dirPath, dirNames, fileNames) in walk (buildDir):
        for dir in list (dirNames):
            path = relPath (join (dirPath, dir), buildDir)
            inSources = isSourcesDir (sources, path)
            inCopy = inToCopy (copyDir, path, True)
            formulaHtml = isFormulaDir (sources, path)
            # Ignore hidden directories and formula directories
            if isHidden (path):
                dirNames.remove (dir)
            # Ignore formula directory: they are cleaned up following a totally
            # different method
            elif formulaHtml:
                dirNames.remove (dir)
                cleanupFormulaDir (path, formulaHtml)
            # Remove directory if it is not part of the sources or the tocopy
            # directory
            elif (not inSources) and (not inCopy):
                dirNames.remove (dir)
                print "DEBUG: removing old directory", path
                removeThing (path)
                
        # Ignore hidden files
        names = filter ((lambda el: not isHidden (el)), fileNames)
        for file in names:
            path = relPath (join (dirPath, file), buildDir)
            inCopy = inToCopy (copyDir, path, False)
            inSources = isSourcesEl (sources, path, rstDir)
            if (not inSources) and (not inCopy):
                print "DEBUG: removing old file", path
                removeThing (path)

def stripCompiledHtml (chtmlPath, assembleDir):
    """
    Strip the compiled html file (remove its <body>, <html> tags, keeping only
    the content). Output it in assembleDir and return the name of the output
    file (same as the basename of chtmlPath but with the ohtml extension
    """

    name = basename (chtmlPath)
    outPath = join (assembleDir, changeExtension (name, 'ohtml'))
    # Lines we will write at the end
    linesToWrite = []

    with open (chtmlPath, 'r') as fileStream:
        # Inclusive begin and end line index of what we will write
        beginIndex = -1
        endIndex = -1
        lines = fileStream.readlines ()
        for (index, value) in enumerate (lines):
            if value.startswith ('<div class="document"'):
                beginIndex = index
                break

        for (index, value) in reversed (list (enumerate (lines))):
            if value.startswith ('</div>'):
                endIndex = index
                break

        linesToWrite = lines[beginIndex:(endIndex + 1)]

    # print "DEBUG: stripped line array:", linesToWrite

    with open (outPath, 'w') as fileStream:
        fileStream.writelines (linesToWrite)
            
    
    return outPath

def concatenateHtml (strippedHtml, assembleDir, htmlDir, options):
    """
    Concatenate all the necessary html files together in the right order and
    output it in a .whtml file in assembleDir. return the path of this html
    file. strippedHtml must be at the middle. The other files must come from
    htmlDir. options is the option dictionnary obtained by calling
    getSourceOptions
    """

    outPath = changeExtension (strippedHtml, 'whtml')
    # Html file coming before and after the stripped html file
    beforeList = []
    afterList = []

    language = getSourceLanguage (strippedHtml)
    htmlList = glob (join (htmlDir, '*.html'))
    if 'alternatecat' in options:
        htmlList = map (lambda el: join (htmlDir, el),
                        options['alternatecat'].split ())
    for el in htmlList:
        name = basename (el)
        fullPath = join (htmlDir, el)

        splitName = name.split ('.')
        if (splitName[-3] == 'bef') and ((splitName[-4] == language) or
                                         (splitName[-4] == 'all')):
            beforeList.append (fullPath)
        elif (splitName[-3] == 'aft') and ((splitName[-4] == language) or
                                           (splitName[-4] == 'all')):
            afterList.append (fullPath)

    def fileCmp (first, second):
        firstId = int ((first.split ('.'))[-2])
        secondId = int ((second.split ('.'))[-2])

        return firstId - secondId

    beforeList.sort (fileCmp)
    afterList.sort (fileCmp)

    concatenateFiles (beforeList + [strippedHtml] + afterList, outPath,
                      separator = '\n')

    return outPath

def getFileTitle (compiledHtmlFile, options):
    """
    Get the title of the html file
    """
    if 'title' in options:
        return options['title']
    else:
        # Parse the compiled html file
        for line in open (compiledHtmlFile, 'r'):
            if line.startswith ('<h' + str (INITIAL_HEADER_LEVEL)):
                # We are at the right line: find the first non-empty string
                # between a > and a <
                closing = -1
                opening = -1

                for (index, character) in enumerate (line):
                    if character == '>':
                        closing = index
                    elif character == '<':
                        opening = index
                        titleStr = line[closing + 1:opening]
                        if (titleStr != '') and not titleStr.isspace ():
                            return titleStr

    # Stupid default document title
    return ''
                            
def getStylesheet (options, compiledHtmlFile):
    """
    Return the path to the css stylesheet (url)
    """

    if 'stylesheet' in options:
        return options['stylesheet']
    else:
        return relPath (DEFAULT_STYLESHEET_URL, compiledHtmlFile)

def getSiteTree (compiledHtmlFile):
    """
    Return a path of links that tell us where we are in the hierarchy. The
    ending file must be compiledHtmlFile
    """

    htmlFile = changeExtension (compiledHtmlFile, 'html')
    SITE_TREE_CLASS = 'site-tree-link'
    SITE_TREE_NOLINK = 'site-tree-nolink'
    path = relPath (htmlFile)
    language = getSourceLanguage (htmlFile)

    if not path.startswith ('./'):
        path = './' + path
        
    splitPath = path.split (os.sep)

    linkList = []
    nameList = []
    for (index, component) in enumerate (splitPath):
        if isdir (component) or (not component.startswith ('index_')):
            pointTo = os.sep.join (splitPath[:(index + 1)])
            # We link to the index in the language of the page
            indexInLanguage = join (pointTo, 'index_' + language + '.chtml')
            if exists (indexInLanguage) or not isdir (pointTo):
                pointTo = changeExtension (indexInLanguage, 'html')
            else:
                candidates = glob (join (pointTo, 'index_*.chtml'))
                pointTo = join (pointTo, 'index.html')
                if not exists (pointTo) and candidates:
                    pointTo = changeExtension (candidates[0], 'html')

            url = relPath (pointTo, htmlFile)

            componentName = component
            if not isdir (component):
                componentName = (component.split ('.')[0]).split ('_')[0]
            if component == '.':
                componentName = 'home'

            linkList.append (htmlLink (url, componentName, SITE_TREE_CLASS))
            nameList.append (componentName)

    # The last element is the current page: do not make a link
    linkList[-1] = '<span class="' + SITE_TREE_NOLINK + '" >' + \
        nameList[-1] + '</span>'

    return ' / '.join (linkList)

def htmlLink (url, content, itemClass = None):
    """
    Create an html link element
    """

    item = '<a href="' + url + '"'
    if not itemClass is None:
        item = item + ' class="' + itemClass + '"'
        
    item = item + '>' + content + '</a>'
    
    return item

def getOtherLanguages (compiledHtmlFile):
    """
    Return a dictionary mapping the different languages this page is in and the
    html page in each language
    """

    languages = dict ()
    htmlDir = dirname (compiledHtmlFile)
    name = basename (compiledHtmlFile)
    splitName = (name.split ('.')[0]).split ('_')
    hasTranslations = False
    if len (splitName) >= 2:
        if len (splitName[-1]) == 2:
            languages[splitName[-1]] = changeExtension (compiledHtmlFile,
                                                        'html')
            hasTranslations = True

    if not hasTranslations:
        languages[getSourceLanguage (compiledHtmlFile)] = \
            changeExtension (compiledHtmlFile, 'html')

    else:
        base = '_'.join (splitName[:-1])
        for el in glob (join (htmlDir, base + '_*.chtml')):
            lang = getSourceLanguage (el)
            languages[lang] = changeExtension (el, 'html')

    return languages
                        

def getTranslationLinks (compiledHtmlFile):
    """
    Return a menu with a link to each translated version of the page, or nothing
    if the page was not translated
    """

    menu = '<p>'
    languages = getOtherLanguages (compiledHtmlFile)
    fileLanguage = getSourceLanguage (compiledHtmlFile)
    print "DEBUG: languages of", compiledHtmlFile, "are", languages
    # If there are no translations, do not create any menu
    if len (languages) == 1:
        return menu + '</p>'

    # Sort by language
    languagePairs = languages.items ()
    languagePairs.sort ((lambda first,second: cmp (first[0], second[0])))

    first = True
    for (lang, file) in languagePairs:
        if not first:
            menu = menu + ' | '
        first = False

        # Do not create a link to the same page
        if lang == fileLanguage:
            menu = menu + '<span class="translation-nolink" >' + \
                lang.upper () + '</span>'
        else:
            menu = menu + htmlLink (basename (file), lang.upper (),
                                    'translation-link')
    menu = menu + '</p>'

    return menu

def getPdfVersionLink (compiledHtmlFile, options):
    """
    Return a link element to the pdf version, preprended with a | if a pdf
    version exists, nothing otherwise
    """

    if 'nopdf' in options:
        return ''
    else:
        return ' | ' + htmlLink (basename (changeExtension (compiledHtmlFile,
                                                            'pdf')),
                                 'PDF')
    
def createVarDict (compiledHtmlFile, rstDir):
    """
    Create all the variables and their mapping to string. compiledHtmlFile is
    the original file compiled from the rst source. rstDir is where all the rst
    files are
    """

    varDict = {}
    options = getSourceOptions (compiledHtmlFile, rstDir)
    varDict['___LANG___'] = getSourceLanguage (compiledHtmlFile)
    varDict['___TITLE___'] = getFileTitle (compiledHtmlFile, options)
    varDict['___STYLESHEET___'] = getStylesheet (options, compiledHtmlFile)
    varDict['___SITE_TREE___'] = getSiteTree (compiledHtmlFile)
    varDict['___TRANSLATION_LINKS___'] = getTranslationLinks (compiledHtmlFile)
    varDict['___PAGE_SOURCE___'] = basename (changeExtension (compiledHtmlFile,
                                                              'source'))
    varDict['___PDF_VERSION_LINK___'] = getPdfVersionLink (compiledHtmlFile,
                                                           options)
    varDict['___PAGE_COMPILED_HTML___'] = basename (compiledHtmlFile)
    varDict['___ROOT_DIR___'] = relPath (getcwd (), compiledHtmlFile)
    curTime = localtime ()
    varDict['___YEAR___'] = str (curTime.tm_year)
    varDict['___MONTH___'] = str (curTime.tm_mon)
    varDict['___MDAY___'] = str (curTime.tm_mday)

    return varDict
    

def replaceVariables (htmlFile, compiledHtmlFile, rstDir, outPath):
    """
    Replace all the variables in htmlFile and write it to outPath
    """
    variables = createVarDict (compiledHtmlFile, rstDir)
    replaceInFile (variables, htmlFile, outPath)
    
                
def assembleFile (sourcePath, rstDir, htmlDir):
    """
    Assemble the compiled html version of the given file
    """

    options = getSourceOptions (sourcePath, rstDir)
    # Path of the compiled html
    assembleDir = mkdtemp (prefix = 'svrst.assemble')
    chtmlPath = changeExtension (sourcePath, 'chtml')
    # Remove the <body> <html> tags from the compiled version before
    # concatenating with other html files
    strippedHtml = stripCompiledHtml (chtmlPath, assembleDir)
    assembledHtml = concatenateHtml (strippedHtml, assembleDir, htmlDir, options)
    outPath = changeExtension (sourcePath, 'html')
    replaceVariables (assembledHtml, chtmlPath, rstDir, outPath)

    removeThing (assembleDir)
                
def assembleSources (sources, rstDir, htmlDir):
    """
    Assemble the compiled html versions of the given sources with the other
    files in htmlDir (header, footer etc...), and replace the given
    variable. Once this step is completed, a complete website is in the build
    directory
    """

    for el in sources:
        assembleFile (normpath (el), rstDir, htmlDir)
    
    
def compileRst (sourceDir, recompileAll = False):
    """
    Compile the (unhidden) files with .rst extension in sourcedir/rst. Every
    file will be outputed to the current directory, but respecting the current
    directory hierarchy in the rst directory: compile those whose basename does
    not match toHtmlExclude to html and those that do not match toPdfExclude to
    pdf. Use the given commands to compile to pdf and html (given as list of
    arguments); they will be invoked like this: cmd + [$src, $outfile].

    The files outputted will have the same name as the original .rst file but
    with the .pdf or .html extension

    If recompileAll is True, then all the files will be recompiled
    inconditionnaly. Otherwise, only the files that have changed since last
    rebuild will be compiled.

    To know whether a file has changed, a database of sha512 hashes is kept up
    to date in the build directory
    """
    
    rstDir = join (sourceDir, 'rst')
    htmlDir = join (sourceDir, 'html')
    changeDatabase = FileChangeDB ('.changed.db')
    allSources = updateAllSources (sourceDir, changeDatabase, recompileAll)
    print "DEBUG: all sources are", allSources
    cleanupBuildDir (allSources, sourceDir)
    assembleSources (allSources, rstDir, htmlDir)
    runPostCompile (sourceDir)
            

    
