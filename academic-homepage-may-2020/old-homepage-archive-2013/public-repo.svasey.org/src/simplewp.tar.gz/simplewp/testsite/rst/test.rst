John Smith's homepage
=====================

.. contents:: Table Of Contents

This is the beginning of the end for this webpage...

* This is the first bullet
* This is the second bullet
* This is the third
  bullet

Hey this is *emphasis* and **big emphasis** and test emphasis

Hey this is some kind of `embedded text` or ``hello world`` command

Definition subsection
---------------------

Testing my own directive

This is a subsection. Latex math directive

.. math::
 
   e^{i\pi} - 1 = 0

Latex math role

The transition :math:`a + b` is contrived!
 
Latex math as default role

.. default-role:: math

Pythagorean theorem: `a^2 + b^2 = c^2`

As a formula on its own

`a^2 + b^2 = c^2`

No image: `a + b = c`

Same formula, but on its own (there should be an image)

`a + b = c`

End of math

Another subsection
------------------

Here is a litteral block::

	(define (fact n)
	  (if (= n 0) 1 (* n (fact (- n 1))))


Hello world

A third subsection
------------------

Here is `an absolute link`_

.. _an absolute link: http://en.wikipedia.org

Here is `a relative link`_

.. _a relative link: translated/index.en.html

Here is an abolute link from its url: http://www.svasey.org

`\tan(x) = \frac{\sin(x)}{\cos(x)}`

This is links to `the subsection of this text`_


.. _the subsection of this text: `A third subsection`_

Subsubsection
#############

This is a subsubsection

    This is some indented text
    This is also indented

Hello world : name
    Hello world is the name of a classical [1]_ computer program. For more
    information see [valuable]_ 

There is no spoon :
    There is no spoon is a famous sentence in the movie "The matrix" [2]_

Mathematics :
    Mathematics are good [3]_

Subsubsection: return
#####################

Another subsubsection

Subsubsectoin: vengeance
########################

Yet another subsubsection


.. [valuable] A valuable citation, online, http://url_%with_underscore$/te%st.html
.. [1] First appeared in the C book written by Ritchie and Kerningham
.. [2] The Matrix is a 1999 movie made by the Wachowski Brothers
.. [3] For some value of good
