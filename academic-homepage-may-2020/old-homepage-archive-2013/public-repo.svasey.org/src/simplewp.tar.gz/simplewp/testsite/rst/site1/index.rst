John Smith's homepage
=====================

This is the beginning of the end for this webpage...

* This is the first bullet
* This is the second bullet
* This is the third
  bullet

Hey this is *emphasis* and **big emphasis** and test emphasis

Hey this is some kind of `embedded text` or ``hello world`` command

Definition subsection
---------------------

Testing my own directive

This is a subsection. Latex math directive

.. math::
 
   e^{i\pi} - 1 = 0

Latex math role

The transition :math:`a + b` is contrived!
 
Latex math as default role

.. default-role:: math

Pythagorean theorem: `a^2 + b^2 = c^2`

As a formula on its own

`a^2 + b^2 = c^2`

No image: `a + b = c`

Same formula, but on its own (there should be an image)

`a + b = c`

End of math

Subsubsection
#############

This is a subsubsection

    This is some indented text
    This is also indented

Hello world : name
    Hello world is the name of a classical computer program. For more
    information see [valuable]_ or [1]_

.. [valuable] A valuable citation, online, http://url_with_underscore/test.html
.. [1] Another valuable citation
