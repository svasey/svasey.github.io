#!/bin/bash

### Author: Sebastien Vasey (http://svasey.org/)

set -o errexit

### Contains helper functions for autonet

if [ -f /etc/autonet/autonet.conf ]; then
    source /etc/autonet/autonet.conf
fi

# Return true if a process with the pid given as argument is still running.
pidrunning ()
{
    PID="$1"

    ps -A | grep -E -q "^[ ]*$PID"
}

# Return 0 if the process with the pid given in a file is still running. Return
# 1 otherwise, or if the file does not exist.
pidfilerunning ()
{
    PIDFILE="$1"

    if [ ! -f "$PIDFILE" ]; then
	return 1
    fi
    PID="$(cat $PIDFILE)"
    pidrunning $PID
}

# Cleanly kill a process with the given pid. If $2 is specified, this gives the
# number of seconds we have to sleep before sending the SIGKILL signal to the
# process (after sending SIGTERM). If $2 is -1, wait undefinitively
cleankill ()
{
    PID="$1"
    GRACETIME="$2"

    kill -TERM $PID 2>/dev/null || true

    if [ "$SLEEPTIME" ]; then
	if [ $SLEEPTIME -lt 0 ]; then
	    while pidrunning $PID ; do
		sleep 1
	    done
	else
	    sleep $SLEEPTIME
	fi
    else
	sleep 1
    fi
    if pidrunning $PID ; then
	kill -9 $PID || true
    fi

    return 0
}

# Kill a process whose pid is given in the pid file $1 . $2 (optional) is the
# time we wait until we issue a kill -9 on the pid, if it still hasn't
# stopped. -1 if we have to wait undefinitely. Remove $1 afterward.
pidfilekill ()
{
    PIDFILE="$1"
    GRACETIME="$2"

    if pidfilerunning "$PIDFILE" ; then
	cleankill "$(cat $PIDFILE)" $GRACETIME
    fi

    rm -f $PIDFILE

    return 0
}

# Return true if element $1 is in array $2, false otherwise
inarray ()
{
    ELEMENT=$1
    ARRAY=$2

    for el in $ARRAY ; do
	if [ "$ELEMENT" = "$el" ]; then
	    return 0
	fi
    done

    return 1
}

# Given a file where each line is a variable and its value
# (VARIABLENAME=VARIABLEVALUE) ($1), change some values according to $2, where
# $2 is of the form VARIABLENAME=VARIABLEVALUE . 
varfilemod ()
{
    FILE="$1"
    MOD="$2"

    TEMP="$(mktemp -t)"

    # Do everything in a temporary file first, so that the main file is never in
    # serious danger.
    if [ -f $FILE ]; then
	cp $FILE $TEMP
    fi

    NAMEPART="$(echo $MOD | sed -r 's@([^=]+)=.*@\1@')"

    # Try to do a modification. If the variable does not exist yet, append it.
    
    if grep -E -q "^${NAMEPART}" $TEMP ; then
	sed -i -r "s@^${NAMEPART}=.*@$MOD@" $TEMP
    else
	echo $MOD >> $TEMP
    fi

    # Just a trick to create the file with the good permissions if it does not
    # exist yet.
    touch "$FILE"

    # Copy the temporary file and restore the file's old permissiosn
    OLD_MOD="$(stat --printf=%a $FILE)"
    cp $TEMP $FILE
    chmod $OLD_MOD $FILE


    rm -f $TEMP
}

# Log a message to the logfile or to stdout if it is not specified
log ()
{
    MESSAGE="($(date)) $@"

    if [ "$LOG_FILE" ]; then
	echo $MESSAGE >> $LOG_FILE
    else
	echo $MESSAGE
    fi
}
