#!/bin/bash

### Author: Sebastien Vasey (http://svasey.org/)

### Get darwrap's version number. First mandatory argument is the source root
### directory.

set -o errexit

usage ()
{
    echo "usage: $0 sourcedir" 1>&2
}

SOURCEDIR="${1}"

if [ $# -ne 1 ]; then
    usage
    exit 1
fi

cd ${SOURCEDIR}

VERSION="unknown"
if [ -e ${SOURCEDIR}/.git ] && which git &>/dev/null ; then
    VERSION="$(git describe --tags)"
    VERSION="$(echo $VERSION | sed 's/^version-//')"
    UNCLEAN="$(git --no-pager diff | head -n 1)"
    if [ "$UNCLEAN" ]; then
	VERSION="${VERSION}-+"
    fi

    echo $VERSION > ${SOURCEDIR}/VERSION
fi

if [ -f ${SOURCEDIR}/VERSION ]; then
    VERSION="$(cat ${SOURCEDIR}/VERSION)"
fi

echo $VERSION

exit 0
