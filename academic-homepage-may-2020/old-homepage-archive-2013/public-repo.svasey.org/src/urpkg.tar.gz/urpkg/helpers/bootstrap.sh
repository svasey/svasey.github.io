#!/bin/bash

# Bootstrap the installation of urpkg: use urpkg to install itself. Takes
# several argument: the project root directory and the project build directory

# Author: Sebastien Vasey (http://svasey.org/)

set -o errexit

usage ()
{
    echo "usage: $0 project_root_dir build_dir" 1>&2
}

get_cmakevar ()
{
    VARNAME="$1"
    CACHE="${BUILD_DIR}/CMakeCache.txt"
    grep -E "^$VARNAME" "${BUILD_DIR}/CMakeCache.txt" \
	| sed -r "s@^${VARNAME}.+=(.+)@\1@" 
}

if [ $# -ne 2 ]; then
    usage
    exit 1
fi

PROJECT_ROOT="$1"
BUILD_DIR="$2"
URPKG="${BUILD_DIR}/src/urpkg"
PKGDIR="$(mktemp -d -t urpkg.XXXXXXXX)"
VERSION="$(${PROJECT_ROOT}/helpers/version.sh $PROJECT_ROOT)"
FINDCMD="${PROJECT_ROOT}/scripts/find"
TRUE_PKGDIR="$($URPKG --info | grep 'package directory' | sed -r 's/.+: //')"
CMAKE_INSTALL_PREFIX="$(get_cmakevar CMAKE_INSTALL_PREFIX)"
CONFIGDIR="$(get_cmakevar CONFIGDIR)"
DOCDIR="$(get_cmakevar DOCDIR)"
MANDIR="$(get_cmakevar MANDIR)"

# Create the true package directory as root
if [ ! -d $TRUE_PKGDIR ]; then
    mkdir $TRUE_PKGDIR
fi

# Add the install groups
groupadd urpkgrp-install || ( test $? -eq 9 )
groupadd urpkgrp-shared || ( test $? -eq 9 )
$URPKG --gen ${CMAKE_INSTALL_PREFIX}/bin
$URPKG --gen ${DOCDIR}
$URPKG --gen ${MANDIR}/man*
$URPKG --gen $(dirname $CONFIGDIR)

chmod -Rv o+xrw ${BUILD_DIR}
$URPKG --install --pkg-name="urpkg-${VERSION}" --findcmd="$FINDCMD" \
    --pkg-dir="$PKGDIR" --no-preinst --no-postinst make -C $BUILD_DIR install

cp -rav ${PKGDIR}/urpkg-${VERSION} ${TRUE_PKGDIR}/

USERNAME="$(stat --format=%U ${TRUE_PKGDIR}/urpkg-${VERSION})"

usermod -d ${TRUE_PKGDIR}/urpkg-${VERSION} $USERNAME

rm -rv $PKGDIR

exit 0


