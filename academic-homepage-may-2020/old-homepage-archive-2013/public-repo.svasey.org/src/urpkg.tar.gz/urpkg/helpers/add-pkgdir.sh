#!/bin/bash

### Run by the slackware-creating script. Add the package directory to the
### slackware package. The first argument is the path to the package tree
### directory.

# Author: Sebastien Vasey (http://svasey.org/)

set -o errexit

if [ $# -ne 1 ]; then
    echo "ERROR: expected exactly one argument" 1>&2
    exit 1
fi

PKGTREE="$1"
PKGDIR=$(urpkg --info --quiet | grep "Default package directory:" | \
    sed -r 's@.+: (.+)@\1@')

if [ ! -d ${PKGTREE}/${PKGDIR} ]; then
    mkdir -m 0755 ${PKGTREE}/${PKGDIR}
fi

exit 0
