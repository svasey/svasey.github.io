#!/bin/bash
# Print the program's version number and write it to the VERSION file
# if it is actually different than what was in that file. Argument: project root
# directory

# Author: Sebastien Vasey (http://svasey.org/)

set -o errexit

usage ()
{
    echo "usage: $0 project_root_directory" 1>&2
}

PROJECT_ROOT="$1"

if [ $# -ne 1 ]; then
    usage
    exit 1
fi

VERSION="unknown"
if [ -f ${PROJECT_ROOT}/VERSION ]; then
    VERSION="$(cat ${PROJECT_ROOT}/VERSION)"
fi
if (which git && which sed && test -d ${PROJECT_ROOT}/.git) &>/dev/null ; then
    VERSION="$(git describe --tags)"
    VERSION="$(echo $VERSION | sed 's/^v//')"
    CLEAN="$( { git --no-pager status || true; } | \
	grep 'nothing to commit (working' || true)"
    if [ "$CLEAN" ]; then
	true
    else
	VERSION="${VERSION}-+"
    fi
fi

if [ ! -f ${PROJECT_ROOT}/VERSION ]; then
    echo "$VERSION" > ${PROJECT_ROOT}/VERSION
elif [ "$(cat ${PROJECT_ROOT}/VERSION)" != "$VERSION" ]; then
    # Necessary, in case VERSION is owned by root and we are only an
    # unprivileged user.
    rm -f ${PROJECT_ROOT}/VERSION
    echo "$VERSION" > ${PROJECT_ROOT}/VERSION
fi

echo "$VERSION"

exit 0