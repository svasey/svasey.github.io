#!/bin/bash

# Update the text files in our source directory (TODO, FAQ etc...) by copying
# the files in the documentation build directories, given as first argument. The
# project root is the second argument

# Author: Sebastien Vasey (http://svasey.org/)

set -o errexit

usage ()
{
    echo "usage: $0 documentation_build_directory project_root_directory" 1>&2
}

BUILD_DOCDIR="$1"
PROJECT_ROOT="$2"

if [ $# -ne 2 ]; then
    usage
    exit 1
fi

for f in ${BUILD_DOCDIR}/{TODO,FAQ,INSTALL,BUGS} ; do
    cp -v $f $PROJECT_ROOT/.
done

exit 0
