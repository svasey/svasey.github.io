/* Contains implementation of the functions declared in io.h */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#include <string.h>
#include <math.h>
#include <errno.h>

#include "io.h"
#include "str.h"
#include "error.h"
#include "fs.h"

void
io_stream_table_init (void)
{
	int i;

	xdebug ("%s\n",__FUNCTION__);

	for (i = 0;i < MAX_STREAM;i++){
		stream_table[i].stream = NULL;
		stream_table[i].filename = NULL;
	}
}

void
io_help (void (*formatf)(const char *fmt,...),
	 const char *shortopt,const char *longopt,const char *description)
{
	/* FIRST_INDENT spaces between the beginning of the line and the short
	   form of the option. DESC_INDENT spaces between the beginning of the
	   line and the beginning of each line of the description text. We write
	   a new line every time that the length of a line exceeds MAX_LENGTH
	   char. Even if the option name takes more than 29 char, we need
	   MIN_SPACES between it and the beginning of the first description
	   line */
	const int FIRST_INDENT = 2;
	const int DESC_INDENT = 29;
	const int MAX_LENGTH = 80;
	const int MIN_SPACES = 3;

	/* What we have left to display of the description string */
	const char *pos = description;
	/* Where the description should start in the line */
	int desc_start;
	/* The position we are in relative to the beginning of the line */
	int line_pos = 0;

	io_spaces (formatf,FIRST_INDENT);
	if (!shortopt){
		io_spaces (formatf,4);
	}
	else {
		formatf ("%s, ",shortopt);
	}
	formatf ("%s",longopt);
	line_pos = FIRST_INDENT + 4 + strlen (longopt);
	if (line_pos > (DESC_INDENT - MIN_SPACES)){
		desc_start = line_pos + MIN_SPACES;
	}
	else {
		desc_start = DESC_INDENT;
	}
	io_spaces (formatf,desc_start - line_pos);
	line_pos = desc_start;

	while ((pos - description) < strlen (description)){
		char *word;
		const char *next_space = strchr(pos,' ');

		if (!next_space){
			next_space = pos + strlen (pos);
		}
		word = xstrncpy(&word,pos,next_space - pos + 1);
		pos = next_space + 1;
		if ((line_pos + strlen (word)) > MAX_LENGTH){
			formatf("\n");
			io_spaces (formatf,DESC_INDENT);
			line_pos = strlen(word) + DESC_INDENT;
		}
		else {
			line_pos += strlen (word);
		}
		formatf ("%s",word);
		free(word);
	}
	
	formatf ("\n");
}

void
io_heading (void (*formatf)(const char *fmt,...),const char *heading)
{
	const int INDENT = 1;

	io_spaces (formatf,INDENT);
	formatf ("%s\n\n",heading);
}

void
io_spaces (void (*formatf)(const char *fmt,...),int n)
{
	int i;

	for (i = 0;i < n;i++){
		formatf (" ");
	}
}

int
io_string_to_mask (const char *str,int *mask,int maxlength)
{
	char *endptr;
	long n;
	double max = pow (2.0,(double)(maxlength));

	xdebug ("%s (%s,%p,%d)\n",__FUNCTION__,str,mask,maxlength);
	xassert (maxlength < sizeof(int));

	errno = 0;
	n = strtol (str,&endptr,8);

	if (errno != 0){
		error_set (CUSTOM_ERROR,"Mask %s could not be read: %s",
			   str,strerror (errno));
		return -1;
	}
	else if (n < 0){
		error_set (CUSTOM_ERROR,"Mask %s is negative",str);
		return -1;
	}
	if ((double)(n) >= max){
		error_set (CUSTOM_ERROR,"Mask %s has too many bits. The "
			   "maximum number of bits is %d",str,maxlength);
		return -1;
	}

	*mask = (int)(n);

	xdebug ("%s : %o\n",__FUNCTION__,*mask);
	return 0;
}

const char *
io_stream_to_name (const FILE *stream)
{
	int i;

	for (i = 0;i < MAX_STREAM;i++){
		if (stream == stream_table[i].stream){
			return stream_table[i].filename;
		}
	}

	return NULL;
}

FILE *
io_fopen (const char *filename,const char *mode)
{
	int i;

	xdebug ("%s (%s,%s)\n",__FUNCTION__,filename,mode);
	
	/* Do not make a backup if the file is opened read-only or does not
	   exist yet */
	if ((strcmp (mode,"r") != 0) && fs_file_exists_p (filename)){
		if (fs_make_backup (filename) < 0){
			error_set (CUSTOM_ERROR,"Could not backup file %s : %s",
				   filename,error_describe ());
			return NULL;
		}
	}

	/* Look for a 'null' stream */
	for (i = 0;(i < MAX_STREAM) && (stream_table[i].stream != NULL);i++);
	xassert (i < MAX_STREAM);

	stream_table[i].stream = fopen (filename,mode);
	if (stream_table[i].stream == NULL){
		error_set (CUSTOM_ERROR,"Could not open file %s with mode %s : "
			   "%s",filename,mode,strerror (errno));
		return NULL;
	}
	xstrcpy (&stream_table[i].filename,filename);
			
	return stream_table[i].stream;
}

void
io_fclose (FILE *stream)
{
	int i;
	char backup[PATH_MAX];

	for (i = 0;i < MAX_STREAM;i++){
		if (stream_table[i].stream == stream){
			break;
		}
	}

	if (i >= MAX_STREAM){
		return;
	}
	
	fclose (stream);
	xdebug ("%s : filename = %s\n",__FUNCTION__,stream_table[i].filename);

	xassert ((strlen (stream_table[i].filename) + strlen (BACKUP_SUFFIX))
		 < PATH_MAX);

	sprintf (backup,"%s%s",stream_table[i].filename,BACKUP_SUFFIX);
	fs_file_delete (backup);
	
	stream_table[i].stream = NULL;
	free (stream_table[i].filename);
	stream_table[i].filename = NULL;
}

FILE *
io_fopen_backup (const FILE *stream)
{
	const char *filename;
	char backup[PATH_MAX];

	filename = io_stream_to_name (stream);
	if (filename == NULL){
		error_set (CUSTOM_ERROR,"No stream %p was found in stream "
			   "table",stream);
		return NULL;
	}

	xassert ((strlen (filename) + strlen (BACKUP_SUFFIX)) < PATH_MAX);
	sprintf (backup,"%s%s",filename,BACKUP_SUFFIX);

	return io_fopen (backup,"r");
}

void
io_fclose_all (int restore)
{
	int i;
	char backup[PATH_MAX];

	xdebug ("%s (%d)\n",__FUNCTION__,restore);

	for (i = 0;i < MAX_STREAM;i++){
		if (stream_table[i].stream == NULL){
			continue;
		}
		xassert ((strlen (stream_table[i].filename)
			  + strlen (BACKUP_SUFFIX)) < PATH_MAX);
		sprintf (backup,"%s%s",stream_table[i].filename,BACKUP_SUFFIX);

		if (restore && fs_file_exists_p (backup)){
			fs_restore_backup (stream_table[i].filename);
		}

		io_fclose (stream_table[i].stream);
	}
}

void
io_print_stream (void (*formatf)(const char *fmt,...),FILE *stream,FILE *cpy)
{
	int c;
	
	while ( (c = fgetc (stream)) != EOF){
		formatf ("%c",c);
		if (cpy != NULL){
			fprintf (cpy,"%c",c);
		}
	}
}

void
xdebug (const char *message,...)
{
#if DEBUG_MSG
	va_list ap;

	if (verbosity != XDEBUG){
		return;
	}

	va_start (ap,message);

	xstderr ("%s","DEBUG: ");
	xstderr_valist (message,ap);

	va_end (ap);
#endif
}

void
xlog (const char *message,...)
{
	va_list ap;

	if ((verbosity != XDEBUG) && (verbosity != VERBOSE)){
		return;
	}

	va_start (ap,message);

	xstdout_valist (message,ap);

	va_end (ap);
}

void
xmsg (const char *message,...)
{
	va_list ap;

	if (verbosity == QUIET){
		return;
	}

	va_start (ap,message);
	
	xstdout_valist (message,ap);
	
	va_end (ap);
}

void
xwarn (const char *message,...)
{
	va_list ap;

	va_start (ap,message);

	xstderr ("%s","*** WARNING: ");
	xstderr_valist (message,ap);

	va_end (ap);
}

void
xerror (const char *message,...)
{
	va_list ap;
	extern char *program_invocation_name;

	va_start (ap,message);

	xstderr ("%s","*** ERROR ***\n");
	xstderr ("%s: ",program_invocation_name);
	xstderr_valist (message,ap);
	xstderr ("\n");

	va_end (ap);
}

void
xstdout (const char *message,...)
{
	va_list ap;

	va_start (ap,message);

	xstdout_valist (message,ap);

	va_end (ap);
}

void
xstderr (const char *message,...)
{
	va_list ap;

	va_start (ap,message);

	xstderr_valist (message,ap);

	va_end (ap);
}

void
xstdout_valist (const char *message,va_list ap)
{
	vfprintf (stdout,message,ap);
}

void
xstderr_valist (const char *message,va_list ap)
{
	fflush (stdout);
	vfprintf (stderr,message,ap);
}


