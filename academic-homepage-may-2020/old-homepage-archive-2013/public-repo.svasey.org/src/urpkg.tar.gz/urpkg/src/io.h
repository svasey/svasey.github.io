/* Contains declarations of functions having to do with printing information to
   the user, interpreting it, or handling streams. */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_IO_H
#define INCLUDE_IO_H

#include <stdarg.h>
#include <stdio.h>

#include "action.h"

/* Define the verbosity for the whole program */
enum verbosity verbosity;

/* Maximum number of streams in the stream table */
#define MAX_STREAM 32

struct stream
{
	FILE *stream;
	/* Name of the file that stream reads/writes */
	char *filename;
};

struct stream stream_table[MAX_STREAM];

/* Set the stream table to reasonnable start values */
void
io_stream_table_init (void);

/* Print the description of one option using a given function. Format and indent
   according to needs. Assume we are at the beginning of a line. Print a new
   line at the end. The shortopt argument can be omitted (null pointer) but
   should be two characters wide in order for the layout to be effective. Also,
   there should be only non-escaped characters in the description e.g no tabs or
   newlines. */
void
io_help (void (*formatf)(const char *fmt,...),
	 const char *shortopt,const char *longopt,const char *description);

/* Print a heading (used in a help text), and two new lines, using xmsg */
void
io_heading (void (*formatf)(const char *fmt,...),const char *heading);

/* Print n spaces using xmsg */
void
io_spaces (void (*formatf)(const char *fmt,...),int n);

/* Set mask to the bit mask specified in string and return 0. Return -1 in case
   str is not a mask (given in base 8) of maxlength bits or less. */
int
io_string_to_mask (const char *str,int *mask,int maxlength);

/* Look up stream in table and return a pointer to the filename associated with
   it, or null if nothing was found */
const char *
io_stream_to_name (const FILE *stream);

/* Return a stream to the given filename opened with mode. Make a backup if
   opened for writing, and add the stream to the stream table. Return NULL if
   some error happened */
FILE *
io_fopen (const char *filename,const char *mode);

/* Close the stream and remove the eventual backup file that was
   created. Remove the stream from the stream table. */
void
io_fclose (FILE *stream);

/* Open the backup of stream for reading */
FILE *
io_fopen_backup (const FILE *stream);

/* Close all streams in the stream table. If restore is true, restore the
   existing backups */
void
io_fclose_all (int restore);

/* Print the content of stream (assumed to be opened for reading), using
   formatf. If cpy is non-null also print to cpy using the usual fprintf
   functions. */
void
io_print_stream (void (*formatf)(const char *fmt,...),FILE *stream,FILE *cpy);

/* Print message to stderr only if DEBUG_MSG is true and the --xdebug flag is
   given. Do not print a new line.  */
void
xdebug (const char *message,...)
	__attribute__ ((format (printf,1,2)));

/* Print message to stdout if the --verbose is on. Do not print a new line. */
void
xlog (const char *message,...)
	__attribute__ ((format (printf,1,2)));

/* Print message to stdout unless --quiet is on. Do not print a new line. */
void
xmsg (const char *message,...)
	__attribute__ ((format (printf,1,2)));

/* Print a warning to stderr. Do not print a new line at the end */
void
xwarn (const char *message,...)
	__attribute__ ((format (printf,1,2)));

/* Print an error to stderr. Print a new line at the end of the message */
void
xerror (const char *message,...)
	__attribute__ ((format (printf,1,2)));

/* Print something to stdout. Will be displayed whatever the settings are */
void
xstdout (const char *message,...)
	__attribute__ ((format (printf,1,2)));

/* Print something to stderr, flushing stdout beforehand. Will be displayed
   whatever the settings are */
void
xstderr (const char *message,...)
	__attribute__ ((format (printf,1,2)));

/* Same as xstdout, but using a variadic list of argument. Do not call va_end */
void
xstdout_valist (const char *message,va_list ap);

/* Same as xstderr, but using a variadic list of argument. Do not call va_end */
void
xstderr_valist (const char *message,va_list ap);

#endif	/* INCLUDE_IO_H */
