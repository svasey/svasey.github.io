/* Contains some small helper functions dealing with strings */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_STR_H
#define INCLUDE_STR_H

#include <stdlib.h>

/* Strip all trailing new lines from str */
void
chomp (char *str);

/* Return the last character from str (before the null byte) */
char
lastchar (const char *str);

/* Replace the uppercase letters in src by uppercase in dest. Src and dest can
   be the same address with the expected result */
void
string_up_to_low (char *dest,const char *src);

/* Return 1 if s1 is exactly the same as s2, 0 otherwise */
int
string_equal_p (const char *s1,const char *s2);

/* Return 1 if str begins with sub, 0 otherwise */
int
string_beginwith_p (const char *str,const char *sub);

/* Like the standard functions, but do the memory allocation for you. Also,
   strncpy adds a null byte at the end of the string */
char *
xstrcpy (char **s1,const char *s2);

char *
xstrncpy (char **s1,const char *s2,size_t n);

#endif	/* INCLUDE_STR_H */
