/* Contains declarations of functions dealing with the users and groups */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_UGRP_H
#define INCLUDE_UGRP_H

#include <sys/types.h>
#include <grp.h>
#include <pwd.h>

/* The maximum user or group length, including the terminal null byte, a
   user/group which we _create_ can be. The value given is based on what is
   written in the useradd manpage and what I observed on a Slackware 12.1
   system. To understand the difference between this variable and
   UGRP_RE_MAX_LENGTH, you can imagine that UGRP_CR_MAX_LENGTH must only be used
   when checking for a user length before we create it. For all other uses, one
   must use UGRP_RE_MAX_LENGTH . For example, all username string sizes must be
   of UGRP_RE_MAX_LENGTH ! */
#define UGRP_CR_MAX_LENGTH 17

/* The maximum user or group length, including the terminal null byte, we can
   _read_ . This value is set arbitrarily. */
#define UGRP_RE_MAX_LENGTH 128

gid_t ugrp_old_primgid;
/* Contains all the supplementary group ids of the process before we
   dropped privilleges */
gid_t *ugrp_old_supgid;
int ugrp_old_supgid_size;
/* True if we are running with low privilleges */
int ugrp_dropped_privilleges;

/* Return true if c is a valid username character, false otherwise */
int
ugrp_userchar_p (char c);

/* Check whether the format of name is correct to be accepted as a user or group
   name to be created. Do not check the existence of it. Return 0 if the format
   is correct, -1 otherwise, setting urpkg_errno appropriately */
int
ugrp_check_format (const char *name);

/* Replace whichever irregular characters there is in the username with a _ */
void
ugrp_replace_weirdchar (char *user);

/* Return 1 if the given group is in the group database, 0 if it is not and -1
   if an error happened. Additionally, put the return value of  getgrnam in gd
   if it is non-NULL */
int
ugrp_group_exists_p (const char *gname,struct group **gd);

/* Same as ugrp_group_exists_p but for users */
int
ugrp_user_exists_p (const char *uname,struct passwd **ud);

/* Return the home directory of username */
const char *
ugrp_user_homedir (const char *username);

/* Save the current supplementary and primary group ids of the process and store
   them in ugrp_old_supgid, and ugrp_old_primgid */
int
ugrp_save_gid (void);

/* Restore the supplementary group ids from ugrp_old_supgid and the primary
   group ids from ugrp_old_primgid. The current ones will be lost */
int
ugrp_restore_gid (void);

/* Restore our old privilleges (i.e set the effective uid and gid to the real
   ones). */
int
ugrp_restore_privilleges (void);

/* Set our effective uid and gid as that of the user user  */
int
ugrp_drop_privilleges (const char *user);

/* Return true if we have super user privilleges, false otherwise. Never return
   -1 */
int
ugrp_have_privilleges_p (void);


#endif	/* INCLUDE_UGRP_H */
