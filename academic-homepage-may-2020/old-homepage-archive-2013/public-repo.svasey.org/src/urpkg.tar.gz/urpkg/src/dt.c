/* Contains implementation of the functions declared in dt.h */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
#include <stdarg.h>

#include "dt.h"
#include "mem.h"
#include "str.h"
#include "error.h"

void
alloc_string_init (struct alloc_string *astr,size_t size)
{
	if (size > 0){
		astr->str = xmalloc (size);
		astr->str[0] = '\0';
	}
	else {
		astr->str = NULL;
	}

	astr->size = size;
}

void
alloc_string_push (struct alloc_string *astr,const char *fmt,...)
{
	va_list ap;
	
	va_start (ap,fmt);
	alloc_string_push_valist (astr,fmt,ap);
	va_end (ap);
}

void
alloc_string_push_valist (struct alloc_string *astr,const char *fmt,va_list ap)
{
	/* The bytes we have allocated memory for that we not using right now */
	size_t size_left;
	size_t size_needed;
	int n;
	char *end;

	if (astr->size == 0){
		alloc_string_init (astr,2);
	}

	size_needed = astr->size;
	while (1){
		va_list ap_cpy;

		va_copy (ap_cpy,ap);

		astr->str = xrealloc (astr->str,size_needed * sizeof(char));

		for (end = astr->str;*end != '\0';end++);

		astr->size = size_needed;
		*end = '\0';

		size_left = astr->size - (strlen (astr->str) + 1);
	
		n = vsnprintf (end,size_left,fmt,ap);

		if (n >= size_left){
			*end = '\0';
			size_needed = strlen (astr->str) + n + 2;
		}
		else {
			break;
		}

		va_copy (ap,ap_cpy);
	}
}

void
alloc_string_free (struct alloc_string *astr)
{
	if (astr->size > 0){
		free (astr->str);
		astr->size = 0;
	}

	astr->str = NULL;
}

const char *
alloc_string_read (const struct alloc_string *astr)
{
	return astr->str;
}


void
dictionary_init (struct dictionary *dict)
{
	dict->alloc_step = 10;
	dict->size = 0;
	dict->allocated_size = 0;
	dict->keys = NULL;
	dict->values = NULL;
}

void
dictionary_free (struct dictionary *dict)
{
	int i;
	
	for (i = 0;i < dict->size;i++){
		free (dict->keys[i]);
		free (dict->values[i]);
	}

	free (dict->keys);
	free (dict->values);
	
	dictionary_init (dict);
}

void
dictionary_add (struct dictionary *dict,const char *key,const char *value)
{
	int i;

	/* If the key already exists, we just have to replace the existing
	   element */
	for (i = 0;i < dict->size;i++){
		if (strcmp (key,dict->keys[i]) == 0){
			free (dict->values[i]);
			xstrcpy (&dict->values[i],value);
			return;
		}
	}
	
	/* We have to allocate more memory */
	if (dict->size >= dict->allocated_size){
		dict->allocated_size += dict->alloc_step;
		dict->keys = xrealloc (dict->keys,sizeof(char *)
				       * dict->allocated_size);
		dict->values = xrealloc (dict->values,sizeof(char *)
					 * dict->allocated_size);
	}

	xstrcpy (&dict->keys[dict->size],key);
	xstrcpy (&dict->values[dict->size],value);
	dict->size++;
}

void
dictionary_to_list (const struct dictionary *dict,struct string_list *l)
{
	int i;

	for (i = 0;i < dict->size;i++){
		string_list_add (l,dict->keys[i]);
		string_list_add (l,dict->values[i]);
	}
}

int
dictionary_empty_p (const struct dictionary *dict)
{
	if (dict->size == 0){
		return 1;
	}
	else {
		return 0;
	}
}

void
dictionary_print (void (*formatf)(const char *fmt,...),
		  const struct dictionary *dict,const char *sep)
{
	int i;

	for (i = 0;i < dict->size;i++){
		formatf ("%s%s%s\n",dict->keys[i],sep,dict->values[i]);
	}
}

const char *
dictionary_get_val (const struct dictionary *dict,const char *key)
{
	int i;

	for (i = 0;i < dict->size;i++){
		if (strcmp (key,dict->keys[i]) == 0){
			return dict->values[i];
		}
	}

	return NULL;
}

const char *
dictionary_get_key (const struct dictionary *dict,const char *value)
{
	int i;

	for (i = 0;i < dict->size;i++){
		if (strcmp (value,dict->values[i]) == 0){
			return dict->keys[i];
		}
	}

	return NULL;
}

void
dictionary_get_n_keys (const struct dictionary *dict,const char *value,
		       struct string_list *dest,int n)
{
	int i;
	int j;

	xassert (n > 0);
	j = 0;
	for (i = 0;i < dict->size;i++){
		if (strcmp (value,dict->values[i]) == 0){
			string_list_add (dest,dict->keys[i]);
			j++;
			if (j >= n){
				return;
			}
		}
	}
}

void
string_list_init (struct string_list *l)
{
	l->size = 0;
	l->last = NULL;
	l->first = NULL;
}

void
string_list_free (struct string_list *l)
{
	struct string_list_el *it = string_list_it (l);

	while (it != NULL){
		struct string_list_el *next_it;
		
		free (it->string);
		next_it = it->next;
		free (it);
		it = next_it;
	}

	string_list_init (l);
}

void
string_list_add (struct string_list *l,const char *str)
{
	struct string_list_el **el;

	if (l->size == 0){
		el = &l->first;
	}
	else {
		el = &l->last->next;
	}

	*el = xmalloc (sizeof(struct string_list_el));
	xstrcpy (&((*el)->string),str);
	(*el)->next = NULL;

	l->size++;
	l->last = *el;
}

void
string_list_remove_fast (struct string_list *l,struct string_list_el *el,
			 struct string_list_el *prev)
{
	xassert ((prev == NULL) || (prev->next == el));

	/* No previous element */
	if (prev != NULL){
		prev->next = el->next;
	}
	else {
		l->first = el->next;
	}
	free (el->string);
	free (el);

	if (l->last == el){
		l->last = prev;
	}
	l->size--;
}

void
string_list_remove (struct string_list *l,struct string_list_el *el)
{
	struct string_list_el *it = string_list_it (l);
	struct string_list_el *prev = NULL;

	while (it != NULL){
		if (it == el){
			string_list_remove_fast (l,el,prev);
			return;
		}
		prev = it;
		it = it->next;
	}
}



struct string_list_el *
string_list_it (const struct string_list *l)
{
	return l->first;
}

const char *
string_list_first (const struct string_list *l)
{
	return l->first->string;
}

int
string_list_size (const struct string_list *l)
{
	return l->size;
}

int
string_list_find (const struct string_list *l,const char *key,
		  struct string_list_el **pos,
		  int (*equal_p)(const char *el1,const char *el2))
{
	return string_list_find_at (string_list_it (l),key,pos,equal_p);
}

int
string_list_find_at (struct string_list_el *start, const char *key,
		     struct string_list_el **pos,
		     int (*equal_p)(const char *el1,const char *el2))
{
	struct string_list_el *it;
	int r;

	for (it = start;it != NULL;it = it->next){
		r = equal_p (key,it->string);

		if (r < 0){
			return -1;
		}
		else if (r){
			*pos = it;
			return 0;
		}
	}

	*pos = NULL;
	return 0;
}

int
string_list_remove_dup (struct string_list *l,
			int (*equal_p)(const char *el1,const char *el2))
{
	/* This takes O(n^2) time, which is inevitable since I cannot sort the
	   list. */
	
	struct string_list_el *it_a = string_list_it (l);

	while (it_a != NULL){
		struct string_list_el *it_b = string_list_it (l);
		struct string_list_el *prev = NULL;
		
		while (it_b != NULL){
			int r;
			
			if (it_a == it_b){
				prev = it_b;
				it_b = it_b->next;
				continue;
			}

			r = equal_p (it_a->string,it_b->string);
			if (r < 0){
				return -1;
			}
			else if (r){
				struct string_list_el *next = it_b->next;
				/* This is much faster than the
				   string_list_remove function here */
				string_list_remove_fast (l,it_b,prev);
				it_b = next;
			}
			else {
				prev = it_b;
				it_b = it_b->next;
			}
		}
		
		it_a = it_a->next;
	}

	return 0;
}

int
string_list_empty_p (const struct string_list *l)
{
	if (l->size == 0){
		return 1;
	}
	else {
		return 0;
	}
}

void
string_list_print (void (*formatf)(const char *fmt,...),
		   const struct string_list *l)
{
	struct string_list_el *it;

	for (it = string_list_it (l);it != NULL;it = it->next){
		formatf ("%s\n",it->string);
	}
}

void
string_list_cat (const struct string_list *a,const struct string_list *b,
		 struct string_list *dest)
{
	struct string_list_el *it;

	for (it = string_list_it (a);it != NULL;it = it->next){
		string_list_add (dest,it->string);
	}
	for (it = string_list_it (b);it != NULL;it = it->next){
		string_list_add (dest,it->string);
	}
}

int
nullarray_size (const void *array,size_t el_size)
{
	int i;
	char *ptr = (char *)(array);

	for (i = 0;ptr != NULL;i++){
		ptr += el_size;
	}

	return i;
}

int
optarray_size (const struct option opt[])
{
	int i;
	
	for (i = 0;(opt[i].name != 0) || (opt[i].has_arg != 0)
		     || (opt[i].flag != 0) || (opt[i].val != 0);i++);

	return i;		
}
