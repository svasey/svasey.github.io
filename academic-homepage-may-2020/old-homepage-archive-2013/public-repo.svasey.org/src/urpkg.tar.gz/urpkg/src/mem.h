/* Contains declaration of some small memory helper functions */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_MEM_H
#define INCLUDE_MEM_H

/* Like the standard malloc and realloc, but check if the allocation succeeded
   and exit if it didn't */
void *
xmalloc (size_t size);

void *
xrealloc (void *ptr,size_t size);

#endif	/* INCLUDE_MEM_H */
