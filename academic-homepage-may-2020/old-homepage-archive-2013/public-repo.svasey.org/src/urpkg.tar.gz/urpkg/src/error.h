/* Functions to set and interprete the error code the program return */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_ERROR_H
#define INCLUDE_ERROR_H

#define MAX_ARGS 128

#include "defaults.h"
#include "io.h"

/* The format of each error can be seen in the error_set's code */ 
enum error_code {
	NO_ERROR = 0,
	FWRITE_ERROR,		/* Could not write to file (content) */
	FCREATE_ERROR,		/* Could not create file */
	FREAD_ERROR,		/* Could not read file (content) */
	FPERM_ERROR,		/* Could not write to file (metadata) */
	FSTAT_ERROR,		/* Could not read file (metadata) */
	FOPEN_ERROR,		/* Could not open file */
	DIR_ERROR,		/* Could not open/close, list directory */
	FREMOVE_ERROR,		/* Could not remove file */
	FNEXIST_ERROR,		/* File does not exist */
	UID_ERROR,
	GID_ERROR,		/* Could not find any group name for the given
				   gid */
	PIPE_C_ERROR,		/* Could not create pipe */
	PIPE_R_ERROR,		/* Could not read pipe */
	FORK_ERROR,		/* Could not fork */
	DUP_ERROR,		/* Could not redirect file descriptor */
	PRIV_ERROR,		/* Could not drop privilleges or get them
				   back */
	EXEC_ERROR,		/* Couldn't run an external program */
	PWAIT_ERROR,		/* Could not wait for process to terminate */
	SIG_ERROR,		/* Could not send signal to process */
	UGNAME_ERROR,		/* Bad format for user or group name */
	UGFIND_ERROR,		/* Error while looking up the user/group db */
	UGEXIST_ERROR,		/* User or group exists */
	UGNEXIST_ERROR,		/* User or group does not exist */
	RPATH_ERROR,		/* Error while resolving path */
	LONGPATH_ERROR,		/* Path length is greater than PATH_MAX */
	INVOKE_ERROR,		/* Bad command line arguments */
	HANDLERSET_ERROR,	/* Error while setting signal handlers */
	CMD_ERROR,		/* Some command exited with non-zero status */
	
	CUSTOM_ERROR
}; 

enum error_code urpkg_errno;

/* Sometimes errors imply specific things like files. This can be specified
   here.  */
char *error_args[MAX_ARGS];

/* True if it is the first time that xassert fails */
int error_assert_first;

/* Modified version of assert */
#define xassert(expr)							\
	do {								\
		if (! (expr)){						\
			xerror ("Assertion %s failed in file %s, "	\
				"function %s, line %d . Please "	\
				"report this as a bug",#expr,__FILE__,	\
				__FUNCTION__,__LINE__);			\
									\
			if (DEBUG){					\
				abort ();				\
			}						\
			else {						\
				if (error_assert_first){		\
					error_assert_first = 0;		\
					error_cleanup ();		\
				}					\
				exit (1);				\
			}						\
		}							\
	} while (0)							

/* Set urpkg_errno. Optionally, add a few arguments (not more than MAX_ARGS) to
   the error. This erases the previous error. */
void
error_set (enum error_code val,...);

/* Generate an error message describing the current error condition and return a
   pointer to the beginning. The generated pointer will point to the message
   only until the function is called another time */
const char *
error_describe (void);

/* Set everything back as it was at initialization time */
void
error_init (void);

/* Clean up whatever mess the program made (restore backups, kill process
   etc...). Called in case an error happens */
void
error_cleanup (void);

/* Exit, with status, describing the error on the way. If cleanup is true, call
   error_cleanup */
void
error_exit (int status,int cleanup);

#endif	/* INCLUDE_ERROR_H */
