/* Contains implementation of the functions declared in str.h */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#include <string.h>
#include <ctype.h>

#include "str.h"
#include "mem.h"

void
chomp (char *str)
{
	int i;

	for (i = (strlen (str) - 1);i >= 0;i--){
		if (str[i] == '\n'){
			str[i] = '\0';
		}
		else {
			break;
		}
	}
}

char
lastchar (const char *str)
{
	if (str[0] == '\0'){
		return '\0';
	}
	else {
		return str[strlen (str) - 1];
	}
}

void
string_up_to_low (char *dest,const char *src)
{
	int i;

	for (i = 0;src[i] != '\0';i++){
		if (isupper (src[i])){
			dest[i] = tolower (src[i]);
		}
		else {
			dest[i] = src[i];
		}
	}
	dest[i] = '\0';
}

int
string_equal_p (const char *s1,const char *s2)
{
	if (strcmp (s1,s2) == 0){
		return 1;
	}
	else {
		return 0;
	}
}

int
string_beginwith_p (const char *str,const char *sub)
{
	if (strstr (str,sub) == str){
		return 1;
	}
	else {
		return 0;
	}
}

char *
xstrcpy (char **s1,const char *s2)
{
	xstrncpy (s1,s2,strlen (s2));
	return *s1;
}

char *
xstrncpy (char **s1,const char *s2,size_t n)
{
	int len = strlen (s2);
	int size;

	size = ((len < n) ? len : n);

	*s1 = xmalloc (sizeof(char) * (size + 1));
	strncpy (*s1,s2,n);
	(*s1)[size] = '\0';

	return *s1;
}

