/* Contains implementation of the function declared in action.h  */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#include <string.h>

#include "action.h"
#include "defaults.h"
#include "pkg.h"
#include "error.h"
#include "io.h"
#include "mem.h"
#include "str.h"

void
action_init (struct user_action *action)
{
	action->action = UNKNOWN;
	action->verbosity = NORMAL;
	action->pretend = 0;
	action->list_all = 0;
	action->change_owner = 0;
	action->change_group = 0;
	strcpy (action->pkg_dir,DEFAULT_PKGDIR);
	strcpy (action->install_cmd,"");
	strcpy (action->find_cmd,DEFAULT_FINDCMD);
	strcpy (action->new_owner,"");
	strcpy (action->new_group,"");
	action->new_perm = -1;
	action->install_argv = NULL;
	dictionary_init (&action->postscript_args);
	string_list_init (&action->pkg_list);
	string_list_init (&action->file_list);
	action->exclude.preinst = 0;
	action->exclude.postinst = 0;
	string_list_init (&action->exclude.postinst_list);
}

void
action_print (void (*formatf)(const char *fmt,...),
	      const struct user_action *action)
{
	int i;

	formatf ("Action: %s\n",ACT_TOSTR (action->action));
	formatf ("Verbosity: %s\n",VER_TOSTR (action->verbosity));

	if ((action->action == INSTALL) || (action->action == UNINSTALL)){
		formatf ("Pretend: %s\n",FLAG_TOSTR (action->pretend));
	}
	if ((action->action == LIST_INST) && action->list_all){
		formatf ("All installed packages will be listed\n");
	}
	if (action->action == ADD_FILES){
		formatf ("Change owner: %s\n",
			 FLAG_TOSTR (action->change_owner));
		formatf ("Change group: %s\n",
			 FLAG_TOSTR (action->change_group));
	}
	if (action->action == INSTALL){
		formatf ("Package directory: %s\n",action->pkg_dir);
		formatf ("Install command: %s",action->install_cmd);
		for (i = 1;action->install_argv[i] != NULL;i++){
			formatf (" %s",action->install_argv[i]);
		}
		formatf ("\n");
	}
	if ((action->action == LIST_INST) || (action->action == LIST_DIR)
	    || (action->action == LIST_SHARED)){
		formatf ("Find command: %s\n",action->find_cmd);
	}
	if ((action->action == FREE_FILES) || (action->action == UNGEN)
	    || (action->action == UNSHARE)){
		if ((action->new_owner != NULL)
		    || (strlen (action->new_owner) > 0)){
			formatf ("New owner: %s\n",action->new_owner);
		}
		if ((action->new_group != NULL)
		    || (strlen (action->new_group) > 0)){
			formatf ("New group: %s\n",action->new_group);
		}
	}
	if ((action->action == UNGEN) || (action->action == UNSHARE)){
		if (action->new_perm >= 0){
			formatf ("New perm: %o\n",(unsigned int)
				 (action->new_perm));
		}
	}
	if ((action->action == INSTALL) || (action->action == UNINSTALL)
	    || ((action->action == LIST_INST) && (!action->list_all))
	    || (action->action == ADD_FILES) || (action->action == FREE_FILES)){
		char pkgname[PKG_MAX_LENGTH];
		struct string_list_el *it;
		int r;

		formatf ("Packages:\n");
		for (it = string_list_it (&action->pkg_list);it != NULL
			     ;it = it->next){
			r = pkg_user_to_name (it->string,pkgname);
			xassert (r == 0);
			formatf ("%s\n",pkgname);
		}
	}
	if ((action->action == LIST_DIR) || (action->action == LIST_SHARED)
	    || (action->action == ADD_FILES) || (action->action == FREE_FILES)
	    || (action->action == GEN) || (action->action == UNGEN)
	    || (action->action == SHARE) || (action->action == UNSHARE)
	    || (action->action == FIND)){
		formatf ("Files:\n");
		string_list_print (formatf,&action->file_list);
	}


	if (action->action == INSTALL){
		if (! dictionary_empty_p (&action->postscript_args)){
			formatf ("Postinstall script: arguments\n");
			dictionary_print (formatf,
					  &action->postscript_args," : ");
		}

		if (action->exclude.preinst){
			formatf ("I will not run any preinstall scripts\n");
		}
		if (action->exclude.postinst){
			formatf ("I will not run any postinstall scripts\n");
		}
		if (! string_list_empty_p (&action->exclude.postinst_list)){
			formatf ("The following postinstall scripts will not "
				 "be run:\n");
			string_list_print (formatf,
					   &action->exclude.postinst_list);
		}
	}
}

int
action_complete (struct user_action *action)
{
	/* The only thing we will do here is transform the package name into
	   username, if they are not already usernames */

	char pkguser[UGRP_RE_MAX_LENGTH];
	struct string_list_el *it;
	int r;
	/* True if the package names given on the command line must exist */
	int in_db = 1;

	xdebug ("%s\n",__FUNCTION__);

	if (action->action == INSTALL){
		if (string_list_empty_p (&action->pkg_list)){
			if (pkg_name_to_user (NULL,pkguser,0) < 0){
				return -1;
			}
			string_list_add (&action->pkg_list,pkguser);
		}
		in_db = 0;
	}
	
	for (it = string_list_it (&action->pkg_list);it != NULL;it = it->next){
		string_up_to_low (it->string,it->string);
		r = pkguser_p (it->string, 0);
		if (r < 0){
			return -1;
		}
		else if (r){
			continue;
		}

		if (pkg_name_to_user (it->string,pkguser,in_db) < 0){
			return -1;
		}

		it->string = xmalloc ((strlen (pkguser) + 1) * sizeof(char));
		strcpy (it->string,pkguser);
	}

	return 0;
}
