/* Contains functions handling transformation from/to the user's input format
   of the package name */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_PKG_H
#define INCLUDE_PKG_H

/* Maximum length of a package name */
#define PKG_MAX_LENGTH 128

/* Match each username (key) to its equivalent package name (value) */
struct dictionary pkg_user_name_table;
int pkg_built_table;	/* True if we have already called
				   pkg_name_user_table_build */

/* Build the table looking up the comments in /etc/passwd */
int
pkg_user_name_table_build (void);

/* Add another entry to the table */
void
pkg_user_name_add_match (const char *username,const char *pkgname);

/* Guess a package name from the current directory. Name must be able to hold
   at least PKG_MAX_LENGTH characters, including the terminal null byte  */
int
pkg_guess (char *name);

/* Increment the username user so that it is slightly different from
   the previous one */
int
pkg_next_username (char *user);

/* From a package name, build a username which does not exist and is
   properly formatted. */
int
pkg_build_user (const char *name,char *user);

/* Replace pkgname by the full package user name. Return -1 if that is
   not possible or some other error happened. . If in_db is true, use
   only the existing package name <-> user database, if not, just try
   to guess the package name. If name is NULL and in_db false, try to
   guess using the current directory. In that case, if the guessed
   package name already exists, return an error. */
int
pkg_name_to_user (const char *name,char *user,int in_db);

/* Convert username to the original package name. Return -1 in case some
   error happened on the way */
int
pkg_user_to_name (const char *username,char *pkgname);

/* Return true if username is a package user. If assume_exits is true, assume
   that the user exists, otherwise, do a lookup*/
int
pkguser_p (const char *username, int assume_exists);

/* Return true if name is a package group. */
int
pkgrp_p (const char *name);

#endif	/* INCLUDE_PKG_H */
