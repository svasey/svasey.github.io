/* Contains implementation of the functions declared in clopt.h */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#include <string.h>
#include <ctype.h>
#include <errno.h>

#include "clopt.h"
#include "mem.h"
#include "io.h"
#include "defaults.h"
#include "version.h"
#include "error.h"
#include "str.h"

char *
gen_shortopt_string(struct option longopt[],char **shortopt)
{
	int i;
	int size = optarray_size (longopt);

	
	*shortopt = xmalloc(size * 3 * sizeof(char) + 1);
	*shortopt[0] = '+';

	for (i = 0;longopt[i].name;i++){
		char argtype[] = "::";
		char optchar[4] = "a";

		if (isascii(longopt[i].val)){
			optchar[0] = longopt[i].val;
		}
		else {
			continue;
		}
		
		if (longopt[i].has_arg == no_argument){
			argtype[0] = '\0';
		}
		else if (longopt[i].has_arg == required_argument){
			argtype[1] = '\0';
		}
		strcat(optchar,argtype);
		*shortopt = strcat(*shortopt,optchar);
	}

	return *shortopt;
}

void
bug_text (void)
{
	xstdout ("Report bugs and send patches to <%s>\n",PACKAGE_BUGREPORT);
}

void
usage_text (void)
{
	extern char *program_invocation_name;
	
	xstdout ("Usage: %s [OPTION ...] [ARG ...]\n",program_invocation_name);
}

void
help_text (void)
{
	usage_text ();
	xstdout("\n");
	io_heading(&xstdout,
		   "Actions (you must specify exactly one action before "
		   "any options)");
	io_help(&xstdout,"-h","--help","print this help and exit");
	io_help(&xstdout,"-v","--version","output version information and "
		"exit");
	io_help (&xstdout,"-I","--info","output some information on the "
		 "settings urpkg was compiled with and exit");
	io_help(&xstdout,"-i","--install","install the package by running the "
		"command given in ARG");
	io_help(&xstdout,"-u","--uninstall","uninstall the package(s) given in "
		"ARG");
	io_help(&xstdout,"-l","--list","without ARG, list all packages "
		"installed on the system; otherwise, list all files part of "
		"the package(s) given in ARG");
	io_help (&xstdout,"-W","--list-instdir","Print all install directories "
		 "in ARGS, (which default to /)");
	io_help (&xstdout,"-L","--list-shared","Print all the shared files "
		 "in ARGS, defaulting to /");
	io_help(&xstdout,"-a","--add-files","add the files in ARG to the given "
		"package, without changing their owner or group unless "
		"--change-owner and/or --change-group is given");
	io_help (&xstdout,"-T","--free-files","Remove the files in ARG from "
		 "the given package i.e the program will not remove those "
		 "files if we remove the package. Restore the file's owner "
		 "and groups if possible");
	io_help(&xstdout,"-g","--gen","add the directories in ARG to "
		"the list of install directories (i.e where package "
		"files can be installed)");
	io_help (&xstdout,"-w","--ungen","remove the directories in ARG from "
		 "the list of install directories");
	io_help (&xstdout,"-s","--share","add the files in ARG to the list "
		 "of shared files");
	io_help (&xstdout,"-S","--unshare","remove the files in ARG from the "
		 "list of shared files");
	io_help (&xstdout,"-f","--find","Find the package(s) the files in ARG "
		 "are part of");
	xstdout("\n");
	io_heading(&xstdout,"Global Options (valid with any action)");
	io_help(&xstdout,"-D","--debug","print debugging information. Implies "
		"--verbose");
	io_help(&xstdout,"-V","--verbose","print more details on what the "
		"program is doing to stdout");
	io_help(&xstdout,"-q","--quiet","print only warnings, errors and what "
		"is being specifically asked");
	xstdout("\n");
	io_heading(&xstdout,"Install Options");
	io_help(&xstdout,"-p","--pretend","print what would have been done but "
		"don't do anything for real");
	io_help(&xstdout,"-P","--no-preinst","don't run the preinstall "
		"script");
	io_help(&xstdout,"-G","--no-postinst",
		"don't run the postinstall scripts");
	io_help(&xstdout,"-e","--exclude-script=NAME","don't run the NAME "
		"user postinstall script, where NAME is the beginning of the "
		"script's name such that it can be recognized unambigously");
	io_help(&xstdout,NULL,"--NAME-arg=A","pass the argument A to the "
		"postinstall script NAME");
	io_help(&xstdout,"-H","--pkg-dir=PATH","use PATH/NAME as the package's "
		"home directory, where NAME is the name of the package "
		"(guessed or given explicitely using --pkg-name)");
	io_help(&xstdout,"-n","--pkg-name=NAME","explicitely specify the "
		"package's name. Otherwise, the program will try to guess it "
		"from the current directory");
	io_help (&xstdout,"-F","--findcmd=SCRIPT","give a custom script to be "
		 "used to find files part of a given package.");
	xstdout("\n");
	xstdout("\n");
	io_heading(&xstdout,"Uninstall Options");
	io_help (&xstdout,"-p","--pretend","see install options");
	io_help (&xstdout,"-F","--findcmd=SCRIPT","see install options");
	io_heading (&xstdout,"List Options");
	io_help (&xstdout,"-F","--findcmd=SCRIPT","see uninstall options");
	xstdout ("\n");
	io_heading (&xstdout,"List-instdir Options");
	io_help (&xstdout,"-F","--findcmd=SCRIPT","see uninstall options");
	xstdout ("\n");
	io_heading (&xstdout,"List-shared Options");
	io_help (&xstdout,"-F","--findcmd=SCRIPT","see uninstall options");
	xstdout ("\n");
	io_heading (&xstdout,"Add Options");
	io_help (&xstdout,"-U","--change-owner","Change the file's owner "
		 "(set it to the package user). By default, the file's owner"
		 " will not be changed.");
	io_help (&xstdout,"-d","--change-group","Change the file's group "
		 "(set it to the package user). By default, the file's group"
		 " will not be changed.");
	xstdout ("\n");
	io_heading (&xstdout,"Free Options");
	io_help (&xstdout,"-U","--change-owner=USER","restore the file's owner "
		 "to USER. By default, the program will set it to root");
	io_help (&xstdout,"-d","--change-group=GROUP","restore the file's "
		 "group to GROUP. By default, the program will set it to root");
	xstdout ("\n");
	io_heading (&xstdout,"Ungen / Unshare options");
	io_help (&xstdout,"-d","--change-group=GROUP","see free options");
	io_help (&xstdout,"-m","--change-perm=PERM","Change the files access "
		 "permission to PERM (given in octal form). If not given, the "
		 "program will try to set the permission to a reasonnable "
		 "default.");
	xstdout ("\n");
	bug_text ();
}

void
version_text (void)
{
	xstdout ("%s %s\n",PACKAGE_NAME,PACKAGE_VERSION);
	xstdout ("Author: Sebastien Vasey (http://svasey.org/)\n");
	xstdout ("This is free software, released in the public domain."
		 "See the source for copying conditions\n");

	bug_text ();
}

void
info_text (void)
{
	xstdout ("Debug message enabled: %s\n",FLAG_TOSTR (DEBUG_MSG));
	xstdout ("Abort if false assertion: %s\n",FLAG_TOSTR (DEBUG));
	xstdout ("Default package directory: %s\n",DEFAULT_PKGDIR);
	xstdout ("Default configuration directory: %s\n",DEFAULT_CONFIGDIR);
	xstdout ("Default find command: %s\n",DEFAULT_FINDCMD);
	xstdout ("Default presinstall script: %s\n",DEFAULT_PREINST);
	xstdout ("Default postinstall directory: %s\n",DEFAULT_POSTINST_DIR);
	xstdout ("Path of useradd: %s\n",USERADD_PATH);
	xstdout ("Path of usermod: %s\n",USERMOD_PATH);
	xstdout ("Path of groupadd: %s\n",GROUPADD_PATH);
	xstdout ("Path of groupdel: %s\n",GROUPDEL_PATH);
	xstdout ("Path of userdel: %s\n",USERDEL_PATH);
}

int
is_specialopt_p (const char *optstr)
{
	/* First occurence of '=' */
	char *first_equal = strchr(optstr,'=');
	/* First occurence of the constant string '-arg=' */
	char *constant = strstr(optstr,"-arg=");

	/* In regular expression term, we have --[^=]+-arg=.+ */
	if ((optstr[0] != '-') || (optstr[1] != '-')
	    || (first_equal == NULL) || (constant == NULL)
	    || (first_equal - constant != 4) /* There must be no equal sign
						 before the string constant */
	    || (*(first_equal + 1) == '\0')){ /* There must be at least one
						 character after the = */
		return 0;
	}
	else {
		return 1;
	}
}

void
process_specialopt(const char *optstr,struct user_action *user_action)
{
	/* The key is the left hand part, value the right hand one */
	int len_key;
	char *key;
	int len_value;
	char *value;
	char *constant_pos = strstr(optstr,"-arg=");

	xassert (is_specialopt_p (optstr));
	/* Get key */
	len_key = (constant_pos - (optstr + 2));
	key = xstrncpy(&key,optstr + 2,len_key);

	/* Get value */
	len_value = strlen(optstr) - strlen("--") - strlen(key)
		- strlen("-arg=");
	value = xstrcpy(&value,constant_pos + strlen("-arg="));

	/* Update user_action */
	dictionary_add (&user_action->postscript_args,key,value);
}

int
parse_options (int argc,char *argv[],struct user_action *user_action)
{
	/* This is only here to provide a unique character to each option. The
	   order does not matter, and there could be values that aren't used
	   anymore. The C_ prefix is necessary to avoid conflicts with other
	   enum in global.h */
	enum all_options 
	{
		C_INSTALL = 'i',C_UNINSTALL = 'u',C_LIST = 'l',
		C_LIST_DIR = 'W',C_LIST_SHARED = 'L',C_ADD_FILES = 'a',
		C_FREE_FILES = 'T',C_GEN = 'g',
		C_UNGEN = 'w',C_SHARE = 's',C_UNSHARE = 'S',C_FIND = 'f',
		C_VERBOSE = 'V',C_QUIET = 'q',C_PRETEND = 'p',
		C_NO_POSTINST ='G',C_NO_PREINST = 'P',
		C_HELP = 'h',C_VERSION = 'v',C_INFO = 'I',C_PKG_DIR = 'H',
		C_PKG_NAME = 'n',C_EXCLUDE_SCRIPT = 'e',C_FINDCMD = 'F',
		C_CHANGE_OWNER = 'U',C_CHANGE_GROUP = 'd',C_CHANGE_PERM = 'm',
		C_DEBUG='D'
	};

	struct option long_options[] =
		{
			{"help",no_argument,NULL,C_HELP},
			{"version",no_argument,NULL,C_VERSION},
			{"info",no_argument,NULL,C_INFO},
			{"install",no_argument,NULL,C_INSTALL},
			{"uninstall",no_argument,NULL,C_UNINSTALL},
			{"list",no_argument,NULL,C_LIST},
			{"list-instdir",no_argument,NULL,C_LIST_DIR},
			{"list-shared",no_argument,NULL,C_LIST_SHARED},
			{"add-files",no_argument,NULL,C_ADD_FILES},
			{"free-files",no_argument,NULL,C_FREE_FILES},
			{"gen",no_argument,NULL,C_GEN},
			{"ungen",no_argument,NULL,C_UNGEN},
			{"share",no_argument,NULL,C_SHARE},
			{"unshare",no_argument,NULL,C_UNSHARE},
			{"find",no_argument,NULL,C_FIND},
			{"debug",no_argument,NULL,C_DEBUG},
			{"verbose",no_argument,NULL,C_VERBOSE},
			{"quiet",no_argument,NULL,C_QUIET},
			{"pretend",no_argument,NULL,C_PRETEND},
			{"no-preinst",no_argument,NULL,C_NO_PREINST},
			{"no-postinst",no_argument,NULL,
			 C_NO_POSTINST},
			{"pkg-dir",required_argument,NULL,C_PKG_DIR},
			{"pkg-name",required_argument,NULL,C_PKG_NAME},
			{"exclude-script",required_argument,NULL,
			 C_EXCLUDE_SCRIPT},
			{"findcmd",required_argument,NULL,
			 C_FINDCMD},
			{"change-owner",optional_argument,NULL,
			 C_CHANGE_OWNER},
			{"change-group",optional_argument,NULL,
			 C_CHANGE_GROUP},
			{"change-perm",required_argument,NULL,
			 C_CHANGE_PERM},
			{0,0,0,0} /* Used to know the size of the array */
		};

	char* short_options;
	/* True if an action was already given to the program */
	int gave_action = 0;

	gen_shortopt_string(long_options,&short_options);

	/* Do not output any error message when the option isn't recognized. */
	opterr = 0;

	action_init (user_action);

	/* Begins option processing */
	while (1){
		/* True if the given option is an action */
		int is_action = 0;
		int optid = 0;
		int c = getopt_long(argc,argv,short_options,long_options
				    ,&optid);
		
		if (c == -1){
			break;
		}

		/* Check if an action was given */
		if ((c == C_HELP) || (c == C_VERSION) || (c == C_INFO)
		    || (c == C_INSTALL) || (c == C_UNINSTALL)
		    || (c == C_LIST) || (c == C_LIST_DIR)
		    || (c == C_LIST_SHARED) || (c == C_ADD_FILES)
		    || (c == C_FREE_FILES)  || (c == C_GEN)
		    || (c == C_UNGEN) || (c == C_SHARE)
		    || (c == C_UNSHARE) || (c == C_FIND)){
			is_action = 1;
		}

		/* Check whether two or more actions are given, or
		   whether options are given before actions */
		if (is_action){
			if (gave_action){
				error_set (INVOKE_ERROR,"You cannot specify "
					   "more than one action");
				return -1;
			}
			else {
				gave_action = 1;
			}
		}
		else {
			if (!gave_action){
				error_set (INVOKE_ERROR,"You must specify "
					   "an action first");
				return -1;
			}
		}
		
		switch (c){
		case C_HELP:
			user_action->action = HELP;
			break;
		case C_VERSION:
			user_action->action = XVERSION;
			break;
		case C_INFO:
			user_action->action = INFO;
			break;
		case C_INSTALL:
			user_action->action = INSTALL;
			break;
		case C_UNINSTALL:
			user_action->action = UNINSTALL;
			break;
		case C_LIST:
			user_action->action = LIST_INST;
			break;
		case C_LIST_DIR:
			user_action->action = LIST_DIR;
			break;
		case C_LIST_SHARED:
			user_action->action = LIST_SHARED;
			break;
		case C_ADD_FILES:
			user_action->action = ADD_FILES;
			break;
		case C_FREE_FILES:
			user_action->action = FREE_FILES;
			break;
		case C_GEN:
			user_action->action = GEN;
			break;
		case C_UNGEN:
			user_action->action = UNGEN;
			break;
		case C_SHARE:
			user_action->action = SHARE;
			break;
		case C_UNSHARE:
			user_action->action = UNSHARE;
			break;
		case C_FIND:
			user_action->action = FIND;
			break;
		case C_DEBUG:
			user_action->verbosity = XDEBUG;
			break;
		case C_VERBOSE:
			user_action->verbosity = VERBOSE;
			break;
		case C_QUIET:
			user_action->verbosity = QUIET;
			break;
		case C_PRETEND:
			if ((user_action->action != UNINSTALL)
			    && (user_action->action != INSTALL)){
				error_set (INVOKE_ERROR,
					   "The pretend flag is only "
					   "meaningful with the uninstall or "
					   "install actions");
				return -1;
			}
			user_action->pretend = 1;
			break;
		case C_NO_POSTINST:
			if (user_action->action != INSTALL){
				error_set (INVOKE_ERROR,"The no-postint "
					   "flag is only meaningful with the "
					   "install action");
				return -1;
			}
			user_action->exclude.postinst = 1;
			break;
		case C_NO_PREINST:
			if (user_action->action != INSTALL){
				error_set (INVOKE_ERROR,"The no-preinst-script "
					   "flag is only meaningful with the "
					   "install action");
				return -1;
			}
			user_action->exclude.preinst = 1;
			break;
		case C_PKG_DIR:
			if (user_action->action != INSTALL){
				error_set (INVOKE_ERROR,"The pkg-dir option is "
					   "only meaningful with the install "
					   "action");
				return -1;
			}
			/* Path checking will be done later */
			if (strlen (optarg) >= PATH_MAX){
				error_set (LONGPATH_ERROR,"pkg-dir argument: %s"
					   "too long",optarg);
				return -1;
			}
			strcpy(user_action->pkg_dir,optarg);
			break;
		case C_PKG_NAME:
			if (user_action->action != INSTALL){
				error_set (INVOKE_ERROR,"The pkg-name option "
					   "is only meaningful with the "
					   "install action");
				return -1;
			}
			/* Error checking will be done later */
			string_list_add (&user_action->pkg_list,optarg);
			break;
		case C_EXCLUDE_SCRIPT:
			if (user_action->action != INSTALL){
				error_set (INVOKE_ERROR,"The exclude-script "
					   "option is only meaningful with "
					   "the install action");
				return -1;
			}
			string_list_add (&user_action->exclude.postinst_list,
					 optarg);
			break;
		case C_FINDCMD:
			if ((user_action->action != LIST_INST)
			    && (user_action->action != LIST_DIR)
			    && (user_action->action != LIST_SHARED)
			    && (user_action->action != UNINSTALL)
			    && (user_action->action != INSTALL)){
				error_set (INVOKE_ERROR,"The findcmd option "
					   "is only meaningful with the "
					   "install, list, "
					   "list-instdir, list-shared or "
					   "uninstall actions");
				return -1;
			}
			if (strlen (optarg) >= PATH_MAX){
				error_set (LONGPATH_ERROR,"findcmd argument: %s"
					   " too long",optarg);
				return -1;
			}
			strcpy (user_action->find_cmd,optarg);
			break;
		case C_CHANGE_OWNER:
		case C_CHANGE_GROUP:
			if ((c == C_CHANGE_OWNER)
			    && (user_action->action != ADD_FILES)
			    && (user_action->action != FREE_FILES)){
				error_set (INVOKE_ERROR,"the change-owner "
					   "option is only meaningful with the "
					   "add-files or free files actions");
				return -1;
			}
			else if ((c == C_CHANGE_GROUP)
				 && (user_action->action != ADD_FILES)
				 && (user_action->action != FREE_FILES)
				 && (user_action->action != UNGEN)
				 && (user_action->action != UNSHARE)){
				error_set (INVOKE_ERROR,"The change-group "
					   "option is only meaningful with the "
					   "add-files, ungen, unshare or "
					   "free-files actions");
				return -1;
			}
			if ((user_action->action == ADD_FILES)
			    && (optarg != NULL)){
				error_set (INVOKE_ERROR,"The change-owner "
					   "or change-group options do not "
					   "take any argument when used with "
					   "the add-files action");
				return -1;
			}
			else if ((user_action->action != ADD_FILES)
				 && (optarg == NULL)){
				error_set (INVOKE_ERROR,"The change-owner "
					   "or change-group options "
					   "take an argument when "
					   "used with the free-files, ungen "
					   "or unshare actions");
				return -1;
			}
			if (user_action->action == ADD_FILES){
				if (c == C_CHANGE_OWNER){
					user_action->change_owner = 1;
				}
				else if (c == C_CHANGE_GROUP) {
					user_action->change_group = 1;
				}
			}
			else {
				if (strlen (optarg) >= UGRP_RE_MAX_LENGTH){
					error_set (UGNAME_ERROR,optarg
						   ,"Name too long");
					return -1;
				}
				if (c == C_CHANGE_OWNER){
					strcpy (user_action->new_owner,optarg);
				}
				else if (c == C_CHANGE_GROUP){
					strcpy (user_action->new_group,optarg);
				}
			}
			break;
		case C_CHANGE_PERM:
			if ((user_action->action != UNGEN)
			    && (user_action->action != UNSHARE)){
				error_set (INVOKE_ERROR,"The change-perm "
					   "option is meaningful only with "
					   "the ungen or unshare actions");
				return -1;
			}
			if (io_string_to_mask (optarg,&user_action->new_perm
					       ,12) < 0){
				error_set (INVOKE_ERROR,"Invalid permission "
					   "%s : %s",optarg,error_describe ());
			}
			break;
		case '?':
			/* Check for special -arg options */

			/* This _must_ be a long option, finishing by -arg,
			   with an argument ( /--.+-arg=.+/ )*/
			if (!is_specialopt_p(argv[optind - 1])){
				error_set (INVOKE_ERROR,
					   "Unrecognized option: %s",
					   argv[optind - 1]);
				return -1;
			}
			else if (user_action->action != INSTALL){
				error_set(INVOKE_ERROR,"You can only specify "
					  "special option %s with the install "
					  "action",
					  argv[optind - 1]);
				return -1;
			}
			else {
				process_specialopt(argv[optind - 1],
						   user_action);
			}

			break;
		} /* End switch */
	} /* End option processing */
	if (user_action->action == UNKNOWN){
		error_set (INVOKE_ERROR,"You must specify an action.");
		return -1;
	}

	return parse_args (argc,argv,optind,user_action);
}

int
parse_args(int argc,char *argv[],int start,struct user_action *action)
{
	const int ACTION = action->action;
	int i;


	if ((ACTION == HELP) || (ACTION == XVERSION) || (ACTION == INFO)){
		return 0;
	}
	else if ((ACTION == LIST_INST) && (argc == start)){
		action->list_all = 1;
	}
	else if (((ACTION == LIST_DIR) || (ACTION == LIST_SHARED))
		 && (argc == start)){
		/* Add the default */
		string_list_add (&action->file_list,"/");
	}
	else if (argc == start){
		if (ACTION == UNKNOWN){
			error_set (INVOKE_ERROR,"You did not specify any "
				   "action");
		}
		else {
			error_set (INVOKE_ERROR,"The action you specified "
				   "needs at least one argument");
		}
		return -1;
	}
	else if (ACTION == INSTALL){
		if (strlen (argv[start]) >= PATH_MAX){
			error_set (LONGPATH_ERROR,"Install command: %s is too "
				   "long",argv[start]);
			return -1;
		}
		strcpy (action->install_cmd,argv[start]);
		/* We need to include the command in our argv, and leave room
		   for a null element at the end */
		action->install_argv = xmalloc (sizeof(char *)
						* (argc - start + 1));
		xstrcpy (&action->install_argv[0],action->install_cmd);
		for (i = start + 1;i < argc;i++){
			xstrcpy (&action->install_argv[i - start],argv[i]);
		}
		action->install_argv[i - start] = NULL;
		start = argc;
	}
	else if ((ACTION == ADD_FILES) || (ACTION == FREE_FILES)){
		/* Add the package name so that we don't have to bother with it
		   anymore */
		if ((argc - start) == 1){
			error_set (INVOKE_ERROR,"The add-files and free-files "
				   "actions take two or more arguments");
			return -1;
		}
		string_list_add (&action->pkg_list,argv[start]);
		start++;
	}
		
	
	for (i = start;i < argc;i++){
		switch (ACTION){
			/* Package name */
		case UNINSTALL:
		case LIST_INST:
			string_list_add (&action->pkg_list,argv[i]);
			break;
		case LIST_DIR:
		case LIST_SHARED:
		case ADD_FILES:
		case FREE_FILES:
		case GEN:
		case UNGEN:
		case SHARE:
		case UNSHARE:
		case FIND:
			string_list_add (&action->file_list,argv[i]);
			break;
		default:
			/* Should not happen */
			xassert (0);
			break;
		}
	}

	return 0;
}
