/* Contains implementation of the functions in mem.h */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#include <stdlib.h>

#include "mem.h"
#include "io.h"
#include "error.h"

void *
xmalloc (size_t size)
{
	static int had_error = 0;
	void *ret = malloc (size);

	if (ret == NULL){
		xerror ("Not enough memory to continue");

		if (!had_error){
			had_error = 1;
			error_cleanup ();
		}
		exit (1);
	}

	return ret;
}

void *
xrealloc (void *ptr,size_t size)
{
	static int had_error = 0;
	void *ret = realloc (ptr,size);

	if (ret == NULL){
		xerror ("Not enough memory to continue");

		if (!had_error){
			had_error = 1;
			error_cleanup ();
		}
		exit (1);
	}

	return ret;
	
}
