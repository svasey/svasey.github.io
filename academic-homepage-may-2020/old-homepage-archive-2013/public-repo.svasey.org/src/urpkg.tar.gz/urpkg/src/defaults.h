/* Contains macros containing default paths and name. Some of them can be
   changed with the configure script */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_DEFAULT_H
#define INCLUDE_DEFAULT_H

#include "config.h"

/* Print debug message when --xdebug is specified on the command line */
#define DEBUG_MSG 1

#define BACKUP_SUFFIX ".bckp"

/* What is added before the username when installing a package */
#define USER_PREFIX "urpkg-"

/* What is added before a package group */
#define GROUP_PREFIX "urpkgrp-"

/* What is added before the name of environment variables defined by the
   program */
#define VAR_PREFIX "URPKG_"

/* The path where the package keeps its meta files like added; relative to the
   home directory */
#define PRIVDIR ".urpkg/"

/* Text file where the path of all added files are stored, relative to the
   package's home directory */
#define ADDED_FILE PRIVDIR "/added"

/* The install group */
#define INSTALL_GROUP GROUP_PREFIX "install"

/* The shared group */
#define SHARED_GROUP GROUP_PREFIX "shared"

#endif	/* INCLUDE_DEFAULT_H */
