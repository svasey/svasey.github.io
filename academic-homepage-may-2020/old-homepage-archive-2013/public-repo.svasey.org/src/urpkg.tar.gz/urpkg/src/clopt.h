/* Contains all the functions related to command line options parsing */

/*
  Author: Sebastien Vasey (http://svasey.org/)
*/

#ifndef INCLUDE_CLOPT_H
#define INCLUDE_CLOPT_H

#include <getopt.h>

#include "action.h"


/* Given a long option string, generate and allocate a short option string for
   getopt. Return it. */
char *
gen_shortopt_string (struct option longopt[],char **shortopt);

/* Print the program's help text (--help) , using xstdout */
void
help_text (void);

/* Print a short message giving information about where to report bugs,
   followed by a new line, using xstdout */
void
bug_text (void);

/* Print a short text giving the program's usage, followed by a new line using
   xstdout */
void
usage_text (void);

/* Print version information, using xstdout */
void
version_text (void);

/* Print some information about the settings urpkg was compiled with */
void
info_text (void);

/* Return true if the given (long) option string is a special option (i.e an
   option specifying arguments to some user postinst script) */
int
is_specialopt_p (const char *optstr);

/* Process the special option optstr (i.e extract the name and arguments of the
   script) and put the results into the action object. */
void
process_specialopt (const char *optstr,struct user_action *action);

/* Parse the command line options and arguments; Put what the user asked to do
   in user_action. Otherwise, exit with an error message. Also handle the
   standard --help and --version options. This does not check for the
   meaningfulness of individual arguments. Return -1 on failure, 0 on success */
int
parse_options(int argc,char *argv[],struct user_action *user_action);

/* Parse the command line arguments (what comes after the options :-). start
   describes the starting point of our investigation. Again, does not check for
   the meaningfulness of individual arguments. The results are put in
   action. Assume that action->action is not UNKNOWN. Return -1 on failure, 0 on
   sucess */
int
parse_args(int argc,char *argv[],int start,struct user_action *action);

#endif	/* INCLUDE_CLOPT_H */
